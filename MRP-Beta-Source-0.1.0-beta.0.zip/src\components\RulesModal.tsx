import React, { useState } from 'react';
import { X, BookOpen, Shield, DollarSign, Sparkles, Award, Wrench, AlertTriangle, CheckCircle2, ChevronRight, Users, Flame, Star, Trophy } from 'lucide-react';
import { playClickSound } from '../utils/audio';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
  soundEnabled: boolean;
}

export const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose, soundEnabled }) => {
  const [activeTab, setActiveTab] = useState<'basics' | 'economy' | 'ranks' | 'tuning' | 'etiquette'>('basics');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-xl animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-[#0c0d15] border-2 border-emerald-500/40 rounded-3xl shadow-[0_0_60px_rgba(16,185,129,0.25)] flex flex-col max-h-[90vh] overflow-hidden text-slate-100">
        
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-[#091812] via-[#0b1319] to-[#0c0d15] border-b border-emerald-500/30 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-2xl shadow-[0_0_20px_rgba(16,185,129,0.4)] text-slate-950 font-bold shrink-0">
              📜
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black bg-gradient-to-r from-emerald-300 via-teal-200 to-cyan-300 bg-clip-text text-transparent">
                  MRP • წესები & სრული გზამკვლევი
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[10px] font-mono font-bold uppercase">
                  Roleplay Guide
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                გაეცანი MRP (Money Roleplay) სიმულატორის წესებს, ეკონომიკას, VIP რანკებსა და ქცევის ეთიკას
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              playClickSound(soundEnabled);
              onClose();
            }}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Categories */}
        <div className="flex items-center gap-1.5 p-2 bg-slate-950/80 border-b border-slate-800/80 overflow-x-auto scrollbar-thin">
          {[
            { id: 'basics', label: '🏙️ თამაშის არსი & მიზანი' },
            { id: 'economy', label: '💼 ფულის შოვნა & ბიზნესი' },
            { id: 'ranks', label: '👑 Rank Shop & VIP სტატუსები' },
            { id: 'tuning', label: '🚗 ავტო ტიუნინგი & სახელოსნო' },
            { id: 'etiquette', label: '🛡️ RP ეთიკა & წესები' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                playClickSound(soundEnabled);
                setActiveTab(tab.id as typeof activeTab);
              }}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-emerald-500 text-slate-950 shadow-md font-black'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-7 overflow-y-auto space-y-6 flex-1 text-slate-300 text-xs sm:text-sm leading-relaxed">
          
          {/* 1. BASICS */}
          {activeTab === 'basics' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="p-4 rounded-2xl bg-emerald-950/20 border border-emerald-500/30">
                <h3 className="font-extrabold text-base text-emerald-300 flex items-center gap-2 mb-2">
                  <span>🏙️ რა არის MRP (Money Roleplay)?</span>
                </h3>
                <p>
                  <strong>MRP</strong> არის ბრაუზერული RP სიმულატორი, სადაც იწყებ კურიერობით 20 ₾ საწყისი ბიუჯეტით და შენი მიზანია განვითარდე სამუშაოებით, ვაჭრობითა და გონივრული ხარჯვით.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-2">
                  <div className="font-bold text-slate-100 flex items-center gap-2">
                    <Award className="w-4 h-4 text-amber-400" />
                    <span>დონეები (Level) & გამოცდილება (XP)</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    ყოველი შესრულებული სამუშაო, ავიატორის რეისი და მოგება გაძლევს XP-ს. ყოველ ახალ დონეზე გადასვლისას გერიცხება ფულადი ბონუსი და გეხსნება ახალი პროფესიები.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-2">
                  <div className="font-bold text-slate-100 flex items-center gap-2">
                    <Shield className="w-4 h-4 text-emerald-400" />
                    <span>RP რეპუტაცია (Respect)</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    რეპუტაცია ასახავს შენს გავლენას ქალაქში. მას ზრდის ლუქს ავტომობილების ყიდვა, აგარაკების ფლობა, პირადი დაცვის დაქირავება და ელიტური აქსესუარების ტარება.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* 2. ECONOMY */}
          {activeTab === 'economy' && (
            <div className="space-y-4 animate-fadeIn">
              <h3 className="font-extrabold text-base text-slate-100 flex items-center gap-2">
                <span>💼 ფულის გამომუშავების ყველა მექანიზმი</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-1.5">
                  <div className="font-bold text-emerald-400">1. სამუშაოები & მინი-დავალებები</div>
                  <p className="text-xs text-slate-400">
                    იმუშავე კურიერად, ბარბერად, ავტომექანიკოსად, DJ-დ, კრიპტო სკალპერად ან ტექ-მაგნატად. თითოეულ სამუშაოს აქვს უნიკალური ინტერაქციული დავალება (კოდი, სლაიდერი, სწრაფი დაწკაპუნება ან ქვიზი). სწორი შესრულება იძლევა 1.35x ხელფასის ბონუსს!
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-1.5">
                  <div className="font-bold text-cyan-400">2. ბიზნესი & პასიური შემოსავალი</div>
                  <p className="text-xs text-slate-400">
                    შეიძინე აგარაკები და ბიზნესები, რომ ნელ-ნელა მიიღო პასიური შემოსავალი.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-1.5">
                  <div className="font-bold text-amber-400">3. ავიატორი (Aviator)</div>
                  <p className="text-xs text-slate-400">
                    დადე ფსონი რეისზე, დააკვირდი თვითმფრინავის აფრენას და გაიტანე მოგება სანამ გასკდება! გამოიყენე <strong>ავტო-განაღდება</strong> რისკის მინიმიზაციისთვის.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-1.5">
                  <div className="font-bold text-fuchsia-400">4. კაზინო & სპორტული ფსონები</div>
                  <p className="text-xs text-slate-400">
                    ითამაშე სლოტი, იღბლის ბორბალი, 21 კლუბი და სხვა თამაშები. თითოეულ თამაშს თავისი წესები აქვს; ფსონი შეიძლება წააგო.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* 3. RANKS */}
          {activeTab === 'ranks' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-950/40 via-fuchsia-950/20 to-slate-900 border-2 border-purple-500/40">
                <h3 className="font-extrabold text-base text-fuchsia-300 flex items-center gap-2 mb-1">
                  <span>👑 Rank Shop — VIP სტატუსები</span>
                </h3>
                <p className="text-xs text-slate-300">
                  VIP სტატუსი მუდმივია და გაძლევს კოლოსალურ ბუსტს მთელ თამაშში. მისი შეძენა შესაძლებელია კრისტალებით (💎).
                </p>
              </div>

              <div className="space-y-3">
                <div className="p-3.5 rounded-2xl bg-red-950/20 border border-red-500/40 flex items-start gap-3">
                  <span className="text-2xl shrink-0">🔴</span>
                  <div>
                    <div className="font-black text-red-400 text-sm">Red VIP (50 კრისტალი)</div>
                    <p className="text-xs text-slate-300 mt-0.5">
                      <strong>x2 XP და x1.2 ფულადი ჯილდო</strong> თამაშის შემოსავლებზე. წითელი VIP ნიშანი პროფილსა და ჩატში.
                    </p>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-purple-950/20 border border-purple-500/40 flex items-start gap-3">
                  <span className="text-2xl shrink-0">🟣</span>
                  <div>
                    <div className="font-black text-purple-400 text-sm">Purple VIP (150 კრისტალი)</div>
                    <p className="text-xs text-slate-300 mt-0.5">
                      <strong>x3 XP და x1.5 ფულადი ჯილდო</strong> თამაშის შემოსავლებზე. იასამნისფერი VIP ნიშანი.
                    </p>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-gradient-to-r from-[#1c0836] via-[#100424] to-[#080212] border-2 border-fuchsia-500/80 shadow-[0_0_20px_rgba(217,70,239,0.3)] flex items-start gap-3">
                  <span className="text-2xl shrink-0">🌌</span>
                  <div>
                    <div className="font-black text-fuchsia-300 text-sm flex items-center gap-2">
                      <span>Midnight Purple VIP (60,000 კრისტალი)</span>
                      <span className="px-1.5 py-0.2 rounded bg-fuchsia-500/30 text-[9px] font-mono text-fuchsia-200">ელიტარული</span>
                    </div>
                    <p className="text-xs text-slate-300 mt-0.5">
                      <strong>x5 XP და x2 ფულადი ჯილდო</strong> თამაშის შემოსავლებზე. ანიმირებული Midnight ნიშანი და გამორჩეული პროფილის სტატუსი.
                    </p>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-950/40 via-red-950/30 to-fuchsia-950/40 border-2 border-rose-500/60 flex items-start gap-3 shadow-[0_0_22px_rgba(244,35,89,.2)]">
                  <span className="text-2xl shrink-0">😈</span>
                  <div>
                    <div className="font-black text-rose-300 text-sm">RedDevil (666,666 კრისტალი)</div>
                    <p className="text-xs text-slate-200 mt-0.5"><strong>x30 XP და x25 ფულადი შედეგი</strong> თამაშის შემოსავლებზე. Trading-ში x25-ზე ითვლება მოგებაც და ზარალიც; პოზიციის საწყისი თანხა უცვლელი რჩება.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 5. TUNING */}
          {activeTab === 'tuning' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="p-4 rounded-2xl bg-purple-950/20 border border-purple-500/40">
                <h3 className="font-extrabold text-base text-purple-300 flex items-center gap-2 mb-1">
                  <span>🚗 ავტო ტიუნინგი & "შენი საკუთარი ტიუნინგი"</span>
                </h3>
                <p className="text-xs text-slate-300">
                  ლუქს მაღაზიის ახალ განყოფილებაში შეგიძლია დაატუნინგო შენი ნაყიდი მანქანები ან შეიძინო პირადი სახელოსნო!
                </p>
              </div>

              <div className="space-y-3">
                <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800">
                  <div className="font-bold text-slate-100 mb-1">რისი შეცვლა შეგიძლია ტიუნინგში?</div>
                  <p className="text-xs text-slate-400">
                    🎨 <strong>ფერების შეცვლა:</strong> Midnight Purple, Nardo Grey, Obsidian Black და სხვა.<br />
                    ⚡ <strong>Stage 1, 2, 3 ECU:</strong> ძრავის სიმძლავრის, ცხენის ძალისა და მაქსიმალური სიჩქარის ზრდა.<br />
                    🌪️ <strong>ტურბინები & სუპერჩარჯერი:</strong> Garrett Hybrid, Twin-Scroll, Whipple (+220 ცხ.ძ).<br />
                    💨 <strong>ჰაერის სპორტული ფილტრები:</strong> K&N, Eventuri Dual Carbon.<br />
                    🔥 <strong>გამოსაბოლქვი:</strong> Akrapovič Titanium Full Exhaust (ცეცხლის გასროლით).<br />
                    🛑 <strong>სავალი ნაწილი & მუხრუჭები:</strong> KW V3 Coilovers, Brembo Carbon-Ceramic.
                  </p>
                </div>

                <div className="p-3.5 rounded-2xl bg-amber-950/20 border border-amber-500/40">
                  <div className="font-bold text-amber-300 mb-1">🏢 "შენი საკუთარი ტიუნინგი" (2,350,500 ₾)</div>
                  <p className="text-xs text-slate-300">
                    შეიძინე პირადი სახელოსნო 2,350,500 ₾-ად! ამის შემდეგ მიიღებ წვდომას საბითუმო საწყობზე, სადაც ნაწილები 50%-ით იაფია და რაც მთავარია — <strong>შენს მანქანებზე ნაწილების დაყენება ხდება სრულიად უფასოდ (0 ₾ მონტაჟი)!</strong>
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* 6. ETIQUETTE & RULES */}
          {activeTab === 'etiquette' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="p-4 rounded-2xl bg-rose-950/20 border border-rose-500/40">
                <h3 className="font-extrabold text-base text-rose-300 flex items-center gap-2 mb-1">
                  <span>🛡️ RP ქცევის წესები & ეთიკა</span>
                </h3>
                <p className="text-xs text-slate-300">
                  იმისათვის, რომ ქალაქში სიმულაცია იყოს სასიამოვნო და სამართლიანი, დაიცავი შემდეგი წესები:
                </p>
              </div>

              <div className="space-y-2.5">
                <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex items-start gap-2.5 text-xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong>ბანკროლ მენეჯმენტი:</strong> არასოდეს დადო მთელი ბალანსი ერთ რეისზე ავია-სთარში ან კაზინოში. გაანაწილე კაპიტალი ბიზნესებში, რომ წაგების შემთხვევაშიც პასიური შემოსავალი გქონდეს.
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex items-start gap-2.5 text-xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong>სიმშვიდე წაგებისას:</strong> ავიატორი და კაზინო შეიცავს რისკს. როცა რეისი 1.02-ზე სკდება, გაითვალისწინე, რომ შემდეგი რაუნდები უფრო მაღალი შეიძლება იყოს. ნუ აჰყვები ემოციებს.
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex items-start gap-2.5 text-xs">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <strong>გაფრთხილება "ღორშოფზე":</strong> ჩატში ზოგჯერ გამოჩნდება საეჭვო პერსონაჟი "ღორშოფი", რომელიც არარეალურ ფასდაკლებებსა და ტალიზმანებს არეკლამებს. ნუ ენდობით თაღლითებს, იცინეთ და ითამაშეთ ოფიციალური წესებით!
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex items-start gap-2.5 text-xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong>პატივისცემა ჩატში:</strong> მოექეცი თანამოთამაშეებს პატივისცემით. დაეხმარე ახალბედებს რჩევებით და გაუზიარე შენი მოგების სტრატეგია.
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950/90 border-t border-slate-800/80 flex items-center justify-between text-xs">
          <span className="text-slate-400">
            MRP (Money Roleplay) • ელიტარული სიმულატორი
          </span>
          <button
            onClick={() => {
              playClickSound(soundEnabled);
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold transition-all cursor-pointer"
          >
            გასაგებია, თამაშში დაბრუნება
          </button>
        </div>
      </div>
    </div>
  );
};
