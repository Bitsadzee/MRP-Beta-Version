﻿import React, { useState } from 'react';
import { Wrench, Sparkles, Check, Zap, Gauge, DollarSign, Package, ShieldCheck, ChevronRight, AlertCircle, Palette, Flame, Wind } from 'lucide-react';
import { Car, TuningPart, CarTuningData } from '../types/game';
import { TUNING_PARTS } from '../utils/constants';
import { formatLari } from '../utils/formatters';
import { playCashSound, playClickSound, playLevelUpSound } from '../utils/audio';

interface CarTuningStudioProps {
  balance: number;
  soundEnabled: boolean;
  ownedCars: string[];
  cars: Car[];
  carTunings?: { [carId: string]: CarTuningData };
  hasCustomWorkshop?: boolean;
  workshopInventory?: { [partId: string]: number };
  onTuneCar: (carId: string, part: TuningPart, isFreeFromWorkshop: boolean) => void;
  onBuyWorkshopPart: (part: TuningPart) => void;
  onBuyCustomWorkshop: () => void;
}

export const CarTuningStudio: React.FC<CarTuningStudioProps> = ({
  balance,
  soundEnabled,
  ownedCars,
  cars,
  carTunings = {},
  hasCustomWorkshop = false,
  workshopInventory = {},
  onTuneCar,
  onBuyWorkshopPart,
  onBuyCustomWorkshop
}) => {
  const ownedCarsList = cars.filter((c) => ownedCars.includes(c.id));
  const [selectedCarId, setSelectedCarId] = useState<string>(() => (ownedCarsList[0]?.id || ''));
  const [tuningTab, setTuningTab] = useState<'tune_car' | 'workshop_inventory'>('tune_car');
  const [partCategoryFilter, setPartCategoryFilter] = useState<'all' | 'color' | 'stage' | 'turbo' | 'intake' | 'exhaust' | 'suspension'>('all');

  const activeCar = cars.find((c) => c.id === selectedCarId) || ownedCarsList[0];
  const activeCarTuning = activeCar ? carTunings[activeCar.id] : undefined;
  const getInstalledPartId = (category: TuningPart['category']) => {
    if (!activeCarTuning) return undefined;
    if (activeCarTuning.installedPartIds?.[category]) return activeCarTuning.installedPartIds[category];
    if (category === 'stage' && activeCarTuning.stageLevel) return `tune_stage_${activeCarTuning.stageLevel}`;
    const slotName = category === 'color' ? activeCarTuning.colorName
      : category === 'turbo' ? activeCarTuning.turboType
      : category === 'intake' ? activeCarTuning.intakeType
      : category === 'exhaust' ? activeCarTuning.exhaustType
      : category === 'suspension' ? activeCarTuning.suspensionType : undefined;
    return TUNING_PARTS.find((item) => item.category === category && item.name === slotName)?.id;
  };

  const WORKSHOP_PRICE = 2350500;
  const canAffordWorkshop = balance >= WORKSHOP_PRICE;

  const categories = [
    { id: 'all', label: 'ყველა ნაწილი' },
    { id: 'color', label: '🎨 ფერები' },
    { id: 'stage', label: '⚡ სთეიჯი (ECU)' },
    { id: 'turbo', label: '🌪️ ტურბოები' },
    { id: 'intake', label: '💨 ფილტრები' },
    { id: 'exhaust', label: '🔥 გამოსაბოლქვი' },
    { id: 'suspension', label: '🛑 სავალი & მუხრუჭები' }
  ];

  const filteredParts = TUNING_PARTS.filter(
    (p) => partCategoryFilter === 'all' || p.category === partCategoryFilter
  );

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Workshop Ownership Top Banner */}
      <div className="rounded-3xl p-5 sm:p-6 bg-gradient-to-r from-[#170a24] via-[#0f0a1c] to-[#0a0714] border-2 border-purple-500/40 shadow-xl flex flex-col md:flex-row items-center justify-between gap-5">
        <div className="flex items-center gap-4 text-center md:text-left">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-500 flex items-center justify-center text-3xl shadow-[0_0_25px_rgba(168,85,247,0.4)] shrink-0">
            🏢
          </div>
          <div>
            <div className="flex items-center gap-2 justify-center md:justify-start">
              <h3 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-300 via-fuchsia-300 to-amber-300">
                შენი საკუთარი ტიუნინგი • WORKSHOP & GARAGE
              </h3>
            </div>
            <p className="text-xs text-slate-400 mt-1 max-w-xl">
              {hasCustomWorkshop
                ? 'შენი პირადი ტიუნინგ-სახელოსნო და საწყობი აქტიურია! იყიდე ნაწილები საბითუმო ფასებში და დააყენე შენს მანქანებზე სრულიად უფასოდ (0 ₾ მონტაჟი).'
                : 'შეიძინე "შენი საკუთარი ტიუნინგი" 2,350,500 ₾-ად, მიიღე წვდომა საბითუმო საწყობზე და დააყენე ნაწილები შენს მანქანებზე უფასოდ!'}
            </p>
          </div>
        </div>

        <div>
          {hasCustomWorkshop ? (
            <div className="px-5 py-3 rounded-2xl bg-emerald-500/10 border-2 border-emerald-500/50 text-emerald-400 font-black text-xs font-mono flex items-center gap-2 shadow-lg">
              <Check className="w-5 h-5" />
              <span>სახელოსნო შენს საკუთრებაშია</span>
            </div>
          ) : (
            <button
              onClick={() => {
                if (!canAffordWorkshop) return;
                playLevelUpSound(soundEnabled);
                onBuyCustomWorkshop();
              }}
              disabled={!canAffordWorkshop}
              className={`px-5 py-3 rounded-2xl font-black text-xs sm:text-sm tracking-wider flex items-center gap-2 transition-all shadow-lg ${
                canAffordWorkshop
                  ? 'bg-gradient-to-r from-purple-600 via-fuchsia-600 to-amber-500 hover:brightness-110 text-white shadow-purple-500/40 cursor-pointer animate-pulse'
                  : 'bg-slate-900 border border-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              <Wrench className="w-4 h-4" />
              <span>
                {canAffordWorkshop
                  ? `სახელოსნოს შეძენა (${formatLari(WORKSHOP_PRICE)})`
                  : `არასაკმარისი თანხა (${formatLari(WORKSHOP_PRICE)})`}
              </span>
            </button>
          )}
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 p-1.5 bg-[#0a0c14] border border-slate-800 rounded-2xl">
        <button
          onClick={() => {
            playClickSound(soundEnabled);
            setTuningTab('tune_car');
          }}
          className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            tuningTab === 'tune_car'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md font-black'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
          }`}
        >
          <Wrench className="w-4 h-4" />
          <span>მანქანის დატუნინგება & აფგრეიდი</span>
        </button>

        <button
          onClick={() => {
            playClickSound(soundEnabled);
            setTuningTab('workshop_inventory');
          }}
          className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            tuningTab === 'workshop_inventory'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md font-black'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>
            {hasCustomWorkshop
              ? 'საბითუმო საწყობი & ნაწილების მარკეტი'
              : 'საბითუმო ნაწილების კატალოგი'}
          </span>
        </button>
      </div>

      {/* TAB 1: TUNE CAR */}
      {tuningTab === 'tune_car' && (
        <div className="space-y-6">
          {/* Car Picker & Stats Card */}
          {ownedCarsList.length === 0 ? (
            <div className="p-8 rounded-3xl bg-slate-900/60 border border-slate-800 text-center space-y-3">
              <span className="text-4xl">🏎️</span>
              <h4 className="text-base font-bold text-slate-200">ჯერ არ გყავს ნაყიდი ავტომობილი</h4>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                გადადი ავტომობილების განყოფილებაში, შეიძინე სასურველი მოდელი და შემდეგ დაბრუნდი მის დასატუნინგებლად!
              </p>
            </div>
          ) : (
            <div className="rounded-3xl bg-slate-900/90 border border-purple-500/30 p-5 sm:p-6 shadow-xl space-y-5">
              {/* Car Selector Dropdown / Pills */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">
                  აირჩიე ავტომობილი დასატუნინგებლად:
                </span>
                <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
                  {ownedCarsList.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => {
                        playClickSound(soundEnabled);
                        setSelectedCarId(c.id);
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                        activeCar?.id === c.id
                          ? 'bg-purple-600 text-white shadow-md font-black border border-purple-400'
                          : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                      }`}
                    >
                      <span>{c.image}</span>
                      <span>{c.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Selected Car Specs Dashboard */}
              {activeCar && (
                <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center p-4 sm:p-5 rounded-2xl bg-black/60 border border-slate-800">
                  <div className="md:col-span-5 flex items-center gap-4">
                    <div
                      className="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl border-2 shadow-inner shrink-0"
                      style={{
                        backgroundColor: activeCarTuning?.colorHex || activeCar.color || '#1e293b',
                        borderColor: '#a855f7'
                      }}
                    >
                      {activeCar.image}
                    </div>
                    <div>
                      <h4 className="text-base sm:text-lg font-black text-slate-100">{activeCar.name}</h4>
                      <span className="text-xs font-mono text-purple-400 font-bold block">
                        ბრენდი: {activeCar.brand.toUpperCase()}
                      </span>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[11px] font-mono text-slate-400">ფერი:</span>
                        <span className="text-[11px] font-mono text-amber-300 font-bold">
                          {activeCarTuning?.colorName || 'საქარხნო'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Tuning Boost Metrics */}
                  <div className="md:col-span-7 grid grid-cols-3 gap-3 text-center font-mono">
                    <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                      <span className="text-[10px] text-slate-400 uppercase font-bold block">სიმძლავრე</span>
                      <div className="text-base sm:text-lg font-black text-amber-400">
                        +{activeCarTuning?.extraHp || 0} HP
                      </div>
                      <span className="text-[9px] text-slate-500">ცხენის ძალა</span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                      <span className="text-[10px] text-slate-400 uppercase font-bold block">სიჩქარე</span>
                      <div className="text-base sm:text-lg font-black text-emerald-400">
                        +{activeCarTuning?.extraSpeedKm || 0} კმ/სთ
                      </div>
                      <span className="text-[9px] text-slate-500">მაქს. სიჩქარე</span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                      <span className="text-[10px] text-slate-400 uppercase font-bold block">რეპუტაცია</span>
                      <div className="text-base sm:text-lg font-black text-purple-400">
                        +{activeCarTuning?.extraRespect || 0} RP
                      </div>
                      <span className="text-[9px] text-slate-500">პატივისცემა</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Parts Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => {
                  playClickSound(soundEnabled);
                  setPartCategoryFilter(cat.id as typeof partCategoryFilter);
                }}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  partCategoryFilter === cat.id
                    ? 'bg-purple-600 text-white shadow-md font-black'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Tuning Parts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredParts.map((part) => {
              const inStock = workshopInventory[part.id] || 0;
              const canAffordRetail = balance >= part.retailPrice;

              return (
                <div
                  key={part.id}
                  className="rounded-2xl bg-gradient-to-b from-[#13111f] to-[#0c0d15] border border-slate-800 hover:border-purple-500/50 p-4 transition-all flex flex-col justify-between space-y-4 shadow-md"
                >
                  <div>
                    {/* Top Part Header */}
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        {part.colorHex ? (
                          <div
                            className="w-7 h-7 rounded-lg border border-white/30 shadow-inner shrink-0"
                            style={{ backgroundColor: part.colorHex }}
                          />
                        ) : (
                          <span className="text-xl">
                            {part.category === 'stage'
                              ? '⚡'
                              : part.category === 'turbo'
                              ? '🌪️'
                              : part.category === 'intake'
                              ? '💨'
                              : part.category === 'exhaust'
                              ? '🔥'
                              : '🛑'}
                          </span>
                        )}
                        <div>
                          <h5 className="font-bold text-sm text-slate-100 leading-snug">{part.name}</h5>
                          <span className="text-[10px] text-purple-400 font-mono font-bold uppercase">
                            {part.category}
                          </span>
                        </div>
                      </div>
                    </div>

                    <p className="text-xs text-slate-400 leading-relaxed min-h-[36px]">
                      {part.description}
                    </p>

                    {/* Stats Gains */}
                    <div className="mt-3 p-2 rounded-xl bg-slate-950/70 border border-slate-800/80 flex items-center justify-between text-xs font-mono">
                      {part.hpBonus > 0 && (
                        <span className="text-amber-400 font-bold">+{part.hpBonus} HP</span>
                      )}
                      {part.speedBonusKm > 0 && (
                        <span className="text-emerald-400 font-bold">+{part.speedBonusKm} კმ/სთ</span>
                      )}
                      {part.respectBonus > 0 && (
                        <span className="text-purple-400 font-bold">+{part.respectBonus} RP</span>
                      )}
                      {part.category === 'color' && (
                        <span className="text-cyan-300 font-bold">Custom Finish</span>
                      )}
                    </div>
                  </div>

                  {/* Action Installation Button */}
                  <div>
                    {hasCustomWorkshop && inStock > 0 ? (
                      <button
                        type="button"
                        disabled={!activeCar || getInstalledPartId(part.category) === part.id}
                        onClick={() => {
                          if (!activeCar || getInstalledPartId(part.category) === part.id) return;
                          playCashSound(soundEnabled);
                          onTuneCar(activeCar.id, part, true);
                        }}
                        className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:brightness-110 text-slate-950 font-black text-xs font-mono tracking-wider flex items-center justify-center gap-1.5 shadow-md cursor-pointer animate-pulse"
                      >
                        <Check className="w-4 h-4" />
                        <span>{getInstalledPartId(part.category) === part.id ? "უკვე დაყენებულია" : `უფასოდ დაყენება (მარაგშია: ${inStock})`}</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        disabled={!activeCar || getInstalledPartId(part.category) === part.id || !canAffordRetail}
                        onClick={() => {
                          if (!activeCar || getInstalledPartId(part.category) === part.id || !canAffordRetail) return;
                          playCashSound(soundEnabled);
                          onTuneCar(activeCar.id, part, false);
                        }}
                        className={`w-full py-2.5 rounded-xl font-bold text-xs font-mono transition-all flex items-center justify-center gap-1.5 ${
                          canAffordRetail
                            ? 'bg-purple-600 hover:bg-purple-500 text-white shadow-md active:scale-95 cursor-pointer'
                            : 'bg-slate-900 border border-slate-800 text-slate-600 cursor-not-allowed'
                        }`}
                      >
                        <DollarSign className="w-3.5 h-3.5" />
                        <span>
                          {getInstalledPartId(part.category) === part.id
                            ? 'უკვე დაყენებულია'
                            : canAffordRetail
                            ? `ჩანაცვლება (${formatLari(part.retailPrice)})`
                            : `არასაკმარისია (${formatLari(part.retailPrice)})`}
                        </span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: WHOLESALE PARTS STORE & WAREHOUSE INVENTORY */}
      {tuningTab === 'workshop_inventory' && (
        <div className="space-y-6">
          <div className="p-4 rounded-2xl bg-[#0e0f1a] border border-purple-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <div>
              <span className="font-bold text-slate-200">
                {hasCustomWorkshop
                  ? '🏢 შენი პირადი საბითუმო საწყობი'
                  : '🔒 საბითუმო ფასები (საჭიროებს სახელოსნოს)'}
              </span>
              <p className="text-slate-400 mt-0.5">
                საბითუმო ფასებში ნაწილების შეძენის შემდეგ, ისინი შეინახება შენს საწყობში და ნებისმიერ მანქანაზე დაყენდება 0 ₾-ად!
              </p>
            </div>
            <div className="text-emerald-400 font-mono font-bold shrink-0">
              ფასდაკლება: ~50% საბითუმო ტარიფი
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {TUNING_PARTS.map((part) => {
              const inStock = workshopInventory[part.id] || 0;
              const canAffordWholesale = balance >= part.wholesalePrice;

              return (
                <div
                  key={`wh_${part.id}`}
                  className="rounded-2xl bg-slate-950 border border-slate-800 p-4 flex flex-col justify-between space-y-4"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {part.colorHex ? (
                          <div
                            className="w-6 h-6 rounded-md border border-white/30 shrink-0"
                            style={{ backgroundColor: part.colorHex }}
                          />
                        ) : (
                          <span>📦</span>
                        )}
                        <h5 className="font-bold text-xs text-slate-200">{part.name}</h5>
                      </div>
                      <span className="px-2 py-0.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] font-mono text-cyan-300 font-bold">
                        მარაგში: {inStock} ცალი
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-xs font-mono mt-3 p-2 bg-slate-900/60 rounded-xl">
                      <div>
                        <span className="text-[10px] text-slate-500 block">საცალო ფასი</span>
                        <span className="line-through text-slate-400">{formatLari(part.retailPrice)}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-emerald-400 font-bold block">საბითუმო ფასი</span>
                        <span className="font-black text-emerald-300">{formatLari(part.wholesalePrice)}</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    {hasCustomWorkshop ? (
                      <button
                        type="button"
                        disabled={!canAffordWholesale}
                        onClick={() => {
                          if (!canAffordWholesale) return;
                          playCashSound(soundEnabled);
                          onBuyWorkshopPart(part);
                        }}
                        className={`w-full py-2.5 rounded-xl font-bold text-xs font-mono transition-all flex items-center justify-center gap-1.5 ${
                          canAffordWholesale
                            ? 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:brightness-110 text-slate-950 shadow-md cursor-pointer'
                            : 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed'
                        }`}
                      >
                        <Package className="w-3.5 h-3.5" />
                        <span>ყიდვა საწყობისთვის ({formatLari(part.wholesalePrice)})</span>
                      </button>
                    ) : (
                      <div className="w-full py-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-500 font-mono text-[11px] text-center flex items-center justify-center gap-1">
                        <AlertCircle className="w-3 h-3 text-amber-500" />
                        <span>საჭიროა "შენი საკუთარი ტიუნინგი"</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};







