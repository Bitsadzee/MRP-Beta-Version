﻿import React, { useState, useEffect } from 'react';
import { X, CheckCircle2, AlertCircle, ArrowRight, Zap, Target, Gauge, Hash } from 'lucide-react';
import { Job, JobTask } from '../types/game';
import { playClickSound, playWinSound, playCashSound } from '../utils/audio';
import { formatLari } from '../utils/formatters';

interface JobTaskModalProps {
  job: Job;
  soundEnabled: boolean;
  onComplete: (bonusMultiplier: number) => void;
  onCancel: () => void;
}

export const JobTaskModal: React.FC<JobTaskModalProps> = ({
  job,
  soundEnabled,
  onComplete,
  onCancel
}) => {
  // Select a random task from the job's tasks, or fall back to a default
  const [currentTask] = useState<JobTask>(() => {
    if (job.tasks && job.tasks.length > 0) {
      const idx = Math.floor(Math.random() * job.tasks.length);
      return job.tasks[idx];
    }
    return {
      id: 'default_task',
      name: 'სწრაფი ენერგია',
      type: 'quick_tap',
      prompt: 'დააჭირე 5-ჯერ სამუშაოს წარმატებით შესასრულებლად!',
      targetCount: 5
    };
  });

  // State for quiz
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  // State for tap
  const [tapCount, setTapCount] = useState<number>(0);
  // State for slider
  const [sliderVal, setSliderVal] = useState<number>(50);
  // State for code
  const [codeInput, setCodeInput] = useState<string>('');

  const [isSuccess, setIsSuccess] = useState<boolean | null>(null);
  const [feedback, setFeedback] = useState<string>('');

  const targetTaps = currentTask.targetCount || 6;
  const targetSlider = currentTask.sliderTarget || 65;

  const handleTap = () => {
    playClickSound(soundEnabled);
    const nextCount = tapCount + 1;
    setTapCount(nextCount);
    if (nextCount >= targetTaps) {
      finishTask(true, 'შესანიშნავია! დავალება სისწრაფითა და უნაკლოდ შესრულდა!');
    }
  };

  const handleQuizSubmit = (idx: number) => {
    setSelectedOption(idx);
    playClickSound(soundEnabled);
    const isCorrect = idx === (currentTask.correctOption ?? 0);
    if (isCorrect) {
      finishTask(true, 'სწორი პასუხია! პროფესიონალი ხარ შენს საქმეში!');
    } else {
      finishTask(false, '❌ არასწორი არჩევანია! დავალება ჩაიშალა და თანხა არ დაგერიცხა.');
    }
  };

  const handleSliderSubmit = () => {
    playClickSound(soundEnabled);
    const diff = Math.abs(sliderVal - targetSlider);
    if (diff <= 5) {
      finishTask(true, `ზუსტი პარამეტრებია (${sliderVal})! მაქსიმალური ბონუსი!`);
    } else {
      finishTask(false, `❌ პარამეტრები აგცდა მიზანს (${sliderVal} vs ${targetSlider})! დავალება ჩაიშალა და თანხა არ დაგერიცხა.`);
    }
  };

  const handleCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    playClickSound(soundEnabled);
    const expected = currentTask.options?.[0] || '7709';
    if (codeInput.trim() === expected) {
      finishTask(true, 'კოდი ავტორიზებულია! ელიტური ოპერაცია წარმატებით ჩატარდა!');
    } else {
      finishTask(false, '❌ კოდი არასწორია! სისტემამ ოპერაცია დაბლოკა და თანხა არ დაგერიცხა.');
    }
  };

  const finishTask = (success: boolean, msg: string) => {
    setIsSuccess(success);
    setFeedback(msg);
    if (success) {
      playWinSound(soundEnabled);
    } else {
      playClickSound(soundEnabled);
    }

    // Auto complete after short celebration
    setTimeout(() => {
      // 1.35x bonus if succeeded with precision, 0x if failed (no money on failure)
      onComplete(success ? 1.35 : 0);
    }, 1400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0e1017] border border-emerald-500/40 rounded-2xl p-6 sm:p-7 shadow-[0_0_40px_rgba(16,185,129,0.2)] text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-slate-100">
                სამუშაო მისია: {job.name}
              </h3>
              <span className="text-xs text-amber-400 font-mono">
                დავალება: {currentTask.name}
              </span>
            </div>
          </div>
          <button
            onClick={onCancel}
            disabled={isSuccess !== null}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Task Body */}
        <div className="py-5 space-y-4">
          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800/80">
            <span className="text-[11px] uppercase tracking-wider text-slate-400 block mb-1 font-semibold">
              ინსტრუქცია:
            </span>
            <p className="text-sm text-slate-200 font-medium leading-relaxed">
              {currentTask.prompt}
            </p>
          </div>

          {/* 1. QUIZ TYPE */}
          {currentTask.type === 'quiz' && currentTask.options && (
            <div className="space-y-2">
              {currentTask.options.map((opt, idx) => {
                const isPicked = selectedOption === idx;
                return (
                  <button
                    key={idx}
                    disabled={selectedOption !== null}
                    onClick={() => handleQuizSubmit(idx)}
                    className={`w-full p-3 rounded-xl border text-left text-xs sm:text-sm font-semibold transition-all ${
                      isPicked
                        ? 'border-emerald-500 bg-emerald-500/20 text-emerald-300'
                        : 'border-slate-800 bg-slate-900/60 text-slate-300 hover:border-slate-700 hover:bg-slate-900'
                    } disabled:opacity-80`}
                  >
                    <div className="flex items-center justify-between">
                      <span>{opt}</span>
                      <ArrowRight className="w-4 h-4 text-slate-500 shrink-0 ml-2" />
                    </div>
                  </button>
                );
              })}
            </div>
          )}

          {/* 2. QUICK TAP TYPE */}
          {currentTask.type === 'quick_tap' && (
            <div className="space-y-4 text-center">
              <div className="flex items-center justify-center gap-3">
                <div className="w-full bg-slate-900 h-3 rounded-full overflow-hidden border border-slate-800 max-w-xs">
                  <div
                    className="h-full bg-emerald-500 transition-all duration-150"
                    style={{ width: `${Math.min(100, (tapCount / targetTaps) * 100)}%` }}
                  />
                </div>
                <span className="font-mono text-xs font-bold text-amber-400">
                  {tapCount} / {targetTaps}
                </span>
              </div>

              <button
                type="button"
                disabled={tapCount >= targetTaps}
                onClick={handleTap}
                className="w-36 h-36 mx-auto rounded-full bg-gradient-to-tr from-emerald-600 to-teal-400 hover:from-emerald-500 hover:to-teal-300 active:scale-95 shadow-[0_0_30px_rgba(16,185,129,0.5)] border-4 border-slate-950 flex flex-col items-center justify-center text-slate-950 font-black transition-transform cursor-pointer"
              >
                <Zap className="w-8 h-8 mb-1" />
                <span className="text-base uppercase tracking-wider">დააჭირე!</span>
              </button>
            </div>
          )}

          {/* 3. SLIDER CALIBRATION */}
          {currentTask.type === 'slider' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between font-mono text-xs">
                <span className="text-slate-400">მიზნობრივი მაჩვენებელი:</span>
                <span className="text-emerald-400 font-bold text-sm">{targetSlider}</span>
              </div>

              <div className="space-y-2">
                <input
                  type="range"
                  min="0"
                  max="200"
                  value={sliderVal}
                  onChange={(e) => setSliderVal(Number(e.target.value))}
                  className="w-full h-2.5 bg-slate-900 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
                <div className="text-center font-mono text-2xl font-black text-amber-400">
                  {sliderVal}
                </div>
              </div>

              <button
                type="button"
                disabled={isSuccess !== null}
                onClick={handleSliderSubmit}
                className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all"
              >
                დადასტურება & დაკალიბრება
              </button>
            </div>
          )}

          {/* 4. CODE TYPE */}
          {currentTask.type === 'code' && (
            <form onSubmit={handleCodeSubmit} className="space-y-3">
              <div className="relative">
                <input
                  type="text"
                  value={codeInput}
                  onChange={(e) => setCodeInput(e.target.value)}
                  placeholder="შეიყვანე კოდი..."
                  maxLength={10}
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-center font-mono text-lg font-bold text-emerald-400 focus:outline-none focus:border-emerald-500"
                />
                <Hash className="w-5 h-5 text-slate-600 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
              <button
                type="submit"
                disabled={isSuccess !== null || !codeInput.trim()}
                className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all disabled:opacity-40"
              >
                კოდის შემოწმება
              </button>
            </form>
          )}

          {/* Feedback banner */}
          {feedback && (
            <div
              className={`p-3 rounded-xl border flex items-center gap-2 text-xs font-semibold animate-in fade-in ${
                isSuccess
                  ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                  : 'bg-amber-500/20 border-amber-500/40 text-amber-300'
              }`}
            >
              {isSuccess ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
              )}
              <span>{feedback}</span>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono text-slate-400">
          <span>საბაზისო ანაზღაურება:</span>
          <span className="text-emerald-400 font-bold">
            {formatLari(job.salary)} (+{job.xpReward} XP)
          </span>
        </div>
      </div>
    </div>
  );
};


