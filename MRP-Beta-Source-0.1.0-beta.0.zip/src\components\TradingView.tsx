import React, { useEffect, useMemo, useState } from 'react';
import { Activity, ArrowDownRight, ArrowUpRight, BadgePercent, CandlestickChart, Clock3, DollarSign, ShieldCheck, TrendingDown, TrendingUp } from 'lucide-react';
import { TradingPosition } from '../types/game';

export const TRADING_USD_TO_GEL = 2.7;

interface TradeAsset {
  id: string;
  symbol: string;
  name: string;
  sector: string;
  color: string;
  basePrice: number;
  stepRange: number;
}

const TRADE_ASSETS: TradeAsset[] = [
  { id: 'nova', symbol: 'NOVA', name: 'Nova Systems', sector: 'ტექნოლოგია', color: '#50d9ff', basePrice: 10.24, stepRange: 0.075 },
  { id: 'volt', symbol: 'VOLT', name: 'Volt Motors', sector: 'ავტომობილები', color: '#a3e635', basePrice: 34.80, stepRange: 0.12 },
  { id: 'crude', symbol: 'WTI', name: 'Crude Oil', sector: 'ნედლეული', color: '#fb923c', basePrice: 72.35, stepRange: 0.16 },
  { id: 'aurum', symbol: 'GOLD', name: 'Aurum Metals', sector: 'ოქრო', color: '#fbbf24', basePrice: 202.60, stepRange: 0.22 },
  { id: 'atlas', symbol: 'ATLAS', name: 'Atlas 500', sector: 'საფონდო ინდექსი', color: '#c084fc', basePrice: 415.25, stepRange: 0.28 }
];

interface Quote { price: number; previous: number; }
type MarketQuotes = Record<string, Quote>;
type PriceHistory = Record<string, number[]>;

interface TradingViewProps {
  balance: number;
  portfolio: Record<string, TradingPosition>;
  moneyMultiplier: number;
  onTrade: (assetId: string, side: 'buy' | 'sell', quantity: number, price: number) => void;
}

const MARKET_KEY = 'mrp_market_quotes_v2';
const makeInitialQuotes = (): MarketQuotes => Object.fromEntries(TRADE_ASSETS.map((asset) => [asset.id, { price: asset.basePrice, previous: asset.basePrice }]));
const makeInitialHistory = (): PriceHistory => Object.fromEntries(TRADE_ASSETS.map((asset) => [asset.id, [asset.basePrice]]));

const readQuotes = (): MarketQuotes => {
  try {
    const saved = localStorage.getItem(MARKET_KEY);
    if (saved) {
      const parsed = JSON.parse(saved) as MarketQuotes;
      return Object.fromEntries(TRADE_ASSETS.map((asset) => [asset.id, {
        price: Math.max(0.01, Number(parsed[asset.id]?.price) || asset.basePrice),
        previous: Math.max(0.01, Number(parsed[asset.id]?.previous) || asset.basePrice)
      }]));
    }
  } catch { /* Start a fresh simulated market if storage is unavailable. */ }
  return makeInitialQuotes();
};

const money = (value: number) => `$${value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export const TradingView: React.FC<TradingViewProps> = ({ balance, portfolio, moneyMultiplier, onTrade }) => {
  const [quotes, setQuotes] = useState<MarketQuotes>(readQuotes);
  const [history, setHistory] = useState<PriceHistory>(makeInitialHistory);
  const [investment, setInvestment] = useState(10);
  const [selectedAsset, setSelectedAsset] = useState(TRADE_ASSETS[0].id);
  const [side, setSide] = useState<'buy' | 'sell'>('buy');
  const [lastTick, setLastTick] = useState(() => new Date());

  useEffect(() => {
    const timer = window.setInterval(() => {
      setQuotes((current) => {
        const next: MarketQuotes = {};
        TRADE_ASSETS.forEach((asset) => {
          const quote = current[asset.id] || { price: asset.basePrice, previous: asset.basePrice };
          // Small one-cent moves are common; occasional simulated news creates a sharp $1–$2 jump.
          const hasNewsSpike = Math.random() < 0.012;
          const move = hasNewsSpike
            ? (Math.random() < 0.5 ? -1 : 1) * (1 + Math.random())
            : (Math.random() - 0.49) * asset.stepRange;
          const price = Math.max(0.01, Math.round((quote.price + move) * 100) / 100);
          next[asset.id] = { price, previous: quote.price };
        });
        try { localStorage.setItem(MARKET_KEY, JSON.stringify(next)); } catch { /* Market stays active for this session. */ }
        return next;
      });
      setLastTick(new Date());
    }, 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    setHistory((old) => Object.fromEntries(TRADE_ASSETS.map((asset) => [
      asset.id,
      [...(old[asset.id] || [asset.basePrice]), quotes[asset.id]?.price || asset.basePrice].slice(-120)
    ])));
  }, [quotes]);

  const selected = TRADE_ASSETS.find((asset) => asset.id === selectedAsset) || TRADE_ASSETS[0];
  const quote = quotes[selected.id] || { price: selected.basePrice, previous: selected.basePrice };
  const chartPoints = history[selected.id] || [selected.basePrice];
  const position = portfolio[selected.id] || { quantity: 0, averagePrice: 0 };
  const balanceUsd = balance / TRADING_USD_TO_GEL;
  const portfolioValueUsd = useMemo(() => TRADE_ASSETS.reduce((total, asset) => total + (portfolio[asset.id]?.quantity || 0) * (quotes[asset.id]?.price || asset.basePrice), 0), [portfolio, quotes]);
  const positionValueUsd = position.quantity * quote.price;
  const maxOrderUsd = side === 'buy' ? balanceUsd / 1.015 : positionValueUsd;
  const safeInvestment = Number.isFinite(investment) ? Math.max(0.01, investment) : 0.01;
  const orderUsd = Math.min(safeInvestment, maxOrderUsd);
  const shares = side === 'buy' ? orderUsd / quote.price : Math.min(position.quantity, orderUsd / quote.price);
  const grossUsd = shares * quote.price;
  const feeUsd = grossUsd * 0.015;
  const buyTotalUsd = grossUsd + feeUsd;
  const costBasisUsd = position.averagePrice * shares;
  const netProceedsUsd = grossUsd - feeUsd;
  const realizedPnLUsd = netProceedsUsd - costBasisUsd;
  const settlementUsd = Math.max(0, costBasisUsd + realizedPnLUsd * moneyMultiplier);
  const canTrade = side === 'buy'
    ? safeInvestment * 1.015 <= balanceUsd
    : position.quantity >= shares && shares > 0 && safeInvestment <= positionValueUsd;
  const movePercent = quote.previous ? ((quote.price - quote.previous) / quote.previous) * 100 : 0;
  const minPoint = Math.min(...chartPoints);
  const maxPoint = Math.max(...chartPoints);
  const spread = Math.max(0.1, maxPoint - minPoint);
  const points = chartPoints.map((price, index) => `${chartPoints.length < 2 ? 0 : (index / (chartPoints.length - 1)) * 100},${96 - ((price - minPoint) / spread) * 82}`).join(' ');
  const chartUp = chartPoints[chartPoints.length - 1] >= chartPoints[0];
  const chartColor = chartUp ? '#34d399' : '#fb7185';

  const submitTrade = () => {
    if (!canTrade) return;
    onTrade(selected.id, side, shares, quote.price);
  };

  return (
    <div className="mx-auto w-full max-w-[1500px] space-y-5 px-3 py-5 sm:px-5 sm:py-7 lg:px-8 animate-fadeIn">
      <section className="relative overflow-hidden rounded-3xl border border-cyan-400/25 bg-gradient-to-br from-[#08151e] via-[#101322] to-[#1a1022] p-5 shadow-[0_24px_80px_rgba(0,0,0,.4)] sm:p-7">
        <div className="pointer-events-none absolute -right-10 -top-24 h-64 w-64 rounded-full bg-cyan-400/10 blur-3xl" />
        <div className="relative flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <div className="mb-2 inline-flex items-center gap-2 rounded-full border border-cyan-300/20 bg-cyan-300/5 px-3 py-1 text-[10px] font-bold uppercase tracking-[.2em] text-cyan-200"><Activity className="h-3.5 w-3.5" /> სიმულირებული საფონდო ბაზარი</div>
            <h1 className="text-3xl font-black tracking-tight text-white sm:text-4xl">MRP <span className="bg-gradient-to-r from-cyan-300 to-violet-300 bg-clip-text text-transparent">TRADING</span></h1>
            <p className="mt-2 max-w-2xl text-xs leading-relaxed text-slate-400 sm:text-sm">რეალურ დროში მოძრავი ფასები, ცოცხალი ჩარტი და ბაზრის მკვეთრი ნახტომები. აქტივები გამოგონილია; კრიპტო და ბერკეტი არ გამოიყენება.</p>
          </div>
          <div className="grid grid-cols-2 gap-2 sm:gap-3">
            <div className="min-w-32 rounded-2xl border border-emerald-400/20 bg-black/30 p-3 sm:p-4"><span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">თავისუფალი თანხა</span><strong className="mt-1 block text-lg font-black text-emerald-300 sm:text-xl">{money(balanceUsd)}</strong></div>
            <div className="min-w-32 rounded-2xl border border-violet-400/20 bg-black/30 p-3 sm:p-4"><span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">პორტფელი</span><strong className="mt-1 block text-lg font-black text-violet-300 sm:text-xl">{money(portfolioValueUsd)}</strong></div>
          </div>
        </div>
        <div className="relative mt-4 flex flex-wrap items-center gap-x-4 gap-y-1 border-t border-white/5 pt-3 text-[10px] text-slate-500">
          <span>თამაშის კურსი: $1 = ₾{TRADING_USD_TO_GEL.toFixed(2)}</span><span>საკომისიო: 1.5%</span><span>ბერკეტი: გამორთულია</span>
        </div>
      </section>

      <section className="grid grid-cols-1 gap-4 xl:grid-cols-[1.55fr_.75fr]">
        <div className="overflow-hidden rounded-3xl border border-slate-800 bg-[#0d111a] shadow-xl">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 p-4 sm:p-5">
            <div className="flex min-w-0 items-center gap-3">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border border-white/10 text-base font-black" style={{ backgroundColor: `${selected.color}18`, color: selected.color }}>{selected.symbol.slice(0, 1)}</div>
              <div className="min-w-0"><div className="flex items-center gap-2"><h2 className="truncate text-base font-black text-white sm:text-lg">{selected.name}</h2><span className="rounded-md bg-white/5 px-1.5 py-0.5 text-[9px] font-bold text-slate-400">{selected.symbol}</span></div><div className="mt-0.5 flex items-center gap-1 text-[10px] text-slate-500"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />ცოცხალი ბაზარი · 1 წამი</div></div>
            </div>
            <div className="text-right"><div className="text-2xl font-black tracking-tight text-white sm:text-3xl">{money(quote.price)}</div><div className={`flex items-center justify-end gap-1 text-xs font-bold ${movePercent >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>{movePercent >= 0 ? <ArrowUpRight className="h-3.5 w-3.5" /> : <ArrowDownRight className="h-3.5 w-3.5" />}{movePercent >= 0 ? '+' : ''}{movePercent.toFixed(2)}% <span className="ml-1 text-[9px] font-normal text-slate-500">ბოლო ტიკი</span></div></div>
          </div>
          <div className="relative h-64 px-2 py-4 sm:h-80 sm:px-5">
            <div className="pointer-events-none absolute inset-x-4 top-8 bottom-8 flex flex-col justify-between sm:inset-x-7"><div className="border-t border-dashed border-slate-800/80"/><div className="border-t border-dashed border-slate-800/80"/><div className="border-t border-dashed border-slate-800/80"/><div className="border-t border-dashed border-slate-800/80"/></div>
            <div className="pointer-events-none absolute left-5 top-3 flex gap-3 text-[9px] font-mono text-slate-600 sm:left-7"><span>H {money(maxPoint)}</span><span>L {money(minPoint)}</span></div>
            <svg className="relative h-full w-full overflow-visible" viewBox="0 0 100 100" preserveAspectRatio="none" aria-label={`${selected.name} price chart`}>
              <defs><linearGradient id="tradingFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor={chartColor} stopOpacity=".24"/><stop offset="100%" stopColor={chartColor} stopOpacity="0"/></linearGradient></defs>
              <polygon points={`0,100 ${points} 100,100`} fill="url(#tradingFill)" />
              <polyline points={points} fill="none" stroke={chartColor} strokeWidth=".85" vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span className="absolute bottom-2 left-5 text-[9px] font-mono text-slate-600">120 ბოლო მოძრაობა</span>
            <span className="absolute bottom-2 right-5 flex items-center gap-1 text-[9px] font-mono text-slate-500"><Clock3 className="h-3 w-3" />{lastTick.toLocaleTimeString('ka-GE')}</span>
          </div>
          <div className="grid grid-cols-2 gap-2 border-t border-slate-800 p-3 sm:grid-cols-5 sm:p-4">
            {TRADE_ASSETS.map((asset) => {
              const current = quotes[asset.id] || { price: asset.basePrice, previous: asset.basePrice };
              const change = current.price - current.previous;
              const active = selectedAsset === asset.id;
              return <button key={asset.id} onClick={() => setSelectedAsset(asset.id)} className={`rounded-xl border px-3 py-2 text-left transition-all ${active ? 'border-cyan-400/50 bg-cyan-400/10' : 'border-slate-800 bg-slate-950/60 hover:border-slate-600'}`}><span className="block text-[9px] font-black tracking-wider" style={{ color: asset.color }}>{asset.symbol}</span><span className="mt-0.5 block text-xs font-bold text-white">{money(current.price)}</span><span className={`mt-0.5 block text-[9px] ${change >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>{change >= 0 ? '+' : ''}{money(change)}</span></button>;
            })}
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-3xl border border-slate-800 bg-[#0d111a] p-4 shadow-xl sm:p-5">
            <div className="mb-4 flex items-start justify-between gap-3"><div><h2 className="text-base font-black text-white">შეკვეთის გახსნა</h2><p className="mt-1 text-[10px] text-slate-500">{selected.symbol} · ფასი {money(quote.price)}</p></div><CandlestickChart className="h-5 w-5 text-cyan-300" /></div>
            <div className="mb-4 grid grid-cols-2 rounded-xl border border-slate-800 bg-slate-950 p-1"><button onClick={() => setSide('buy')} className={`rounded-lg py-2 text-xs font-black transition ${side === 'buy' ? 'bg-emerald-400 text-slate-950' : 'text-slate-400 hover:text-white'}`}>ყიდვა / LONG</button><button onClick={() => setSide('sell')} className={`rounded-lg py-2 text-xs font-black transition ${side === 'sell' ? 'bg-rose-400 text-slate-950' : 'text-slate-400 hover:text-white'}`}>გაყიდვა / CLOSE</button></div>
            <label className="block"><span className="mb-1.5 block text-[10px] font-bold uppercase tracking-wider text-slate-500">ინვესტიციის თანხა · USD</span><div className="relative"><span className="absolute left-3 top-1/2 -translate-y-1/2 font-black text-emerald-300">$</span><input type="number" min={0.01} step={0.01} value={investment} onChange={(event) => setInvestment(event.target.value === '' ? 0.01 : Math.max(0.01, Number(event.target.value)))} className="w-full rounded-xl border border-slate-700 bg-slate-950 py-3 pl-8 pr-3 text-lg font-black text-white outline-none focus:border-cyan-400" /></div></label>
            <div className="mt-3 grid grid-cols-3 gap-2">{[10, 25, 50, 100].map((value) => <button key={value} onClick={() => setInvestment(value)} className={`rounded-lg border px-2 py-1.5 text-[10px] font-bold transition ${investment === value ? 'border-cyan-400/50 bg-cyan-400/10 text-cyan-200' : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white'}`}>${value}</button>)}<button onClick={() => setInvestment(Math.max(0.01, Math.floor(maxOrderUsd * 100) / 100))} className="rounded-lg border border-amber-500/30 bg-amber-500/10 px-2 py-1.5 text-[10px] font-bold text-amber-200">MAX {money(maxOrderUsd)}</button></div>
            <div className="mt-4 space-y-2 rounded-xl border border-slate-800 bg-slate-950/70 p-3 text-xs"><div className="flex justify-between text-slate-400"><span>საბაზრო ერთეულები</span><span className="font-mono text-slate-200">{shares.toFixed(4)}</span></div><div className="flex justify-between text-slate-400"><span>საკომისიო (1.5%)</span><span className="font-mono text-slate-200">{money(feeUsd)}</span></div><div className="flex justify-between border-t border-slate-800 pt-2 font-bold"><span className="text-slate-300">{side === 'buy' ? 'სულ ჩამოგეჭრება' : 'მოსალოდნელი ჩარიცხვა'}</span><span className="font-mono text-white">{money(side === 'buy' ? buyTotalUsd : settlementUsd)}</span></div><div className="flex justify-between text-[10px] text-slate-500"><span>თამაშის ბალანსიდან</span><span>₾{Math.round((side === 'buy' ? buyTotalUsd : settlementUsd) * TRADING_USD_TO_GEL).toLocaleString('ka-GE')}</span></div></div>
            <button onClick={submitTrade} disabled={!canTrade} className={`mt-4 flex w-full items-center justify-center gap-2 rounded-xl py-3 text-xs font-black transition ${canTrade ? side === 'buy' ? 'bg-gradient-to-r from-emerald-400 to-cyan-400 text-slate-950 hover:brightness-110' : 'bg-gradient-to-r from-rose-500 to-orange-400 text-white hover:brightness-110' : 'cursor-not-allowed border border-slate-800 bg-slate-900 text-slate-600'}`}><DollarSign className="h-4 w-4" />{canTrade ? side === 'buy' ? `იყიდე ${selected.symbol}` : `დახურე პოზიცია` : side === 'buy' ? 'ბალანსი არ კმარა' : 'ღია პოზიცია არ გაქვს'}</button>
            <p className="mt-3 text-[10px] leading-relaxed text-slate-500">ბაზარზე ფასის ნახტომმა შეიძლება მოგებაც და ზარალიც სწრაფად შეცვალოს. ვალი და უარყოფითი ბალანსი გამორთულია.</p>
          </div>

          <div className="rounded-3xl border border-cyan-400/15 bg-gradient-to-br from-[#0b1720] to-[#10111a] p-4 sm:p-5">
            <div className="flex items-center gap-2 text-cyan-200"><ShieldCheck className="h-5 w-5" /><h2 className="text-sm font-black">პოზიცია და რისკი</h2></div>
            <div className="mt-3 space-y-2 text-[11px] text-slate-300"><div className="flex justify-between"><span>შენი {selected.symbol} პოზიცია</span><b className="font-mono text-white">{position.quantity.toFixed(4)} წილი</b></div><div className="flex justify-between"><span>მიმდინარე ღირებულება</span><b className="font-mono text-white">{money(positionValueUsd)}</b></div><div className="flex justify-between"><span>საშუალო შესვლის ფასი</span><b className="font-mono text-white">{money(position.averagePrice)}</b></div></div>
            <ul className="mt-4 space-y-2 border-t border-slate-800 pt-3 text-[10px] leading-relaxed text-slate-400"><li className="flex gap-2"><BadgePercent className="h-3.5 w-3.5 shrink-0 text-amber-300" />ყოველ შესრულებულ გარიგებაზე 1.5% საკომისიო.</li><li className="flex gap-2"><TrendingUp className="h-3.5 w-3.5 shrink-0 text-emerald-300" />ხშირად ფასი რამდენიმე ცენტით იცვლება; იშვიათი ბაზრის ამბავი $1–$2 ნახტომს იწვევს.</li><li className="flex gap-2"><TrendingDown className="h-3.5 w-3.5 shrink-0 text-rose-300" />RedDevil რანკი მიღებულ მოგებასაც და ზარალსაც x25-ზე ითვლის.</li></ul>
          </div>
        </div>
      </section>
    </div>
  );
};
