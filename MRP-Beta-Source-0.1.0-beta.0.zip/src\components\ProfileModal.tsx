﻿import React, { useState, useRef } from 'react';
import { X, Check, Shield, Trophy, Car, Briefcase, Zap, AlertTriangle, Image as ImageIcon, Sparkles, Upload, Trash2 } from 'lucide-react';
import { PlayerProfile } from '../types/game';
import { AVATAR_PRESETS, PHOTO_AVATAR_PRESETS, getXpRequiredForLevel, getRankForLevel } from '../utils/constants';
import { formatLari } from '../utils/formatters';

interface ProfileModalProps {
  player: PlayerProfile;
  ownedCarsCount: number;
  onUpdateProfile: (name: string, title: string, avatar: string, customPhoto?: string) => void;
  onResetGame: () => void;
  onClose: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  player,
  ownedCarsCount,
  onUpdateProfile,
  onResetGame,
  onClose
}) => {
  const [name, setName] = useState(player.name);
  const [title, setTitle] = useState(player.title);
  const [avatar, setAvatar] = useState(player.avatar);
  const [customPhoto, setCustomPhoto] = useState(player.customPhoto || '');
  const [avatarTab, setAvatarTab] = useState<'upload' | 'photos' | 'emojis' | 'custom'>('upload');
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const xpNeeded = getXpRequiredForLevel(player.level);
  const currentRank = getRankForLevel(player.level);

  // Resize and compress image to base64 for fast & lightweight storage
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 320;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxDim) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          }
        } else {
          if (height > maxDim) {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.85);
          setCustomPhoto(compressedDataUrl);
        }
      };
      if (typeof event.target?.result === 'string') {
        img.src = event.target.result;
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSave = () => {
    if (name.trim()) {
      onUpdateProfile(
        name.trim(),
        title.trim() || currentRank.title,
        avatar,
        customPhoto.trim() || undefined
      );
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[92vh] overflow-y-auto bg-[#0d0e15] border border-slate-800 rounded-2xl p-6 sm:p-7 shadow-2xl text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800/80">
          <div className="flex items-center gap-3">
            <div className="relative w-12 h-12 rounded-xl overflow-hidden border border-emerald-500/40 bg-slate-900 flex items-center justify-center shadow-lg">
              {customPhoto ? (
                <img
                  src={customPhoto}
                  alt={name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    // Fallback to avatar emoji on error
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              ) : (
                <span className="text-2xl">{avatar}</span>
              )}
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2 flex-wrap">
                <span>პროფილის რედაქტირება & ავატარი</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  {currentRank.badge} {currentRank.title}
                </span>
                {player.premiumRank === 'red' && (
                  <span className="text-xs px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/50 font-black font-mono tracking-wider animate-pulse shadow-[0_0_10px_rgba(239,68,68,0.4)]">
                    🔴 RED VIP
                  </span>
                )}
                {player.premiumRank === 'purple' && (
                  <span className="text-xs px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/50 font-black font-mono tracking-wider animate-pulse shadow-[0_0_12px_rgba(168,85,247,0.5)]">
                    🟣 PURPLE VIP
                  </span>
                )}
              </h2>
              <span className="text-xs text-slate-400">დააყენე პირადი ფოტო და მოირგე შენი RP იმიჯი</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Avatar Selection Tabs */}
        <div className="py-4 space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-slate-300">
              პროფილის ავატარი & ფოტო
            </label>
            <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl text-xs flex-wrap">
              <button
                type="button"
                onClick={() => setAvatarTab('upload')}
                className={`px-3 py-1 rounded-lg font-medium transition-all ${
                  avatarTab === 'upload'
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                💻 ფაილით ატვირთვა
              </button>
              <button
                type="button"
                onClick={() => setAvatarTab('photos')}
                className={`px-3 py-1 rounded-lg font-medium transition-all ${
                  avatarTab === 'photos'
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                📸 გალერეა
              </button>
              <button
                type="button"
                onClick={() => setAvatarTab('emojis')}
                className={`px-3 py-1 rounded-lg font-medium transition-all ${
                  avatarTab === 'emojis'
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                😎 ემოჯი
              </button>
              <button
                type="button"
                onClick={() => setAvatarTab('custom')}
                className={`px-3 py-1 rounded-lg font-medium transition-all ${
                  avatarTab === 'custom'
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                🔗 ბმული
              </button>
            </div>
          </div>

          {/* 0. Direct File Upload from Computer */}
          {avatarTab === 'upload' && (
            <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-emerald-500/30 space-y-4">
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />

              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-emerald-500/40 hover:border-emerald-400 hover:bg-emerald-500/5 transition-all rounded-xl p-6 flex flex-col items-center justify-center gap-3 cursor-pointer text-center group"
              >
                <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Upload className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-100 group-hover:text-emerald-300 transition-colors">
                    დააწკაპუნე ფოტოს ასატვირთად კომპიუტერიდან
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    მხარდაჭერილია ნებისმიერი სურათი: PNG, JPG, JPEG, WebP
                  </p>
                </div>
                <button
                  type="button"
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md transition-colors"
                >
                  ფაილის არჩევა
                </button>
              </div>

              {customPhoto && (
                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center gap-3">
                    <img
                      src={customPhoto}
                      alt="Uploaded preview"
                      className="w-12 h-12 rounded-lg object-cover border border-emerald-500/40"
                    />
                    <div>
                      <span className="text-xs font-bold text-emerald-400 block">
                        ფოტო წარმატებით აიტვირთა!
                      </span>
                      <span className="text-[11px] text-slate-400">
                        დააჭირე ქვემოთ "შენახვა"-ს დასადასტურებლად
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCustomPhoto('')}
                    className="p-2 rounded-lg bg-rose-950/40 text-rose-400 hover:bg-rose-900/60 transition-colors"
                    title="ფოტოს წაშლა"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          )}

          {/* 1. Real Photo Gallery */}
          {avatarTab === 'photos' && (
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2.5">
              {PHOTO_AVATAR_PRESETS.map((item) => {
                const isSelected = customPhoto === item.url;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setCustomPhoto(item.url)}
                    className={`group relative rounded-xl overflow-hidden border p-1 flex flex-col items-center gap-1 transition-all ${
                      isSelected
                        ? 'border-emerald-500 bg-emerald-500/15 shadow-[0_0_15px_rgba(16,185,129,0.3)]'
                        : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
                    }`}
                  >
                    <div className="w-14 h-14 rounded-lg overflow-hidden relative">
                      <img
                        src={item.url}
                        alt={item.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                      {isSelected && (
                        <div className="absolute inset-0 bg-emerald-500/30 flex items-center justify-center">
                          <span className="w-5 h-5 bg-emerald-500 text-black rounded-full flex items-center justify-center text-[10px] font-bold">
                            <Check className="w-3 h-3 stroke-[3]" />
                          </span>
                        </div>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-300 font-medium truncate max-w-full">
                      {item.name}
                    </span>
                  </button>
                );
              })}
            </div>
          )}

          {/* 2. Emoji Presets */}
          {avatarTab === 'emojis' && (
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2.5">
              {AVATAR_PRESETS.map((item) => {
                const isSelected = avatar === item.emoji && !customPhoto;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setAvatar(item.emoji);
                      setCustomPhoto('');
                    }}
                    className={`relative p-2.5 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                      isSelected
                        ? 'border-emerald-500 bg-emerald-500/15 shadow-[0_0_15px_rgba(16,185,129,0.3)]'
                        : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
                    }`}
                  >
                    <span className="text-2xl">{item.emoji}</span>
                    <span className="text-[10px] text-slate-400 truncate max-w-full">
                      {item.name}
                    </span>
                    {isSelected && (
                      <span className="absolute top-1 right-1 w-3.5 h-3.5 bg-emerald-500 text-black rounded-full flex items-center justify-center text-[9px] font-bold">
                        <Check className="w-2.5 h-2.5 stroke-[3]" />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          )}

          {/* 3. Custom Image URL */}
          {avatarTab === 'custom' && (
            <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 space-y-3">
              <label className="block text-xs text-slate-300">
                ჩასვი ნებისმიერი ფოტოს პირდაპირი ბმული (URL):
              </label>
              <div className="flex gap-2">
                <input
                  type="url"
                  value={customPhoto}
                  onChange={(e) => setCustomPhoto(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="flex-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:outline-none text-xs text-slate-200"
                />
                {customPhoto && (
                  <button
                    type="button"
                    onClick={() => setCustomPhoto('')}
                    className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-300"
                  >
                    გასუფთავება
                  </button>
                )}
              </div>
              <p className="text-[11px] text-slate-400">
                შეგიძლია გამოიყენო Unsplash, Imgur ან ნებისმიერი საჯარო ფოტოს ლინკი.
              </p>
            </div>
          )}

          {/* Name & Title Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  მოთამაშის მეტსახელი
                </label>
                {player.premiumRank === 'red' && (
                  <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/50 text-[10px] font-black font-mono tracking-wider animate-pulse shadow-[0_0_10px_rgba(239,68,68,0.4)]">
                    🔴 RED VIP
                  </span>
                )}
                {player.premiumRank === 'purple' && (
                  <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/50 text-[10px] font-black font-mono tracking-wider animate-pulse shadow-[0_0_12px_rgba(168,85,247,0.5)]">
                    🟣 PURPLE VIP
                  </span>
                )}
              </div>
              <input
                type="text"
                value={name}
                maxLength={24}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 focus:border-emerald-500 focus:outline-none text-sm text-slate-100 placeholder-slate-500"
                placeholder="შენი სახელი..."
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                სტატუსი / RP ტიტული
              </label>
              <input
                type="text"
                value={title}
                maxLength={36}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 focus:border-emerald-500 focus:outline-none text-sm text-slate-100 placeholder-slate-500"
                placeholder={`მაგ: ${currentRank.title}`}
              />
            </div>
          </div>

          {/* Statistics Grid */}
          <div className="pt-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
              <Trophy className="w-4 h-4 text-amber-400" />
              <span>თამაშის სრული სტატისტიკა & პროგრესი</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80">
                <span className="text-[11px] text-slate-400 block">მიმდინარე დონე</span>
                <span className="text-lg font-mono font-bold text-amber-400">
                  Lvl {player.level} / 350
                </span>
                <span className="text-[10px] text-slate-500 block truncate">
                  {currentRank.badge} {currentRank.title}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80">
                <span className="text-[11px] text-slate-400 block">რეპუტაცია (RP)</span>
                <span className="text-lg font-mono font-bold text-cyan-400">
                  {player.reputation} RP
                </span>
                <span className="text-[10px] text-slate-500 block">ქალაქის გავლენა</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80">
                <span className="text-[11px] text-slate-400 block">სულ გამომუშავებული</span>
                <span className="text-lg font-mono font-bold text-emerald-400 truncate block">
                  {formatLari(player.stats.totalEarned)}
                </span>
                <span className="text-[10px] text-slate-500 block">ჯამური კაპიტალი</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80">
                <span className="text-[11px] text-slate-400 block">ავტოპარკი</span>
                <span className="text-lg font-mono font-bold text-violet-400">
                  {ownedCarsCount} / {player.garageCapacity}
                </span>
                <span className="text-[10px] text-slate-500 block">მანქანა გარაჟში</span>
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-800/80">
            <div>
              {!showResetConfirm ? (
                <button
                  type="button"
                  onClick={() => setShowResetConfirm(true)}
                  className="text-xs text-rose-400 hover:text-rose-300 underline transition-colors"
                >
                  პროგრესის განულება (ახალი თამაში)
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-rose-400 flex items-center gap-1 font-semibold">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    დარწმუნებული ხარ?
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      onResetGame();
                      setShowResetConfirm(false);
                      onClose();
                    }}
                    className="px-2.5 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
                  >
                    დიახ, წაშალე
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowResetConfirm(false)}
                    className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 text-xs"
                  >
                    გაუქმება
                  </button>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2.5 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="w-1/2 sm:w-auto px-4 py-2 rounded-xl border border-slate-800 text-slate-300 hover:bg-slate-800 text-xs font-medium transition-colors"
              >
                დახურვა
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="w-1/2 sm:w-auto px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-sm transition-colors"
              >
                შენახვა
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};


