﻿import React from 'react';
import { X, Star, CheckCircle, Sparkles, Trophy, ArrowRight, Shield } from 'lucide-react';
import { PlayerProfile } from '../types/game';
import { STAR_MISSIONS, getStarsForPlayer } from '../utils/constants';
import { formatLari } from '../utils/formatters';
import { playWinSound, playClickSound } from '../utils/audio';

interface StarMissionsModalProps {
  player: PlayerProfile;
  soundEnabled: boolean;
  ownedCarsCount: number;
  ownedEstatesCount: number;
  onClose: () => void;
  onClaimStarMission: (missionId: string, cashReward: number, starsReward: number) => void;
}

export const StarMissionsModal: React.FC<StarMissionsModalProps> = ({
  player,
  soundEnabled,
  ownedCarsCount,
  ownedEstatesCount,
  onClose,
  onClaimStarMission
}) => {
  const completedMissions = player.completedStarMissions || [];
  const playerStars = player.stars || 0;
  const currentRank = player.premiumRank || 'none';

  const starsRateText =
    currentRank === 'purple' || currentRank === 'midnight_purple'
      ? '6-7 ⭐ (Purple / Midnight Bonus)'
      : currentRank === 'red'
      ? '3-4 ⭐ (Red VIP Bonus)'
      : '1-2 ⭐ (სტანდარტული)';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-xl animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-[#0c0d16] border-2 border-amber-500/40 rounded-3xl shadow-[0_0_60px_rgba(245,158,11,0.2)] flex flex-col max-h-[90vh] overflow-hidden text-slate-100">
        
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-[#1c1206] via-[#140c06] to-[#0c0d16] border-b border-amber-500/30 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center text-2xl shadow-[0_0_20px_rgba(245,158,11,0.4)] text-slate-950 font-bold shrink-0">
              ⭐
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black bg-gradient-to-r from-amber-300 to-yellow-400 bg-clip-text text-transparent">
                  STAR MISSIONS • ვარსკვლავური მისიები
                </h2>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                შეასრულე ყოველდღიური RP ამოცანები, გამოიმუშავე ვარსკვლავები Star Pass-ისთვის და სოლიდური ქეში!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Stars Capsule */}
            <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-slate-950/80 border border-amber-500/50 text-xs font-mono text-amber-300 font-bold">
              <span>⭐</span>
              <span>{playerStars} Stars</span>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Rate Banner */}
        <div className="px-5 py-2.5 bg-amber-500/10 border-b border-amber-500/20 flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
          <span className="text-amber-200">
            🌟 შენი ვარსკვლავების კოეფიციენტი თითო მისიაზე: <strong className="text-amber-400">{starsRateText}</strong>
          </span>
          <span className="text-slate-400">
            პროგრესი: {completedMissions.length} / {STAR_MISSIONS.length} მისია
          </span>
        </div>

        {/* Missions Grid */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-3.5 flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {STAR_MISSIONS.map((m) => {
              const isClaimed = completedMissions.includes(m.id);
              const progress = m.getProgress(player, ownedCarsCount, ownedEstatesCount);
              const percent = Math.min(100, Math.floor((progress.current / m.targetCount) * 100));

              return (
                <div
                  key={m.id}
                  className={`p-4 rounded-2xl border-2 transition-all flex flex-col justify-between ${
                    isClaimed
                      ? 'bg-slate-950/50 border-slate-800/60 opacity-60'
                      : progress.completed
                      ? 'bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-900 border-amber-500/50 shadow-lg'
                      : 'bg-slate-900/80 border-slate-800/80'
                  }`}
                >
                  <div>
                    {/* Top Row */}
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2.5">
                        <span className="text-2xl">{m.icon}</span>
                        <div>
                          <h4 className="font-bold text-sm text-slate-100">{m.title}</h4>
                          <p className="text-xs text-slate-400 mt-0.5">{m.description}</p>
                        </div>
                      </div>

                      {/* Rewards Tags */}
                      <div className="text-right shrink-0">
                        <span className="text-xs font-mono font-bold text-emerald-400 block">
                          +{formatLari(m.rewardCash)}
                        </span>
                        <span className="text-[11px] font-mono font-bold text-amber-300 flex items-center gap-0.5 justify-end">
                          <span>+⭐ Stars</span>
                        </span>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="space-y-1 my-3">
                      <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                        <span>პროგრესი</span>
                        <span className={progress.completed ? 'text-amber-400 font-bold' : ''}>
                          {progress.current} / {m.targetCount} {m.unit} ({percent}%)
                        </span>
                      </div>
                      <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                        <div
                          className={`h-full transition-all duration-300 ${
                            progress.completed
                              ? 'bg-gradient-to-r from-amber-500 to-yellow-400'
                              : 'bg-slate-700'
                          }`}
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Claim Button */}
                  <div>
                    {isClaimed ? (
                      <div className="w-full py-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold text-xs text-center font-mono">
                        ✓ ჯილდო აღებულია
                      </div>
                    ) : progress.completed ? (
                      <button
                        onClick={() => {
                          const starsAwarded = getStarsForPlayer(player.premiumRank);
                          playWinSound(soundEnabled);
                          onClaimStarMission(m.id, m.rewardCash, starsAwarded);
                        }}
                        className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-xs uppercase tracking-wider shadow-[0_0_15px_rgba(245,158,11,0.4)] transition-all cursor-pointer animate-pulse"
                      >
                        ⭐ ჯილდოს აღება
                      </button>
                    ) : (
                      <div className="w-full py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-500 font-mono text-xs text-center">
                        მიმდინარეობს...
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#08090f] border-t border-slate-800 text-center text-xs text-slate-400">
          ⭐ ვარსკვლავები ავტომატურად ირიცხება შენს Star Pass 50 Tiers პროგრესში!
        </div>
      </div>
    </div>
  );
};


