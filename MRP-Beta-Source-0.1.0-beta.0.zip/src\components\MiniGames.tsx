﻿import React, { useState, useRef, useEffect } from 'react';
import {
  Lock,
  Unlock,
  RotateCw,
  Coins,
  ShieldAlert,
  Award,
  DollarSign,
  Sparkles,
  ArrowRight,
  RefreshCw,
  HelpCircle,
  Dices,
  CircleDot,
  Flame,
  Trophy
} from 'lucide-react';
import {
  playCashSound,
  playWinSound,
  playClickSound,
  playSpinSound,
  playCardSound
} from '../utils/audio';
import { formatLari } from '../utils/formatters';

interface MiniGamesProps {
  balance: number;
  soundEnabled: boolean;
  onWin: (amount: number, xpReward: number) => void;
  onLoss: (amount: number) => void;
  onBetPlaced: (amount: number) => void;
}

export const MiniGames: React.FC<MiniGamesProps> = ({
  balance,
  soundEnabled,
  onWin,
  onLoss,
  onBetPlaced
}) => {
  const [activeGame, setActiveGame] = useState<'slots' | 'safe' | 'wheel' | 'blackjack' | 'coin' | 'dice' | 'thimbles'>('slots');

  // ==========================================
  // 0. ROYAL 777 SLOTS (5-LINE DELUXE SLOTS)
  // ==========================================
  // 10 symbols pool for realistic casino difficulty and rare, high-value jackpots
  const SLOT_SYMBOLS = ['7️⃣', '💎', '👑', '🏎️', '💰', '⚡', '🔔', '🍇', '🍋', '🍒'];

  // 5 Paylines in 3x3 matrix: row, col
  const SLOT_PAYLINES = [
    { id: 1, name: 'ლაინი 1 (შუა ჰორიზონტალი)', shortName: 'L1', color: '#f59e0b', strokeColor: 'rgb(245, 158, 11)', cells: [[1, 0], [1, 1], [1, 2]] as [number, number][] },
    { id: 2, name: 'ლაინი 2 (ზედა ჰორიზონტალი)', shortName: 'L2', color: '#06b6d4', strokeColor: 'rgb(6, 182, 212)', cells: [[0, 0], [0, 1], [0, 2]] as [number, number][] },
    { id: 3, name: 'ლაინი 3 (ქვედა ჰორიზონტალი)', shortName: 'L3', color: '#10b981', strokeColor: 'rgb(16, 185, 129)', cells: [[2, 0], [2, 1], [2, 2]] as [number, number][] },
    { id: 4, name: 'ლაინი 4 (დიაგონალი ↘)', shortName: 'L4', color: '#ec4899', strokeColor: 'rgb(236, 72, 153)', cells: [[0, 0], [1, 1], [2, 2]] as [number, number][] },
    { id: 5, name: 'ლაინი 5 (დიაგონალი ↗)', shortName: 'L5', color: '#f97316', strokeColor: 'rgb(249, 115, 22)', cells: [[2, 0], [1, 1], [0, 2]] as [number, number][] }
  ];

  // 3x3 Matrix Grid
  const [slotGrid, setSlotGrid] = useState<string[][]>([
    ['💎', '7️⃣', '💎'],
    ['7️⃣', '7️⃣', '7️⃣'],
    ['👑', '7️⃣', '👑']
  ]);
  const [slotBet, setSlotBet] = useState<number>(50);
  const [slotBetInput, setSlotBetInput] = useState<string>('50');
  const [isSlotSpinning, setIsSlotSpinning] = useState<boolean>(false);
  const [slotMessage, setSlotMessage] = useState<string>('5 აქტიური ლაინი! დააჭირე სპინს დასატრიალებლად 🎰');
  const [slotLastWin, setSlotLastWin] = useState<number | null>(null);
  const [winningLines, setWinningLines] = useState<Array<{
    lineId: number;
    name: string;
    symbol: string;
    multiplier: number;
    payout: number;
    color: string;
    cells: [number, number][];
  }>>([]);
  const [showPaylinesDiagram, setShowPaylinesDiagram] = useState<boolean>(false);

  const spinSlots = () => {
    const finalBet = Number(slotBetInput) || slotBet;
    if (balance < finalBet || isSlotSpinning || finalBet < 5) return;

    onBetPlaced(finalBet);
    playClickSound(soundEnabled);
    playSpinSound(soundEnabled);
    setIsSlotSpinning(true);
    setSlotLastWin(null);
    setWinningLines([]);
    setSlotMessage('სლოტები ტრიალებს 5-ვე ლაინზე... 🔥');

    let counter = 0;
    const spinInterval = setInterval(() => {
      counter++;
      setSlotGrid([
        [SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)], SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)], SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)]],
        [SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)], SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)], SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)]],
        [SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)], SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)], SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)]]
      ]);

      if (counter > 15) {
        clearInterval(spinInterval);

        // Generate final 3x3 outcome using balanced casino reel distribution
        const REEL_POOL = [
          '🍒', '🍒', '🍒', '🍒',
          '🍋', '🍋', '🍋', '🍋',
          '🍇', '🍇', '🍇', '🍇',
          '🔔', '🔔', '🔔',
          '⚡', '⚡', '⚡',
          '💰', '💰',
          '🏎️', '🏎️',
          '👑',
          '💎',
          '7️⃣'
        ];

        const finalGrid: string[][] = [
          [REEL_POOL[Math.floor(Math.random() * REEL_POOL.length)], REEL_POOL[Math.floor(Math.random() * REEL_POOL.length)], REEL_POOL[Math.floor(Math.random() * REEL_POOL.length)]],
          [REEL_POOL[Math.floor(Math.random() * REEL_POOL.length)], REEL_POOL[Math.floor(Math.random() * REEL_POOL.length)], REEL_POOL[Math.floor(Math.random() * REEL_POOL.length)]],
          [REEL_POOL[Math.floor(Math.random() * REEL_POOL.length)], REEL_POOL[Math.floor(Math.random() * REEL_POOL.length)], REEL_POOL[Math.floor(Math.random() * REEL_POOL.length)]]
        ];

        setSlotGrid(finalGrid);
        setIsSlotSpinning(false);

        // Evaluate all 5 paylines!
        const lineBet = Math.max(1, Math.floor(finalBet / 5));
        const detectedWins: Array<{
          lineId: number;
          name: string;
          symbol: string;
          multiplier: number;
          payout: number;
          color: string;
          cells: [number, number][];
        }> = [];

        SLOT_PAYLINES.forEach((line) => {
          const [c1, c2, c3] = line.cells;
          const s1 = finalGrid[c1[0]][c1[1]];
          const s2 = finalGrid[c2[0]][c2[1]];
          const s3 = finalGrid[c3[0]][c3[1]];

          let lineMult = 0;
          let winSym = s1;

          // 3 of a kind matches
          if (s1 === s2 && s2 === s3) {
            if (s1 === '7️⃣') lineMult = 120;
            else if (s1 === '💎') lineMult = 70;
            else if (s1 === '👑') lineMult = 45;
            else if (s1 === '🏎️') lineMult = 32;
            else if (s1 === '💰') lineMult = 22;
            else if (s1 === '⚡') lineMult = 16;
            else if (s1 === '🔔') lineMult = 12;
            else if (s1 === '🍇') lineMult = 9;
            else if (s1 === '🍋') lineMult = 7;
            else if (s1 === '🍒') lineMult = 5;
          } else if (s1 === s2) {
            // 2 matching starting from 1st reel gives partial returns to stabilize balance
            if (s1 === '7️⃣') { lineMult = 6; winSym = '7️⃣7️⃣ (6x)'; }
            else if (s1 === '💎') { lineMult = 4.5; winSym = '💎💎 (4.5x)'; }
            else if (s1 === '👑') { lineMult = 3.5; winSym = '👑👑 (3.5x)'; }
            else if (s1 === '💰' || s1 === '🏎️') { lineMult = 2.5; winSym = `${s1}${s1} (2.5x)`; }
            else if (s1 === '🔔' || s1 === '⚡') { lineMult = 2.0; winSym = `${s1}${s1} (2x)`; }
            else { lineMult = 1.5; winSym = `${s1}${s1} (1.5x)`; }
          }

          if (lineMult > 0) {
            const payout = Math.floor(lineBet * lineMult);
            detectedWins.push({
              lineId: line.id,
              name: line.name,
              symbol: winSym,
              multiplier: lineMult,
              payout,
              color: line.color,
              cells: line.cells
            });
          }
        });

        // Rare full-screen jackpot; outcomes otherwise come directly from the reels.
        const flat = finalGrid.flat();
        const allSame = flat.every((s) => s === flat[0]);
        let totalWin = detectedWins.reduce((acc, w) => acc + w.payout, 0);

        if (allSame) {
          totalWin += finalBet * 150;
        }

        if (totalWin > 0) {
          playWinSound(soundEnabled);
          onWin(totalWin, Math.min(35, Math.floor(Math.sqrt(totalWin) * 1.1)));
          setSlotLastWin(totalWin);
          setWinningLines(detectedWins);

          if (allSame) {
            setSlotMessage(`🔥 FULL SCREEN MEGA JACKPOT! 9x ${flat[0]} — მოგება: +${formatLari(totalWin)}! 👑`);
          } else if (detectedWins.length > 1) {
            setSlotMessage(`💥 მულტი-მოგება ${detectedWins.length} ლაინზე! სულ: +${formatLari(totalWin)}! 🎰`);
          } else {
            setSlotMessage(`🎉 მოგება ${detectedWins[0].name}-ზე (${detectedWins[0].symbol}) — +${formatLari(totalWin)}!`);
          }
        } else {
          onLoss(finalBet);
          setSlotMessage('არცერთი ლაინი არ დაემთხვა. სცადე ხელახლა!');
        }
      }
    }, 75);
  };

  // ==========================================
  // 1. SAFE CRACKER (სეიფის გატეხვა)
  // ==========================================
  const [safeTier, setSafeTier] = useState<'easy' | 'medium' | 'hard'>('easy');
  const [safeTargetCode, setSafeTargetCode] = useState<string>('472');
  const [safeGuess, setSafeGuess] = useState<string>('');
  const [safeAttemptsLeft, setSafeAttemptsLeft] = useState<number>(4);
  const [safeLogs, setSafeLogs] = useState<string[]>([]);
  const [safeState, setSafeState] = useState<'IDLE' | 'CRACKING' | 'WON' | 'FAILED'>('IDLE');

  const safeConfig = {
    easy: { name: 'მიკრო სეიფი', bet: 50, win: 200, xp: 60, digits: 3, maxAttempts: 4 },
    medium: { name: 'ბანკის საცავი', bet: 300, win: 1500, xp: 250, digits: 4, maxAttempts: 5 },
    hard: { name: 'ოლიგარქის ბუნკერი', bet: 2000, win: 12000, xp: 1200, digits: 4, maxAttempts: 6 }
  };

  const startSafeCracker = () => {
    const cfg = safeConfig[safeTier];
    if (balance < cfg.bet) return;

    onBetPlaced(cfg.bet);
    playClickSound(soundEnabled);

    // Generate random secret code
    let code = '';
    for (let i = 0; i < cfg.digits; i++) {
      code += Math.floor(Math.random() * 10).toString();
    }

    setSafeTargetCode(code);
    setSafeGuess('');
    setSafeAttemptsLeft(cfg.maxAttempts);
    setSafeLogs([`სისტემა დაწყებულია. შეიყვანე ${cfg.digits}-ნიშნა კოდი.`]);
    setSafeState('CRACKING');
  };

  const handleKeypadPress = (digit: string) => {
    if (safeState !== 'CRACKING') return;
    const cfg = safeConfig[safeTier];
    if (safeGuess.length < cfg.digits) {
      playClickSound(soundEnabled);
      setSafeGuess((prev) => prev + digit);
    }
  };

  const handleKeypadClear = () => {
    playClickSound(soundEnabled);
    setSafeGuess('');
  };

  const handleKeypadSubmit = () => {
    const cfg = safeConfig[safeTier];
    if (safeGuess.length !== cfg.digits || safeState !== 'CRACKING') return;

    if (safeGuess === safeTargetCode) {
      // Crack Success!
      playWinSound(soundEnabled);
      setSafeState('WON');
      setSafeLogs((prev) => [`✅ კოდი ${safeGuess} სწორია! სეიფი გაიხსნა!`, ...prev]);
      onWin(cfg.win, cfg.xp);
      return;
    }

    // Evaluate proximity hint
    let correctDigits = 0;
    for (let i = 0; i < cfg.digits; i++) {
      if (safeGuess[i] === safeTargetCode[i]) correctDigits++;
    }

    const numericGuess = parseInt(safeGuess, 10);
    const numericTarget = parseInt(safeTargetCode, 10);
    const hint = numericGuess > numericTarget ? '🔻 უფრო ნაკლებია' : '🔺 უფრო მეტია';

    const newAttempts = safeAttemptsLeft - 1;
    setSafeAttemptsLeft(newAttempts);

    if (newAttempts <= 0) {
      // Failed!
      setSafeState('FAILED');
      setSafeLogs((prev) => [
        `❌ მცდელობები ამოიწურა. სწორი კოდი იყო: ${safeTargetCode}`,
        ...prev
      ]);
      onLoss(cfg.bet);
    } else {
      setSafeLogs((prev) => [
        `კოდი ${safeGuess}: ${correctDigits} ციფრი ადგილზეა · ${hint} (დარჩა: ${newAttempts})`,
        ...prev
      ]);
      setSafeGuess('');
    }
  };

  // ==========================================
  // 2. LUCKY WHEEL (იღბლის ბორბალი)
  // ==========================================
  const canvasWheelRef = useRef<HTMLCanvasElement>(null);
  const [wheelBet, setWheelBet] = useState<number>(50);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [wheelResultText, setWheelResultText] = useState<string>('');
  const currentAngleRef = useRef<number>(0);

  const WHEEL_SEGMENTS = [
    { label: '💀 წაგება (0x)', mult: 0, color: '#1e293b' },
    { label: '1.5x', mult: 1.5, color: '#065f46' },
    { label: '2.0x', mult: 2.0, color: '#047857' },
    { label: '💀 წაგება (0x)', mult: 0, color: '#1e293b' },
    { label: '3.0x', mult: 3.0, color: '#059669' },
    { label: '💀 წაგება (0x)', mult: 0, color: '#1e293b' },
    { label: '5.0x', mult: 5.0, color: '#d97706' },
    { label: '10.0x', mult: 10.0, color: '#b45309' },
    { label: '2.5x', mult: 2.5, color: '#047857' },
    { label: '👑 50x JACKPOT', mult: 50.0, color: '#e11d48' }
  ];

  const drawWheel = (angle: number) => {
    const canvas = canvasWheelRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = canvas.width;
    const radius = size / 2 - 12;
    const center = size / 2;
    const numSegments = WHEEL_SEGMENTS.length;
    const arc = (Math.PI * 2) / numSegments;

    ctx.clearRect(0, 0, size, size);

    // Draw Wheel slices
    ctx.save();
    ctx.translate(center, center);
    ctx.rotate(angle);

    WHEEL_SEGMENTS.forEach((seg, i) => {
      const segAngle = i * arc;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, radius, segAngle, segAngle + arc);
      ctx.fillStyle = seg.color;
      ctx.fill();
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Label text
      ctx.save();
      ctx.rotate(segAngle + arc / 2);
      ctx.textAlign = 'right';
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 12px monospace';
      ctx.fillText(seg.label, radius - 18, 4);
      ctx.restore();
    });

    // Outer rim glow
    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 4;
    ctx.stroke();

    // Center pin
    ctx.beginPath();
    ctx.arc(0, 0, 18, 0, Math.PI * 2);
    ctx.fillStyle = '#0f172a';
    ctx.fill();
    ctx.strokeStyle = '#fbbf24';
    ctx.lineWidth = 3;
    ctx.stroke();

    ctx.restore();

    // Draw fixed pointer at top
    ctx.beginPath();
    ctx.moveTo(center - 10, 12);
    ctx.lineTo(center + 10, 12);
    ctx.lineTo(center, 34);
    ctx.closePath();
    ctx.fillStyle = '#ef4444';
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.stroke();
  };

  useEffect(() => {
    drawWheel(0);
  }, []);

  const spinWheel = () => {
    if (balance < wheelBet || isSpinning) return;

    onBetPlaced(wheelBet);
    setIsSpinning(true);
    setWheelResultText('');
    playSpinSound(soundEnabled);

    // Pick target segment
    const targetIdx = Math.floor(Math.random() * WHEEL_SEGMENTS.length);
    const numSegments = WHEEL_SEGMENTS.length;
    const arc = (Math.PI * 2) / numSegments;

    // Desired final absolute angle where targetIdx center lands directly under 12 o'clock (-PI/2)
    const pointerOffset = -Math.PI / 2;
    const sliceCenterAngle = (targetIdx + 0.5) * arc;
    const desiredFinalNormalized = ((pointerOffset - sliceCenterAngle) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
    const currentNormalized = (currentAngleRef.current % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
    let diff = desiredFinalNormalized - currentNormalized;
    if (diff <= 0) diff += Math.PI * 2;
    const totalRotation = diff + Math.PI * 2 * 6; // 6 full rotations

    const startAngle = currentAngleRef.current;
    const duration = 4000;
    const startTime = performance.now();

    const animateSpin = (now: number) => {
      const elapsed = now - startTime;
      const t = Math.min(1, elapsed / duration);
      // Ease out cubic
      const ease = 1 - Math.pow(1 - t, 3);
      const cur = startAngle + totalRotation * ease;
      currentAngleRef.current = cur;
      drawWheel(cur);

      if (t < 1) {
        requestAnimationFrame(animateSpin);
      } else {
        setIsSpinning(false);
        // Guarantee exact synchronization with chosen target segment
        const wonSegment = WHEEL_SEGMENTS[targetIdx];
        const finalSnapAngle = pointerOffset - (targetIdx + 0.5) * arc;
        currentAngleRef.current = finalSnapAngle;
        drawWheel(finalSnapAngle);

        if (wonSegment && wonSegment.mult > 0) {
          const winAmount = Math.floor(wheelBet * wonSegment.mult);
          playWinSound(soundEnabled);
          setWheelResultText(`🎉 გილოცავ! მოიგე: ${formatLari(winAmount)} (${wonSegment.label})`);
          onWin(winAmount, Math.floor(wonSegment.mult * 20));
        } else {
          // Absolute loss - zero money awarded!
          playClickSound(soundEnabled);
          setWheelResultText(`💀 წააგე: 0 ₾ (${wonSegment ? wonSegment.label : 'წაგება'}). ფსონი დაკარგულია!`);
          onLoss(wheelBet);
        }
      }
    };

    requestAnimationFrame(animateSpin);
  };

  // ==========================================
  // 3. BLACKJACK 21 კლუბი
  // ==========================================
  interface Card {
    suit: string;
    value: string;
    num: number;
  }
  const [bjBet, setBjBet] = useState<number>(100);
  const [bjState, setBjState] = useState<'BETTING' | 'PLAYING' | 'ENDED'>('BETTING');
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [dealerHand, setDealerHand] = useState<Card[]>([]);
  const [bjMessage, setBjMessage] = useState<string>('');

  const createDeck = (): Card[] => {
    const suits = ['♠', '♥', '♦', '♣'];
    const values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
    const deck: Card[] = [];
    for (const suit of suits) {
      for (const value of values) {
        let num = parseInt(value, 10);
        if (['J', 'Q', 'K'].includes(value)) num = 10;
        if (value === 'A') num = 11;
        deck.push({ suit, value, num });
      }
    }
    return deck.sort(() => Math.random() - 0.5);
  };

  const calcHandScore = (hand: Card[]): number => {
    let score = hand.reduce((acc, c) => acc + c.num, 0);
    let aces = hand.filter((c) => c.value === 'A').length;
    while (score > 21 && aces > 0) {
      score -= 10;
      aces--;
    }
    return score;
  };

  const startBlackjack = () => {
    if (balance < bjBet) return;
    onBetPlaced(bjBet);
    playCardSound(soundEnabled);

    const deck = createDeck();
    const p1 = deck.pop()!;
    const d1 = deck.pop()!;
    const p2 = deck.pop()!;
    const d2 = deck.pop()!;

    const initialPlayer = [p1, p2];
    const initialDealer = [d1, d2];

    setPlayerHand(initialPlayer);
    setDealerHand(initialDealer);
    setBjState('PLAYING');
    setBjMessage('');

    if (calcHandScore(initialPlayer) === 21) {
      // Natural Blackjack
      playWinSound(soundEnabled);
      setBjState('ENDED');
      const winAmount = Math.floor(bjBet * 2.5);
      setBjMessage(`ბლექჯეკი! მოიგე: ${formatLari(winAmount)}`);
      onWin(winAmount, 150);
    }
  };

  const hitBlackjack = () => {
    if (bjState !== 'PLAYING') return;
    playCardSound(soundEnabled);
    const deck = createDeck();
    const newCard = deck.pop()!;
    const nextHand = [...playerHand, newCard];
    setPlayerHand(nextHand);

    const score = calcHandScore(nextHand);
    if (score > 21) {
      setBjState('ENDED');
      setBjMessage('გადაცილება! 21-ს გადააჭარბე.');
      onLoss(bjBet);
    }
  };

  const standBlackjack = () => {
    if (bjState !== 'PLAYING') return;
    playCardSound(soundEnabled);

    // Dealer turn: hits until >= 17
    let currentDealer = [...dealerHand];
    const deck = createDeck();
    while (calcHandScore(currentDealer) < 17) {
      currentDealer.push(deck.pop()!);
    }

    setDealerHand(currentDealer);
    setBjState('ENDED');

    const pScore = calcHandScore(playerHand);
    const dScore = calcHandScore(currentDealer);

    if (dScore > 21 || pScore > dScore) {
      playWinSound(soundEnabled);
      const winAmount = Math.floor(bjBet * 2);
      setBjMessage(`მოიგე! დილერს აქვს ${dScore}, შენ გაქვს ${pScore}`);
      onWin(winAmount, 80);
    } else if (pScore === dScore) {
      setBjMessage(`ფრე (Push)! ფსონი დაბრუნდა (${formatLari(bjBet)})`);
      onWin(bjBet, 20);
    } else {
      setBjMessage(`წაგება! დილერმა გაჯობა (${dScore} vs ${pScore})`);
      onLoss(bjBet);
    }
  };

  // ==========================================
  // 4. COIN FLIP (ორბი თუ გერბი)
  // ==========================================
  const [coinBet, setCoinBet] = useState<number>(50);
  const [coinSide, setCoinSide] = useState<'eagle' | 'shield'>('eagle');
  const [coinStreak, setCoinStreak] = useState<number>(0);
  const [coinFlipping, setCoinFlipping] = useState<boolean>(false);
  const [coinResult, setCoinResult] = useState<'eagle' | 'shield' | null>(null);

  const flipCoin = () => {
    if (balance < coinBet && coinStreak === 0) return;
    if (coinFlipping) return;

    if (coinStreak === 0) {
      onBetPlaced(coinBet);
    }

    setCoinFlipping(true);
    playClickSound(soundEnabled);

    setTimeout(() => {
      const outcome: 'eagle' | 'shield' = Math.random() > 0.5 ? 'eagle' : 'shield';
      setCoinResult(outcome);
      setCoinFlipping(false);

      if (outcome === coinSide) {
        // Correct guess
        playCashSound(soundEnabled);
        setCoinStreak((s) => s + 1);
      } else {
        // Lost
        onLoss(coinBet);
        setCoinStreak(0);
      }
    }, 1000);
  };

  const cashOutCoin = () => {
    if (coinStreak === 0) return;
    const payout = Math.floor(coinBet * Math.pow(1.95, coinStreak));
    playWinSound(soundEnabled);
    onWin(payout, coinStreak * 40);
    setCoinStreak(0);
  };

  // ==========================================
  // 5. NEON CRAPS / STREET DICE (ქუჩის კამათლები)
  // ==========================================
  const [diceBet, setDiceBet] = useState<number>(100);
  const [diceBetType, setDiceBetType] = useState<'seven' | 'high' | 'low' | 'doubles'>('seven');
  const [dice1, setDice1] = useState<number>(3);
  const [dice2, setDice2] = useState<number>(4);
  const [diceRolling, setDiceRolling] = useState<boolean>(false);
  const [diceMessage, setDiceMessage] = useState<string>('აირჩიე ფსონი და გააგორე კამათლები');

  const rollDice = () => {
    if (balance < diceBet || diceRolling) return;
    onBetPlaced(diceBet);
    playClickSound(soundEnabled);
    setDiceRolling(true);
    setDiceMessage('კამათლები გორდება...');

    let rollsCount = 0;
    const interval = setInterval(() => {
      setDice1(Math.floor(Math.random() * 6) + 1);
      setDice2(Math.floor(Math.random() * 6) + 1);
      rollsCount++;
      if (rollsCount > 10) {
        clearInterval(interval);
        const final1 = Math.floor(Math.random() * 6) + 1;
        const final2 = Math.floor(Math.random() * 6) + 1;
        setDice1(final1);
        setDice2(final2);
        setDiceRolling(false);

        const sum = final1 + final2;
        const isDouble = final1 === final2;

        let won = false;
        let mult = 0;

        if (diceBetType === 'seven' && sum === 7) {
          won = true;
          mult = 4.5;
        } else if (diceBetType === 'high' && sum >= 8) {
          won = true;
          mult = 2.0;
        } else if (diceBetType === 'low' && sum <= 6) {
          won = true;
          mult = 2.0;
        } else if (diceBetType === 'doubles' && isDouble) {
          won = true;
          mult = 5.8;
        }

        if (won) {
          const payout = Math.floor(diceBet * mult);
          playWinSound(soundEnabled);
          onWin(payout, Math.floor(mult * 30));
          setDiceMessage(`🎉 მოიგე! კამათლების ჯამია ${sum} (${final1}+${final2}). მოგება: +${formatLari(payout)}!`);
        } else {
          onLoss(diceBet);
          setDiceMessage(`სამწუხაროდ წააგე. ჯამია ${sum} (${final1}+${final2}). სცადე ხელახლა!`);
        }
      }
    }, 100);
  };

  // ==========================================
  // 6. THIMBLES / STREET CUPS (ქუჩის ჭიქები)
  // ==========================================
  const [thimblesBet, setThimblesBet] = useState<number>(100);
  const [diamondIndex, setDiamondIndex] = useState<number>(1);
  const [pickedCup, setPickedCup] = useState<number | null>(null);
  const [thimblesState, setThimblesState] = useState<'IDLE' | 'SHUFFLING' | 'WAITING' | 'REVEALED'>('IDLE');
  const [thimblesMessage, setThimblesMessage] = useState<string>('ჩადე ფსონი და დააჭირე ჭიქების არევას');

  const startThimbles = () => {
    if (balance < thimblesBet || thimblesState === 'SHUFFLING') return;
    onBetPlaced(thimblesBet);
    playClickSound(soundEnabled);
    setPickedCup(null);
    setThimblesState('SHUFFLING');
    setThimblesMessage('ჭიქები ირევა... თვალი ადევნე!');

    const secret = Math.floor(Math.random() * 3);
    setDiamondIndex(secret);

    setTimeout(() => {
      setThimblesState('WAITING');
      setThimblesMessage('აირჩიე ერთ-ერთი ჭიქა!');
    }, 1500);
  };

  const handlePickCup = (index: number) => {
    if (thimblesState !== 'WAITING') return;
    playClickSound(soundEnabled);
    setPickedCup(index);
    setThimblesState('REVEALED');

    if (index === diamondIndex) {
      const payout = Math.floor(thimblesBet * 2.9);
      playWinSound(soundEnabled);
      onWin(payout, 120);
      setThimblesMessage(`🎉 ბრილიანტი იპოვე! შენი მოგებაა: +${formatLari(payout)}!`);
    } else {
      onLoss(thimblesBet);
      setThimblesMessage(`ჭიქა ცარიელი აღმოჩნდა! ბრილიანტი იყო №${diamondIndex + 1} ჭიქის ქვეშ.`);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-5 space-y-5">
      {/* Game Selector Tab */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 bg-[#0c0d14] border border-slate-800 rounded-2xl">
        <button
          onClick={() => setActiveGame('slots')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
            activeGame === 'slots'
              ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 shadow-lg font-black'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
          }`}
        >
          <span className="text-base">🎰</span>
          <span>კაზინო</span>
        </button>
        <button
          onClick={() => setActiveGame('wheel')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
            activeGame === 'wheel'
              ? 'bg-amber-500 text-slate-950 shadow-md'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
          }`}
        >
          <RotateCw className="w-4 h-4" />
          <span>იღბლის ბორბალი</span>
        </button>
        <button
          onClick={() => setActiveGame('blackjack')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
            activeGame === 'blackjack'
              ? 'bg-blue-500 text-slate-950 shadow-md'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>21 კლუბი</span>
        </button>
        <button
          onClick={() => setActiveGame('coin')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
            activeGame === 'coin'
              ? 'bg-purple-500 text-slate-950 shadow-md'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
          }`}
        >
          <Coins className="w-4 h-4" />
          <span>ორბი თუ გერბი</span>
        </button>
        <button
          onClick={() => setActiveGame('dice')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
            activeGame === 'dice'
              ? 'bg-rose-500 text-slate-950 shadow-md'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
          }`}
        >
          <Dices className="w-4 h-4" />
          <span>ქუჩის კამათლები</span>
        </button>
        <button
          onClick={() => setActiveGame('thimbles')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
            activeGame === 'thimbles'
              ? 'bg-teal-500 text-slate-950 shadow-md'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>ქუჩის ჭიქები</span>
        </button>
      </div>

      <div className="rounded-2xl border border-cyan-400/20 bg-cyan-950/20 px-4 py-3 text-xs leading-relaxed text-cyan-100/90">
        <b className="text-cyan-200">თამაშის წესები:</b>{' '}
        {activeGame === 'slots' ? 'სლოტზე ფსონი იყოფა 5 ხაზზე. მოგება გაიცემა მხოლოდ ხაზზე სამი ერთნაირი სიმბოლოს დამთხვევისას; იშვიათი 9 სიმბოლოს ჯეკპოტი 150x-ია.' :
          activeGame === 'wheel' ? 'აირჩიე ფერის ან რიცხვის ფსონი და დაატრიალე ბორბალი. მოგება დამოკიდებულია დამთხვევასა და ნაჩვენებ კოეფიციენტზე.' :
          activeGame === 'blackjack' ? 'შეეცადე 21-ს მიუახლოვდე გადაცილების გარეშე. ბოტის ქულას თუ აჯობებ, იგებ; ფრე ფსონს აბრუნებს.' :
          activeGame === 'coin' ? 'აირჩიე ორბი ან გერბი. სწორ გამოცნობაზე მიიღებ ნაჩვენებ მოგებას, არასწორზე ფსონი იკარგება.' :
          activeGame === 'dice' ? 'აირჩიე კამათლის შედეგის დიაპაზონი და დადე ფსონი. ვიწრო დიაპაზონი იშვიათია, მაგრამ მეტს იხდის.' :
          'აირჩიე ჭიქა, რომლის ქვეშაც ბრილიანტია. ერთი სწორი არჩევანია; არასწორ არჩევანზე ფსონს კარგავ.'}
      </div>

      {/* 0. ROYAL 777 5-LINE DELUXE SLOTS GAME */}
      {activeGame === 'slots' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Slots Machine Display (8 cols) */}
          <div className="lg:col-span-8 bg-gradient-to-b from-[#14121e] via-[#0d0d16] to-[#08080f] border-2 border-amber-500/40 rounded-3xl p-5 sm:p-7 space-y-5 shadow-[0_0_50px_rgba(245,158,11,0.2)]">
            <div className="flex items-center justify-between pb-3 border-b border-amber-500/20">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center font-bold text-2xl shadow-lg">
                  🎰
                </div>
                <div>
                  <h3 className="font-black text-lg text-white flex items-center gap-2">
                    <span>კაზინო — 5 PAYLINES DELUXE</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 font-black uppercase tracking-wider">
                      5 ლაინიანი კლასიკა
                    </span>
                  </h3>
                  <span className="text-xs text-amber-300/80 font-mono">
                    3 ჰორიზონტალი + 2 დიაგონალი • 7️⃣7️⃣7️⃣ x120 ჯეკპოტი!
                  </span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">ბალანსი</span>
                <span className="font-mono font-black text-emerald-400 text-base">
                  {formatLari(balance)}
                </span>
              </div>
            </div>

            {/* 3x3 Reels Cabinet with 5 Line Indicators */}
            <div className="relative p-3 sm:p-6 rounded-2xl bg-black/90 border-4 border-amber-500/60 shadow-[inset_0_0_50px_rgba(0,0,0,0.95)] flex items-center justify-center gap-2 sm:gap-4 overflow-hidden">
              <div className="absolute inset-x-0 top-0 h-4 bg-gradient-to-b from-amber-500/25 to-transparent pointer-events-none z-10" />
              <div className="absolute inset-x-0 bottom-0 h-4 bg-gradient-to-t from-amber-500/25 to-transparent pointer-events-none z-10" />

              {/* Left Line Tags Column */}
              <div className="flex flex-col justify-around h-full py-3 gap-2 sm:gap-3 z-10 shrink-0">
                {SLOT_PAYLINES.map((line) => {
                  const isWinning = winningLines.some((w) => w.lineId === line.id);
                  return (
                    <div
                      key={`left_${line.id}`}
                      className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center font-mono font-black text-[10px] sm:text-xs border transition-all ${
                        isWinning
                          ? 'scale-110 shadow-lg text-slate-950 animate-bounce'
                          : 'bg-slate-900/80 border-slate-700 text-slate-300 opacity-70'
                      }`}
                      style={{
                        backgroundColor: isWinning ? line.color : undefined,
                        borderColor: line.color,
                        boxShadow: isWinning ? `0 0 15px ${line.color}` : undefined
                      }}
                      title={`${line.name} (ხაზი ${line.id})`}
                    >
                      {line.shortName}
                    </div>
                  );
                })}
              </div>

              {/* 3x3 Grid Matrix */}
              <div className="grid grid-rows-3 gap-2 sm:gap-3.5 flex-1 max-w-lg">
                {[0, 1, 2].map((rowIndex) => (
                  <div key={rowIndex} className="grid grid-cols-3 gap-2 sm:gap-3.5">
                    {[0, 1, 2].map((colIndex) => {
                      const symbol = slotGrid[rowIndex][colIndex];
                      const matchedWinningLine = winningLines.find((w) =>
                        w.cells.some(([r, c]) => r === rowIndex && c === colIndex)
                      );

                      return (
                        <div
                          key={`${rowIndex}_${colIndex}`}
                          className={`h-20 sm:h-24 md:h-28 rounded-2xl bg-gradient-to-b from-slate-900 via-[#0a0b12] to-slate-900 border-2 flex items-center justify-center text-4xl sm:text-5xl select-none transition-all shadow-2xl relative ${
                            isSlotSpinning
                              ? 'border-amber-400/80 animate-pulse scale-95 blur-[0.4px]'
                              : matchedWinningLine
                              ? 'scale-105 z-10'
                              : 'border-slate-800/90'
                          }`}
                          style={{
                            borderColor: matchedWinningLine ? matchedWinningLine.color : undefined,
                            boxShadow: matchedWinningLine
                              ? `0 0 25px ${matchedWinningLine.color}, inset 0 0 15px ${matchedWinningLine.color}40`
                              : undefined
                          }}
                        >
                          <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-white/10 rounded-2xl pointer-events-none" />
                          <span className={isSlotSpinning ? 'animate-bounce' : ''}>
                            {symbol}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>

              {/* Right Line Tags Column */}
              <div className="flex flex-col justify-around h-full py-3 gap-2 sm:gap-3 z-10 shrink-0">
                {SLOT_PAYLINES.map((line) => {
                  const isWinning = winningLines.some((w) => w.lineId === line.id);
                  return (
                    <div
                      key={`right_${line.id}`}
                      className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center font-mono font-black text-[10px] sm:text-xs border transition-all ${
                        isWinning
                          ? 'scale-110 shadow-lg text-slate-950 animate-bounce'
                          : 'bg-slate-900/80 border-slate-700 text-slate-300 opacity-70'
                      }`}
                      style={{
                        backgroundColor: isWinning ? line.color : undefined,
                        borderColor: line.color,
                        boxShadow: isWinning ? `0 0 15px ${line.color}` : undefined
                      }}
                      title={`${line.name} (ხაზი ${line.id})`}
                    >
                      {line.shortName}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Winning Lines Breakdown Chips */}
            {winningLines.length > 0 && (
              <div className="p-3 rounded-2xl bg-slate-950/90 border border-emerald-500/40 space-y-2 animate-in fade-in zoom-in-95 duration-200">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="font-bold text-emerald-400 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>მოგებული ლაინები ({winningLines.length}):</span>
                  </span>
                  <span className="font-black text-emerald-300">
                    სულ: +{formatLari(slotLastWin || 0)}
                  </span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {winningLines.map((w, idx) => (
                    <div
                      key={idx}
                      className="px-2.5 py-1 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 border shadow-sm"
                      style={{
                        backgroundColor: `${w.color}20`,
                        borderColor: w.color,
                        color: w.color
                      }}
                    >
                      <span>{w.name}:</span>
                      <span>{w.symbol}</span>
                      <span className="text-white font-extrabold">+{formatLari(w.payout)}</span>
                      <span className="text-[10px] opacity-80">(x{w.multiplier})</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Status / Message Display */}
            <div
              className={`p-3.5 rounded-xl border text-center font-bold text-xs sm:text-sm transition-all ${
                slotLastWin
                  ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300 shadow-[0_0_20px_rgba(16,185,129,0.3)]'
                  : 'bg-slate-900/80 border-slate-800 text-slate-300'
              }`}
            >
              {slotMessage}
            </div>

            {/* Bet Controls & Spin Action */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1 flex-1">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>სრული ფსონი (5 ლაინი)</span>
                    <span className="font-mono text-emerald-400 font-bold">
                      {formatLari(Number(slotBetInput) || slotBet)} (თითო ლაინზე: {formatLari(Math.max(1, Math.floor((Number(slotBetInput) || slotBet) / 5)))})
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      type="text"
                      inputMode="numeric"
                      value={slotBetInput}
                      disabled={isSlotSpinning}
                      onChange={(e) => {
                        const clean = e.target.value.replace(/[^0-9]/g, '');
                        setSlotBetInput(clean);
                        const num = Number(clean);
                        if (!isNaN(num) && num > 0) setSlotBet(num);
                      }}
                      onBlur={() => {
                        const num = Number(slotBetInput);
                        if (!slotBetInput || isNaN(num) || num < 5) {
                          setSlotBet(5);
                          setSlotBetInput('5');
                        } else if (num > balance) {
                          const capped = Math.max(5, Math.floor(balance));
                          setSlotBet(capped);
                          setSlotBetInput(capped.toString());
                        }
                      }}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 focus:border-amber-400 focus:outline-none text-base font-mono font-bold text-slate-100 disabled:opacity-50"
                      placeholder="ფსონი (მინ. 5 ₾)"
                    />
                    <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-sm font-bold text-amber-400">
                      ₾
                    </span>
                  </div>
                </div>

                {/* Preset Chips */}
                <div className="flex flex-wrap gap-1.5 sm:self-end">
                  {[25, 50, 100, 250, 500].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      disabled={isSlotSpinning}
                      onClick={() => {
                        setSlotBet(amt);
                        setSlotBetInput(amt.toString());
                      }}
                      className={`px-3 py-2 rounded-xl text-xs font-mono font-bold transition-all border ${
                        (Number(slotBetInput) || slotBet) === amt
                          ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-sm'
                          : 'bg-slate-900 text-slate-400 hover:text-white border-slate-800'
                      }`}
                    >
                      {amt}₾
                    </button>
                  ))}
                  <button
                    type="button"
                    disabled={isSlotSpinning}
                    onClick={() => {
                      const maxBet = Math.max(5, Math.floor(balance));
                      setSlotBet(maxBet);
                      setSlotBetInput(maxBet.toString());
                    }}
                    className="px-3 py-2 rounded-xl text-xs font-mono font-black bg-slate-900 text-amber-400 border border-slate-800 hover:border-amber-500"
                  >
                    MAX
                  </button>
                </div>
              </div>

              {/* Big Golden 5-Line Spin Button */}
              <button
                type="button"
                disabled={isSlotSpinning || balance < (Number(slotBetInput) || slotBet)}
                onClick={spinSlots}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 hover:via-yellow-300 hover:to-amber-400 active:scale-98 text-slate-950 font-black text-base sm:text-lg tracking-wider uppercase shadow-[0_0_30px_rgba(245,158,11,0.5)] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <span>🎰</span>
                <span>{isSlotSpinning ? '5 ლაინი ტრიალებს...' : 'დაატრიალე 5 ლაინი (SPIN)'}</span>
              </button>
            </div>
          </div>

          {/* Paytable & 5-Line Diagram Sidebar (4 cols) */}
          <div className="lg:col-span-4 bg-[#0c0d14] border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4 shadow-xl">
            {/* Diagram / Paytable Tab Switcher */}
            <div className="flex items-center gap-1.5 p-1 bg-slate-900 rounded-xl border border-slate-800">
              <button
                type="button"
                onClick={() => setShowPaylinesDiagram(false)}
                className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                  !showPaylinesDiagram
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                გადახდის ცხრილი
              </button>
              <button
                type="button"
                onClick={() => setShowPaylinesDiagram(true)}
                className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                  showPaylinesDiagram
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                5 ლაინის სქემა
              </button>
            </div>

            {/* View 1: 5 Lines Diagram */}
            {showPaylinesDiagram ? (
              <div className="space-y-3 animate-in fade-in duration-200">
                <span className="text-xs text-slate-400 block font-mono">
                  თამაში ითვლის 5 აქტიურ ხაზს (ლაინს) ერთდროულად:
                </span>
                <div className="space-y-2">
                  {SLOT_PAYLINES.map((line) => (
                    <div
                      key={line.id}
                      className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between text-xs font-mono"
                    >
                      <div className="flex items-center gap-2.5">
                        <span
                          className="w-6 h-6 rounded-md flex items-center justify-center font-bold text-slate-950 text-xs shadow-sm"
                          style={{ backgroundColor: line.color }}
                        >
                          {line.shortName}
                        </span>
                        <span className="text-slate-200 font-semibold">{line.name}</span>
                      </div>
                      <span className="text-[11px] text-slate-500">
                        {line.id === 1 ? 'შუა რიგი' : line.id === 2 ? 'ზედა რიგი' : line.id === 3 ? 'ქვედა რიგი' : line.id === 4 ? '↘ დიაგონალი' : '↗ დიაგონალი'}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-400 font-mono">
                  💡 თუ რამდენიმე ლაინზე ერთდროულად დაჯდება მომგებიანი კომბინაცია, ყველა მოგება იკრიბება და ემატება ბალანსს!
                </div>
              </div>
            ) : (
              /* View 2: Multipliers Paytable */
              <div className="space-y-2 text-xs animate-in fade-in duration-200">
                <div className="p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-between">
                  <span className="font-bold text-slate-100 flex items-center gap-1.5">
                    <span className="text-lg">7️⃣ 7️⃣ 7️⃣</span>
                    <span>სამმაგი შვიდიანი</span>
                  </span>
                  <span className="font-mono font-black text-amber-400 text-sm">x100 JACKPOT</span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-200 flex items-center gap-1.5">
                    <span className="text-lg">💎 💎 💎</span>
                    <span>ბრილიანტები</span>
                  </span>
                  <span className="font-mono font-bold text-cyan-400">x50</span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-200 flex items-center gap-1.5">
                    <span className="text-lg">👑 👑 👑</span>
                    <span>ოქროს გვირგვინი</span>
                  </span>
                  <span className="font-mono font-bold text-amber-300">x35</span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-200 flex items-center gap-1.5">
                    <span className="text-lg">🏎️ 🏎️ 🏎️</span>
                    <span>სუპერქარები</span>
                  </span>
                  <span className="font-mono font-bold text-emerald-400">x25</span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-200 flex items-center gap-1.5">
                    <span className="text-lg">💰 💰 💰</span>
                    <span>ფულის ტომარა</span>
                  </span>
                  <span className="font-mono font-bold text-emerald-400">x18</span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-200 flex items-center gap-1.5">
                    <span className="text-lg">⚡ ⚡ ⚡</span>
                    <span>ელვა</span>
                  </span>
                  <span className="font-mono font-bold text-yellow-400">x12</span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-200 flex items-center gap-1.5">
                    <span className="text-lg">🍒 🍒 🍒</span>
                    <span>ალუბალი (3 ცალი)</span>
                  </span>
                  <span className="font-mono font-bold text-rose-400">x8</span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/60 flex items-center justify-between text-slate-400">
                  <span>ნებისმიერი 2 ალუბალი ლაინზე</span>
                  <span className="font-mono font-bold text-slate-300">x2.5</span>
                </div>

                <div className="p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-between text-purple-300">
                  <span className="font-bold">🔥 9-ვე ერთნაირი (FULL SCREEN)</span>
                  <span className="font-mono font-black text-purple-400">+x150 BONUS</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 1. SAFE CRACKER GAME */}
      {activeGame === 'safe' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-7 bg-[#0c0d14] border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base text-slate-100 flex items-center gap-2">
                  <Lock className="w-5 h-5 text-emerald-400" />
                  <span>ქალაქის სეიფის გატეხვა</span>
                </h3>
                <span className="text-xs text-slate-400">
                  გამოიცანი ციფრული კომბინაცია მინიშნებების დახმარებით
                </span>
              </div>

              {/* Tier selector */}
              <div className="flex gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
                {(['easy', 'medium', 'hard'] as const).map((t) => (
                  <button
                    key={t}
                    disabled={safeState === 'CRACKING'}
                    onClick={() => setSafeTier(t)}
                    className={`px-2.5 py-1 rounded-lg font-bold transition-colors ${
                      safeTier === t
                        ? 'bg-emerald-500 text-slate-950'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {t === 'easy' ? 'მარტივი' : t === 'medium' ? 'საშუალო' : 'რთული'}
                  </button>
                ))}
              </div>
            </div>

            {/* Display screen */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center font-mono">
              <span className="text-xs text-slate-500 block mb-1">
                დარჩენილი მცდელობები: {safeAttemptsLeft}
              </span>
              <div className="text-4xl sm:text-5xl font-extrabold tracking-widest text-emerald-400 h-14 flex items-center justify-center">
                {safeGuess
                  ? safeGuess.padEnd(safeConfig[safeTier].digits, '·')
                  : '·'.repeat(safeConfig[safeTier].digits)}
              </div>
            </div>

            {/* Keypad */}
            <div className="grid grid-cols-3 gap-2 max-w-xs mx-auto">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', 'OK'].map((btn) => (
                <button
                  key={btn}
                  type="button"
                  disabled={safeState !== 'CRACKING'}
                  onClick={() => {
                    if (btn === 'C') handleKeypadClear();
                    else if (btn === 'OK') handleKeypadSubmit();
                    else handleKeypadPress(btn);
                  }}
                  className={`py-3 rounded-xl font-mono text-base font-bold transition-all ${
                    btn === 'OK'
                      ? 'bg-emerald-500 text-slate-950 hover:bg-emerald-400 disabled:opacity-40'
                      : btn === 'C'
                      ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30 hover:bg-rose-500/30 disabled:opacity-40'
                      : 'bg-slate-900 text-slate-200 border border-slate-800 hover:border-slate-700 disabled:opacity-40'
                  }`}
                >
                  {btn}
                </button>
              ))}
            </div>

            {/* Trigger start button */}
            <div className="pt-2">
              <button
                type="button"
                disabled={safeState === 'CRACKING' || balance < safeConfig[safeTier].bet}
                onClick={startSafeCracker}
                className={`w-full py-3 rounded-xl font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 ${
                  safeState === 'CRACKING' || balance < safeConfig[safeTier].bet
                    ? 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
                    : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/20 active:scale-95'
                }`}
              >
                <Unlock className="w-4 h-4" />
                <span>
                  {safeState === 'CRACKING'
                    ? 'სეიფი აქტიურია...'
                    : `გატეხვის დაწყება (${formatLari(safeConfig[safeTier].bet)})`}
                </span>
              </button>
            </div>
          </div>

          {/* Logs & Payouts */}
          <div className="lg:col-span-5 bg-[#0c0d14] border border-slate-800 rounded-2xl p-5 flex flex-col justify-between shadow-xl">
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="font-bold text-xs uppercase tracking-wider text-slate-300">
                  ჯილდო & დეტალები
                </span>
                <span className="text-xs font-mono font-bold text-emerald-400">
                  მოგება: +{formatLari(safeConfig[safeTier].win)}
                </span>
              </div>

              <div className="space-y-1.5 text-xs text-slate-400 leading-relaxed">
                <div className="flex justify-between">
                  <span>სეიფის ტიპი:</span>
                  <span className="text-slate-200 font-bold">{safeConfig[safeTier].name}</span>
                </div>
                <div className="flex justify-between">
                  <span>ციფრების რაოდენობა:</span>
                  <span className="text-slate-200 font-bold">{safeConfig[safeTier].digits} ნიშნა</span>
                </div>
                <div className="flex justify-between">
                  <span>ბონუს XP:</span>
                  <span className="text-amber-400 font-mono font-bold">+{safeConfig[safeTier].xp} XP</span>
                </div>
              </div>

              {/* Cracking Event Logs */}
              <div className="pt-2">
                <span className="text-xs font-bold text-slate-400 block mb-2">
                  სკანირების ისტორია:
                </span>
                <div className="h-44 overflow-y-auto p-2.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5 text-xs font-mono">
                  {safeLogs.map((log, idx) => (
                    <div key={idx} className="text-slate-300 leading-tight">
                      {log}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. LUCKY WHEEL GAME */}
      {activeGame === 'wheel' && (
        <div className="bg-[#0c0d14] border border-slate-800 rounded-2xl p-6 shadow-xl max-w-3xl mx-auto flex flex-col items-center gap-6">
          <div className="text-center">
            <h3 className="font-bold text-lg text-slate-100 flex items-center justify-center gap-2">
              <RotateCw className="w-5 h-5 text-amber-400" />
              <span>იღბლის ნეონ ბორბალი</span>
            </h3>
            <span className="text-xs text-slate-400">
              დაატრიალე და მოიგე 50x-მდე ჯეკპოტი მომენტალურად!
            </span>
          </div>

          <div className="relative w-[300px] h-[300px]">
            <canvas ref={canvasWheelRef} width={300} height={300} className="w-full h-full" />
          </div>

          {wheelResultText && (
            <div className="px-4 py-2 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold text-sm text-center">
              {wheelResultText}
            </div>
          )}

          {/* Wheel Controls */}
          <div className="w-full max-w-sm space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>ფსონი:</span>
              <div className="flex gap-1.5 font-mono">
                {[20, 50, 100, 500].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    disabled={isSpinning}
                    onClick={() => setWheelBet(amt)}
                    className={`px-2 py-0.5 rounded-md border text-xs ${
                      wheelBet === amt
                        ? 'border-amber-500 bg-amber-500/20 text-amber-300'
                        : 'border-slate-800 bg-slate-900 text-slate-400'
                    }`}
                  >
                    {amt}₾
                  </button>
                ))}
              </div>
            </div>

            <button
              type="button"
              disabled={isSpinning || balance < wheelBet}
              onClick={spinWheel}
              className={`w-full py-3.5 rounded-xl font-extrabold text-sm sm:text-base uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${
                isSpinning || balance < wheelBet
                  ? 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
                  : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-[0_0_20px_rgba(245,158,11,0.4)] active:scale-95'
              }`}
            >
              <RotateCw className={`w-4 h-4 ${isSpinning ? 'animate-spin' : ''}`} />
              <span>{isSpinning ? 'ტრიალებს...' : `დატრიალება (${formatLari(wheelBet)})`}</span>
            </button>
          </div>
        </div>
      )}

      {/* 3. BLACKJACK 21 */}
      {activeGame === 'blackjack' && (
        <div className="bg-[#0c0d14] border border-slate-800 rounded-2xl p-6 shadow-xl max-w-2xl mx-auto space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-base text-slate-100 flex items-center gap-2">
                <Award className="w-5 h-5 text-blue-400" />
                <span>21 კლუბი (Blackjack RP)</span>
              </h3>
              <span className="text-xs text-slate-400">
                დაამარცხე დილერი 21 ქულამდე მისვლით
              </span>
            </div>
            <span className="text-xs font-mono text-emerald-400 font-bold">
              ბალანსი: {formatLari(balance)}
            </span>
          </div>

          {/* Table area */}
          <div className="p-5 rounded-2xl bg-emerald-950/20 border border-emerald-900/30 space-y-4">
            {/* Dealer Hand */}
            <div>
              <div className="flex justify-between text-xs text-slate-400 mb-1.5 font-mono">
                <span>დილერის კარტები</span>
                <span>
                  ქულა:{' '}
                  {bjState === 'PLAYING'
                    ? `${dealerHand[0]?.num || 0} + ?`
                    : calcHandScore(dealerHand)}
                </span>
              </div>
              <div className="flex gap-2">
                {dealerHand.map((card, i) => (
                  <div
                    key={i}
                    className={`w-14 h-20 rounded-xl border flex flex-col justify-between p-2 font-bold shadow-md ${
                      i === 1 && bjState === 'PLAYING'
                        ? 'bg-slate-800 border-slate-700 text-slate-500 items-center justify-center'
                        : ['♥', '♦'].includes(card.suit)
                        ? 'bg-white border-slate-200 text-rose-600'
                        : 'bg-white border-slate-200 text-slate-950'
                    }`}
                  >
                    {i === 1 && bjState === 'PLAYING' ? (
                      <HelpCircle className="w-6 h-6" />
                    ) : (
                      <>
                        <span className="text-xs leading-none">{card.value}</span>
                        <span className="text-xl text-center">{card.suit}</span>
                        <span className="text-xs text-right leading-none">{card.value}</span>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Player Hand */}
            <div className="pt-3 border-t border-emerald-900/30">
              <div className="flex justify-between text-xs text-slate-400 mb-1.5 font-mono">
                <span>შენი კარტები</span>
                <span className="text-emerald-400 font-bold">
                  ქულა: {calcHandScore(playerHand)}
                </span>
              </div>
              <div className="flex gap-2">
                {playerHand.map((card, i) => (
                  <div
                    key={i}
                    className={`w-14 h-20 rounded-xl border flex flex-col justify-between p-2 font-bold shadow-md ${
                      ['♥', '♦'].includes(card.suit)
                        ? 'bg-white border-slate-200 text-rose-600'
                        : 'bg-white border-slate-200 text-slate-950'
                    }`}
                  >
                    <span className="text-xs leading-none">{card.value}</span>
                    <span className="text-xl text-center">{card.suit}</span>
                    <span className="text-xs text-right leading-none">{card.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Outcome Message */}
          {bjMessage && (
            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-center text-xs font-bold text-slate-100">
              {bjMessage}
            </div>
          )}

          {/* Controls */}
          {bjState === 'PLAYING' ? (
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={hitBlackjack}
                className="py-3 rounded-xl bg-blue-500 hover:bg-blue-400 text-white font-bold text-sm shadow-md"
              >
                დამატება (Hit)
              </button>
              <button
                type="button"
                onClick={standBlackjack}
                className="py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm shadow-md"
              >
                გაჩერება (Stand)
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <input
                type="number"
                min={20}
                max={Math.floor(balance)}
                value={bjBet}
                onChange={(e) => setBjBet(Math.max(20, Number(e.target.value)))}
                className="w-32 px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono font-bold text-emerald-400"
              />
              <button
                type="button"
                disabled={balance < bjBet}
                onClick={startBlackjack}
                className="flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md disabled:opacity-40"
              >
                დარიგება ({formatLari(bjBet)})
              </button>
            </div>
          )}
        </div>
      )}

      {/* 4. COIN FLIP (ორბი თუ გერბი) */}
      {activeGame === 'coin' && (
        <div className="bg-[#0c0d14] border border-slate-800 rounded-2xl p-6 shadow-xl max-w-lg mx-auto text-center space-y-5">
          <div>
            <h3 className="font-bold text-base text-slate-100 flex items-center justify-center gap-2">
              <Coins className="w-5 h-5 text-purple-400" />
              <span>ორბი თუ გერბი (Double or Nothing)</span>
            </h3>
            <span className="text-xs text-slate-400">
              გაამრავლე შენი თანხა ყოველ სწორ არჩევანზე
            </span>
          </div>

          {/* Animated Coin */}
          <div className="py-4">
            <div
              className={`w-28 h-28 mx-auto rounded-full border-4 border-amber-400 bg-gradient-to-tr from-amber-600 to-yellow-300 flex items-center justify-center text-4xl shadow-[0_0_30px_rgba(245,158,11,0.5)] transition-transform duration-700 ${
                coinFlipping ? 'animate-bounce rotate-180' : ''
              }`}
            >
              {coinResult === 'eagle' ? '🦅' : coinResult === 'shield' ? '🛡️' : '🪙'}
            </div>
          </div>

          {/* Side choice buttons */}
          <div className="grid grid-cols-2 gap-3 max-w-xs mx-auto">
            <button
              type="button"
              disabled={coinFlipping}
              onClick={() => setCoinSide('eagle')}
              className={`py-2.5 px-3 rounded-xl border text-xs font-bold transition-all ${
                coinSide === 'eagle'
                  ? 'border-amber-400 bg-amber-500/20 text-amber-300'
                  : 'border-slate-800 bg-slate-900 text-slate-400'
              }`}
            >
              🦅 არწივი / ორბი
            </button>
            <button
              type="button"
              disabled={coinFlipping}
              onClick={() => setCoinSide('shield')}
              className={`py-2.5 px-3 rounded-xl border text-xs font-bold transition-all ${
                coinSide === 'shield'
                  ? 'border-amber-400 bg-amber-500/20 text-amber-300'
                  : 'border-slate-800 bg-slate-900 text-slate-400'
              }`}
            >
              🛡️ გერბი / ფარი
            </button>
          </div>

          {/* Current streak info */}
          {coinStreak > 0 && (
            <div className="p-3 rounded-xl bg-purple-500/20 border border-purple-500/40 font-mono text-xs">
              <span className="text-purple-300 block">
                სტრიქი: {coinStreak} მოგება ზედიზედ!
              </span>
              <span className="text-emerald-400 text-sm font-bold block mt-1">
                განაღდება: {formatLari(Math.floor(coinBet * Math.pow(1.95, coinStreak)))}
              </span>
            </div>
          )}

          {/* Action buttons */}
          <div className="flex gap-2">
            <button
              type="button"
              disabled={coinFlipping || (coinStreak === 0 && balance < coinBet)}
              onClick={flipCoin}
              className="flex-1 py-3 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-bold text-xs shadow-md disabled:opacity-40"
            >
              {coinStreak > 0 ? 'გაგრძელება (რისკი)' : `მონეტის აგდება (${formatLari(coinBet)})`}
            </button>
            {coinStreak > 0 && (
              <button
                type="button"
                onClick={cashOutCoin}
                className="py-3 px-5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md"
              >
                განაღდება
              </button>
            )}
          </div>
        </div>
      )}

      {/* 5. STREET DICE / NEON CRAPS */}
      {activeGame === 'dice' && (
        <div className="bg-[#0c0d14] border border-slate-800 rounded-2xl p-5 space-y-6 max-w-xl mx-auto shadow-2xl">
          <div className="text-center space-y-1">
            <h3 className="font-bold text-lg text-slate-100 flex items-center justify-center gap-2">
              <Dices className="w-5 h-5 text-rose-400" />
              <span>ქუჩის კამათლები (Neon Craps)</span>
            </h3>
            <p className="text-xs text-slate-400">
              აირჩიე ფსონის ტიპი, გააგორე 2 კამათელი და მოიგე 5.8x-მდე!
            </p>
          </div>

          {/* Dice Display Board */}
          <div className="p-8 rounded-2xl bg-gradient-to-b from-slate-950 to-[#08080c] border border-slate-800/80 flex flex-col items-center justify-center gap-4 relative overflow-hidden shadow-inner">
            <div className="flex items-center justify-center gap-6">
              {/* Die 1 */}
              <div
                className={`w-20 h-20 rounded-2xl bg-gradient-to-br from-rose-600 to-red-800 border-2 border-rose-400/80 shadow-[0_0_25px_rgba(244,63,94,0.4)] flex items-center justify-center text-3xl font-black text-white font-mono transform transition-all duration-300 ${
                  diceRolling ? 'rotate-45 scale-110 animate-bounce' : 'rotate-0 scale-100'
                }`}
              >
                {dice1}
              </div>
              {/* Die 2 */}
              <div
                className={`w-20 h-20 rounded-2xl bg-gradient-to-br from-rose-600 to-red-800 border-2 border-rose-400/80 shadow-[0_0_25px_rgba(244,63,94,0.4)] flex items-center justify-center text-3xl font-black text-white font-mono transform transition-all duration-300 ${
                  diceRolling ? '-rotate-45 scale-110 animate-bounce' : 'rotate-0 scale-100'
                }`}
              >
                {dice2}
              </div>
            </div>

            <div className="font-mono text-sm font-bold text-slate-200">
              {diceRolling ? (
                <span className="text-rose-400 animate-pulse">კამათლები გორდება...</span>
              ) : (
                <span>ჯამი: <span className="text-rose-400 text-lg">{dice1 + dice2}</span> {dice1 === dice2 ? '🔥 (დუბლი!)' : ''}</span>
              )}
            </div>

            <div className="text-xs text-slate-300 text-center font-medium bg-slate-900/80 px-4 py-2 rounded-xl border border-slate-800 max-w-sm">
              {diceMessage}
            </div>
          </div>

          {/* Bet Type Selection */}
          <div className="space-y-2">
            <label className="text-xs font-mono text-slate-400 block font-semibold">
              ფსონის ტიპი & მამრავლი:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                disabled={diceRolling}
                onClick={() => setDiceBetType('seven')}
                className={`p-3 rounded-xl border text-xs font-bold transition-all flex flex-col items-center gap-1 ${
                  diceBetType === 'seven'
                    ? 'border-rose-400 bg-rose-500/20 text-rose-300 shadow-md'
                    : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-slate-200'
                }`}
              >
                <span>იღბლიანი 7</span>
                <span className="font-mono text-emerald-400 font-extrabold text-[11px]">x4.50</span>
              </button>
              <button
                type="button"
                disabled={diceRolling}
                onClick={() => setDiceBetType('high')}
                className={`p-3 rounded-xl border text-xs font-bold transition-all flex flex-col items-center gap-1 ${
                  diceBetType === 'high'
                    ? 'border-rose-400 bg-rose-500/20 text-rose-300 shadow-md'
                    : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-slate-200'
                }`}
              >
                <span>დიდი (8-12)</span>
                <span className="font-mono text-emerald-400 font-extrabold text-[11px]">x2.00</span>
              </button>
              <button
                type="button"
                disabled={diceRolling}
                onClick={() => setDiceBetType('low')}
                className={`p-3 rounded-xl border text-xs font-bold transition-all flex flex-col items-center gap-1 ${
                  diceBetType === 'low'
                    ? 'border-rose-400 bg-rose-500/20 text-rose-300 shadow-md'
                    : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-slate-200'
                }`}
              >
                <span>პატარა (2-6)</span>
                <span className="font-mono text-emerald-400 font-extrabold text-[11px]">x2.00</span>
              </button>
              <button
                type="button"
                disabled={diceRolling}
                onClick={() => setDiceBetType('doubles')}
                className={`p-3 rounded-xl border text-xs font-bold transition-all flex flex-col items-center gap-1 ${
                  diceBetType === 'doubles'
                    ? 'border-rose-400 bg-rose-500/20 text-rose-300 shadow-md'
                    : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-slate-200'
                }`}
              >
                <span>დუბლები</span>
                <span className="font-mono text-emerald-400 font-extrabold text-[11px]">x5.80</span>
              </button>
            </div>
          </div>

          {/* Bet Quick Selector */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-slate-400">ფსონის ოდენობა:</span>
              <span className="text-emerald-400 font-bold">{formatLari(diceBet)}</span>
            </div>
            <div className="flex gap-2">
              {[50, 100, 500, 2500, 10000].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  disabled={diceRolling}
                  onClick={() => setDiceBet(amt)}
                  className={`flex-1 py-1.5 rounded-lg border text-xs font-mono font-bold transition-all ${
                    diceBet === amt
                      ? 'border-rose-400 bg-rose-500/20 text-rose-300'
                      : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {amt}₾
                </button>
              ))}
            </div>
          </div>

          <button
            type="button"
            disabled={diceRolling || balance < diceBet}
            onClick={rollDice}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-rose-500 to-red-600 hover:from-rose-400 hover:to-red-500 disabled:opacity-40 text-white font-extrabold text-sm shadow-xl flex items-center justify-center gap-2 transition-all active:scale-95"
          >
            <Dices className="w-4 h-4" />
            <span>{diceRolling ? 'გორდება...' : `კამათლების გაგორება (${formatLari(diceBet)})`}</span>
          </button>
        </div>
      )}

      {/* 6. THIMBLES / STREET CUPS */}
      {activeGame === 'thimbles' && (
        <div className="bg-[#0c0d14] border border-slate-800 rounded-2xl p-5 space-y-6 max-w-xl mx-auto shadow-2xl">
          <div className="text-center space-y-1">
            <h3 className="font-bold text-lg text-slate-100 flex items-center justify-center gap-2">
              <Sparkles className="w-5 h-5 text-teal-400" />
              <span>ქუჩის ჭიქები (Thimbles 2.9x)</span>
            </h3>
            <p className="text-xs text-slate-400">
              თვალი ადევნე ბრილიანტს! გამოიცანი რომელი ჭიქის ქვეშ იმალება და გაასამმაგე ფსონი!
            </p>
          </div>

          {/* Three Cups Display */}
          <div className="p-8 rounded-2xl bg-gradient-to-b from-slate-950 to-[#08080c] border border-slate-800/80 flex flex-col items-center justify-center gap-6 relative shadow-inner">
            <div className="flex items-end justify-center gap-8 sm:gap-12 w-full">
              {[0, 1, 2].map((cupIdx) => {
                const isPicked = pickedCup === cupIdx;
                const hasDiamond = diamondIndex === cupIdx;
                const isRevealed = thimblesState === 'REVEALED';
                const isShuffling = thimblesState === 'SHUFFLING';

                return (
                  <div key={cupIdx} className="flex flex-col items-center gap-2">
                    <button
                      type="button"
                      disabled={thimblesState !== 'WAITING'}
                      onClick={() => handlePickCup(cupIdx)}
                      className={`w-20 h-24 sm:w-24 sm:h-28 rounded-t-3xl bg-gradient-to-b from-amber-400 via-amber-600 to-amber-800 border-2 border-amber-300 shadow-[0_0_20px_rgba(245,158,11,0.3)] flex flex-col items-center justify-center transition-all duration-300 transform relative ${
                        isShuffling
                          ? 'animate-pulse translate-y-1'
                          : isRevealed
                          ? '-translate-y-8 shadow-[0_0_30px_rgba(245,158,11,0.6)]'
                          : thimblesState === 'WAITING'
                          ? 'hover:-translate-y-3 cursor-pointer hover:border-emerald-400'
                          : ''
                      }`}
                    >
                      <div className="w-full h-2 bg-amber-300/40 rounded-full mb-2" />
                      <span className="text-amber-100 font-mono font-black text-sm">
                        №{cupIdx + 1}
                      </span>
                      {isPicked && isRevealed && (
                        <span className="text-[10px] font-bold text-amber-200 mt-1">შენი არჩევანი</span>
                      )}
                    </button>

                    {/* Diamond underneath */}
                    <div className="h-8 flex items-center justify-center">
                      {isRevealed && hasDiamond ? (
                        <div className="text-3xl animate-bounce" title="ბრილიანტი!">
                          💎
                        </div>
                      ) : (
                        <div className="w-3 h-1 bg-slate-800 rounded-full" />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="text-xs text-slate-300 text-center font-medium bg-slate-900/80 px-4 py-2 rounded-xl border border-slate-800 max-w-sm">
              {thimblesMessage}
            </div>
          </div>

          {/* Bet Quick Selector */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-slate-400">ფსონის ოდენობა:</span>
              <span className="text-emerald-400 font-bold">{formatLari(thimblesBet)}</span>
            </div>
            <div className="flex gap-2">
              {[50, 200, 1000, 5000].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  disabled={thimblesState === 'SHUFFLING'}
                  onClick={() => setThimblesBet(amt)}
                  className={`flex-1 py-1.5 rounded-lg border text-xs font-mono font-bold transition-all ${
                    thimblesBet === amt
                      ? 'border-teal-400 bg-teal-500/20 text-teal-300'
                      : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {amt}₾
                </button>
              ))}
            </div>
          </div>

          <button
            type="button"
            disabled={thimblesState === 'SHUFFLING' || balance < thimblesBet}
            onClick={startThimbles}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-400 hover:to-emerald-500 disabled:opacity-40 text-slate-950 font-extrabold text-sm shadow-xl flex items-center justify-center gap-2 transition-all active:scale-95"
          >
            <Sparkles className="w-4 h-4" />
            <span>
              {thimblesState === 'SHUFFLING'
                ? 'ჭიქები ირევა...'
                : thimblesState === 'WAITING'
                ? 'ხელახლა არევა'
                : `ჭიქების არევა (${formatLari(thimblesBet)})`}
            </span>
          </button>
        </div>
      )}
    </div>
  );
};


