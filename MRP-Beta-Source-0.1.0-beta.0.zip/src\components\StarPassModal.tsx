﻿import React, { useState } from 'react';
import { X, Sparkles, Star, Lock, Check, Gift, Crown, Trophy, ShieldCheck, ChevronRight, Zap, Car, Home } from 'lucide-react';
import { PlayerProfile } from '../types/game';
import { STAR_PASS_TIERS, CRYSTAL_PRICE_GEL } from '../utils/constants';
import { formatLari } from '../utils/formatters';
import { playWinSound, playClickSound, playLevelUpSound } from '../utils/audio';

interface StarPassModalProps {
  player: PlayerProfile;
  soundEnabled: boolean;
  onClose: () => void;
  onUnlockPassPlus: () => void;
  onClaimTierFree: (tier: number) => void;
  onClaimTierPlus: (tier: number) => void;
  onOpenExchangeModal: () => void;
}

export const StarPassModal: React.FC<StarPassModalProps> = ({
  player,
  soundEnabled,
  onClose,
  onUnlockPassPlus,
  onClaimTierFree,
  onClaimTierPlus,
  onOpenExchangeModal
}) => {
  const playerStars = player.stars || 0;
  const isPassPlus = !!player.isPassPlusActive;
  const claimedFree = player.claimedPassTiersFree || [];
  const claimedPlus = player.claimedPassTiersPlus || [];
  const isPurpleOrMidnight = player.premiumRank === 'purple' || player.premiumRank === 'midnight_purple';

  const [activeTierRange, setActiveTierRange] = useState<number>(1); // 1 = 1-10, 2 = 11-20, etc.

  // Current tier calculation
  let currentTier = 0;
  for (const t of STAR_PASS_TIERS) {
    if (playerStars >= t.requiredStars) {
      currentTier = t.tier;
    } else {
      break;
    }
  }

  const nextTierDef = STAR_PASS_TIERS.find((t) => t.tier === currentTier + 1);
  const starsForNext = nextTierDef ? nextTierDef.requiredStars - playerStars : 0;
  const totalPassStars = 500;
  const overallPercent = Math.min(100, Math.floor((playerStars / totalPassStars) * 100));

  const filteredTiers = STAR_PASS_TIERS.slice((activeTierRange - 1) * 10, activeTierRange * 10);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-xl animate-fadeIn">
      <div className="relative w-full max-w-5xl bg-[#0b0c13] border-2 border-purple-500/40 rounded-3xl shadow-[0_0_60px_rgba(168,85,247,0.25)] flex flex-col max-h-[92vh] overflow-hidden text-slate-100">
        
        {/* Top Header Banner */}
        <div className="relative p-5 sm:p-6 bg-gradient-to-r from-[#170a2c] via-[#100720] to-[#0d0716] border-b border-purple-500/30 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3.5 text-center md:text-left">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-600 via-fuchsia-500 to-amber-400 p-0.5 shadow-[0_0_25px_rgba(168,85,247,0.5)] shrink-0">
              <div className="w-full h-full bg-[#0d0a17] rounded-[14px] flex items-center justify-center text-3xl">
                🌟
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2 justify-center md:justify-start">
                <h2 className="text-xl sm:text-2xl font-black bg-gradient-to-r from-amber-300 via-purple-300 to-fuchsia-400 bg-clip-text text-transparent">
                  STAR PASS • 50 TIERS ელიტური პასი
                </h2>
                {isPassPlus && (
                  <span className="px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-[10px] uppercase tracking-wider shadow-md animate-pulse">
                    PASS+ აქტიურია
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                დააგროვე 500 ⭐ ვარსკვლავი მისიებით. ქვედა Pass+ ტრეკი იძლევა სპორტკარებს და სახლებს ლაგოდეხსა და ქუთაისში!
              </p>
            </div>
          </div>

          {/* Right Action / Stars & Unlock Capsule */}
          <div className="flex flex-wrap items-center gap-3 justify-center">
            {/* Stars Count Capsule */}
            <div className="flex items-center gap-2.5 px-4 py-2 rounded-2xl bg-slate-950/80 border-2 border-amber-500/50 shadow-[0_0_15px_rgba(245,158,11,0.25)]">
              <span className="text-2xl animate-spin" style={{ animationDuration: '6s' }}>⭐</span>
              <div>
                <span className="text-[10px] text-slate-400 font-mono font-bold uppercase tracking-wider block">
                  შენი ვარსკვლავები
                </span>
                <span className="text-lg font-black text-amber-300 font-mono leading-none">
                  {playerStars} / {totalPassStars} ⭐
                </span>
              </div>
            </div>

            {/* Unlock Pass+ Button if not active */}
            {!isPassPlus ? (
              <button
                onClick={() => {
                  playClickSound(soundEnabled);
                  if (!isPurpleOrMidnight) {
                    alert('⚠️ Pass+ გასახსნელად აუცილებელია გქონდეს Purple Premium ან Midnight Purple VIP სტატუსი!');
                    return;
                  }
                  if ((player.crystals || 0) < 500) {
                    onOpenExchangeModal();
                    return;
                  }
                  playLevelUpSound(soundEnabled);
                  onUnlockPassPlus();
                }}
                className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 via-fuchsia-600 to-purple-600 hover:brightness-110 text-white font-black text-xs sm:text-sm shadow-[0_0_25px_rgba(217,70,239,0.5)] transition-all cursor-pointer flex items-center gap-2"
                title={
                  !isPurpleOrMidnight
                    ? 'საჭიროა Purple Premium + 500 💎'
                    : 'გახსენი Pass+ 500 კრისტალად'
                }
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>გახსენი Pass+ (500 💎)</span>
              </button>
            ) : (
              <div className="px-3.5 py-2 rounded-2xl bg-emerald-500/10 border border-emerald-500/40 text-emerald-400 font-mono font-bold text-xs flex items-center gap-1.5">
                <Check className="w-4 h-4" />
                <span>Pass+ აქტიურია</span>
              </div>
            )}

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Progress Bar & Info Strip */}
        <div className="px-5 py-3 bg-slate-950/70 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
          <div className="flex items-center gap-3">
            <span className="font-bold text-amber-400 flex items-center gap-1">
              <Trophy className="w-4 h-4" />
              <span>მიმდინარე საფეხური: Tier {currentTier} / 50</span>
            </span>
            {nextTierDef && (
              <span className="text-slate-400">
                (შემდეგ Tier {currentTier + 1}-მდე დარჩა: <span className="text-amber-300 font-bold">{starsForNext} ⭐</span>)
              </span>
            )}
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="w-48 h-2 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-amber-500 via-fuchsia-500 to-purple-500 transition-all duration-300"
                style={{ width: `${overallPercent}%` }}
              />
            </div>
            <span className="text-slate-400">{overallPercent}% დასრულებული</span>
          </div>
        </div>

        {/* Tier Range Pagination Tabs */}
        <div className="px-5 py-2.5 bg-[#0e0f18] border-b border-slate-800 flex items-center gap-2 overflow-x-auto scrollbar-none">
          {[
            { range: 1, label: 'Tier 1 - 10 (🏎️ BMW M4 CSL)' },
            { range: 2, label: 'Tier 11 - 20 (⚡ Stage 2 Pro)' },
            { range: 3, label: 'Tier 21 - 30 (🏡 სახლი ლაგოდეხში)' },
            { range: 4, label: 'Tier 31 - 40 (🚀 Porsche GT3 RS)' },
            { range: 5, label: 'Tier 41 - 50 (🏰 სახლი ქუთაისში)' }
          ].map((tab) => (
            <button
              key={tab.range}
              onClick={() => {
                playClickSound(soundEnabled);
                setActiveTierRange(tab.range);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                activeTierRange === tab.range
                  ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(168,85,247,0.5)] font-black'
                  : 'bg-slate-900/90 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tiers List Section */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
          <div className="grid grid-cols-1 gap-3.5">
            {filteredTiers.map((t) => {
              const isUnlocked = playerStars >= t.requiredStars;
              const isFreeClaimed = claimedFree.includes(t.tier);
              const isPlusClaimed = claimedPlus.includes(t.tier);

              return (
                <div
                  key={t.tier}
                  className={`rounded-2xl border-2 p-3.5 sm:p-4 transition-all flex flex-col md:flex-row items-center justify-between gap-4 ${
                    isUnlocked
                      ? 'bg-gradient-to-r from-slate-900/90 via-[#130f1e] to-slate-900/90 border-purple-500/40 shadow-md'
                      : 'bg-slate-950/60 border-slate-800/80 opacity-75'
                  }`}
                >
                  {/* Left: Tier Number & Required Stars */}
                  <div className="flex items-center gap-3 shrink-0 min-w-[130px]">
                    <div
                      className={`w-12 h-12 rounded-xl flex flex-col items-center justify-center font-black font-mono border-2 ${
                        isUnlocked
                          ? 'bg-purple-500/20 border-purple-500 text-purple-300 shadow-[0_0_15px_rgba(168,85,247,0.3)]'
                          : 'bg-slate-900 border-slate-800 text-slate-500'
                      }`}
                    >
                      <span className="text-[10px] uppercase text-slate-400">Tier</span>
                      <span className="text-base leading-none">{t.tier}</span>
                    </div>
                    <div>
                      <div className="flex items-center gap-1 text-xs font-mono font-bold text-amber-400">
                        <span>⭐</span>
                        <span>{t.requiredStars} Stars</span>
                      </div>
                      <span className={`text-[10px] font-mono block ${isUnlocked ? 'text-emerald-400' : 'text-slate-500'}`}>
                        {isUnlocked ? '✓ გახსნილია' : 'ჩაკეტილია'}
                      </span>
                    </div>
                  </div>

                  {/* Center: Two Tracks (Top: Free / Bottom: Pass+) */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 flex-1 w-full">
                    {/* 1. TOP TRACK (FREE) */}
                    <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between gap-2.5">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="text-2xl shrink-0">{t.freeReward.icon}</span>
                        <div className="min-w-0">
                          <span className="text-[10px] text-slate-400 font-mono font-bold block uppercase tracking-wider">
                            ზედა ტრეკი (უფასო)
                          </span>
                          <span className="font-bold text-xs text-slate-200 truncate block">
                            {t.freeReward.title}
                          </span>
                        </div>
                      </div>

                      {/* Claim Button Free */}
                      <button
                        disabled={!isUnlocked || isFreeClaimed}
                        onClick={() => {
                          playWinSound(soundEnabled);
                          onClaimTierFree(t.tier);
                        }}
                        className={`px-3 py-1.5 rounded-xl font-bold text-xs whitespace-nowrap transition-all font-mono shrink-0 ${
                          isFreeClaimed
                            ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 cursor-default'
                            : isUnlocked
                            ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md cursor-pointer animate-pulse'
                            : 'bg-slate-900 border border-slate-800 text-slate-600 cursor-not-allowed'
                        }`}
                      >
                        {isFreeClaimed ? 'აღებულია' : isUnlocked ? 'აღება' : 'ჩაკეტილი'}
                      </button>
                    </div>

                    {/* 2. BOTTOM TRACK (PASS+) */}
                    <div
                      className={`p-3 rounded-xl border flex items-center justify-between gap-2.5 relative overflow-hidden ${
                        t.plusReward.type === 'car' || t.plusReward.type === 'estate'
                          ? 'bg-gradient-to-r from-amber-950/40 via-purple-950/50 to-slate-950 border-amber-500/60 shadow-[0_0_20px_rgba(245,158,11,0.2)]'
                          : 'bg-gradient-to-r from-purple-950/30 via-slate-950 to-slate-950 border-purple-500/40'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="text-2xl shrink-0">{t.plusReward.icon}</span>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="text-[10px] text-amber-400 font-mono font-bold block uppercase tracking-wider">
                              ქვედა ტრეკი (Pass+)
                            </span>
                            {(t.plusReward.type === 'car' || t.plusReward.type === 'estate') && (
                              <span className="px-1.5 py-0.2 rounded bg-amber-500 text-slate-950 text-[9px] font-black uppercase">
                                ლეგენდარული
                              </span>
                            )}
                          </div>
                          <span className="font-extrabold text-xs text-amber-200 truncate block">
                            {t.plusReward.title}
                          </span>
                        </div>
                      </div>

                      {/* Claim Button Pass+ */}
                      <button
                        disabled={!isUnlocked || !isPassPlus || isPlusClaimed}
                        onClick={() => {
                          playLevelUpSound(soundEnabled);
                          onClaimTierPlus(t.tier);
                        }}
                        className={`px-3 py-1.5 rounded-xl font-bold text-xs whitespace-nowrap transition-all font-mono shrink-0 ${
                          isPlusClaimed
                            ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 cursor-default'
                            : isUnlocked && isPassPlus
                            ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black shadow-[0_0_15px_rgba(245,158,11,0.5)] cursor-pointer animate-pulse'
                            : 'bg-slate-900 border border-slate-800 text-slate-600 cursor-not-allowed flex items-center gap-1'
                        }`}
                      >
                        {isPlusClaimed ? (
                          'აღებულია'
                        ) : isUnlocked && isPassPlus ? (
                          'აღება'
                        ) : (
                          <>
                            <Lock className="w-3 h-3" />
                            <span>{!isPassPlus ? 'Pass+' : 'ჩაკეტილი'}</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer info note */}
        <div className="p-3 bg-[#08090f] border-t border-slate-800/80 text-center text-xs text-slate-400 flex flex-wrap items-center justify-center gap-4">
          <span>💡 ვარსკვლავები გაიცემა ყველა მისიის შესრულებაზე</span>
          <span className="text-amber-400 font-bold">•</span>
          <span>Purple Premium = 6-7 ⭐ თითო მისიაზე</span>
          <span className="text-amber-400 font-bold">•</span>
          <span>Pass+ გააქტიურება: 500 💎 კრისტალი</span>
        </div>
      </div>
    </div>
  );
};


