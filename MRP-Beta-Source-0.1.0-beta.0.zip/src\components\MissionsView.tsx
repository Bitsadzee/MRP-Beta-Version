﻿import React from 'react';
import { Target, CheckCircle2, Sparkles, Gift, ShieldAlert, Award, Clock } from 'lucide-react';
import { PlayerProfile } from '../types/game';
import { GAME_MISSIONS, MissionDef } from '../utils/constants';
import { formatLari } from '../utils/formatters';
import { playWinSound, playClickSound } from '../utils/audio';

interface MissionsViewProps {
  player: PlayerProfile;
  ownedCarsCount: number;
  ownedEstatesCount: number;
  soundEnabled: boolean;
  onClaimMission: (missionId: string, cashReward: number, crystalReward: number) => void;
  onOpenExchangeModal: () => void;
}

export const MissionsView: React.FC<MissionsViewProps> = ({
  player,
  ownedCarsCount,
  ownedEstatesCount,
  soundEnabled,
  onClaimMission,
  onOpenExchangeModal
}) => {
  const completedList = player.completedMissions || [];

  const completedCount = completedList.length;
  const totalMissions = GAME_MISSIONS.length;
  const progressPercent = Math.min(100, Math.floor((completedCount / totalMissions) * 100));

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 animate-fadeIn">
      {/* Top Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-[#141829] to-slate-900 border-2 border-amber-500/30 p-6 sm:p-8 mb-8 shadow-[0_0_50px_rgba(245,158,11,0.15)]">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
          <div className="flex items-center gap-4 text-center md:text-left">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-emerald-500 flex items-center justify-center text-3xl shadow-[0_0_25px_rgba(245,158,11,0.4)]">
              🎯
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-teal-300 to-cyan-300">
                სპეციალური მისიები & კრისტალები
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl">
                შეასრულე რთული ეკონომიკური და სათამაშო გამოწვევები, გამოიმუშავე ათასობით ლარი და ძვირფასი 💎 კრისტალები!
              </p>
            </div>
          </div>

          {/* Stats Capsule */}
          <div className="flex items-center gap-4 bg-slate-950/80 border border-slate-800 px-5 py-3 rounded-2xl">
            <div className="text-center">
              <span className="text-[10px] text-slate-400 font-mono uppercase block">შესრულებული</span>
              <span className="text-xl font-black text-emerald-400 font-mono">
                {completedCount} / {totalMissions}
              </span>
            </div>
            <div className="w-[1px] h-8 bg-slate-800" />
            <div className="text-center">
              <span className="text-[10px] text-slate-400 font-mono uppercase block">კრისტალები</span>
              <span className="text-xl font-black text-cyan-300 font-mono">
                {player.crystals || 0} 💎
              </span>
            </div>
          </div>
        </div>

        {/* Global Missions Progress Bar */}
        <div className="mt-6 pt-4 border-t border-slate-800/80">
          <div className="flex items-center justify-between text-xs font-mono font-bold text-slate-400 mb-1.5">
            <span>მთლიანი პროგრესი:</span>
            <span className="text-amber-400">{progressPercent}%</span>
          </div>
          <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
            <div
              className="h-full bg-gradient-to-r from-amber-500 via-emerald-400 to-cyan-400 transition-all duration-500 shadow-[0_0_12px_rgba(245,158,11,0.6)]"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Missions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
        {GAME_MISSIONS.map((mission: MissionDef) => {
          const isClaimed = completedList.includes(mission.id);
          const progress = mission.getProgress(player, ownedCarsCount, ownedEstatesCount);
          const canClaim = !isClaimed && progress.completed;
          const currentPercent = Math.min(100, Math.floor((progress.current / mission.targetCount) * 100));

          return (
            <div
              key={mission.id}
              className={`p-5 rounded-3xl border-2 transition-all flex flex-col justify-between ${
                isClaimed
                  ? 'bg-slate-950/60 border-slate-800/60 opacity-80'
                  : canClaim
                  ? 'bg-gradient-to-br from-amber-950/30 via-slate-900 to-slate-950 border-amber-500/60 shadow-[0_0_25px_rgba(245,158,11,0.2)]'
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Mission Header */}
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl p-2 rounded-2xl bg-slate-800/80 border border-slate-700/80 shrink-0">
                      {mission.icon}
                    </span>
                    <div>
                      <h3 className="text-base font-extrabold text-slate-100 flex items-center gap-2">
                        <span>{mission.title}</span>
                        {isClaimed && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-mono font-bold">
                            ✓ შესრულებული
                          </span>
                        )}
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5 leading-snug">
                        {mission.description}
                      </p>
                    </div>
                  </div>

                  {/* Rewards preview pill */}
                  <div className="flex flex-col items-end shrink-0">
                    <span className="text-xs font-mono font-black text-emerald-400">
                      +{formatLari(mission.rewardCash)}
                    </span>
                    <span className="text-xs font-mono font-black text-cyan-300 flex items-center gap-1">
                      <span>+{mission.rewardCrystals}</span>
                      <span>💎</span>
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="mt-4 mb-3">
                  <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mb-1">
                    <span>პროგრესი:</span>
                    <span className="font-bold text-slate-200">
                      {progress.current.toLocaleString()} / {mission.targetCount.toLocaleString()} {mission.unit}
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className={`h-full transition-all duration-300 ${
                        isClaimed
                          ? 'bg-emerald-500'
                          : canClaim
                          ? 'bg-gradient-to-r from-amber-400 to-emerald-400'
                          : 'bg-emerald-500/80'
                      }`}
                      style={{ width: `${currentPercent}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-2">
                {isClaimed ? (
                  <div className="w-full py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-500 font-bold text-xs font-mono text-center flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    <span>ჯილდო მიღებულია</span>
                  </div>
                ) : canClaim ? (
                  <button
                    onClick={() => {
                      playWinSound(soundEnabled);
                      onClaimMission(mission.id, mission.rewardCash, mission.rewardCrystals);
                    }}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-emerald-500 to-teal-500 text-slate-950 font-black text-xs font-mono tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer"
                  >
                    <Gift className="w-4 h-4" />
                    <span>ჯილდოს მიღება (+{formatLari(mission.rewardCash)} & +{mission.rewardCrystals} 💎)</span>
                  </button>
                ) : (
                  <div className="w-full py-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80 text-slate-400 font-medium text-xs font-mono text-center flex items-center justify-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-500" />
                    <span>მიმდინარეობს ({currentPercent}%)</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};


