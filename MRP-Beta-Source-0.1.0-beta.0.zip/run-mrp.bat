@echo off
setlocal
set "NODE_HOME=%~dp0..\node-runtime\node-v26.13.0-win-x64"
if exist "%NODE_HOME%\node.exe" set "PATH=%NODE_HOME%;%PATH%"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Install the Node.js LTS version, then run this file again.
  pause
  exit /b 1
)
set "PATH=%NODE_HOME%;%PATH%"
cd /d "%~dp0"
if not exist "node_modules\vite\bin\vite.js" (
  echo Game packages are missing. Installing them now...
  call "%NODE_HOME%\npm.cmd" install --cache "%~dp0..\mrp-npm-cache"
  if errorlevel 1 pause & exit /b 1
  call "%NODE_HOME%\npm.cmd" install-scripts approve esbuild
  if errorlevel 1 pause & exit /b 1
)
start "MRP Game" http://127.0.0.1:5173
"%NODE_HOME%\node.exe" "%~dp0node_modules\vite\bin\vite.js" --host 127.0.0.1 --port 5173
pause
