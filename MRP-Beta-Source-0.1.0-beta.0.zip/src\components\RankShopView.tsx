﻿import React, { useState } from 'react';
import { Crown, Sparkles, Check, Zap, Coins, ArrowRight, ShieldCheck } from 'lucide-react';
import { PlayerProfile } from '../types/game';
import { RANK_SHOP_ITEMS, CRYSTAL_PRICE_GEL } from '../utils/constants';
import { formatLari } from '../utils/formatters';
import { playWinSound, playClickSound, playCashSound } from '../utils/audio';

interface RankShopViewProps {
  player: PlayerProfile;
  soundEnabled: boolean;
  onBuyRank: (rank: 'red' | 'purple' | 'midnight_purple' | 'devil_red', costCrystals: number) => void;
  onExchangeMoneyForCrystals: (crystals: number) => void;
  onOpenExchangeModal: () => void;
}

export const RankShopView: React.FC<RankShopViewProps> = ({
  player,
  soundEnabled,
  onBuyRank,
  onExchangeMoneyForCrystals,
  onOpenExchangeModal
}) => {
  const currentRank = player.premiumRank || 'none';
  const playerCrystals = player.crystals || 0;

  // Inline Quick Exchange
  const [exchangeInput, setExchangeInput] = useState<string>('50');
  const parsedExchange = parseInt(exchangeInput, 10);
  const validExchange = isNaN(parsedExchange) || parsedExchange < 1 ? 0 : parsedExchange;
  const exchangeCost = validExchange * CRYSTAL_PRICE_GEL;
  const canAffordExchange = player.balance >= exchangeCost && validExchange > 0;

  const handleQuickExchange = () => {
    if (!canAffordExchange) return;
    playCashSound(soundEnabled);
    onExchangeMoneyForCrystals(validExchange);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 animate-fadeIn">
      {/* Top Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-[#131122] to-slate-900 border-2 border-purple-500/30 p-6 sm:p-8 mb-8 shadow-[0_0_50px_rgba(168,85,247,0.15)]">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
          <div className="flex items-center gap-4 text-center md:text-left">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-600 via-fuchsia-600 to-amber-500 flex items-center justify-center text-3xl shadow-[0_0_25px_rgba(168,85,247,0.5)]">
              👑
            </div>
            <div>
              <div className="flex items-center gap-2 justify-center md:justify-start">
                <h1 className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-400 via-purple-300 to-fuchsia-400">
                  RANK SHOP & VIP სტატუსები
                </h1>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl">
                აირჩიე VIP რანკი. RedDevil გაძლევს x30 XP-ს და x25 ფულად შედეგს.
              </p>
            </div>
          </div>

          {/* Crystals Balance Capsule */}
          <div className="flex items-center gap-3 bg-slate-950/80 border-2 border-cyan-500/40 px-5 py-3 rounded-2xl shadow-[0_0_20px_rgba(6,182,212,0.2)]">
            <span className="text-3xl animate-bounce">💎</span>
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-400 font-mono font-bold uppercase tracking-wider">
                შენი კრისტალები
              </span>
              <span className="text-xl font-black text-cyan-300 font-mono">
                {playerCrystals} 💎
              </span>
            </div>
            <button
              onClick={onOpenExchangeModal}
              className="ml-2 px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 text-xs font-bold font-mono transition-all cursor-pointer"
            >
              + გადაცვლა
            </button>
          </div>
        </div>

        {/* Current Status pill */}
        <div className="mt-5 pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">მიმდინარე VIP რანკი:</span>
            {currentRank === 'devil_red' ? (
              <span className="rounded-full border border-rose-300/80 bg-gradient-to-r from-rose-700/80 via-red-600/70 to-fuchsia-700/80 px-3 py-1 font-black text-white shadow-[0_0_20px_rgba(244,35,89,.55)] animate-pulse">😈 REDDEVIL (x30 XP · x25 ფული)</span>
            ) : currentRank === 'midnight_purple' ? (
              <span className="px-3 py-1 rounded-full bg-gradient-to-r from-purple-900/60 to-fuchsia-900/60 border border-fuchsia-500/80 text-fuchsia-300 font-black tracking-wider animate-pulse shadow-[0_0_15px_rgba(217,70,239,0.7)]">🌌 MIDNIGHT PURPLE (x5 XP · x2 ფული)</span>
            ) : currentRank === 'purple' ? (
              <span className="px-3 py-1 rounded-full bg-purple-500/20 border border-purple-500/50 text-purple-400 font-black tracking-wider animate-pulse">🟣 PURPLE VIP (x3 XP · x1.5 ფული)</span>
            ) : currentRank === 'red' ? (
              <span className="px-3 py-1 rounded-full bg-red-500/20 border border-red-500/50 text-red-400 font-black tracking-wider animate-pulse">🔴 RED VIP (x2 XP · x1.2 ფული)</span>
            ) : (
              <span className="px-3 py-1 rounded-full bg-slate-800 text-slate-400 font-bold border border-slate-700">სტანდარტული მოქალაქე (არ გაქვს Premium)</span>
            )}
          </div>
          <span className="text-slate-400 font-mono">
            კურსი: 10 💎 = 5,000 ₾ (1 💎 = 500 ₾)
          </span>
        </div>
      </div>

      {/* Ranks Cards Grid (3 Columns) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 sm:gap-5 mb-10">
        {RANK_SHOP_ITEMS.map((rank) => {
          const isOwned = currentRank === rank.id;
          const rankOrder = { red: 1, purple: 2, midnight_purple: 3, devil_red: 4 } as const;
          const isHigherOwned = currentRank !== 'none' && rankOrder[currentRank] > rankOrder[rank.id];
          const canAfford = playerCrystals >= rank.priceCrystals;

          return (
            <div
              key={rank.id}
              className={`relative overflow-hidden rounded-3xl p-6 sm:p-7 border-2 transition-all flex flex-col justify-between ${
                rank.id === 'devil_red'
                  ? 'bg-gradient-to-b from-[#390612] via-[#190817] to-[#050b16] border-rose-400/80 shadow-[0_0_48px_rgba(244,35,89,.35)]'
                  : rank.id === 'midnight_purple'
                  ? 'bg-gradient-to-b from-[#21093f] via-[#120524] to-[#080210] border-fuchsia-500/80 shadow-[0_0_45px_rgba(217,70,239,0.35)]'
                  : rank.id === 'purple'
                  ? 'bg-gradient-to-b from-[#180a22] via-[#11071c] to-[#090b12] border-purple-500/50 hover:border-purple-400 shadow-[0_0_40px_rgba(168,85,247,0.25)]'
                  : 'bg-gradient-to-b from-[#1a0c0f] via-[#120a10] to-[#090b12] border-red-500/40 hover:border-red-500 shadow-[0_0_30px_rgba(239,68,68,0.2)]'
              }`}
            >
              <div className="mb-5 space-y-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">
                      {rank.id === 'devil_red' ? '😈' : rank.id === 'midnight_purple' ? '🌌' : rank.id === 'purple' ? '🟣' : '🔴'}
                    </span>
                    <h3 className={`text-lg sm:text-xl font-black tracking-wide ${rank.textColor}`}>
                      {rank.nameGe}
                    </h3>
                  </div>
                  <span className="text-xs text-slate-400 font-mono mt-0.5 block">
                    {rank.name}
                  </span>
                </div>

                <div className={`rounded-2xl border px-4 py-3 ${rank.id === 'devil_red' ? 'border-rose-300/50 bg-gradient-to-r from-rose-950/90 via-red-950/70 to-fuchsia-950/80 shadow-[0_0_24px_rgba(244,35,89,.2)]' : 'border-cyan-400/30 bg-slate-950/85'}`}>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] font-black uppercase tracking-[.18em] text-slate-400">რანკის ფასი</span>
                    <span className="rounded-full bg-cyan-300/10 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-cyan-200">კრისტალები</span>
                  </div>
                  <div className="mt-1 flex items-baseline gap-2">
                    <span className={`text-2xl sm:text-3xl font-black font-mono tracking-tight ${rank.id === 'devil_red' ? 'text-rose-100' : 'text-cyan-200'}`}>{rank.priceCrystals.toLocaleString()}</span>
                    <span className="text-lg">💎</span>
                  </div>
                  <span className="mt-1 block text-[10px] font-mono text-slate-400">ღირებულება: {formatLari(rank.priceCrystals * CRYSTAL_PRICE_GEL)}</span>
                </div>
              </div>

              {/* Multiplier Big Display */}
              <div className="p-4 rounded-2xl bg-black/40 border border-slate-800/80 mb-5 flex items-center justify-around text-center">
                <div>
                  <div className="text-[10px] uppercase font-mono font-bold text-slate-400">XP ბონუსი</div>
                  <div className={`text-2xl font-black font-mono ${rank.textColor}`}>
                    x{rank.xpMultiplier} XP
                  </div>
                </div>
                <div className="w-[1px] h-8 bg-slate-800" />
                <div>
                  <div className="text-[10px] uppercase font-mono font-bold text-slate-400">ფულის ბონუსი</div>
                  <div className="text-2xl font-black text-emerald-400 font-mono">
                    x{rank.moneyMultiplier} MONEY
                  </div>
                </div>
              </div>

              {/* Perks List */}
              <div className="space-y-2 mb-6 flex-1">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                  რანკის პრივილეგიები:
                </span>
                {rank.perks.map((perk, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-xs text-slate-200">
                    <div className={`w-4 h-4 rounded-full flex items-center justify-center shrink-0 ${
                      rank.id === 'devil_red'
                        ? 'bg-rose-500/25 text-rose-200'
                        : rank.id === 'midnight_purple'
                        ? 'bg-fuchsia-500/20 text-fuchsia-300'
                        : rank.id === 'purple'
                        ? 'bg-purple-500/20 text-purple-400'
                        : 'bg-red-500/20 text-red-400'
                    }`}>
                      <Check className="w-3 h-3" />
                    </div>
                    <span>{perk}</span>
                  </div>
                ))}
              </div>

              {/* Action Button */}
              <div>
                {isOwned ? (
                  <div className="w-full py-3.5 rounded-2xl bg-emerald-500/10 border-2 border-emerald-500/50 text-emerald-400 font-black text-center text-sm font-mono flex items-center justify-center gap-2">
                    <Check className="w-4 h-4" />
                    <span>მიმდინარე აქტიური რანკი</span>
                  </div>
                ) : isHigherOwned ? (
                  <div className="w-full py-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-slate-500 font-bold text-center text-xs font-mono">
                    გაქვს უფრო მაღალი VIP სტატუსი
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      if (!canAfford) {
                        onOpenExchangeModal();
                        return;
                      }
                      playWinSound(soundEnabled);
                      onBuyRank(rank.id, rank.priceCrystals);
                    }}
                    className={`w-full py-3.5 rounded-2xl font-black text-sm tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer ${
                      rank.id === 'devil_red'
                        ? 'bg-gradient-to-r from-rose-600 via-red-600 to-fuchsia-600 hover:brightness-110 text-white shadow-[0_0_26px_rgba(244,35,89,.45)] animate-pulse'
                        : rank.id === 'midnight_purple'
                        ? 'bg-gradient-to-r from-fuchsia-600 via-purple-600 to-amber-500 hover:brightness-110 text-white shadow-[0_0_25px_rgba(217,70,239,0.5)] animate-pulse'
                        : rank.id === 'purple'
                        ? 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-purple-500/40'
                        : 'bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white shadow-red-500/30'
                    }`}
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>
                      {canAfford
                          ? `შეძენა · ${rank.priceCrystals.toLocaleString()} 💎`
                        : `კრისტალების ყიდვა & შეძენა`}
                    </span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Built-in Quick Crystal Exchange Box */}
      <div className="p-6 rounded-3xl bg-slate-900/90 border-2 border-cyan-500/30 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 text-2xl flex items-center justify-center border border-cyan-500/40">
            💎
          </div>
          <div>
            <h4 className="text-base font-black text-slate-100">
              ფულის გადაცვლა კრისტალებში (Exchange)
            </h4>
            <p className="text-xs text-slate-400 font-mono">
              შეიყვანე სასურველი რაოდენობა: 10 💎 = 5,000 ₾ (1 💎 = 500 ₾)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:w-40">
            <input
              type="number"
              min="1"
              max="5000"
              value={exchangeInput}
              onChange={(e) => setExchangeInput(e.target.value)}
              className="w-full px-3 py-2.5 bg-slate-950 border border-slate-700 focus:border-cyan-500 rounded-xl text-slate-100 font-mono font-bold text-sm outline-none pl-9"
              placeholder="50"
            />
            <span className="absolute left-2.5 top-2.5 text-sm">💎</span>
          </div>

          <button
            onClick={handleQuickExchange}
            disabled={!canAffordExchange}
            className={`px-5 py-2.5 rounded-xl font-black text-xs font-mono tracking-wider flex items-center gap-2 transition-all ${
              canAffordExchange
                ? 'bg-gradient-to-r from-cyan-500 to-teal-500 text-slate-950 hover:brightness-110 shadow-md cursor-pointer'
                : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
            }`}
          >
            <span>გადაცვლა ({formatLari(exchangeCost)})</span>
          </button>
        </div>
      </div>
    </div>
  );
};



