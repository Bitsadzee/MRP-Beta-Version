# MRP Beta Version

MRP is a Georgian-language Money Roleplay simulator. This is an early beta: expect bugs and send feedback so we can improve it.

## Download and play

On the GitHub repository, open **Releases**, download `MRP Beta Version Setup`, and run it. The installer adds MRP to the Start menu.

## Report a bug

Open **Issues** in the GitHub repository and include what you clicked, what you expected, what happened, and a screenshot if possible. Do not include passwords or private account details.

## Player saves

Accounts and progress are saved on the current computer. This beta does not sync saves between people or devices, and reinstalling on another computer will not transfer a save.

## Run from source

Install Node.js LTS, run `npm install`, then `npm run dev`. For a Windows desktop build, run `npm run desktop:dist`. It creates the installer in `release/`.

## Automatic beta releases

Push a tag such as `v0.1.0-beta.0` to start the Windows build workflow. GitHub Actions attaches both Windows download formats to a prerelease automatically.

## Current beta changes

- Find cars by brand or model, enter a custom trading amount, and browse more sports leagues.
- Start with 20 ₾, use the expanded missions and jobs, and read each casino game's rules.
- Remove the safe-cracking game and the contracts tab; slot outcomes are based on reel results.
- Use the RedDevil rank, the refreshed menu and the gold MRP coin app icon.
