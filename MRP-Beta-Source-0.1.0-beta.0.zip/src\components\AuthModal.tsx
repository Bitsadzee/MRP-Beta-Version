﻿import React, { useState } from 'react';
import { Lock, User, KeyRound, Sparkles, ArrowRight, ShieldCheck, AlertCircle, LogIn, UserPlus } from 'lucide-react';
import { playClickSound, playCashSound } from '../utils/audio';

export interface UserAccount {
  username: string;
  passwordHash: string; // Stored securely in client storage
  createdAt: number;
  avatar: string;
  title: string;
}

interface AuthModalProps {
  isOpen: boolean;
  soundEnabled: boolean;
  onLoginSuccess: (username: string) => void;
  onRegisterSuccess: (username: string, password: string, avatar: string) => void;
  accounts: { [username: string]: UserAccount };
}

const AVATAR_OPTIONS = ['🕶️', '👑', '🏎️', '💎', '🦁', '🐺', '🎩', '👸', '🚀', '⚡'];

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  soundEnabled,
  onLoginSuccess,
  onRegisterSuccess,
  accounts
}) => {
  const [tab, setTab] = useState<'login' | 'register'>('login');
  const [username, setUsername] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [selectedAvatar, setSelectedAvatar] = useState<string>('🕶️');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const cleanUser = username.trim();

    if (!cleanUser || !password) {
      setError('გთხოვთ შეავსოთ მომხმარებლის სახელი და პაროლი');
      return;
    }

    const account = accounts[cleanUser.toLowerCase()];
    if (!account) {
      setError('ექაუნთი ამ სახელით ვერ მოიძებნა. გთხოვთ დარეგისტრირდეთ!');
      return;
    }

    if (account.passwordHash !== password) {
      setError('პაროლი არასწორია. სცადეთ თავიდან!');
      return;
    }

    playCashSound(soundEnabled);
    onLoginSuccess(account.username);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const cleanUser = username.trim();

    if (!cleanUser) {
      setError('გთხოვთ შეიყვანოთ მომხმარებლის სახელი');
      return;
    }

    if (cleanUser.length < 3) {
      setError('სახელი უნდა შეიცავდეს მინიმუმ 3 სიმბოლოს');
      return;
    }

    if (!password || password.length < 3) {
      setError('პაროლი უნდა შეიცავდეს მინიმუმ 3 სიმბოლოს');
      return;
    }

    if (accounts[cleanUser.toLowerCase()]) {
      setError('ეს მომხმარებლის სახელი უკვე დაკავებულია! აირჩიეთ სხვა ან გაიარეთ ავტორიზაცია');
      return;
    }

    playCashSound(soundEnabled);
    onRegisterSuccess(cleanUser, password, selectedAvatar);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-gradient-to-b from-[#13141f] via-[#0c0d15] to-[#08080d] border-2 border-emerald-500/40 rounded-3xl p-6 sm:p-8 shadow-[0_0_50px_rgba(16,185,129,0.25)] relative animate-in fade-in zoom-in-95 duration-200">
        {/* Glow Header */}
        <div className="text-center space-y-2 mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border border-emerald-500/40 text-3xl shadow-lg mb-1">
            {tab === 'login' ? '🔐' : '👑'}
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center justify-center gap-2">
            <span>MONEY SIMULATOR (RP)</span>
          </h2>
          <p className="text-xs text-slate-400">
            {tab === 'login'
              ? 'შეიყვანეთ თქვენი ექაუნთის სახელი და პაროლი თამაშში შესასვლელად'
              : 'შექმენით ახალი RP ექაუნთი (მეილი არ არის საჭირო, მხოლოდ სახელი & პაროლი)'}
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center p-1 bg-slate-950/80 rounded-xl border border-slate-800 mb-6">
          <button
            type="button"
            onClick={() => {
              playClickSound(soundEnabled);
              setTab('login');
              setError(null);
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              tab === 'login'
                ? 'bg-emerald-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>ავტორიზაცია (შესვლა)</span>
          </button>
          <button
            type="button"
            onClick={() => {
              playClickSound(soundEnabled);
              setTab('register');
              setError(null);
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              tab === 'register'
                ? 'bg-emerald-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>რეგისტრაცია</span>
          </button>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2 animate-shake">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Forms */}
        <form onSubmit={tab === 'login' ? handleLogin : handleRegister} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-emerald-400" />
              <span>მომხმარებლის სახელი</span>
            </label>
            <div className="relative">
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="მაგ: გიორგი_Boss ან David_King"
                className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 focus:border-emerald-500 focus:outline-none text-sm text-slate-100 placeholder-slate-500"
                autoFocus
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <KeyRound className="w-3.5 h-3.5 text-emerald-400" />
              <span>პაროლი</span>
            </label>
            <div className="relative">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="შეიყვანეთ პაროლი"
                className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 focus:border-emerald-500 focus:outline-none text-sm text-slate-100 placeholder-slate-500"
              />
            </div>
          </div>

          {/* Avatar picker on Register */}
          {tab === 'register' && (
            <div className="space-y-2 pt-1">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>აირჩიეთ საწყისი ავატარი</span>
              </label>
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                {AVATAR_OPTIONS.map((av) => (
                  <button
                    key={av}
                    type="button"
                    onClick={() => {
                      playClickSound(soundEnabled);
                      setSelectedAvatar(av);
                    }}
                    className={`w-10 h-10 rounded-xl text-xl flex items-center justify-center shrink-0 border transition-all ${
                      selectedAvatar === av
                        ? 'border-emerald-400 bg-emerald-500/20 scale-110 shadow-md'
                        : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
                    }`}
                  >
                    {av}
                  </button>
                ))}
              </div>
            </div>
          )}

          <button
            type="submit"
            className="w-full mt-2 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm shadow-[0_0_25px_rgba(16,185,129,0.35)] transition-all flex items-center justify-center gap-2 active:scale-95"
          >
            <span>{tab === 'login' ? 'თამაშში შესვლა' : 'ექაუნთის შექმნა & დაწყება'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="mt-5 pt-4 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500 font-mono">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>მონაცემები ინახება დაცულად</span>
          </span>
          <span>ვერსია 2.5 RP</span>
        </div>
      </div>
    </div>
  );
};


