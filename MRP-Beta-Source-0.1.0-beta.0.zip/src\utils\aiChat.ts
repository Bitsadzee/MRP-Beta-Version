﻿import { Friend, DirectMessage } from '../types/game';
import { CHARACTERS, getCharacterByName, BotCharacter } from './characters';

// Active Bots in the Room with distinct personalities
export const ACTIVE_CHAT_BOTS = Object.values(CHARACTERS);

export interface EconomicContext {
  recentMultiplier?: number;
  playerWon?: boolean;
  playerLost?: boolean;
  winAmount?: number;
  lossAmount?: number;
  cashedMultiplier?: number;
  playerBalance?: number;
  recentEvent?: string;
}

/**
 * Strips leading mentions or salutations containing the player's name
 * e.g. "Asusu, როგორ ხარ?" -> "როგორ ხარ?"
 * "@Asusu საღოლ!" -> "საღოლ!"
 */
export function stripRepetitiveName(text: string, playerName?: string): string {
  if (!text) return '';
  let clean = text.trim();

  if (playerName) {
    const escaped = playerName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    clean = clean.replace(new RegExp(`^(@?${escaped}\\s*[,:\\-–—]?\\s*)+`, 'i'), '').trim();
  }
  // Generic cleanup of common repetitive tags/names
  clean = clean.replace(/^(@?asusu\s*[,:\-–—]?\s*)+/i, '').trim();
  clean = clean.replace(/^(@?ასუსუ\s*[,:\-–—]?\s*)+/i, '').trim();
  clean = clean.replace(/^(@?მოთამაშე\s*[,:\-–—]?\s*)+/i, '').trim();

  if (clean.length === 0) return text;
  return clean.charAt(0).toUpperCase() + clean.slice(1);
}

// ==========================================
// 1. SMART SERVER-BACKED DIRECT MESSAGE CALL
// ==========================================
export async function getSmartAiDirectMessageReply(
  friend: Friend,
  userMessage: string,
  playerName: string,
  history: DirectMessage[] = [],
  economicContext?: EconomicContext
): Promise<string> {
  const character = getCharacterByName(friend.name);

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6500);

    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        botName: character.name,
        personality: character.personality,
        botBio: character.bio,
        characterSystemInstruction: character.systemInstruction,
        playerName,
        userMessage,
        isGlobal: false,
        economicContext,
        history: history.slice(-6).map((h) => ({
          sender: h.sender,
          text: h.text
        }))
      }),
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      if (data.reply && typeof data.reply === 'string' && data.reply.trim().length > 0) {
        return stripRepetitiveName(data.reply.trim(), playerName);
      }
    }
  } catch {
    // Fallback to our deep semantic character reasoning engine
  }

  const rawFallback = generateDeepCharacterReply(character, userMessage, playerName, history, economicContext);
  return stripRepetitiveName(rawFallback, playerName);
}

// ==========================================
// 2. SMART SERVER-BACKED GLOBAL CHAT REPLIES
// ==========================================
export async function getSmartAiGlobalChatReplies(
  playerMessage: string,
  playerName: string,
  playerLevel: number,
  economicContext?: EconomicContext,
  recentChatHistory?: Array<{ sender: string; text: string }>
): Promise<Array<{
  botName: string;
  avatar: string;
  level: number;
  text: string;
  delayMs: number;
  wantsToBeFriend?: boolean;
}>> {
  const lower = playerMessage.toLowerCase();

  // Find if a specific bot was mentioned
  let chosenChar: BotCharacter | undefined = ACTIVE_CHAT_BOTS.find((b) =>
    lower.includes(`@${b.name.toLowerCase()}`) || lower.includes(`@${b.name.toLowerCase().split('_')[0]}`)
  );

  if (!chosenChar) {
    if (lower.includes('მანქან') || lower.includes('m5') || lower.includes('ფერარ') || lower.includes('დრიფტ') || lower.includes('სისწრაფ') || lower.includes('bmw')) {
      chosenChar = CHARACTERS.sandro;
    } else if (lower.includes('სიყვარულ') || lower.includes('გოგო') || lower.includes('ბიჭ') || lower.includes('გრძნობ') || lower.includes('ურთიერთობ')) {
      chosenChar = CHARACTERS.nino;
    } else if (lower.includes('წიგნ') || lower.includes('მარტოობ') || lower.includes('სიმშვიდ') || lower.includes('აზრ') || lower.includes('მუსიკ')) {
      chosenChar = CHARACTERS.mariam;
    } else if (lower.includes('ბიზნეს') || lower.includes('ინვესტიც') || lower.includes('კრიპტ') || lower.includes('შემოსავალ') || lower.includes('აქცი')) {
      chosenChar = CHARACTERS.luka;
    } else if (lower.includes('სიკეთ') || lower.includes('დახმარებ') || lower.includes('იმედ') || lower.includes('გამამხნევ')) {
      chosenChar = CHARACTERS.elene;
    } else if (lower.includes('ცხოვრებ') || lower.includes('დრო') || lower.includes('მოთმინებ') || lower.includes('წუთისოფელ')) {
      chosenChar = CHARACTERS.giorgi_philo;
    } else if (lower.includes('მატრიც') || lower.includes('ჰაკერ') || lower.includes('უცხოპლანეტ') || lower.includes('კოდ')) {
      chosenChar = CHARACTERS.temo;
    } else if (lower.includes('საცობ') || lower.includes('ნერვებ') || lower.includes('გამწეწ') || lower.includes('სატვირთო')) {
      chosenChar = CHARACTERS.beka;
    } else if (lower.includes('ავიატორ') || lower.includes('გასკდა') || lower.includes('კოეფიციენტ') || lower.includes('ფრენა')) {
      chosenChar = CHARACTERS.lasha;
    } else if (lower.includes('პატივისცემ') || lower.includes('სიტყვა') || lower.includes('სინდიკატ')) {
      chosenChar = CHARACTERS.tornike;
    } else {
      const keys = Object.keys(CHARACTERS);
      chosenChar = CHARACTERS[keys[Math.floor(Math.random() * keys.length)]];
    }
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6500);

    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        botName: chosenChar.name,
        personality: chosenChar.personality,
        botBio: chosenChar.bio,
        characterSystemInstruction: chosenChar.systemInstruction,
        playerName,
        userMessage: playerMessage,
        isGlobal: true,
        economicContext,
        history: recentChatHistory?.slice(-5)
      }),
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      if (data.reply && typeof data.reply === 'string' && data.reply.trim().length > 0) {
        const cleanText = stripRepetitiveName(data.reply.trim(), playerName);
        return [{
          botName: chosenChar.name,
          avatar: chosenChar.avatar,
          level: chosenChar.level,
          text: cleanText,
          delayMs: 800 + Math.random() * 600,
          wantsToBeFriend: Math.random() > 0.45
        }];
      }
    }
  } catch {
    // Offline fallback
  }

  const rawOffline = generateDeepCharacterReply(chosenChar, playerMessage, playerName, [], economicContext);
  const cleanOffline = stripRepetitiveName(rawOffline, playerName);

  return [{
    botName: chosenChar.name,
    avatar: chosenChar.avatar,
    level: chosenChar.level,
    text: cleanOffline,
    delayMs: 800,
    wantsToBeFriend: true
  }];
}

// ==========================================
// 3. DYNAMIC GLOBAL ROOM CHATTER BETWEEN BOTS
// ==========================================
export async function getDynamicRoomChatter(
  recentMessages: Array<{ senderName: string; text: string }>,
  playerName: string
): Promise<{
  senderName: string;
  avatar: string;
  level: number;
  text: string;
  replyTo?: string;
}> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5500);

    const res = await fetch('/api/chat/room-chatter', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        recentMessages: recentMessages.slice(-5),
        playerName,
        roomType: 'global'
      }),
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      if (data.senderName && data.text) {
        return {
          senderName: data.senderName,
          avatar: data.avatar || '💬',
          level: data.level || 75,
          text: stripRepetitiveName(data.text, playerName),
          replyTo: data.replyTo
        };
      }
    }
  } catch {
    // Fallback to dynamic room generator
  }

  // Dynamic room dialogue generator based on context
  const bots = [CHARACTERS.sandro, CHARACTERS.nino, CHARACTERS.luka, CHARACTERS.mariam, CHARACTERS.beka, CHARACTERS.elene, CHARACTERS.giorgi_philo, CHARACTERS.temo];
  const speaker = bots[Math.floor(Math.random() * bots.length)];

  const dialoguePools: Record<string, string[]> = {
    friend_sandro: [
      `დღეს ავტობანზე გავედი და ისეთი ხოდი ქონდა M5-ს, 300 წამებში აკრიფა! 🏎️💨`,
      `ქალაქში რა სიჩუმეა, დღეს ღამე სანაპიროზე დრიფტის პონტია ბიჭებო! 🔥`,
      `ლუქს შოპში მანქანები ნახეთ? Ferrari SF90-ზე ვოცნებობდი წლებია!`
    ],
    friend_nino: [
      `საღამოს თბილისი ისეთი მშვენიერია ხოლმე... განსაკუთრებით როცა პენტჰაუსიდან ყავით ხელში უყურებ ✨`,
      `სიმშვიდე და კარგი მუსიკა ყველაფერს კურნავს, საოცარი განტვირთვაა ❤️`,
      `აქაური ატმოსფერო ძალიან მომწონს, ეტყობა რომ ქალაქს თავისი ცოცხალი რიტმი აქვს.`
    ],
    friend_luka: [
      `პასიური შემოსავალი ყველაზე ჭკვიანური გზაა. 120-წამიანი აფგრეიდები უკვე ყველამ ჩართეთ? 📈`,
      `ბაზარზე ახალი კრიპტო რალი იწყება, დროზე გადაანაწილეთ კაპიტალი! 💼`,
      `ფული მუშაობს მაშინაც, როცა ჩვენ გვძინავს — აი ესაა ნამდვილი ფინანსური თავისუფლება.`
    ],
    friend_mariam: [
      `წიგნის კითხვას არაფერი შეედრება... ხანდახან მგონია, რომ სიჩუმეში უფრო მეტი პასუხია, ვიდრე ხმაურში 🌿`,
      `ადამიანებს ხშირად ავიწყდებათ, რომ მთავარი შინაგანი ჰარმონიაა და არა უბრალო რბოლა.`,
      `ღამის თბილისს ისეთი განსაკუთრებული სევდა და სილამაზე აქვს ხოლმე... 📖`
    ],
    friend_beka: [
      `ისევ სანაპიროზე იყო საცობი, ვინ აპროექტებს ამ გზებს საერთოდ?! 🤬`,
      `როგორ ინარჩუნებს ზოგი სიმშვიდეს არ მესმის, მე ყოველდღე ნერვები მაქვს მოშლილი 😤`,
      `სიმართლე თუ გინდათ, მხოლოდ სანდო ძმაკაცების იმედი მაქვს ამ ქალაქში.`
    ],
    friend_elene: [
      `ყველას საუკეთესო და პოზიტიურ განწყობას გისურვებთ! თუ ვინმეს დახმარება გჭირდებათ, აქ ვარ 💖`,
      `გაიღიმეთ, დღეს მშვენიერი დღეა ახალი დასაწყისისთვის! 🌸`,
      `სიკეთე ყოველთვის ბუმერანგივით ბრუნდება, არასდროს დაკარგოთ რწმენა!`
    ],
    friend_giorgi_philo: [
      `დრო ყველაფერს თავის ადგილს მიუჩენს, ჩემო მეგობრებო. მოთმინება ყველაზე დიდი იარაღია ☕`,
      `ცხოვრება ერთი დიდი თამაშია, მთავარია ღირსება არ დაკარგო გზაში.`,
      `ჭეშმარიტი სიმდიდრე იმაშია, თუ რამდენად მშვიდად გძინავს ღამით.`
    ],
    friend_temo_weird: [
      `ხალხო, გეფიცებით, მატრიცაში ახალი პატჩი ჩაუშვეს, ქალაქის ნეონები უცნაურად ციმციმებს! 🛸`,
      `კვანტური ალგორითმი გავშიფრე და ავიატორის შემდეგი ციკლი გამოვითვალე 👾`,
      `პარალელურ განზომილებაში უკვე ყველანი მილიარდერები ვართ, დროის საკითხია!`
    ]
  };

  const pool = dialoguePools[speaker.id] || dialoguePools.friend_sandro;
  const pickedText = pool[Math.floor(Math.random() * pool.length)];

  return {
    senderName: speaker.name,
    avatar: speaker.avatar,
    level: speaker.level,
    text: pickedText,
    replyTo: pickedText.startsWith('@') ? pickedText.split(' ')[0] : undefined
  };
}

// ==========================================
// 4. SMART AVIATOR BOT REACTIONS
// ==========================================
export async function getSmartAviatorBotReaction(params: {
  event: 'crash' | 'player_win' | 'player_loss' | 'high_multiplier' | 'user_chat';
  multiplier: number;
  playerName: string;
  playerLevel?: number;
  betAmount?: number;
  winAmount?: number;
  userMessage?: string;
  recentMessages?: Array<{ sender: string; text: string }>;
}): Promise<{
  botName: string;
  avatar: string;
  level: number;
  text: string;
  mood: 'rage' | 'joy' | 'crying' | 'threat' | 'normal';
}> {
  const { event, multiplier, playerName, betAmount, winAmount, userMessage, recentMessages } = params;

  let candidateChar: BotCharacter = CHARACTERS.lasha;
  let mood: 'rage' | 'joy' | 'crying' | 'threat' | 'normal' = 'normal';

  if (event === 'crash' && multiplier < 1.15) {
    candidateChar = Math.random() > 0.5 ? CHARACTERS.lasha : CHARACTERS.beka;
    mood = 'rage';
  } else if (event === 'player_win' || multiplier > 8.0) {
    candidateChar = Math.random() > 0.5 ? CHARACTERS.sandro : CHARACTERS.luka;
    mood = 'joy';
  } else if (event === 'player_loss') {
    candidateChar = Math.random() > 0.5 ? CHARACTERS.elene : CHARACTERS.lasha;
    mood = 'crying';
  } else if (event === 'user_chat') {
    const low = (userMessage || '').toLowerCase();
    if (low.includes('წავაგე') || low.includes('გასკდა') || low.includes('ფული') || low.includes('წაიღო')) {
      candidateChar = CHARACTERS.lasha;
      mood = 'rage';
    } else if (low.includes('მოვიგე') || low.includes('საღოლ') || low.includes('მაგარია') || low.includes('გავიტანე')) {
      candidateChar = CHARACTERS.sandro;
      mood = 'joy';
    } else if (low.includes('რჩევა') || low.includes('სტრატეგია') || low.includes('როგორ')) {
      candidateChar = CHARACTERS.luka;
      mood = 'normal';
    } else {
      const candidates = [CHARACTERS.sandro, CHARACTERS.nino, CHARACTERS.lasha, CHARACTERS.luka, CHARACTERS.temo];
      candidateChar = candidates[Math.floor(Math.random() * candidates.length)];
      mood = 'normal';
    }
  }

  // Attempt real AI generation
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6500);

    const promptMessage = userMessage || (
      event === 'crash'
        ? (multiplier < 1.15 ? `თვითმფრინავი ეგრევე გასკდა ${multiplier.toFixed(2)}x-ზე!` : `რეისი დასრულდა ${multiplier.toFixed(2)}x-ზე.`)
        : event === 'player_win'
        ? `მოთამაშემ ახლახან გაიტანა მოგება +${winAmount} ₾ (${multiplier.toFixed(2)}x-ზე)!`
        : event === 'player_loss'
        ? `მოთამაშემ წააგო ${betAmount} ₾ რადგან თვითმფრინავი ${multiplier.toFixed(2)}x-ზე გასკდა.`
        : `თვითმფრინავი ავიდა ${multiplier.toFixed(2)}x-ზე!`
    );

    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        botName: candidateChar.name,
        personality: candidateChar.personality,
        botBio: candidateChar.bio,
        characterSystemInstruction: candidateChar.systemInstruction,
        playerName,
        userMessage: promptMessage,
        gameType: 'aviator',
        isGlobal: true,
        economicContext: {
          recentMultiplier: multiplier,
          playerWon: event === 'player_win',
          playerLost: event === 'player_loss',
          winAmount,
          lossAmount: betAmount,
          recentEvent: event
        },
        history: recentMessages?.slice(-5)
      }),
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      if (data.reply && typeof data.reply === 'string' && data.reply.trim().length > 0) {
        return {
          botName: candidateChar.name,
          avatar: candidateChar.avatar,
          level: candidateChar.level,
          text: stripRepetitiveName(data.reply.trim(), playerName),
          mood
        };
      }
    }
  } catch {
    // Fallback
  }

  // Deep contextual reaction without repetitive name prefixes
  let text = '';
  if (userMessage) {
    const low = userMessage.toLowerCase().trim();
    const has = (...words: string[]) => words.some((word) => low.includes(word));
    const quoted = userMessage.trim().slice(0, 54);
    if (has('წავაგე', 'წამაგებ', 'შემეჭამა', 'გავფლანგე', 'მომეტყნა', 'მოვტყუვდი')) {
      mood = 'rage';
      candidateChar = CHARACTERS.lasha;
      text = 'აუუ, მესმის რა ნერვების მომშლელია 😤 ცოტა შეისვენე და შემდეგი ფსონი პატარა დადე, მთელი ბალანსი არ გარისკო.';
    } else if (has('მოვიგე', 'გავიტანე', 'მოვხსენი', 'საღოლ', 'მაგარია', 'მიხარია')) {
      mood = 'joy';
      candidateChar = CHARACTERS.sandro;
      text = 'ვაა, გილოცავ! 🔥 მოგება ჩაირიცხე და ნუ დააბრუნებ ისევ თამაშში, ძმაო!';
    } else if (has('გამარჯობა', 'სალამი', 'ჰეი', 'როგორ ხარ', 'რას შვები')) {
      mood = 'joy';
      candidateChar = CHARACTERS.nino;
      text = 'ჰეი, გაგიმარჯოს! 😊 მე კარგად ვარ, ჩატში ვათვალიერებ რეისებს. შენ როგორ ხარ?';
    } else if (has('მადლობა', 'გაიხარე', 'გმადლობ')) {
      mood = 'joy';
      candidateChar = CHARACTERS.nino;
      text = 'არაფრის, მეგობარო 💚 რამე თუ დაგაინტერესებს, მომწერე.';
    } else if (has('მანქანა', 'მანქან', 'bmw', 'm5', 'მერსედეს', 'პორშე', 'ფერრარ', 'დრიფტ')) {
      candidateChar = CHARACTERS.sandro;
      text = 'მანქანებზე? ეგ ჩემი თემაა 🏎️ ჯერ სტაბილური შემოსავალი ააწყე და მერე საყვარელი მანქანა დაითრიე. რომელ მოდელზე ფიქრობ?';
    } else if (has('ფული', 'ფულს', 'ფულის', 'სამუშაო', 'ხელფას', 'ბიზნეს', 'კრისტალ')) {
      candidateChar = CHARACTERS.luka;
      text = 'ფულზე გეტყვი: სამუშაოებისა და კონტრაქტების დავალებები შეასრულე, მერე შემოსავლის ნაწილი ბიზნესში დააბრუნე 💼 კონკრეტულად რა გაინტერესებს?';
    } else if (has('ავიატორ', 'თვითმფრინავ', 'რეის', 'კოეფიციენტ', 'ფსონ', 'ქეშაუთ', 'გასკდა')) {
      candidateChar = has('რჩევ', 'როგორ', 'რატომ') ? CHARACTERS.luka : CHARACTERS.lasha;
      mood = has('გასკდა') ? 'rage' : 'normal';
      text = has('რჩევ', 'როგორ', 'რატომ')
        ? 'ზუსტი გარანტირებული სტრატეგია არ არსებობს — რეისი შემთხვევით სრულდება. x2-ზე ადრე გასვლა რისკს კი ამცირებს, მაგრამ მოგებას არ იძლევა 📉'
        : `აჰა, ავიატორზე ამბობ: „${quoted}“ ✈️ ვნახოთ შემდეგი რეისი რას იზამს.`;
    } else if (low.endsWith('?') || has('როგორ', 'რატომ', 'სად', 'როდის', 'რამდენი', 'შეიძლება')) {
      candidateChar = CHARACTERS.luka;
      text = `კარგი შეკითხვაა — „${quoted}“. ზუსტად ამაზე მეკითხები? ერთი სიტყვით დამიზუსტე და გიპასუხებ 🙂`;
    } else if (has('😂', '🤣', 'სასაცილ', 'ვხუმრობ')) {
      mood = 'joy';
      candidateChar = CHARACTERS.sandro;
      text = `ჰაჰა, გავიგე 😄 „${quoted}“ — ჩატს ხასიათი შემოიტანე.`;
    } else if (has('🤬', 'გინებ', 'მომიტყ', 'ჯანდაბა', 'ვერ ვიტან')) {
      mood = 'rage';
      candidateChar = CHARACTERS.lasha;
      text = `ვა, მაგრად გაბრაზებულხარ 😤 „${quoted}“ — რა მოხდა, რეისმა გაგწეწა?`;
    } else {
      const candidates = [CHARACTERS.sandro, CHARACTERS.nino, CHARACTERS.lasha, CHARACTERS.luka, CHARACTERS.temo];
      candidateChar = candidates[Math.floor(Math.random() * candidates.length)];
      text = `გავიგე, ამბობ: „${quoted}“ 🙂 მომიყევი ცოტა მეტი — რას გულისხმობ?`;
    }
  } else if (event === 'crash') {
    if (multiplier < 1.15) {
      text = candidateChar.id === 'friend_lasha_gldaneli'
        ? `აუუუ ${multiplier.toFixed(2)}x რა უნამუსობაა?! 1 წამში გააქრო ფსონი! 🤬`
        : `ისევ 1 წამში გასკდა (${multiplier.toFixed(2)}x)... ვინმემ მოასწრო საერთოდ გამოტანა? 😤`;
    } else if (multiplier > 10.0) {
      text = `ვაააა ${multiplier.toFixed(2)}x დაჯდა! ვინ დარჩა ბოლომდე?! სასწაული რეისი იყო! 🚀💎`;
    } else if (multiplier > 4.0) {
      text = `მშვენიერი ${multiplier.toFixed(2)}x რეისი იყო! ვისაც ქონდა დაყენებული, კარგად გაიტანა 🔥`;
    } else {
      text = `${multiplier.toFixed(2)}x ნორმალური კოეფიციენტი იყო, 2x-ზე მშვენივრად გამოდიოდა 👍`;
    }
  } else if (event === 'player_win') {
    text = `საღოლ! +${winAmount} ₾ მშვენიერი შედეგია, რა დროზე დააჭირე განაღდებას! 🔥`;
  } else if (event === 'player_loss') {
    text = `არაუშავს, ${multiplier.toFixed(2)}x-ზე უცებ გასკდა. შემდეგ რეისზე აუცილებლად ამოვიღებთ! 👊`;
  }

  return {
    botName: candidateChar.name,
    avatar: candidateChar.avatar,
    level: candidateChar.level,
    text: stripRepetitiveName(text || `${multiplier.toFixed(2)}x-ზე გასკდა!`, playerName),
    mood
  };
}

// ==========================================
// 5. DYNAMIC AVIATOR ROOM LIVE CHATTER
// ==========================================
export async function getDynamicAviatorChatter(
  recentMessages: Array<{ senderName: string; text: string }>,
  playerName: string
): Promise<{
  senderName: string;
  avatar: string;
  level: number;
  text: string;
  mood: 'rage' | 'joy' | 'normal' | 'crying';
}> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5500);

    const res = await fetch('/api/chat/room-chatter', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        recentMessages: recentMessages.slice(-5),
        playerName,
        roomType: 'aviator'
      }),
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      if (data.senderName && data.text) {
        return {
          senderName: data.senderName,
          avatar: data.avatar || '✈️',
          level: data.level || 50,
          text: stripRepetitiveName(data.text, playerName),
          mood: data.mood || 'normal'
        };
      }
    }
  } catch {
    // fallback
  }

  const aviatorBots = [
    { name: 'ლაშა_Gldaneli', avatar: '🦁', level: 48, pool: [
      'დღეს ალგორითმი კარგ ხოდზეა, 3x-ს ველოდები შემდეგზე!',
      'წეღან 1.04-ზე რომ გასკდა, ლამის ტელეფონი გავტეხე ნერვებისგან 🤬',
      'ბიჭებო 2x-ზე გაიტანეთ ხოლმე, ნუ ხარბობთ და ყოველთვის პლუსში იქნებით!'
    ]},
    { name: 'სანდრო_M5', avatar: '🏎️', level: 94, pool: [
      'გაზი ბოლომდე! შემდეგ რეისზე 100 ლარს ვდებ 2.5x-ზე 🚀',
      'მთავარია ცივი გონება, აზარტი არ უნდა აგყვეს!',
      'მოგებული მაყუთი პირდაპირ ავტო-შოპში მიმაქვს, M5-ს ახალი დისკები ჭირდება 🔥'
    ]},
    { name: 'ლუკა_Trader', avatar: '💎', level: 165, pool: [
      'სტატისტიკურად ყოველი 5 დაბალი კოეფიციენტის შემდეგ ერთი 5x+ მოდის 📈',
      'რისკ-მენეჯმენტი დაიცავით, ბალანსის 5%-ზე მეტი არასდროს დადოთ ერთ რეისზე.',
      'პასიური ბიზნესებიდან შემოსული თანხით თამაში ყველაზე უსაფრთხოა 💼'
    ]},
    { name: 'გიორგი_Vake', avatar: '🕶️', level: 42, pool: [
      'გუშინ 14.8x დავიჭირე და მთელი დღის გეგმა შევასრულე ✨',
      'ავიატორს თავისი მუღამი აქვს, ადრენალინი პიკზეა!',
      'აბა შემდეგ რეისზე ვინ დებს ფსონს? ✈️'
    ]}
  ];

  const pickedBot = aviatorBots[Math.floor(Math.random() * aviatorBots.length)];
  const text = pickedBot.pool[Math.floor(Math.random() * pickedBot.pool.length)];

  return {
    senderName: pickedBot.name,
    avatar: pickedBot.avatar,
    level: pickedBot.level,
    text,
    mood: text.includes('🤬') ? 'rage' : text.includes('🔥') || text.includes('🚀') ? 'joy' : 'normal'
  };
}

// ==========================================
// 6. DEEP CHARACTER REASONING ENGINE (OFFLINE)
// ==========================================
export function generateDeepCharacterReply(
  char: BotCharacter,
  userMessage: string,
  _playerName: string,
  _history: DirectMessage[] = [],
  economicContext?: EconomicContext
): string {
  const text = userMessage.toLowerCase().trim();

  // 1. CARS, RACING & SPEED
  if (text.includes('მანქან') || text.includes('bmw') || text.includes('m5') || text.includes('ფერარ') || text.includes('მუსტანგ') || text.includes('პორშე') || text.includes('დრიფტ') || text.includes('სისწრაფ')) {
    switch (char.id) {
      case 'friend_sandro':
        return `ჩემი თემაა! Ferrari F8-სა და M5 CS-ზე მეტად არაფერი მიყვარს ამ ცხოვრებაში. V8 BiTurbo-ს ხმა და 720 ცხენის ძალა რომ გულში გირტყამს, ადრენალინი პიკზეა! შენ რომელი მანქანა გევასება? 🏎️💨`;
      case 'friend_nino':
        return `მანქანებში მთავარი კომფორტი და ესთეტიკაა... Maybach-ის უკანა სავარძელში ჯდომას და თბილისის ღამის ხედებით ტკბობას არაფერი შეედრება ✨`;
      case 'friend_luka':
        return `მანქანა პრესტიჟთან ერთად კარგი აქტივიცაა, ოღონდ თუ Porsche 911 GT3 RS-ს იყიდი, ფასი თითქმის არ უვარდება! 📈`;
      case 'friend_beka':
        return `Dodge Demon SRT 840HP მყავს და საცობებში ნერვები მეშლება, მაგრამ ტრასაზე რომ გავალ, ყველა გვერდზე იწევა ხოლმე! 😤`;
      case 'friend_mariam':
        return `სისწრაფეზე მეტად წყნარი მგზავრობა მირჩევნია, საყვარელი მუსიკა და ფიქრები... ხმაური მღლის 🌿`;
      default:
        return `მანქანები ქალაქის რიტმის განუყოფელი ნაწილია. მთავარია მართვისგან სიამოვნება მიიღო!`;
    }
  }

  // 2. LOVE, RELATIONSHIPS & EMOTIONS
  if (text.includes('სიყვარულ') || text.includes('შეყვარებულ') || text.includes('გოგო') || text.includes('ბიჭ') || text.includes('მიყვარს') || text.includes('ურთიერთობ') || text.includes('დავშორდ') || text.includes('გული')) {
    switch (char.id) {
      case 'friend_nino':
        return `სიყვარული ყველაზე ძვირფასი რამაა, რაც შეიძლება ადამიანს დაემართოს. მთავარია გულწრფელობა — როცა შენს ადამიანს პოულობ, მთელი სამყარო სხვა ფერებით ივსება. შენს გულში რა ხდება ახლა? მოყევი, სიამოვნებით მოგისმენ ❤️`;
      case 'friend_mariam':
        return `ხშირად ვფიქრობ ამაზე... ნამდვილი გრძნობები დღეს იშვიათია, იმიტომ რომ ადამიანებს ეშინიათ საკუთარი სისუსტის გამოჩენის. მაგრამ თუ ვინმე გიყვარს, მისი გაგება და გვერდში დგომა ყველაზე დიდი ძალაა 📖`;
      case 'friend_elene':
        return `სიყვარულს შეუძლია ნებისმიერი ჭრილობა მოაშუშოს! არასდროს დაკარგო რწმენა, შენ ძალიან თბილი და კარგი ადამიანი ხარ, ყველაფერი ლამაზად დალაგდება, გპირდები 🌸`;
      case 'friend_sandro':
        return `ეჰ ძმაო, სიყვარულიც რბოლასავითაა — ზოგჯერ 300-ით მიდიხარ და უცებ მოსახვევში მოცურდები! მთავარია საჭე ხელში გეჭიროს და თავმოყვარეობა არ დაკარგო 👊`;
      case 'friend_giorgi_philo':
        return `სიყვარული ის ერთადერთი საგანძურია, რასაც წუთისოფელი ვერ წაგართმევს, ჩემო მეგობარო. ოღონდ მოთმინებაა საჭირო, ნამდვილი გრძნობა წლებით იწრთობა ☕`;
      case 'friend_dato_cold':
        return `სიყვარული დოფამინის და ენდორფინების დროებითი ქიმიური რეაქციაა 😏 თუმცა თუ პარტნიორი შენს მიზნებს იზიარებს, ეგ უკვე კარგი გუნდური მუშაობაა!`;
      default:
        return `ურთიერთობები ყველაზე რთული და ამავე დროს ყველაზე საინტერესო თემაა. მთავარია საკუთარ თავს არ უღალატო!`;
    }
  }

  // 3. MONEY, BUSINESS & INVESTMENTS
  if (text.includes('ფულ') || text.includes('ბიზნეს') || text.includes('ინვესტიც') || text.includes('გამდიდრ') || text.includes('კრიპტ') || text.includes('შემოსავალ') || text.includes('აფგრეიდ')) {
    switch (char.id) {
      case 'friend_luka':
        return `ფულის კეთების მთავარი კანონია: არასდროს იმუშაო მხოლოდ ხელფასზე! "სამუშაო & ბიზნესი"-ს ჩანართში ბიზნესები ჩართე და 120-წამიანი აფგრეიდები გააკეთე — პასიური შემოსავალი წამში გერიცხება და კაპიტალი თვითონ იზრდება 📈💼`;
      case 'friend_sandro':
        return `ფული კარგია როცა შეგიძლია საოცნებო მანქანა იყიდო და მეგობრებთან ერთად ისიამოვნო! მთავარია სწრაფად იმოქმედო და შანსი ხელიდან არ გაუშვა 🚀`;
      case 'friend_giorgi_philo':
        return `ფული კარგი მსახურია, მაგრამ ცუდი ბატონი. როცა ბევრი გაქვს, სხვებსაც გაუწოდე ხელი და სიმშვიდე არ დაკარგო ☕`;
      case 'friend_nino':
        return `ფული თავისუფლებას გაძლევს, რომ შენი ოცნებების გარემო შეიქმნა, იმოგზაურო და საყვარელ ადამიანებს სიხარული აჩუქო ✨`;
      default:
        return `ფინანსური დამოუკიდებლობა საუკეთესო შეგრძნებაა! მიზანმიმართულად აგროვე და ბიზნესებში ჩადე.`;
    }
  }

  // 4. AVIATOR, SLOTS & BETTING
  if (text.includes('ავიატორ') || text.includes('წავაგე') || text.includes('მოვიგე') || text.includes('სლოტ') || text.includes('ფსონ') || text.includes('გასკდა') || text.includes('კოეფიციენტ')) {
    if (economicContext?.playerWon) {
      return `გილოცავ მოგებას! საღოლ, დროზე გამოიტანე! ჩემი რჩევაა ეგ მაყუთი მაშინვე უძრავ ქონებაში ან ბიზნესში დააბანდო, რომ აზარტში არ დაგრჩეს! 🔥`;
    }
    if (text.includes('წავაგე') || text.includes('გასკდა')) {
      return `მესმის შენი... ავიატორმა უცებ იცის ხოლმე გაპარსვა, განსაკუთრებით 1.05x-ზე რო გასკდება. ცოტა ხანი შეისვენე, ყავა დალიე და დამშვიდდი, ფულს ყოველთვის იშოვი, ნერვებია მთავარი! ❤️`;
    }
    return `აზარტულ თამაშებში მთავარი ცივი გონებაა. 2.0x-ზე დააყენე ხოლმე ავტო-ქეშაუთი და ნუ ხარბობ!`;
  }

  // 5. PHILOSOPHY, SADNESS & BURNOUT
  if (text.includes('დავიღალ') || text.includes('ცუდად') || text.includes('დეპრესი') || text.includes('მარტო') || text.includes('ცხოვრებ') || text.includes('აზრ') || text.includes('მოწყენილ')) {
    switch (char.id) {
      case 'friend_elene':
        return `ძალიან მესმის შენი... ყველას გვაქვს დღეები, როცა თითქოს ძალა აღარ გვყოფნის. მინდა იცოდე, რომ მარტო არ ხარ! გაიღიმე, ღრმად ჩაისუნთქე, ეს დროებითი ეტაპია და ყველაფერი აუცილებლად კარგად იქნება, მე შენთან ვარ 💖`;
      case 'friend_mariam':
        return `დაღლა ადამიანურია... ხანდახან უბრალოდ უნდა გაჩერდე, გათიშო ხმაური და საკუთარ თავს სიმშვიდე აჩუქო. თუ გინდა გული გადამიშალე, ყოველთვის მოგისმენ 🌿`;
      case 'friend_giorgi_philo':
        return `ყოველი ღამის შემდეგ მზე ამოდის, ჩემო ძმაო. ცხოვრება ტალღებივითაა — დაცემა მხოლოდ იმისთვისაა, რომ შემდეგ უფრო მაღლა ახვიდე. მოითმინე და გაძლიერდები ☕`;
      case 'friend_beka':
        return `მართალი ხარ, ამ ქალაქში ხანდახან ყველაფერი ყელში ამოგდის! მაგრამ არ დანებდე, ჩემიანებს არ უყვართ ფარ-ხმალის დაყრა. ერთად გადავლახავთ 😤👊`;
      default:
        return `მესმის შენი განწყობა. დაისვენე ცოტა, გაისეირნე და გაიხსენე, რამდენი რამ გაქვს უკვე გადალახული!`;
    }
  }

  // 6. GREETINGS & CASUAL
  if (text.startsWith('სალამ') || text.startsWith('გაუმარჯ') || text.startsWith('როგორ ხარ') || text.includes('რას შვრები') || text.includes('რას აკეთებ')) {
    switch (char.id) {
      case 'friend_nino':
        return `გამარჯობა! ძალიან გამიხარდა შენი მოწერა ✨ პენტჰაუსის ტერასაზე ყავას ვსვამ და საღამოს ვგეგმავ. შენ როგორ ხარ, რა ხდება შენსკენ ახალი?`;
      case 'friend_sandro':
        return `გაუმარჯოს ჩემს ძმას! გარაჟში ვიყავი, M5-ის ტურბინებს ვამოწმებდი. შენ როგორ ხარ, რას საქმიანობ დღეს? 🏎️`;
      case 'friend_luka':
        return `სალამი! ბაზრების ანალიზს ვასრულებდი. შენი ფინანსები როგორ მიდის, რაიმე ახალ ბიზნესს ხომ არ გეგმავ? 📈`;
      case 'friend_mariam':
        return `გამარჯობა... ჩაის ვსვამდი და წიგნს ვკითხულობდი. მიხარია რომ მომწერე, როგორ გრძნობ თავს? 🌿`;
      case 'friend_temo':
        return `ოჰო! მატრიცის ცენტრალური სერვერებიდან გესალმები 🛸 რა ისმის ჩვენს განზომილებაში, რამე საინტერესო ხდება?`;
      default:
        return `გაუმარჯოს! მშვენიერ ხასიათზე ვარ. შენ როგორ ხარ, რა ხდება შენსკენ?`;
    }
  }

  // 7. QUESTIONS ABOUT THE CHARACTER ("ვინ ხარ", "რას საქმიანობ", "მირჩიე")
  if (text.includes('ვინ ხარ') || text.includes('შენზე') || text.includes('მომიყევი')) {
    return `მე ვარ ${char.name} — ${char.bio}. ამ ქალაქში დიდი ხანია ვცხოვრობ და ჩემთვის მთავარია ნამდვილი მეგობრობა და გულწრფელი საუბრები! შენზე რას მეტყვი? ✨`;
  }

  // 8. ADVICE REQUEST ("მირჩიე", "რა ვქნა", "როგორ მოვიქცე")
  if (text.includes('მირჩი') || text.includes('რა ვქნა') || text.includes('როგორ მოვიქცე')) {
    switch (char.id) {
      case 'friend_luka':
        return `ჩემი რჩევაა: ემოციები გვერდზე გადადე, ცივი გონებით დათვალე რისკები და ფული პასიურ ბიზნესებში ჩადე. გრძელვადიან პერსპექტივაში ყოველთვის მოიგებ! 📈`;
      case 'friend_nino':
        return `ჩემი რჩევაა, მოუსმინო შენს ინტუიციას. როცა გული რაღაცას გეუბნება, იშვიათად ცდება. მთავარია საკუთარ თავს ენდო ❤️`;
      case 'friend_sandro':
        return `ჩემი რჩევაა: გაბედე და იმოქმედე! ვინც რისკავს და გაზს აჭერს, ის იგებს. ოღონდ უკანდასახევი გზა ყოველთვის დაიტოვე 👊`;
      case 'friend_giorgi_philo':
        return `ნუ აჩქარდები, ჩემო მეგობარო. ყველაზე სწორი გადაწყვეტილება მშვიდ გონებაში იბადება. დრო მიეცი საკუთარ თავს ☕`;
      default:
        return `დაფიქრდი, რა არის შენთვის ახლა ყველაზე მნიშვნელოვანი, და გადაწყვეტილებაც თავისით გამოჩნდება!`;
    }
  }

  // 9. GENERAL ORGANIC DIALOGUE
  switch (char.id) {
    case 'friend_nino':
      return `საინტერესო აზრია... მომწონს შენთან საუბარი, იმიტომ რომ შენი საკუთარი, განსაკუთრებული ხედვა გაქვს ყველაფერზე ✨ კიდევ რა გაქვს გულში?`;
    case 'friend_sandro':
      return `მართალს ამბობ ძმაო, 100%-ით გეთანხმები! ქალაქში ასეთი პირდაპირი ხალხი ცოტაა დარჩენილი. შემდეგში ერთად გავისეირნოთ! 🏎️`;
    case 'friend_mariam':
      return `დამაფიქრე ახლა... ზუსტად ეგეთი გულწრფელი ფიქრები მიყვარს ადამიანებში. მადლობა რომ გამიზიარე 🌿`;
    case 'friend_luka':
      return `ლოგიკური მსჯელობაა. მთავარია ამ ხედვას პრაქტიკული შედეგი მოჰყვეს და წინ წაგიყვანოს! 📈`;
    case 'friend_elene':
      return `გაიხარე! ისეთი კარგი ენერგია მოდის შენგან, ყოველთვის მიხარია შენი წერილის წაკითხვა 🌸`;
    case 'friend_beka':
      return `ხოო, ეგრეა ნამდვილად! მოკლედ და კონკრეტულად თქვი, ეგრე მირჩევნია ყველაფერში 😤👍`;
    case 'friend_temo':
      return `ვააა, ეგ თეორია მომეწონა! მატრიცის ცენტრალურ პროცესორს ზუსტად ეგრე აქვს გათვლილი 👽`;
    default:
      return `გასაგებია! ძალიან საინტერესო თემაა და მიხარია, რომ ასე თავისუფლად ვსაუბრობთ.`;
  }
}

// Backward compatibility alias
export function generateDirectMessageReply(
  friend: Friend,
  userMessage: string,
  playerName: string,
  history: DirectMessage[] = [],
  economicContext?: EconomicContext
): string {
  const char = getCharacterByName(friend.name);
  return generateDeepCharacterReply(char, userMessage, playerName, history, economicContext);
}


