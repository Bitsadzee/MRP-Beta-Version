﻿import React, { useState } from 'react';
import { X, Sparkles, ArrowRight, ShieldCheck, Coins } from 'lucide-react';
import { CRYSTAL_PRICE_GEL } from '../utils/constants';
import { formatLari } from '../utils/formatters';
import { playCashSound, playClickSound } from '../utils/audio';

interface CrystalExchangeModalProps {
  isOpen: boolean;
  onClose: () => void;
  balance: number;
  crystals: number;
  soundEnabled: boolean;
  onExchange: (crystalAmount: number) => void;
}

export const CrystalExchangeModal: React.FC<CrystalExchangeModalProps> = ({
  isOpen,
  onClose,
  balance,
  crystals,
  soundEnabled,
  onExchange
}) => {
  const [amountInput, setAmountInput] = useState<string>('10');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const parsedAmount = parseInt(amountInput, 10);
  const validAmount = isNaN(parsedAmount) || parsedAmount < 1 ? 0 : parsedAmount;
  const costGel = validAmount * CRYSTAL_PRICE_GEL;
  const canAfford = balance >= costGel && validAmount > 0;

  const handleBuy = () => {
    if (!canAfford) {
      setErrorMsg('არასაკმარისი ბალანსი!');
      return;
    }
    setErrorMsg(null);
    playCashSound(soundEnabled);
    onExchange(validAmount);
    onClose();
  };

  const setPreset = (num: number) => {
    playClickSound(soundEnabled);
    setAmountInput(num.toString());
    setErrorMsg(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-md bg-gradient-to-b from-[#121626] to-[#090b12] border-2 border-cyan-500/40 rounded-3xl p-6 shadow-[0_0_50px_rgba(6,182,212,0.25)] text-slate-100">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/50 flex items-center justify-center text-2xl shadow-[0_0_15px_rgba(6,182,212,0.4)]">
            💎
          </div>
          <div>
            <h3 className="text-lg font-black tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-teal-300 to-indigo-300">
              კრისტალების გადაცვლა
            </h3>
            <p className="text-xs text-slate-400 font-mono">
              კურსი: 10 💎 = 5,000 ₾ (1 💎 = {formatLari(CRYSTAL_PRICE_GEL)})
            </p>
          </div>
        </div>

        {/* Current Balances */}
        <div className="grid grid-cols-2 gap-3 mb-5">
          <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center gap-2.5">
            <span className="text-xl">₾</span>
            <div>
              <div className="text-[10px] text-slate-400 font-mono">მიმდინარე ფული</div>
              <div className="text-sm font-black text-emerald-400 font-mono">{formatLari(balance)}</div>
            </div>
          </div>
          <div className="p-3 rounded-2xl bg-slate-900/90 border border-cyan-500/30 flex items-center gap-2.5">
            <span className="text-xl">💎</span>
            <div>
              <div className="text-[10px] text-slate-400 font-mono">კრისტალები</div>
              <div className="text-sm font-black text-cyan-300 font-mono">{crystals} 💎</div>
            </div>
          </div>
        </div>

        {/* Input form */}
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
              <span>რამდენი კრისტალი გსურს?</span>
              <span className="text-[11px] text-cyan-400 font-mono">1 💎 = 500 ₾</span>
            </label>
            <div className="relative">
              <input
                type="number"
                min="1"
                max="10000"
                value={amountInput}
                onChange={(e) => {
                  setAmountInput(e.target.value);
                  setErrorMsg(null);
                }}
                className="w-full px-4 py-3 bg-slate-950/90 border-2 border-slate-800 focus:border-cyan-500 rounded-2xl text-slate-100 font-mono font-bold text-lg outline-none transition-all pl-11"
                placeholder="10"
              />
              <span className="absolute left-3.5 top-3.5 text-lg">💎</span>
            </div>
          </div>

          {/* Quick Presets */}
          <div className="flex items-center gap-2">
            {[10, 20, 50, 100, 150].map((preset) => (
              <button
                key={preset}
                onClick={() => setPreset(preset)}
                className={`flex-1 py-1.5 rounded-xl border text-xs font-mono font-bold transition-all ${
                  amountInput === preset.toString()
                    ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 shadow-sm'
                    : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                +{preset} 💎
              </button>
            ))}
          </div>

          {/* Cost preview summary */}
          <div className="p-4 rounded-2xl bg-cyan-950/20 border border-cyan-500/30 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xl text-cyan-400 font-bold font-mono">{validAmount} 💎</span>
              <ArrowRight className="w-4 h-4 text-slate-500" />
              <span className="text-sm font-bold text-slate-300">გადასახდელი თანხა:</span>
            </div>
            <div className="text-base font-black text-emerald-400 font-mono">
              {formatLari(costGel)}
            </div>
          </div>

          {errorMsg && (
            <div className="text-center text-xs font-bold text-rose-400 font-mono bg-rose-950/30 p-2 rounded-xl border border-rose-500/30">
              {errorMsg}
            </div>
          )}

          {/* Action button */}
          <button
            onClick={handleBuy}
            disabled={!canAfford}
            className={`w-full py-3.5 rounded-2xl font-black text-sm tracking-wide flex items-center justify-center gap-2 shadow-lg transition-all ${
              canAfford
                ? 'bg-gradient-to-r from-cyan-500 via-teal-500 to-emerald-500 text-slate-950 hover:brightness-110 shadow-cyan-500/30 cursor-pointer active:scale-[0.98]'
                : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>{canAfford ? `გადაცვლა (${formatLari(costGel)})` : 'არასაკმარისი ბალანსი'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};


