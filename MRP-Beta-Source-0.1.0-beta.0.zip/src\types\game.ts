﻿export interface CarTuningData {
  carId: string;
  colorName?: string;
  colorHex?: string;
  stageLevel?: number; // 0, 1, 2, 3
  turboType?: string;
  intakeType?: string;
  exhaustType?: string;
  suspensionType?: string;
  installedPartIds?: Partial<Record<TuningPart['category'], string>>;
  extraHp?: number;
  extraSpeedKm?: number;
  extraRespect?: number;
}

export interface TuningPart {
  id: string;
  name: string;
  category: 'color' | 'stage' | 'turbo' | 'intake' | 'exhaust' | 'suspension';
  retailPrice: number;
  wholesalePrice: number;
  hpBonus: number;
  speedBonusKm: number;
  respectBonus: number;
  description: string;
  colorHex?: string;
}

export interface StarPassTier {
  tier: number;
  requiredStars: number;
  freeReward: {
    type: 'cash' | 'crystals' | 'xp' | 'reputation';
    amount: number;
    title: string;
    icon: string;
  };
  plusReward: {
    type: 'car' | 'estate' | 'cash' | 'crystals' | 'tuning_kit';
    amount?: number;
    item?: Car | Estate;
    title: string;
    description: string;
    icon: string;
  };
}

export interface TradingPosition { quantity: number; averagePrice: number; }

export interface PlayerProfile {
  name: string;
  title: string;
  avatar: string;
  customPhoto?: string;
  rankTitle?: string;
  level: number;
  xp: number;
  balance: number;
  crystals?: number;
  stars?: number;
  premiumRank?: 'none' | 'red' | 'purple' | 'midnight_purple' | 'devil_red';
  tradingPortfolio?: Record<string, TradingPosition>;
  completedMissions?: string[];
  completedStarMissions?: string[];
  isPassPlusActive?: boolean;
  claimedPassTiersFree?: number[];
  claimedPassTiersPlus?: number[];
  hasCustomTuningWorkshop?: boolean;
  workshopInventory?: { [partId: string]: number };
  carTunings?: { [carId: string]: CarTuningData };
  reputation: number;
  soundEnabled: boolean;
  garageCapacity: number;
  equippedAccessories?: string[];
  stats: {
    totalEarned: number;
    totalLost: number;
    aviaBets: number;
    aviaWins: number;
    biggestMultiplier: number;
    jobsCompleted: number;
    contractsDone: number;
    safesCracked: number;
    wheelSpins: number;
    levelUpCount: number;
  };
}

export interface GameMission {
  id: string;
  title: string;
  description: string;
  category: 'career' | 'aviator' | 'luxury' | 'casino' | 'wealth';
  icon: string;
  targetCount: number;
  rewardCash: number;
  rewardCrystals: number;
  checkProgress: (player: PlayerProfile, ownedCarsCount: number, ownedEstatesCount: number) => { current: number; completed: boolean };
}

export interface Accessory {
  id: string;
  name: string;
  category: 'watch' | 'jewelry' | 'clothing' | 'gadget' | 'vip';
  price: number;
  respect: number;
  bonusMultiplier: number;
  image: string;
  description: string;
}

export interface JobTask {
  id: string;
  name: string;
  type: 'quiz' | 'quick_tap' | 'slider' | 'code';
  prompt: string;
  options?: string[];
  correctOption?: number;
  targetCount?: number;
  sliderTarget?: number;
}

export interface Job {
  id: string;
  name: string;
  iconName: string;
  category: string;
  requiredLevel: number;
  salary: number;
  xpReward: number;
  cooldownSeconds: number;
  description: string;
  tasks: JobTask[];
}

export interface Contract {
  id: string;
  title: string;
  client: string;
  cost: number;
  payout: number;
  xpReward: number;
  durationSeconds: number;
  requiredLevel: number;
  description: string;
}

export interface ActiveContract {
  contractId: string;
  startedAt: number;
  durationSeconds: number;
  completed: boolean;
}

export interface Upgrader {
  id: string;
  name: string;
  description: string;
  iconName: string;
  baseCost: number;
  passivePerCycle: number;
  cycleSeconds: number;
  owned: number;
}

export interface Car {
  id: string;
  name: string;
  brand: string;
  price: number;
  respect: number;
  bonusMultiplier: number;
  speed: string;
  color: string;
  image: string;
}

export interface Garage {
  id: string;
  name: string;
  capacity: number;
  price: number;
  location: string;
  description: string;
}

export interface Estate {
  id: string;
  name: string;
  location: string;
  price: number;
  respect: number;
  passiveRentPerSec: number;
  description: string;
}

export interface Business {
  id: string;
  name: string;
  type: string;
  basePrice: number;
  baseIncome: number;
  intervalSeconds: number;
  ownedCount: number;
  description: string;
}

export interface Security {
  id: string;
  name: string;
  price: number;
  respect: number;
  protectionBonus: string;
  description: string;
}

export interface BotChatMessage {
  id: string;
  sender: string;
  level: number;
  avatar: string;
  text: string;
  time: string;
  mood: 'rage' | 'joy' | 'crying' | 'threat' | 'normal';
  premiumRank?: 'none' | 'red' | 'purple' | 'midnight_purple' | 'devil_red';
}

export interface AviatorBotBet {
  id: string;
  name: string;
  avatar: string;
  level: number;
  betAmount: number;
  targetMultiplier: number;
  cashedOut: boolean;
  cashedMultiplier?: number;
}

export interface Friend {
  id: string;
  name: string;
  avatar: string;
  photoUrl?: string;
  level: number;
  status: string;
  bio: string;
  car?: string;
  job?: string;
  personality: 'wholesome' | 'romantic' | 'weird' | 'grumpy' | 'cold' | 'mobster' | 'introvert' | 'philosopher' | 'racer' | 'crypto_bro' | 'tough' | 'friendly' | 'funny';
  unreadCount?: number;
  premiumRank?: 'none' | 'red' | 'purple' | 'midnight_purple' | 'devil_red';
}

export interface DirectMessage {
  id: string;
  friendId: string;
  sender: 'player' | 'friend';
  text: string;
  timestamp: number;
  timeString: string;
}

export interface GlobalChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  senderLevel: number;
  text: string;
  timestamp: number;
  timeString: string;
  isPlayer?: boolean;
  replyTo?: string;
  premiumRank?: 'none' | 'red' | 'purple' | 'midnight_purple' | 'devil_red';
}








