﻿import React, { useState, useEffect } from 'react';
import {
  Briefcase,
  Zap,
  Clock,
  Lock,
  CheckCircle,
  TrendingUp,
  DollarSign,
  Sparkles,
  Bike,
  Scissors,
  Wrench,
  Music,
  Building,
  ShieldAlert,
  Cpu,
  Coffee,
  Bot,
  Globe,
  Crown,
  Building2
} from 'lucide-react';
import { Job, Contract, Upgrader, ActiveContract, Business } from '../types/game';
import { BUSINESS_INCOME_SCALE, UPGRADER_INCOME_SCALE } from '../utils/constants';
import { playCashSound, playClickSound } from '../utils/audio';
import { formatLari } from '../utils/formatters';
import { JobTaskModal } from './JobTaskModal';

interface JobsAndContractsProps {
  playerLevel: number;
  balance: number;
  soundEnabled: boolean;
  jobs: Job[];
  contracts: Contract[];
  upgraders: Upgrader[];
  activeContracts: ActiveContract[];
  businesses?: Business[];
  ownedBusinesses?: { [id: string]: number };
  upgraderSecondsLeft?: number;
  onWorkJob: (job: Job, bonusMultiplier?: number) => void;
  onStartContract: (contract: Contract) => void;
  onClaimContract: (contractId: string) => void;
  onBuyUpgrader: (upgraderId: string, cost: number) => void;
  onBuyBusiness?: (business: Business, cost: number) => void;
}

export const JobsAndContracts: React.FC<JobsAndContractsProps> = ({
  playerLevel,
  balance,
  soundEnabled,
  jobs,
  contracts,
  upgraders,
  activeContracts,
  businesses = [],
  ownedBusinesses = {},
  upgraderSecondsLeft = 120,
  onWorkJob,
  onStartContract,
  onClaimContract,
  onBuyUpgrader,
  onBuyBusiness
}) => {
  const [subTab, setSubTab] = useState<'jobs' | 'businesses' | 'upgraders' | 'contracts'>('jobs');
  const [cooldowns, setCooldowns] = useState<{ [jobId: string]: number }>({});
  const [activeTaskJob, setActiveTaskJob] = useState<Job | null>(null);
  const [, setTick] = useState<number>(0);

  // Tick every second to update active cooldowns and contracts
  useEffect(() => {
    const timer = setInterval(() => {
      setTick((t) => t + 1);
      setCooldowns((prev) => {
        const next: { [key: string]: number } = {};
        for (const [key, value] of Object.entries(prev)) {
          if (value > 1) {
            next[key] = value - 1;
          }
        }
        return next;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleJobClick = (job: Job) => {
    if (cooldowns[job.id] && cooldowns[job.id] > 0) return;
    if (playerLevel < job.requiredLevel) return;

    playClickSound(soundEnabled);
    // Open interactive mini-task for this job
    setActiveTaskJob(job);
  };

  const handleTaskCompleted = (bonusMultiplier: number) => {
    if (!activeTaskJob) return;
    const job = activeTaskJob;
    onWorkJob(job, bonusMultiplier);
    setCooldowns((prev) => ({
      ...prev,
      [job.id]: job.cooldownSeconds
    }));
    setActiveTaskJob(null);
  };

  const getJobIcon = (iconName: string) => {
    switch (iconName) {
      case 'Bike':
        return <Bike className="w-5 h-5 text-emerald-400" />;
      case 'Scissors':
        return <Scissors className="w-5 h-5 text-amber-400" />;
      case 'Wrench':
        return <Wrench className="w-5 h-5 text-blue-400" />;
      case 'Music':
        return <Music className="w-5 h-5 text-pink-400" />;
      case 'TrendingUp':
        return <TrendingUp className="w-5 h-5 text-emerald-400" />;
      case 'Building':
        return <Building className="w-5 h-5 text-cyan-400" />;
      case 'ShieldAlert':
        return <ShieldAlert className="w-5 h-5 text-rose-400" />;
      case 'Cpu':
        return <Cpu className="w-5 h-5 text-purple-400" />;
      default:
        return <Briefcase className="w-5 h-5 text-emerald-400" />;
    }
  };

  const getUpgraderIcon = (iconName: string) => {
    switch (iconName) {
      case 'Coffee':
        return <Coffee className="w-5 h-5 text-amber-400" />;
      case 'Bot':
        return <Bot className="w-5 h-5 text-cyan-400" />;
      case 'Briefcase':
        return <Briefcase className="w-5 h-5 text-emerald-400" />;
      case 'Globe':
        return <Globe className="w-5 h-5 text-blue-400" />;
      case 'Crown':
        return <Crown className="w-5 h-5 text-yellow-400" />;
      case 'Zap':
        return <Zap className="w-5 h-5 text-purple-400" />;
      default:
        return <Zap className="w-5 h-5 text-emerald-400" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-5 space-y-5">
      {/* Segmented Sub-Navigation */}
      <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-900/90 border border-slate-800 rounded-xl max-w-2xl">
        <button
          onClick={() => {
            playClickSound(soundEnabled);
            setSubTab('jobs');
          }}
          className={`flex-1 min-w-[120px] py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
            subTab === 'jobs'
              ? 'bg-emerald-500 text-slate-950 shadow-md font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Briefcase className="w-3.5 h-3.5" />
          <span>💼 სამუშაოები</span>
        </button>
        <button
          onClick={() => {
            playClickSound(soundEnabled);
            setSubTab('businesses');
          }}
          className={`flex-1 min-w-[120px] py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
            subTab === 'businesses'
              ? 'bg-emerald-500 text-slate-950 shadow-md font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>🏢 ბიზნესები ({Object.values(ownedBusinesses).reduce((a, b) => a + b, 0)})</span>
        </button>
        <button
          onClick={() => {
            playClickSound(soundEnabled);
            setSubTab('upgraders');
          }}
          className={`flex-1 min-w-[120px] py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
            subTab === 'upgraders'
              ? 'bg-emerald-500 text-slate-950 shadow-md font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Zap className="w-3.5 h-3.5" />
          <span>⚡ აფგრეიდები (120წმ)</span>
        </button>
      </div>

      {/* 1. JOBS SECTION */}
      {subTab === 'jobs' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>კარიერული საფეხურები & აქტიური სამუშაო</span>
            </h2>
            <span className="text-xs text-slate-400">
              დააჭირე სამუშაოს დასაწყებად და ფულის/XP-ს მისაღებად
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5">
            {jobs.map((job) => {
              const isLocked = playerLevel < job.requiredLevel;
              const cd = cooldowns[job.id] || 0;
              const progressPct = cd > 0 ? (cd / job.cooldownSeconds) * 100 : 0;

              return (
                <div
                  key={job.id}
                  className={`p-4 rounded-2xl border flex flex-col justify-between transition-all ${
                    isLocked
                      ? 'bg-slate-950/40 border-slate-900 opacity-60'
                      : 'bg-[#0c0d14] border-slate-800 hover:border-slate-700 shadow-lg'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                        {getJobIcon(job.iconName)}
                      </div>
                      {isLocked ? (
                        <span className="flex items-center gap-1 text-[11px] font-mono text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-md border border-rose-500/20">
                          <Lock className="w-3 h-3" />
                          Lvl {job.requiredLevel}
                        </span>
                      ) : (
                        <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                          {job.category}
                        </span>
                      )}
                    </div>

                    <div>
                      <h3 className="font-bold text-sm text-slate-100">{job.name}</h3>
                      <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                        {job.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                      <div>
                        <span className="text-slate-500 block text-[10px]">ხელფასი</span>
                        <span className="font-bold text-emerald-400">+{formatLari(job.salary)}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-slate-500 block text-[10px]">გამოცდილება</span>
                        <span className="font-bold text-amber-400">+{job.xpReward} XP</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-2">
                    <button
                      type="button"
                      disabled={isLocked || cd > 0}
                      onClick={() => handleJobClick(job)}
                      className={`relative w-full py-2.5 px-3 rounded-xl font-bold text-xs overflow-hidden transition-all ${
                        isLocked
                          ? 'bg-slate-900 text-slate-500 cursor-not-allowed border border-slate-800'
                          : cd > 0
                          ? 'bg-slate-900 text-slate-400 border border-slate-800 cursor-not-allowed'
                          : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md active:scale-95'
                      }`}
                    >
                      {/* Cooldown bar */}
                      {cd > 0 && (
                        <div
                          className="absolute inset-0 bg-slate-800/70 pointer-events-none transition-all"
                          style={{ width: `${progressPct}%` }}
                        />
                      )}
                      <span className="relative z-10 flex items-center justify-center gap-1.5">
                        {isLocked ? (
                          <>
                            <Lock className="w-3.5 h-3.5" />
                            <span>საჭიროა ლეველი {job.requiredLevel}</span>
                          </>
                        ) : cd > 0 ? (
                          <>
                            <Clock className="w-3.5 h-3.5 animate-spin text-amber-400" />
                            <span>შესვენება ({cd}წმ)</span>
                          </>
                        ) : (
                          <>
                            <Zap className="w-3.5 h-3.5 text-slate-950" />
                            <span>დავალების შესრულება</span>
                          </>
                        )}
                      </span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. BUSINESSES SECTION */}
      {subTab === 'businesses' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-4 rounded-2xl bg-gradient-to-r from-emerald-950/20 via-slate-900/90 to-purple-950/20 border border-slate-800">
            <div>
              <h2 className="text-base font-black text-slate-100 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-emerald-400" />
                <span>კომერციული იმპერია & ბიზნესები</span>
              </h2>
              <span className="text-xs text-slate-400 mt-0.5 block">
                შეიძინე და განავითარე ბიზნესები — პასიური შემოსავალი ირიცხება ავტომატურად ყოველ წამს!
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono">
                <span className="text-slate-400">სულ ბიზნესები: </span>
                <span className="font-bold text-amber-400">
                  {Object.values(ownedBusinesses).reduce((a, b) => a + b, 0)} ერთეული
                </span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {businesses.map((biz) => {
              const ownedCount = ownedBusinesses[biz.id] || 0;
              const currentPrice = Math.floor(biz.basePrice * Math.pow(1.18, ownedCount));
              const currentCycleIncome = biz.baseIncome * BUSINESS_INCOME_SCALE * ownedCount;
              const canAfford = balance >= currentPrice;
              const isHazelnut = biz.id === 'biz_hazelnut';
              const perSec = biz.intervalSeconds > 0 ? (biz.baseIncome * BUSINESS_INCOME_SCALE / biz.intervalSeconds) * ownedCount : 0;

              return (
                <div
                  key={biz.id}
                  className={`p-4 rounded-2xl border flex flex-col justify-between transition-all ${
                    ownedCount > 0
                      ? 'bg-gradient-to-b from-[#10121d] to-[#0a0b12] border-emerald-500/40 shadow-[0_0_20px_rgba(16,185,129,0.12)]'
                      : 'bg-[#0c0d14] border-slate-800 hover:border-slate-700 shadow-xl'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-mono text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded-md border border-purple-500/20">
                        {biz.type}
                      </span>
                      <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded-md border ${
                        ownedCount > 0
                          ? 'text-emerald-400 bg-emerald-500/15 border-emerald-500/30'
                          : 'text-slate-500 bg-slate-900 border-slate-800'
                      }`}>
                        ფლობ: {ownedCount} {isHazelnut ? 'აპარატი' : 'ფილიალი'}
                      </span>
                    </div>

                    <div>
                      <h3 className="font-black text-sm text-slate-100 flex items-center justify-between">
                        <span>{biz.name}</span>
                        {ownedCount > 0 && (
                          <span className="text-[11px] font-mono text-emerald-400 font-bold">
                            +{formatLari(perSec)}/წმ
                          </span>
                        )}
                      </h3>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        {biz.description}
                      </p>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800/80 flex items-center justify-between font-mono text-xs">
                      <div>
                        <span className="text-[10px] text-slate-500 block">საბაზისო შემოსავალი</span>
                        <span className="font-bold text-emerald-400">
                          +{formatLari(biz.baseIncome * BUSINESS_INCOME_SCALE, true)} / {biz.intervalSeconds}წმ
                        </span>
                        {ownedCount > 0 ? (
                          <span className="text-[10px] text-cyan-400 font-semibold block mt-0.5">
                            აქტიური ({ownedCount} ერთ.): +{formatLari(currentCycleIncome, true)} / {biz.intervalSeconds}წმ
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400 block mt-0.5">
                            (თითო ერთეულზე)
                          </span>
                        )}
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-500 block">ერთეულის ფასი</span>
                        <span className="font-bold text-slate-100">{formatLari(currentPrice)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-2">
                    <button
                      type="button"
                      disabled={!canAfford}
                      onClick={() => {
                        playCashSound(soundEnabled);
                        if (onBuyBusiness) onBuyBusiness(biz, currentPrice);
                      }}
                      className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 ${
                        canAfford
                          ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md active:scale-95'
                          : 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
                      }`}
                    >
                      <Building2 className="w-3.5 h-3.5" />
                      <span>{canAfford ? `${ownedCount > 0 ? 'ფილიალის დამატება' : 'ბიზნესის შეძენა'} (${formatLari(currentPrice)})` : 'არასაკმარისი თანხა'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 3. CONTRACTS SECTION */}
      {subTab === 'contracts' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>მაღალშემოსავლიანი კონტრაქტები & მისიები</span>
            </h2>
            <span className="text-xs text-slate-400">
              ჩადე ინვესტიცია, დაელოდე დასრულებას და მიიღე სოლიდური მოგება
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {contracts.map((contract) => {
              const isLocked = playerLevel < contract.requiredLevel;
              const active = activeContracts.find((a) => a.contractId === contract.id);
              const now = Date.now();
              const elapsedSec = active ? Math.floor((now - active.startedAt) / 1000) : 0;
              const isReady = active && elapsedSec >= contract.durationSeconds;
              const remainingSec = active ? Math.max(0, contract.durationSeconds - elapsedSec) : 0;
              const progressPct = active
                ? Math.min(100, (elapsedSec / contract.durationSeconds) * 100)
                : 0;

              return (
                <div
                  key={contract.id}
                  className={`p-4 rounded-2xl border flex flex-col justify-between ${
                    isLocked
                      ? 'bg-slate-950/40 border-slate-900 opacity-60'
                      : 'bg-[#0c0d14] border-slate-800 hover:border-slate-700 shadow-xl'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded-md border border-cyan-500/20">
                        {contract.client}
                      </span>
                      {isLocked ? (
                        <span className="flex items-center gap-1 text-[11px] font-mono text-rose-400">
                          <Lock className="w-3 h-3" /> Lvl {contract.requiredLevel}
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-[11px] text-slate-400 font-mono">
                          <Clock className="w-3 h-3" />
                          {contract.durationSeconds}წმ
                        </span>
                      )}
                    </div>

                    <div>
                      <h3 className="font-bold text-sm text-slate-100">{contract.title}</h3>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        {contract.description}
                      </p>
                    </div>

                    <div className="grid grid-cols-3 gap-2 p-2.5 rounded-xl bg-slate-900/80 border border-slate-800/80 text-center font-mono text-xs">
                      <div>
                        <span className="text-[10px] text-slate-500 block">ხარჯი</span>
                        <span className="font-bold text-rose-400">-{formatLari(contract.cost)}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block">ანაზღაურება</span>
                        <span className="font-bold text-emerald-400">+{formatLari(contract.payout)}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block">XP</span>
                        <span className="font-bold text-amber-400">+{contract.xpReward}</span>
                      </div>
                    </div>

                    {/* Progress bar if active */}
                    {active && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] font-mono">
                          <span className="text-slate-400">
                            {isReady ? 'შესრულებულია!' : `მიმდინარეობს (${remainingSec}წმ)`}
                          </span>
                          <span className="text-emerald-400">{progressPct.toFixed(0)}%</span>
                        </div>
                        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-emerald-500 transition-all duration-300"
                            style={{ width: `${progressPct}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="mt-4 pt-2">
                    {isReady ? (
                      <button
                        type="button"
                        onClick={() => {
                          playCashSound(soundEnabled);
                          onClaimContract(contract.id);
                        }}
                        className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-extrabold text-xs shadow-lg animate-pulse flex items-center justify-center gap-1.5"
                      >
                        <CheckCircle className="w-4 h-4" />
                        <span>თანხის განაღდება (+{formatLari(contract.payout)})</span>
                      </button>
                    ) : active ? (
                      <button
                        type="button"
                        disabled
                        className="w-full py-2.5 px-3 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 text-xs font-semibold cursor-not-allowed flex items-center justify-center gap-2"
                      >
                        <Clock className="w-3.5 h-3.5 animate-spin text-amber-400" />
                        <span>კონტრაქტი მუშავდება...</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        disabled={isLocked || balance < contract.cost}
                        onClick={() => {
                          playClickSound(soundEnabled);
                          onStartContract(contract);
                        }}
                        className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 ${
                          isLocked || balance < contract.cost
                            ? 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
                            : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md active:scale-95'
                        }`}
                      >
                        {isLocked ? (
                          <>
                            <Lock className="w-3.5 h-3.5" />
                            <span>საჭიროა ლეველი {contract.requiredLevel}</span>
                          </>
                        ) : balance < contract.cost ? (
                          <span>არასაკმარისი თანხა</span>
                        ) : (
                          <>
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>კონტრაქტის ხელმოწერა ({formatLari(contract.cost)})</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 3. UPGRADERS SECTION */}
      {subTab === 'upgraders' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <span>აფგრეიდები & პასიური შემოსავალი (120 წამიანი ციკლი)</span>
              </h2>
              <span className="text-xs text-slate-400">
                შეიძინე გამაძლიერებლები, რომლებიც ავტომატურად გაძლევენ სოლიდურ ₾-ს ყოველ 120 წამში (2 წუთში ერთხელ)!
              </span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono">
              <Clock className="w-3.5 h-3.5 text-amber-400 animate-spin" />
              <span className="text-slate-400">შემდეგი ჩარიცხვა:</span>
              <span className="font-bold text-amber-400">{upgraderSecondsLeft} წმ</span>
            </div>
          </div>

          {/* 120-Second Visual Timer Bar */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-slate-950/80 via-slate-900/90 to-slate-950/80 border border-slate-800/90 shadow-lg space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-slate-300 flex items-center gap-2 font-semibold">
                <Zap className="w-4 h-4 text-emerald-400 animate-pulse" />
                120-წამიანი ჩარიცხვის ციკლის პროგრესი
              </span>
              <span className="text-emerald-400 font-bold">
                {120 - upgraderSecondsLeft}/120 წმ
              </span>
            </div>
            <div className="w-full h-2.5 bg-slate-950 rounded-full p-0.5 border border-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-500 via-emerald-400 to-teal-300 rounded-full transition-all duration-1000 ease-linear shadow-[0_0_12px_rgba(16,185,129,0.5)]"
                style={{ width: `${Math.max(1, Math.min(100, ((120 - upgraderSecondsLeft) / 120) * 100))}%` }}
              />
            </div>
            <div className="flex justify-between items-center text-[11px] text-slate-500 font-mono">
              <span>ციკლის დასაწყისი</span>
              <span className="text-emerald-400/90 font-semibold">
                სულ 120 წამში ჩაირიცხება: +{formatLari(upgraders.reduce((s, u) => s + (u.passivePerCycle || 0) * UPGRADER_INCOME_SCALE * (u.owned || 0), 0))}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {upgraders.map((upg) => {
              const currentCost = Math.floor(upg.baseCost * Math.pow(1.18, upg.owned));
              const canAfford = balance >= currentCost;
              const totalCycleIncome = upg.passivePerCycle * UPGRADER_INCOME_SCALE * upg.owned;

              return (
                <div
                  key={upg.id}
                  className="p-4 rounded-2xl bg-[#0c0d14] border border-slate-800 hover:border-slate-700 shadow-xl flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                        {getUpgraderIcon(upg.iconName)}
                      </div>
                      <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
                        ფლობ: {upg.owned}x
                      </span>
                    </div>

                    <div>
                      <h3 className="font-bold text-sm text-slate-100">{upg.name}</h3>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        {upg.description}
                      </p>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800/80 flex items-center justify-between font-mono text-xs">
                      <div>
                        <span className="text-[10px] text-slate-500 block">შემოსავალი (120 წამში)</span>
                        <span className="font-bold text-emerald-400">
                          +{formatLari(upg.passivePerCycle * UPGRADER_INCOME_SCALE)} / 120წმ
                        </span>
                        {upg.owned > 0 ? (
                          <span className="text-[10px] text-cyan-400 font-semibold block mt-0.5">
                            აქტიური ({upg.owned}x): +{formatLari(totalCycleIncome)} / 120წმ
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400 block mt-0.5">
                            (თითო ერთეულზე)
                          </span>
                        )}
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-500 block">ფასი</span>
                        <span className="font-bold text-slate-200">{formatLari(currentCost)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-2">
                    <button
                      type="button"
                      disabled={!canAfford}
                      onClick={() => {
                        playCashSound(soundEnabled);
                        onBuyUpgrader(upg.id, currentCost);
                      }}
                      className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 ${
                        canAfford
                          ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md active:scale-95'
                          : 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
                      }`}
                    >
                      <Zap className="w-3.5 h-3.5" />
                      <span>{canAfford ? `შეძენა (${formatLari(currentCost)})` : 'არასაკმარისი თანხა'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
      {/* Interactive Job Task Mission Modal */}
      {activeTaskJob && (
        <JobTaskModal
          job={activeTaskJob}
          soundEnabled={soundEnabled}
          onComplete={handleTaskCompleted}
          onCancel={() => setActiveTaskJob(null)}
        />
      )}
    </div>
  );
};




