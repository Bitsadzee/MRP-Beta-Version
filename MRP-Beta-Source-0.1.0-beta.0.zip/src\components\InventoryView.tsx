﻿import React, { useState } from 'react';
import {
  Car as CarIcon,
  Home,
  Building2,
  Briefcase,
  Zap,
  Shield,
  Clock,
  Sparkles,
  TrendingUp,
  DollarSign,
  ChevronRight,
  Gauge,
  Warehouse,
  ShoppingBag
} from 'lucide-react';
import { PlayerProfile, Car, Garage, Estate, Business, Security, Accessory, Upgrader } from '../types/game';
import { formatLari } from '../utils/formatters';
import { ESTATE_RENT_SCALE, BUSINESS_INCOME_SCALE, UPGRADER_INCOME_SCALE } from '../utils/constants';

interface InventoryViewProps {
  player: PlayerProfile;
  ownedCars: string[];
  ownedGarages: string[];
  ownedEstates: string[];
  ownedBusinesses: { [id: string]: number };
  ownedSecurity: string[];
  ownedAccessories: string[];
  cars: Car[];
  garages: Garage[];
  estates: Estate[];
  businesses: Business[];
  securityList: Security[];
  accessories: Accessory[];
  upgraders: Upgrader[];
  onNavigateToShop: () => void;
  onBuyEstate?: (estate: Estate) => void;
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  player,
  ownedCars,
  ownedGarages,
  ownedEstates,
  ownedBusinesses,
  ownedSecurity,
  ownedAccessories,
  cars,
  garages,
  estates,
  businesses,
  securityList,
  accessories,
  upgraders,
  onNavigateToShop,
  onBuyEstate
}) => {
  const [activeCategory, setActiveCategory] = useState<'cars' | 'estates' | 'garages' | 'businesses' | 'upgraders' | 'security'>('cars');
  const [purchaseSuccessMessage, setPurchaseSuccessMessage] = useState<string | null>(null);

  // Resolved items
  const myCars = cars.filter((c) => ownedCars.includes(c.id));
  const myGarages = garages.filter((g) => ownedGarages.includes(g.id));
  const myEstates = estates.filter((e) => ownedEstates.includes(e.id));
  const mySecurity = securityList.filter((s) => ownedSecurity.includes(s.id));
  const myAccessories = accessories.filter((a) => (player.equippedAccessories || []).includes(a.id));
  const myUpgraders = upgraders.filter((u) => u.owned > 0);
  const myBusinesses = businesses.filter((b) => (ownedBusinesses[b.id] || 0) > 0);

  // Total valuation calculation
  const carsValue = myCars.reduce((acc, c) => acc + c.price, 0);
  const estatesValue = myEstates.reduce((acc, e) => acc + e.price, 0);
  const garagesValue = myGarages.reduce((acc, g) => acc + g.price, 0);
  const businessesValue = myBusinesses.reduce((acc, b) => acc + b.basePrice * (ownedBusinesses[b.id] || 0), 0);
  const upgradersValue = myUpgraders.reduce((acc, u) => acc + u.baseCost * u.owned, 0);
  const totalNetWorth = player.balance + carsValue + estatesValue + garagesValue + businessesValue + upgradersValue;

  const totalPassiveRent = myEstates.reduce((acc, e) => acc + e.passiveRentPerSec * ESTATE_RENT_SCALE, 0);
  const totalUpgraderDividends = myUpgraders.reduce((acc, u) => acc + u.passivePerCycle * UPGRADER_INCOME_SCALE * u.owned, 0);

  // Available Sololaki house for quick purchase if unowned
  const sololakiHouse = estates.find((e) => e.id === 'est_sololaki');
  const ownsSololaki = ownedEstates.includes('est_sololaki');

  const handleQuickBuySololaki = () => {
    if (!sololakiHouse) return;
    if (onBuyEstate) {
      onBuyEstate(sololakiHouse);
      setPurchaseSuccessMessage('🎉 გილოცავ! სოლოლაკის ბინა წარმატებით შეიძინე! ქირის დარიცხვა დაიწყო (+2 ₾/წთ).');
      setTimeout(() => setPurchaseSuccessMessage(null), 4000);
    } else {
      onNavigateToShop();
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Banner: Net Worth & Asset Summary */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#121420] via-[#0e1017] to-[#090a0f] border border-emerald-500/30 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>ჩემი პირადი ინვენტარი & აქტივები</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {player.name}-ის ქონებრივი იმპერია
            </h1>
            <p className="text-slate-400 text-xs sm:text-sm max-w-xl">
              აქ შეგიძლია ცალ-ცალკე დაათვალიერო შენი მანქანები, სახლები, გარაჟები, ბიზნესები და აფგრეიდერები.
            </p>
          </div>

          {/* Capitalization Box */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl shrink-0 text-right">
            <span className="text-[11px] uppercase tracking-wider text-slate-400 font-bold block mb-1">
              მთლიანი ქონების შეფასება (Net Worth)
            </span>
            <div className="text-2xl sm:text-3xl font-black font-mono text-emerald-400">
              {formatLari(totalNetWorth, true)}
            </div>
            <div className="flex items-center justify-end gap-3 mt-2 text-xs font-mono text-slate-400">
              <span>ნაღდი: <strong className="text-slate-200">{formatLari(player.balance)}</strong></span>
              <span>·</span>
              <span className="text-amber-400 font-bold">+{formatLari(totalPassiveRent * 60)}/წთ</span>
            </div>
          </div>
        </div>

        {/* Interactive KPI stat buttons (Clicking filters to that category directly) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-6 pt-5 border-t border-slate-800/80">
          <button
            type="button"
            onClick={() => setActiveCategory('cars')}
            className={`p-3 rounded-xl border text-left transition-all ${
              activeCategory === 'cars'
                ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                : 'bg-slate-950/60 border-slate-800/60 hover:border-slate-700'
            }`}
          >
            <span className="text-[11px] text-slate-400 block mb-0.5">ავტოპარკი</span>
            <div className="text-base sm:text-lg font-bold font-mono text-white flex items-center justify-between">
              <span>{myCars.length} / {player.garageCapacity}</span>
              <CarIcon className="w-4 h-4 text-emerald-400" />
            </div>
          </button>

          <button
            type="button"
            onClick={() => setActiveCategory('estates')}
            className={`p-3 rounded-xl border text-left transition-all ${
              activeCategory === 'estates'
                ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300'
                : 'bg-slate-950/60 border-slate-800/60 hover:border-slate-700'
            }`}
          >
            <span className="text-[11px] text-slate-400 block mb-0.5">უძრავი ქონება</span>
            <div className="text-base sm:text-lg font-bold font-mono text-white flex items-center justify-between">
              <span>{myEstates.length} სახლი</span>
              <Home className="w-4 h-4 text-cyan-400" />
            </div>
          </button>

          <button
            type="button"
            onClick={() => setActiveCategory('garages')}
            className={`p-3 rounded-xl border text-left transition-all ${
              activeCategory === 'garages'
                ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                : 'bg-slate-950/60 border-slate-800/60 hover:border-slate-700'
            }`}
          >
            <span className="text-[11px] text-slate-400 block mb-0.5">გარაჟები</span>
            <div className="text-base sm:text-lg font-bold font-mono text-white flex items-center justify-between">
              <span>{myGarages.length} ბოქსი</span>
              <Warehouse className="w-4 h-4 text-amber-400" />
            </div>
          </button>

          <button
            type="button"
            onClick={() => setActiveCategory('businesses')}
            className={`p-3 rounded-xl border text-left transition-all ${
              activeCategory === 'businesses'
                ? 'bg-purple-500/20 border-purple-500 text-purple-300'
                : 'bg-slate-950/60 border-slate-800/60 hover:border-slate-700'
            }`}
          >
            <span className="text-[11px] text-slate-400 block mb-0.5">ბიზნესები</span>
            <div className="text-base sm:text-lg font-bold font-mono text-white flex items-center justify-between">
              <span>{Object.values(ownedBusinesses).reduce((a, b) => a + b, 0)} ცალი</span>
              <Briefcase className="w-4 h-4 text-purple-400" />
            </div>
          </button>

          <button
            type="button"
            onClick={() => setActiveCategory('upgraders')}
            className={`p-3 rounded-xl border text-left transition-all ${
              activeCategory === 'upgraders'
                ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                : 'bg-slate-950/60 border-slate-800/60 hover:border-slate-700'
            }`}
          >
            <span className="text-[11px] text-slate-400 block mb-0.5">120წმ დივიდენდი</span>
            <div className="text-base sm:text-lg font-bold font-mono text-emerald-400 flex items-center justify-between">
              <span>+{formatLari(totalUpgraderDividends)}</span>
              <Zap className="w-4 h-4 text-emerald-400" />
            </div>
          </button>

          <button
            type="button"
            onClick={() => setActiveCategory('security')}
            className={`p-3 rounded-xl border text-left transition-all ${
              activeCategory === 'security'
                ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                : 'bg-slate-950/60 border-slate-800/60 hover:border-slate-700'
            }`}
          >
            <span className="text-[11px] text-slate-400 block mb-0.5">რეპუტაცია</span>
            <div className="text-base sm:text-lg font-bold font-mono text-amber-400 flex items-center justify-between">
              <span>{player.reputation} RP</span>
              <Shield className="w-4 h-4 text-amber-400" />
            </div>
          </button>
        </div>
      </div>

      {/* Category Navigation Filter */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-2 bg-[#0c0d14] border border-slate-800 rounded-2xl">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setActiveCategory('cars')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeCategory === 'cars'
                ? 'bg-emerald-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <CarIcon className="w-3.5 h-3.5" />
            <span>მანქანები ({myCars.length})</span>
          </button>
          <button
            onClick={() => setActiveCategory('estates')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeCategory === 'estates'
                ? 'bg-cyan-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Home className="w-3.5 h-3.5" />
            <span>სახლები & უძრავი ქონება ({myEstates.length})</span>
          </button>
          <button
            onClick={() => setActiveCategory('garages')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeCategory === 'garages'
                ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Warehouse className="w-3.5 h-3.5" />
            <span>გარაჟები ({myGarages.length})</span>
          </button>
          <button
            onClick={() => setActiveCategory('businesses')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeCategory === 'businesses'
                ? 'bg-purple-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Briefcase className="w-3.5 h-3.5" />
            <span>ბიზნესები ({myBusinesses.length})</span>
          </button>
          <button
            onClick={() => setActiveCategory('upgraders')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeCategory === 'upgraders'
                ? 'bg-emerald-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>აფგრეიდერები ({myUpgraders.length})</span>
          </button>
          <button
            onClick={() => setActiveCategory('security')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeCategory === 'security'
                ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>დაცვა & ლუქსი ({mySecurity.length + myAccessories.length})</span>
          </button>
        </div>

        <button
          onClick={onNavigateToShop}
          className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-emerald-400 hover:text-emerald-300 text-xs font-bold transition-colors flex items-center gap-1"
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          <span>ლუქს მაღაზია</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Success Notification Banner */}
      {purchaseSuccessMessage && (
        <div className="p-4 rounded-2xl bg-emerald-950/80 border border-emerald-500 text-emerald-200 text-sm font-semibold flex items-center gap-2 shadow-lg animate-in fade-in">
          <span>✨</span>
          <span>{purchaseSuccessMessage}</span>
        </div>
      )}

      {/* 1. CARS SECTION (ONLY when 'cars' is selected - NEVER shows houses) */}
      {activeCategory === 'cars' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base sm:text-lg font-bold text-slate-100 flex items-center gap-2">
              <CarIcon className="w-5 h-5 text-emerald-400" />
              <span>ჩემი ავტოპარკი ({myCars.length} / {player.garageCapacity})</span>
            </h2>
            <span className="text-xs font-mono text-slate-400">
              შეფასება: <strong className="text-emerald-400">{formatLari(carsValue)}</strong>
            </span>
          </div>

          {myCars.length === 0 ? (
            <div className="p-8 rounded-2xl bg-slate-900/40 border border-slate-800 text-center space-y-3">
              <span className="text-4xl block">🏎️</span>
              <h3 className="text-base font-bold text-slate-200">გარაჟი ჯერჯერობით ცარიელია</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                შეიძინე Mustang Shelby, Dodge Hellcat, Ferrari SF90 ან Audi Quattro ლუქს მაღაზიაში!
              </p>
              <button
                onClick={onNavigateToShop}
                className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md"
              >
                მანქანის ყიდვა
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {myCars.map((car) => (
                <div
                  key={car.id}
                  className="p-4 rounded-2xl bg-[#0c0d14] border border-slate-800 hover:border-emerald-500/40 transition-all flex flex-col justify-between space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-400 block mb-0.5">
                        {car.brand}
                      </span>
                      <h4 className="font-extrabold text-sm sm:text-base text-slate-100">
                        {car.name}
                      </h4>
                    </div>
                    <div className="w-12 h-12 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-2xl shrink-0">
                      {car.image}
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800/80 text-xs">
                    <div className="p-2 rounded-lg bg-slate-950 border border-slate-900 text-center">
                      <span className="text-[10px] text-slate-500 block">სიჩქარე</span>
                      <span className="font-mono font-bold text-slate-200">{car.speed}</span>
                    </div>
                    <div className="p-2 rounded-lg bg-slate-950 border border-slate-900 text-center">
                      <span className="text-[10px] text-slate-500 block">პატივისცემა</span>
                      <span className="font-mono font-bold text-amber-400">+{car.respect} RP</span>
                    </div>
                    <div className="p-2 rounded-lg bg-slate-950 border border-slate-900 text-center">
                      <span className="text-[10px] text-slate-500 block">ბონუსი</span>
                      <span className="font-mono font-bold text-emerald-400">x{car.bonusMultiplier}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1 text-slate-400 font-mono">
                    <span>საბაზრო ღირებულება:</span>
                    <span className="text-emerald-400 font-bold">{formatLari(car.price)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 2. ESTATES & HOUSES SECTION (ONLY when 'estates' is selected - NEVER shows cars!) */}
      {activeCategory === 'estates' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base sm:text-lg font-bold text-slate-100 flex items-center gap-2">
              <Home className="w-5 h-5 text-cyan-400" />
              <span>უძრავი ქონება & სახლები ({myEstates.length})</span>
            </h2>
            <span className="text-xs font-mono text-slate-400">
              ქირის შემოსავალი: <strong className="text-emerald-400">+{formatLari(totalPassiveRent * 60)}/წთ</strong>
            </span>
          </div>

          {myEstates.length === 0 ? (
            <div className="p-6 sm:p-8 rounded-2xl bg-slate-900/40 border border-slate-800 text-center space-y-4">
              <span className="text-4xl block">🏚️</span>
              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-200">ჯერჯერობით არ ფლობ სახლს</h3>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  შეიძინე სოლოლაკის "იტალიური ეზოს" ნახევრად დანგრეული ბინა სულ რაღაც 8,500 ₾-ად, რომელიც ყოველ წამს მოგიტანს ქირას!
                </p>
              </div>

              {sololakiHouse && !ownsSololaki && (
                <div className="max-w-md mx-auto p-4 rounded-2xl bg-amber-950/30 border border-amber-500/40 text-left space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase text-amber-400">რეკომენდებული სტარტერი</span>
                    <span className="font-mono text-xs font-black text-amber-300">8,500 ₾</span>
                  </div>
                  <div>
                    <h4 className="font-extrabold text-sm text-slate-100">{sololakiHouse.name}</h4>
                    <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">{sololakiHouse.description}</p>
                  </div>
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[11px] font-mono text-emerald-400 font-bold">+2 ₾ / წამში</span>
                    <button
                      type="button"
                      disabled={player.balance < sololakiHouse.price}
                      onClick={handleQuickBuySololaki}
                      className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 font-black text-xs shadow-md transition-all cursor-pointer"
                    >
                      {player.balance >= sololakiHouse.price ? 'სოლოლაკის ბინის ყიდვა (8,500 ₾)' : 'არ გაქვს საკმარისი თანხა'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {myEstates.map((estate) => (
                <div
                  key={estate.id}
                  className={`p-4 rounded-2xl border transition-all flex flex-col justify-between space-y-3 ${
                    estate.id === 'est_sololaki'
                      ? 'bg-amber-950/20 border-amber-500/40 shadow-[0_0_15px_rgba(245,158,11,0.15)]'
                      : 'bg-[#0c0d14] border-slate-800 hover:border-cyan-500/40'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="text-[10px] uppercase font-bold text-slate-400">
                        {estate.location}
                      </span>
                      {estate.id === 'est_sololaki' && (
                        <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-bold">
                          🏚️ იტალიური ეზო
                        </span>
                      )}
                    </div>
                    <h4 className="font-extrabold text-sm sm:text-base text-slate-100">
                      {estate.name}
                    </h4>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                      {estate.description}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400">ქირის შემოსავალი:</span>
                    <span className="text-emerald-400 font-extrabold">
                      +{formatLari(estate.passiveRentPerSec)}/წთ
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 3. GARAGES SECTION (ONLY when 'garages') */}
      {activeCategory === 'garages' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base sm:text-lg font-bold text-slate-100 flex items-center gap-2">
              <Warehouse className="w-5 h-5 text-amber-400" />
              <span>ავტოფარეხები & ბოქსები ({myGarages.length})</span>
            </h2>
            <span className="text-xs font-mono text-slate-400">
              ტევადობა: <strong className="text-amber-400">{player.garageCapacity} ადგილი</strong>
            </span>
          </div>

          {myGarages.length === 0 ? (
            <div className="p-6 rounded-2xl bg-slate-900/40 border border-slate-800 text-center space-y-2">
              <span className="text-3xl block">🅿️</span>
              <p className="text-xs text-slate-400">
                საბაზისო გარაჟის ტევადობაა 2 მანქანა. შეიძინე ვაკის ან ორთაჭალის გარაჟები მეტი ადგილისთვის!
              </p>
              <button
                onClick={onNavigateToShop}
                className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
              >
                გარაჟის დამატება
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {myGarages.map((garage) => (
                <div key={garage.id} className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-slate-100">{garage.name}</h4>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      +{garage.capacity} ადგილი
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-snug">{garage.description}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 4. BUSINESSES SECTION */}
      {activeCategory === 'businesses' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base sm:text-lg font-bold text-slate-100 flex items-center gap-2">
              <Briefcase className="w-5 h-5 text-purple-400" />
              <span>კომერციული ბიზნესები ({myBusinesses.length})</span>
            </h2>
            <span className="text-xs font-mono text-slate-400">
              შეფასება: <strong className="text-emerald-400">{formatLari(businessesValue)}</strong>
            </span>
          </div>

          {myBusinesses.length === 0 ? (
            <div className="p-6 rounded-2xl bg-slate-900/40 border border-slate-800 text-center space-y-2">
              <span className="text-3xl block">💼</span>
              <p className="text-xs text-slate-400">
                თხილის სარჩევი აპარატები, შაურმის ქსელი ან კრიპტო მაინინგ ფერმა მუდმივ პასიურ შემოსავალს მოგიტანს!
              </p>
              <button
                onClick={onNavigateToShop}
                className="px-3.5 py-1.5 rounded-xl bg-purple-500 hover:bg-purple-400 text-slate-950 font-bold text-xs"
              >
                ბიზნესის შეძენა
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {myBusinesses.map((biz) => {
                const count = ownedBusinesses[biz.id] || 0;
                return (
                  <div
                    key={biz.id}
                    className="p-4 rounded-2xl bg-[#0c0d14] border border-slate-800 hover:border-purple-500/40 transition-all flex flex-col justify-between space-y-3"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-[10px] uppercase font-bold text-purple-400">
                          {biz.type}
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-mono text-xs font-bold border border-purple-500/30">
                          ფლობ: {count} ცალი
                        </span>
                      </div>
                      <h4 className="font-extrabold text-sm sm:text-base text-slate-100">
                        {biz.name}
                      </h4>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        {biz.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                      <span className="text-slate-400">შემოსავალი:</span>
                      <span className="text-emerald-400 font-extrabold">
                        +{formatLari(biz.baseIncome * BUSINESS_INCOME_SCALE * count)} ყოველ {biz.intervalSeconds} წამში
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 5. UPGRADERS SECTION */}
      {activeCategory === 'upgraders' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base sm:text-lg font-bold text-slate-100 flex items-center gap-2">
              <Zap className="w-5 h-5 text-emerald-400" />
              <span>აქტიური აფგრეიდერები (120 წამის დივიდენდები)</span>
            </h2>
            <span className="text-xs font-mono text-emerald-400 font-bold">
              ჯამში: +{formatLari(totalUpgraderDividends)} / 120წმ
            </span>
          </div>

          {myUpgraders.length === 0 ? (
            <div className="p-6 rounded-2xl bg-slate-900/40 border border-slate-800 text-center space-y-2">
              <span className="text-3xl block">⚡</span>
              <p className="text-xs text-slate-400">
                გაააქტიურე სოლოლაკის Airbnb მენეჯმენტი, ავტოსამრეცხაოების ქსელი ან ASIC მაინერები!
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {myUpgraders.map((upg) => (
                <div
                  key={upg.id}
                  className="p-4 rounded-2xl bg-[#0c0d14] border border-emerald-500/30 shadow-lg flex flex-col justify-between space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-emerald-400 block mb-0.5">
                        დონე: {upg.owned}
                      </span>
                      <h4 className="font-extrabold text-sm sm:text-base text-slate-100">
                        {upg.name}
                      </h4>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        {upg.description}
                      </p>
                    </div>
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold shrink-0">
                      <Zap className="w-5 h-5" />
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400">120წმ დივიდენდი:</span>
                    <span className="text-emerald-400 font-extrabold">
                      +{formatLari(upg.passivePerCycle * UPGRADER_INCOME_SCALE * upg.owned)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 6. SECURITY & ACCESSORIES */}
      {activeCategory === 'security' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base sm:text-lg font-bold text-slate-100 flex items-center gap-2">
              <Shield className="w-5 h-5 text-amber-400" />
              <span>დაცვის სისტემები & VIP აქსესუარები</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mySecurity.map((sec) => (
              <div key={sec.id} className="p-4 rounded-2xl bg-[#0c0d14] border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm text-slate-100">{sec.name}</h4>
                  <span className="text-xs font-mono text-amber-400">+{sec.respect} RP</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">{sec.description}</p>
                <div className="text-[11px] font-mono text-emerald-400 pt-1">
                  🛡️ ბონუსი: {sec.protectionBonus}
                </div>
              </div>
            ))}

            {myAccessories.map((acc) => (
              <div key={acc.id} className="p-4 rounded-2xl bg-[#0c0d14] border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{acc.image}</span>
                    <h4 className="font-bold text-sm text-slate-100">{acc.name}</h4>
                  </div>
                  <span className="text-xs font-mono text-amber-400">+{acc.respect} RP</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">{acc.description}</p>
              </div>
            ))}

            {mySecurity.length === 0 && myAccessories.length === 0 && (
              <div className="col-span-full p-6 rounded-2xl bg-slate-900/40 border border-slate-800 text-center text-xs text-slate-400">
                არ გაქვს შეძენილი დაცვის სისტემები ან ლუქს აქსესუარები.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};




