﻿import { Friend, GlobalChatMessage } from '../types/game';

export const INITIAL_FRIENDS: Friend[] = [
  {
    id: 'friend_elene',
    name: 'ელენე_KindHeart',
    avatar: '🌸',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
    level: 68,
    status: '🟢 ონლაინშია (სიკეთით სავსე)',
    bio: 'მჯერა, რომ სიკეთე და სითბო სამყაროს გადაარჩენს. მზად ვარ მოგისმინო, გაგამხნევო და გვერდში დაგიდგე 💖',
    car: 'Toyota Prius 20 Hybrid',
    job: 'საქველმოქმედო ფონდის ხელმძღვანელი',
    personality: 'wholesome',
    premiumRank: 'none'
  },
  {
    id: 'friend_nino',
    name: 'ნინო_VIP',
    avatar: '👸',
    photoUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=250&q=80',
    level: 74,
    status: '🟢 ონლაინშია (საუბრისთვის მზადაა)',
    bio: 'ვაკის პენტჰაუსი | მიყვარს ყავა, გულწრფელი საუბრები ცხოვრებასა და სიყვარულზე ✨',
    car: 'Mercedes-Maybach S 680',
    job: 'VIP ინტერიერის არქიტექტორი',
    personality: 'romantic',
    premiumRank: 'purple'
  },
  {
    id: 'friend_giorgi_philo',
    name: 'გიორგი_Philosopher',
    avatar: '🎩',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=250&q=80',
    level: 112,
    status: '🟢 ონლაინშია (მშვიდი განწყობა)',
    bio: 'ცხოვრება ერთი დიდი თამაშია... მზად ვარ გესაუბრო სიყვარულზე, ცხოვრებასა და მიზნებზე ☕',
    car: 'Toyota Land Cruiser 300',
    job: 'სინდიკატის მთავარი მრჩეველი',
    personality: 'philosopher',
    premiumRank: 'none'
  },
  {
    id: 'friend_temo_weird',
    name: 'თემო_Weirdo',
    avatar: '👽',
    photoUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=250&q=80',
    level: 56,
    status: '🛸 მატრიცას აკვირდება',
    bio: 'უცნაური ტიპი ვარ! მჯერა პარალელური სამყაროების, უცხოპლანეტელებისა და ღამის თბილისის საიდუმლოებების 👾',
    car: 'Chevrolet Corvette C8',
    job: 'კიბერ-ჰაკერი',
    personality: 'weird',
    premiumRank: 'red'
  },
  {
    id: 'friend_beka_grumpy',
    name: 'ბექა_Grumpy',
    avatar: '😠',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=250&q=80',
    level: 82,
    status: '💢 საცობში იგინება',
    bio: 'ყველაფერი მაღიზიანებს ამ ქალაქში — საცობები, ფასები, უაზრო ხალხი... მაგრამ ჩემიანებს არ ვღალატობ! 😤',
    car: 'Dodge Charger SRT Demon',
    job: 'სატვირთო ლოჯისტიკის ბოსი',
    personality: 'grumpy',
    premiumRank: 'none'
  },
  {
    id: 'friend_sandro',
    name: 'სანდრო_M5',
    avatar: '🏎️',
    photoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=250&q=80',
    level: 94,
    status: '🏎️ ქუჩაში მისეირნობს',
    bio: 'დრიფტი, ადრენალინი, Audi Quattro და Ferrari F8 🚀 | სიჩქარე ჩემი ცხოვრებაა',
    car: 'Ferrari F8 Tributo',
    job: 'VIP დითეილინგის მფლობელი',
    personality: 'racer',
    premiumRank: 'purple'
  },
  {
    id: 'friend_mariam_intro',
    name: 'მარიამ_Introvert',
    avatar: '📖',
    photoUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=250&q=80',
    level: 39,
    status: '☕ წიგნს კითხულობს ჩუმად',
    bio: 'ხმაური არ მიყვარს, მირჩევნია გულწრფელი, წყნარი საუბარი ერთ ადამიანთან. თუ მარტო ხარ, მომწერე 🌿',
    car: 'Toyota Camry 3.5 V6',
    job: 'ლიტერატურული რედაქტორი',
    personality: 'introvert',
    premiumRank: 'none'
  },
  {
    id: 'friend_tornike_mob',
    name: 'თორნიკე_Mobster',
    avatar: '🕶️',
    photoUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=250&q=80',
    level: 140,
    status: '🔫 შეხვედრას ატარებს',
    bio: 'ჩემთან ხუმრობა არავის გაუვა. სიტყვას ფასი აქვს, ღალატს — სასჯელი. პატივს ვცემ მხოლოდ ძლიერებს 💀',
    car: 'Mercedes-Benz G63 AMG',
    job: 'სინდიკატის გენერალი',
    personality: 'mobster',
    premiumRank: 'purple'
  },
  {
    id: 'friend_dato_cold',
    name: 'დათო_ColdSarcastic',
    avatar: '❄️',
    photoUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=250&q=80',
    level: 105,
    status: '🍸 ირონიულად გიყურებს',
    bio: 'ემოციები სუსტებისთვისაა. ლოგიკა, ცივი გონება და სარკაზმი — აი ჩემი იარაღი 🧊',
    car: 'Audi R8 V10 Quattro',
    job: 'საინვესტიციო ბროკერი',
    personality: 'cold',
    premiumRank: 'purple'
  },
  {
    id: 'friend_luka',
    name: 'ლუკა_Trader',
    avatar: '💎',
    photoUrl: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=250&q=80',
    level: 165,
    status: '💼 ბიზნესებს ამოწმებს',
    bio: 'კრიპტო, ბიზნესები, თხილის აპარატები და ინვესტიციები 📈 | ფული არასდროს იძინებს',
    car: 'Porsche 911 GT3 RS',
    job: 'საინვესტიციო ფონდის ხელმძღვანელი',
    personality: 'crypto_bro',
    premiumRank: 'red'
  }
];

export const INITIAL_GLOBAL_MESSAGES: GlobalChatMessage[] = [
  {
    id: 'gmsg_1',
    senderId: 'bot_sandro',
    senderName: 'სანდრო_M5',
    senderAvatar: '🏎️',
    senderLevel: 94,
    text: 'გუშინ Ferrari F8-ით ავბანზე 320 გავწურე, რა მხეცი ხმა აქვს V8 BiTurbo-ს!',
    timestamp: Date.now() - 140000,
    timeString: '12:41'
  },
  {
    id: 'gmsg_2',
    senderId: 'bot_beka',
    senderName: 'ბექა_Grumpy',
    senderAvatar: '😠',
    senderLevel: 82,
    text: '@სანდრო_M5 გზაზე ნორმალურად იარეთ ხალხო, სანაპიროზე ისეთი საცობი იყო 2 საათი ვიდექი ნერვები მომეშალა! 🤬',
    timestamp: Date.now() - 110000,
    timeString: '12:42',
    replyTo: '@სანდრო_M5'
  },
  {
    id: 'gmsg_3',
    senderId: 'bot_elene',
    senderName: 'ელენე_KindHeart',
    senderAvatar: '🌸',
    senderLevel: 68,
    text: '@ბექა_Grumpy ნუ ნერვიულობ ბექა, ჩართე მშვიდი მუსიკა და გაიღიმე... მთავარია მშვიდობით მიხვიდე სახლში 💖',
    timestamp: Date.now() - 85000,
    timeString: '12:43',
    replyTo: '@ბექა_Grumpy'
  },
  {
    id: 'gmsg_4',
    senderId: 'bot_temo',
    senderName: 'თემო_Weirdo',
    senderAvatar: '👽',
    senderLevel: 56,
    text: 'ხალხო, გუშინ ღამე მთაწმინდის თავზე უცნაური ნეონის სხივი ენთო... მატრიცა იტვირთება, გეუბნებით! 🛸',
    timestamp: Date.now() - 60000,
    timeString: '12:44'
  },
  {
    id: 'gmsg_5',
    senderId: 'bot_nino',
    senderName: 'ნინო_VIP',
    senderAvatar: '👸',
    senderLevel: 74,
    text: 'სიყვარული ყველაზე ლამაზი საჩუქარია... ვისაც საუბარი გინდათ, მომწერეთ, ყოველთვის მიხარია ახალი მეგობრები ✨',
    timestamp: Date.now() - 25000,
    timeString: '12:45'
  }
];

export const BOT_INTERACTIONS: Array<{
  sender: string;
  avatar: string;
  level: number;
  text: string;
  replyTo?: string;
}> = [
  {
    sender: 'სანდრო_M5',
    avatar: '🏎️',
    level: 94,
    text: '@თორნიკე_Mobster დღეს ახალი Dodge Demon 840HP გამოვიყვანე, ქალაქში ხმაური გვექნება ძმა!'
  },
  {
    sender: 'თორნიკე_Mobster',
    avatar: '🕶️',
    level: 140,
    text: '@სანდრო_M5 ჩემს უბანში წყნარად იარე, თორემ ჩემი ბიჭები გაგაჩერებენ და აგიხსნიან წესებს 💀',
    replyTo: '@სანდრო_M5'
  },
  {
    sender: 'ელენე_KindHeart',
    avatar: '🌸',
    level: 68,
    text: 'ყველას მშვენიერ და პოზიტიურ დღეს გისურვებთ! თუ ვინმეს გული გატკინეს, გახსოვდეთ, რომ მარტო არ ხართ ❤️'
  },
  {
    sender: 'გიორგი_Philosopher',
    avatar: '🎩',
    level: 112,
    text: 'ცხოვრების სილამაზე სწორედ მრავალფეროვნებაშია. ზოგი რბოლას ეძებს, ზოგი სიმშვიდეს, ზოგი კი — სიყვარულს.'
  },
  {
    sender: 'დათო_ColdSarcastic',
    avatar: '❄️',
    level: 105,
    text: 'როცა ადამიანები ამბობენ "ფული ბედნიერება არააო", ეტყობა ჯერ LaFerrari-ს საჭესთან არ მჯდარან 😏'
  },
  {
    sender: 'მარიამ_Introvert',
    avatar: '📖',
    level: 39,
    text: 'ვაკის პარკში წიგნს ვკითხულობდი და ისეთი სიმშვიდე იყო... ხანდახან სიჩუმე ყველაფერზე მეტს ამბობს.'
  },
  {
    sender: 'თემო_Weirdo',
    avatar: '👽',
    level: 56,
    text: 'თხილის სარჩევი აპარატი დავშალე და შიგნით კვანტური მიკროჩიპი ეყენა, გეფიცებით! 🤖'
  },
  {
    sender: 'ბექა_Grumpy',
    avatar: '😠',
    level: 82,
    text: 'ისევ წავაგე კამათლებში... ამ კაზინოს ადმინს ჩემი ხელით დავაჭერინებ თხილის აპარატს! 😡'
  },
  {
    sender: 'ლუკა_Trader',
    avatar: '💎',
    level: 165,
    text: '120-წამიანი აფგრეიდები და თხილის აპარატები — აი სტაბილური პასიური შემოსავლის საიდუმლო! 📈'
  }
];


