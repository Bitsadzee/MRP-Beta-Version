﻿import React, { useState, useEffect, useRef } from 'react';
import {
  MessageSquare,
  Users,
  Send,
  UserPlus,
  Check,
  Sparkles,
  Shield,
  Car as CarIcon,
  Briefcase,
  X,
  Search,
  Heart,
  Compass,
  Smile,
  Zap,
  Clock
} from 'lucide-react';
import { Friend, DirectMessage, GlobalChatMessage } from '../types/game';
import { INITIAL_FRIENDS, INITIAL_GLOBAL_MESSAGES } from '../utils/chatConstants';
import {
  getSmartAiDirectMessageReply,
  getSmartAiGlobalChatReplies,
  getDynamicRoomChatter
} from '../utils/aiChat';
import { playClickSound, playCashSound } from '../utils/audio';

interface CommunityChatProps {
  playerName: string;
  playerAvatar: string;
  playerPhoto?: string;
  playerLevel: number;
  balance?: number;
  soundEnabled: boolean;
}

const STORAGE_GLOBAL_MESSAGES = 'money_sim_global_messages_v1';
const STORAGE_FRIENDS = 'money_sim_friends_v1';
const STORAGE_DIRECT_MESSAGES = 'money_sim_dms_v1';

export const CommunityChat: React.FC<CommunityChatProps> = ({
  playerName,
  playerAvatar,
  playerPhoto,
  playerLevel,
  balance,
  soundEnabled
}) => {
  const [activeTab, setActiveTab] = useState<'global' | 'friends'>('global');

  // Global Chat State
  const [globalMessages, setGlobalMessages] = useState<GlobalChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_GLOBAL_MESSAGES);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_GLOBAL_MESSAGES;
  });
  const [globalInput, setGlobalInput] = useState<string>('');

  // Friends State
  const [friends, setFriends] = useState<Friend[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_FRIENDS);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_FRIENDS;
  });
  const [selectedFriendId, setSelectedFriendId] = useState<string>(() => {
    return INITIAL_FRIENDS[0]?.id || '';
  });

  // Direct Messages State (Keyed by friendId)
  const [directMessages, setDirectMessages] = useState<{ [friendId: string]: DirectMessage[] }>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_DIRECT_MESSAGES);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    // Default initial greeting for first friend
    return {
      friend_nino: [
        {
          id: 'dm_init_1',
          friendId: 'friend_nino',
          sender: 'friend',
          text: 'გამარჯობა! ძალიან გამიხარდა შენი გაცნობა ✨ შეგიძლია ნებისმიერ დროს მომწერო — ცხოვრებაზე, სიყვარულზე თუ უბრალოდ გულის გადასაშლელად ❤️',
          timestamp: Date.now() - 3600000,
          timeString: '11:30'
        }
      ],
      friend_luka: [
        {
          id: 'dm_init_2',
          friendId: 'friend_luka',
          sender: 'friend',
          text: 'სალამი! ბიზნესებში, თხილის აპარატებში ან აფგრეიდებში თუ რამე რჩევა დაგჭირდება, პირდაპირ მომმართე! 📈',
          timestamp: Date.now() - 7200000,
          timeString: '10:15'
        }
      ]
    };
  });

  const [dmInput, setDmInput] = useState<string>('');
  const [isFriendTyping, setIsFriendTyping] = useState<boolean>(false);
  const [friendSearch, setFriendSearch] = useState<string>('');

  // Bot Profile Popup Modal
  const [inspectedBot, setInspectedBot] = useState<{
    id?: string;
    name: string;
    avatar: string;
    level: number;
    bio?: string;
    car?: string;
    job?: string;
    personality?: string;
  } | null>(null);

  // Auto-scroll refs
  const globalChatEndRef = useRef<HTMLDivElement>(null);
  const dmChatEndRef = useRef<HTMLDivElement>(null);

  // Save state to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_GLOBAL_MESSAGES, JSON.stringify(globalMessages));
      localStorage.setItem(STORAGE_FRIENDS, JSON.stringify(friends));
      localStorage.setItem(STORAGE_DIRECT_MESSAGES, JSON.stringify(directMessages));
    } catch {
      // ignore
    }
  }, [globalMessages, friends, directMessages]);

  // Scroll to bottom on new messages
  useEffect(() => {
    if (activeTab === 'global') {
      globalChatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [globalMessages, activeTab]);

  useEffect(() => {
    if (activeTab === 'friends') {
      dmChatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [directMessages, selectedFriendId, isFriendTyping, activeTab]);

  // Periodic dynamic bot-to-bot messages in Global Chat (every 18-24 seconds)
  useEffect(() => {
    const timer = setInterval(async () => {
      const chatter = await getDynamicRoomChatter(
        globalMessages.slice(-5).map((m) => ({ senderName: m.senderName, text: m.text })),
        playerName
      );

      const now = new Date();
      const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

      const newBotMsg: GlobalChatMessage = {
        id: `gmsg_dyn_${Date.now()}_${Math.random()}`,
        senderId: `bot_${chatter.senderName}`,
        senderName: chatter.senderName,
        senderAvatar: chatter.avatar,
        senderLevel: chatter.level,
        text: chatter.text,
        timestamp: Date.now(),
        timeString: timeStr,
        replyTo: chatter.replyTo
      };

      setGlobalMessages((prev) => [...prev.slice(-60), newBotMsg]);
    }, 19000);

    return () => clearInterval(timer);
  }, [globalMessages, playerName]);

  // Send message in Global Chat
  const handleSendGlobalMessage = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!globalInput.trim()) return;

    playClickSound(soundEnabled);
    const textToSend = globalInput.trim();
    setGlobalInput('');

    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    const playerMsg: GlobalChatMessage = {
      id: `pmsg_${Date.now()}`,
      senderId: 'player',
      senderName: playerName,
      senderAvatar: playerAvatar,
      senderLevel: playerLevel,
      text: textToSend,
      timestamp: Date.now(),
      timeString: timeStr,
      isPlayer: true
    };

    setGlobalMessages((prev) => [...prev.slice(-60), playerMsg]);

    // Generate smart contextual bot replies in Global Chat with economic context
    const recentHistory = globalMessages.slice(-6).map((m) => ({ sender: m.senderName, text: m.text }));
    getSmartAiGlobalChatReplies(
      textToSend,
      playerName,
      playerLevel,
      { playerBalance: balance },
      recentHistory
    ).then((replies) => {
      replies.forEach((rep) => {
        setTimeout(() => {
          const replyTime = new Date();
          const repTimeStr = `${replyTime.getHours().toString().padStart(2, '0')}:${replyTime.getMinutes().toString().padStart(2, '0')}`;

          const botReply: GlobalChatMessage = {
            id: `bot_reply_${Date.now()}_${Math.random()}`,
            senderId: `bot_${rep.botName}`,
            senderName: rep.botName,
            senderAvatar: rep.avatar,
            senderLevel: rep.level,
            text: rep.text,
            timestamp: Date.now(),
            timeString: repTimeStr
          };

          setGlobalMessages((prev) => [...prev.slice(-60), botReply]);

          // If bot wants to be friends, ensure they exist in friends list
          if (rep.wantsToBeFriend) {
            setFriends((prev) => {
              const alreadyExists = prev.some((f) => f.name === rep.botName);
              if (!alreadyExists) {
                const newFriend: Friend = {
                  id: `friend_${rep.botName}`,
                  name: rep.botName,
                  avatar: rep.avatar,
                  level: rep.level,
                  status: '🟢 ონლაინშია (გლობალ ჩატიდან)',
                  bio: 'გლობალ ჩატში გაგიცნო და სიამოვნებით იმეგობრებს შენთან!',
                  personality: 'friendly'
                };
                return [...prev, newFriend];
              }
              return prev;
            });
          }
        }, rep.delayMs);
      });
    });
  };

  // Send Direct Message to Selected Friend
  const handleSendDirectMessage = (customText?: string) => {
    const text = customText || dmInput;
    if (!text.trim() || !selectedFriendId) return;

    playClickSound(soundEnabled);
    if (!customText) setDmInput('');

    const activeFriend = friends.find((f) => f.id === selectedFriendId);
    if (!activeFriend) return;

    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    const playerDm: DirectMessage = {
      id: `dm_${Date.now()}`,
      friendId: selectedFriendId,
      sender: 'player',
      text: text.trim(),
      timestamp: Date.now(),
      timeString: timeStr
    };

    const updatedHistory = [...(directMessages[selectedFriendId] || []), playerDm];
    setDirectMessages((prev) => ({
      ...prev,
      [selectedFriendId]: updatedHistory
    }));

    // Trigger typing indicator and smart contextual reply
    setIsFriendTyping(true);
    const delay = 1000 + Math.random() * 1000;

    setTimeout(async () => {
      const replyText = await getSmartAiDirectMessageReply(
        activeFriend,
        text.trim(),
        playerName,
        updatedHistory,
        { playerBalance: balance }
      );
      const repNow = new Date();
      const repTimeStr = `${repNow.getHours().toString().padStart(2, '0')}:${repNow.getMinutes().toString().padStart(2, '0')}`;

      const friendDm: DirectMessage = {
        id: `dm_resp_${Date.now()}`,
        friendId: selectedFriendId,
        sender: 'friend',
        text: replyText,
        timestamp: Date.now(),
        timeString: repTimeStr
      };

      setDirectMessages((prev) => ({
        ...prev,
        [selectedFriendId]: [...(prev[selectedFriendId] || []), friendDm]
      }));

      setIsFriendTyping(false);
      playClickSound(soundEnabled);
    }, delay);
  };

  // Add bot from Global Chat to friends
  const handleAddBotToFriends = (bot: { name: string; avatar: string; level: number; bio?: string; car?: string; job?: string }) => {
    playCashSound(soundEnabled);
    const existing = friends.find((f) => f.name === bot.name);
    if (!existing) {
      const newFriend: Friend = {
        id: `friend_${bot.name}_${Date.now()}`,
        name: bot.name,
        avatar: bot.avatar,
        level: bot.level,
        status: '🟢 ონლაინშია (მეგობარი)',
        bio: bot.bio || 'შენი მეგობარი RP ქალაქში',
        car: bot.car,
        job: bot.job,
        personality: 'friendly'
      };
      setFriends((prev) => [...prev, newFriend]);
      setSelectedFriendId(newFriend.id);
    } else {
      setSelectedFriendId(existing.id);
    }
    setInspectedBot(null);
    setActiveTab('friends');
  };

  const selectedFriend = friends.find((f) => f.id === selectedFriendId) || friends[0];
  const activeDMs = selectedFriend ? directMessages[selectedFriend.id] || [] : [];

  const filteredFriends = friends.filter((f) =>
    f.name.toLowerCase().includes(friendSearch.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-4 py-4 space-y-4">
      {/* Header & Tab Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl bg-[#0c0d14] border border-slate-800 shadow-xl">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-100 flex items-center gap-2.5">
            <MessageSquare className="w-6 h-6 text-emerald-400" />
            <span>ქალაქის ჩატი & სამეგობრო</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            ისაუბრე ცოცხლად ნებისმიერ თემაზე: ცხოვრებაზე, სიყვარულზე, ბიზნესებზე, მანქანებსა და საქმეებზე!
          </p>
        </div>

        {/* Tab switchers */}
        <div className="flex items-center gap-2 p-1 bg-slate-950/80 rounded-xl border border-slate-800">
          <button
            onClick={() => {
              playClickSound(soundEnabled);
              setActiveTab('global');
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'global'
                ? 'bg-emerald-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Compass className="w-4 h-4" />
            <span>🌐 გლობალ ჩატი</span>
          </button>
          <button
            onClick={() => {
              playClickSound(soundEnabled);
              setActiveTab('friends');
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'friends'
                ? 'bg-emerald-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>👥 მეგობრები & პირადი ({friends.length})</span>
          </button>
        </div>
      </div>

      {/* ========================================================
          1. GLOBAL CHAT VIEW
      ======================================================== */}
      {activeTab === 'global' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 h-[680px]">
          {/* Main Global Feed (3 Cols) */}
          <div className="lg:col-span-3 flex flex-col rounded-2xl bg-[#0c0d14] border border-slate-800 shadow-2xl overflow-hidden">
            {/* Global Feed Header */}
            <div className="p-3.5 bg-slate-950/70 border-b border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="font-bold text-slate-100">თბილისის გლობალური RP არხი</span>
                <span className="text-slate-500">| მოთამაშეები ცოცხლად საუბრობენ</span>
              </div>
              <span className="text-[11px] text-slate-400 font-mono">
                დააწკაპუნე მოთამაშეზე პროფილის სანახავად
              </span>
            </div>

            {/* Messages Scroll Area */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3.5 scrollbar-thin scrollbar-thumb-slate-800">
              {globalMessages.map((msg) => {
                const isMe = msg.isPlayer || msg.senderName === playerName;
                const matchedFriend = friends.find((f) => f.name === msg.senderName);
                const displayPhoto = isMe ? playerPhoto : matchedFriend?.photoUrl;

                return (
                  <div
                    key={msg.id}
                    className={`flex items-start gap-2.5 ${isMe ? 'flex-row-reverse' : 'flex-row'}`}
                  >
                    {/* Avatar Button */}
                    <button
                      type="button"
                      onClick={() => {
                        if (!isMe) {
                          setInspectedBot({
                            name: msg.senderName,
                            avatar: msg.senderAvatar,
                            level: msg.senderLevel,
                            bio: matchedFriend?.bio || 'აქტიური მოთამაშე გლობალ ჩატიდან. მზად არის საუბრისთვის!',
                            car: matchedFriend?.car || (msg.senderName.includes('M5') ? 'BMW M5 E39' : 'Mercedes-Benz'),
                            job: matchedFriend?.job || (msg.senderName.includes('Trader') ? 'კრიპტო ტრეიდერი' : 'საქმიანი RP'),
                            personality: matchedFriend?.personality
                          });
                        }
                      }}
                      className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-700/80 flex items-center justify-center text-lg hover:border-emerald-500/60 transition-all flex-shrink-0 overflow-hidden"
                      title={isMe ? 'შენი პროფილი' : `${msg.senderName}-ის პროფილის ნახვა`}
                    >
                      {displayPhoto ? (
                        <img src={displayPhoto} alt={msg.senderName} className="w-full h-full object-cover" />
                      ) : (
                        <span>{msg.senderAvatar}</span>
                      )}
                    </button>

                    {/* Message Bubble */}
                    <div className={`max-w-[85%] sm:max-w-[75%] space-y-1 ${isMe ? 'items-end' : 'items-start'}`}>
                      <div className="flex items-center gap-1.5 text-[11px] font-mono flex-wrap">
                        <span className={`font-bold ${isMe ? 'text-emerald-400' : 'text-slate-200'}`}>
                          {msg.senderName}
                        </span>
                        {/* Red or Purple VIP Rank Badge */}
                        {(msg.premiumRank === 'purple' || (!msg.premiumRank && matchedFriend?.premiumRank === 'purple')) && (
                          <span className="px-1.5 py-0.2 rounded-md bg-purple-500/20 text-purple-400 border border-purple-500/50 text-[9px] font-black font-mono tracking-wider shadow-[0_0_8px_rgba(168,85,247,0.5)]">
                            🟣 PURPLE VIP
                          </span>
                        )}
                        {(msg.premiumRank === 'red' || (!msg.premiumRank && matchedFriend?.premiumRank === 'red')) && (
                          <span className="px-1.5 py-0.2 rounded-md bg-red-500/20 text-red-400 border border-red-500/50 text-[9px] font-black font-mono tracking-wider shadow-[0_0_8px_rgba(239,68,68,0.5)]">
                            🔴 RED VIP
                          </span>
                        )}
                        <span className="text-[10px] text-amber-400 bg-amber-500/10 px-1.5 py-0.2 rounded border border-amber-500/20">
                          Lvl {msg.senderLevel}
                        </span>
                        <span className="text-slate-500 text-[10px]">{msg.timeString}</span>
                      </div>

                      <div
                        className={`p-3 rounded-2xl text-xs leading-relaxed border ${
                          isMe
                            ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-slate-950 font-medium border-emerald-400/40 rounded-tr-none shadow-md'
                            : 'bg-slate-900/90 text-slate-200 border-slate-800 rounded-tl-none shadow-md'
                        }`}
                      >
                        {msg.replyTo && (
                          <div className="text-[11px] font-bold text-amber-300 mb-1 opacity-90">
                            {msg.replyTo}
                          </div>
                        )}
                        <span>{msg.text}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
              <div ref={globalChatEndRef} />
            </div>

            {/* Input Bar */}
            <form onSubmit={handleSendGlobalMessage} className="p-3 bg-slate-950/80 border-t border-slate-800 flex items-center gap-2">
              <input
                type="text"
                value={globalInput}
                onChange={(e) => setGlobalInput(e.target.value)}
                placeholder="დაწერე გლობალ ჩატში (მაგ: სალამი ყველას, სიყვარულზე რას ფიქრობთ? რჩევა მჭირდება)..."
                className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500/60"
              />
              <button
                type="submit"
                disabled={!globalInput.trim()}
                className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 disabled:bg-slate-800 disabled:text-slate-600 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all active:scale-95 shadow-md"
              >
                <span>გაგზავნა</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>

          {/* Right Sidebar: Active Citizens & Friends shortcuts */}
          <div className="flex flex-col rounded-2xl bg-[#0c0d14] border border-slate-800 p-4 space-y-4">
            <div>
              <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
                <span>ონლაინ მოქალაქეები</span>
                <span className="text-emerald-400">● 14 აქტიური</span>
              </h3>
              <p className="text-[11px] text-slate-400 mt-1">
                დააწკაპუნე მეგობრებში დასამატებლად ან პირადში სასაუბროდ
              </p>
            </div>

            <div className="space-y-2 overflow-y-auto max-h-[500px]">
              {friends.map((friend) => (
                <div
                  key={friend.id}
                  className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80 flex items-center justify-between hover:border-slate-700 transition-all"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-lg overflow-hidden bg-slate-800 flex items-center justify-center flex-shrink-0 border border-slate-700">
                      {friend.photoUrl ? (
                        <img src={friend.photoUrl} alt={friend.name} className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-lg">{friend.avatar}</span>
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-slate-200 truncate flex items-center gap-1.5">
                        <span>{friend.name}</span>
                        {friend.premiumRank === 'purple' && (
                          <span className="px-1 py-0.1 rounded text-[8px] font-black font-mono bg-purple-500/20 text-purple-400 border border-purple-500/50">
                            🟣 VIP
                          </span>
                        )}
                        {friend.premiumRank === 'red' && (
                          <span className="px-1 py-0.1 rounded text-[8px] font-black font-mono bg-red-500/20 text-red-400 border border-red-500/50">
                            🔴 VIP
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate">{friend.status}</div>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setSelectedFriendId(friend.id);
                      setActiveTab('friends');
                    }}
                    className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500 hover:text-slate-950 transition-all text-[11px] font-bold"
                    title="პირადში მიწერა"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/70 text-[11px] text-slate-400 space-y-1">
              <span className="text-amber-400 font-bold block">💡 RP რჩევა:</span>
              <span>
                როცა გლობალ ჩატში რამეს დაწერ, მოთამაშეები რეაგირებენ და პასუხს გიბრუნებენ. შეგიძლია ნებისმიერი მათგანი დაამატო მეგობრებში!
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          2. FRIENDS & 1-ON-1 DIRECT MESSAGES VIEW
      ======================================================== */}
      {activeTab === 'friends' && (
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4 h-[680px]">
          {/* Left Sidebar: Friends List */}
          <div className="md:col-span-1 flex flex-col rounded-2xl bg-[#0c0d14] border border-slate-800 overflow-hidden shadow-xl">
            {/* Friends Search Header */}
            <div className="p-3 border-b border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider">
                  სამეგობრო სია ({friends.length})
                </span>
              </div>
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
                <input
                  type="text"
                  value={friendSearch}
                  onChange={(e) => setFriendSearch(e.target.value)}
                  placeholder="ძებნა მეგობრებში..."
                  className="w-full pl-8 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Friends Scrollable List */}
            <div className="flex-1 overflow-y-auto p-2 space-y-1.5 scrollbar-thin scrollbar-thumb-slate-800">
              {filteredFriends.map((f) => {
                const isSelected = selectedFriend?.id === f.id;
                return (
                  <button
                    key={f.id}
                    onClick={() => {
                      playClickSound(soundEnabled);
                      setSelectedFriendId(f.id);
                    }}
                    className={`w-full p-2.5 rounded-xl text-left flex items-center justify-between transition-all ${
                      isSelected
                        ? 'bg-emerald-500/20 border border-emerald-500/40 text-slate-100 shadow-sm'
                        : 'bg-slate-900/40 border border-transparent hover:bg-slate-900 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="relative">
                        <span className="text-2xl">{f.avatar}</span>
                        <span className="w-2 h-2 rounded-full bg-emerald-400 absolute bottom-0 right-0 border border-slate-950" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold truncate flex items-center gap-1.5">
                          <span>{f.name}</span>
                          <span className="text-[10px] text-amber-400 font-mono">Lvl {f.level}</span>
                        </div>
                        <div className="text-[10px] text-slate-400 truncate mt-0.5">
                          {f.status}
                        </div>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Area: Active 1-on-1 Chat Pane */}
          <div className="md:col-span-2 lg:col-span-3 flex flex-col rounded-2xl bg-[#0c0d14] border border-slate-800 shadow-2xl overflow-hidden">
            {selectedFriend ? (
              <>
                {/* Chat Top Bar */}
                <div className="p-3.5 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl overflow-hidden bg-slate-900 border border-slate-700 flex items-center justify-center flex-shrink-0 shadow-md">
                      {selectedFriend.photoUrl ? (
                        <img src={selectedFriend.photoUrl} alt={selectedFriend.name} className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-2xl">{selectedFriend.avatar}</span>
                      )}
                    </div>
                    <div>
                      <div className="text-sm font-bold text-slate-100 flex items-center gap-2">
                        <span>{selectedFriend.name}</span>
                        <span className="text-xs font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                          ლეველი {selectedFriend.level}
                        </span>
                      </div>
                      <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                        <span className="text-emerald-400 font-medium">{selectedFriend.status}</span>
                        {selectedFriend.car && (
                          <span className="hidden sm:inline text-slate-500 font-mono">
                            • 🚗 {selectedFriend.car}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-400 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>ცოცხალი RP საუბარი</span>
                  </div>
                </div>

                {/* Conversation Topic Starters (Pills) */}
                <div className="px-4 py-2 bg-slate-950/40 border-b border-slate-800/80 flex items-center gap-2 overflow-x-auto text-xs scrollbar-none">
                  <span className="text-[11px] text-slate-500 font-mono whitespace-nowrap">
                    სწრაფი თემები:
                  </span>
                  <button
                    onClick={() => handleSendDirectMessage('ცხოვრებაზე რას ფიქრობ? როგორ ხარ საერთოდ?')}
                    className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 text-[11px] whitespace-nowrap transition-all"
                  >
                    ☕ ცხოვრებაზე საუბარი
                  </button>
                  <button
                    onClick={() => handleSendDirectMessage('სიყვარულზე და ურთიერთობებზე მინდა დაგელაპარაკო, რჩევა მჭირდება ❤️')}
                    className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 text-[11px] whitespace-nowrap transition-all"
                  >
                    ❤️ სიყვარული & რჩევა
                  </button>
                  <button
                    onClick={() => handleSendDirectMessage('რომელი ბიზნესები ჯობია ვიყიდო? თხილის აპარატები თუ აფგრეიდები?')}
                    className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 text-[11px] whitespace-nowrap transition-all"
                  >
                    💼 ბიზნესები & ფული
                  </button>
                  <button
                    onClick={() => handleSendDirectMessage('შენ რომელი მანქანა მოგწონს ყველაზე მეტად? მერსედესი თუ აუდი?')}
                    className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 text-[11px] whitespace-nowrap transition-all"
                  >
                    🏎️ მანქანები & სიჩქარე
                  </button>
                </div>

                {/* Direct Messages Scroll Area */}
                <div className="flex-1 p-4 overflow-y-auto space-y-3.5 scrollbar-thin scrollbar-thumb-slate-800">
                  {/* Bio Welcome Card */}
                  <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 text-center max-w-md mx-auto space-y-2 my-2">
                    <div className="w-16 h-16 rounded-2xl overflow-hidden bg-slate-900 border border-slate-700 mx-auto flex items-center justify-center shadow-lg">
                      {selectedFriend.photoUrl ? (
                        <img src={selectedFriend.photoUrl} alt={selectedFriend.name} className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-3xl">{selectedFriend.avatar}</span>
                      )}
                    </div>
                    <div className="text-xs font-bold text-slate-200">{selectedFriend.name}</div>
                    <div className="text-xs text-slate-400 italic">"{selectedFriend.bio}"</div>
                    {selectedFriend.job && (
                      <div className="text-[11px] text-amber-400/90 font-mono pt-1">
                        საქმიანობა: {selectedFriend.job}
                      </div>
                    )}
                  </div>

                  {activeDMs.map((dm) => {
                    const isMe = dm.sender === 'player';
                    return (
                      <div
                        key={dm.id}
                        className={`flex items-start gap-2.5 ${isMe ? 'flex-row-reverse' : 'flex-row'}`}
                      >
                        {isMe ? (
                          <div className="w-8 h-8 rounded-lg overflow-hidden bg-slate-800 flex items-center justify-center flex-shrink-0 border border-emerald-500/30">
                            {playerPhoto ? (
                              <img src={playerPhoto} alt={playerName} className="w-full h-full object-cover" />
                            ) : (
                              <span className="text-base">{playerAvatar}</span>
                            )}
                          </div>
                        ) : (
                          <div className="w-8 h-8 rounded-lg overflow-hidden bg-slate-800 flex items-center justify-center flex-shrink-0 border border-slate-700">
                            {selectedFriend.photoUrl ? (
                              <img src={selectedFriend.photoUrl} alt={selectedFriend.name} className="w-full h-full object-cover" />
                            ) : (
                              <span className="text-base">{selectedFriend.avatar}</span>
                            )}
                          </div>
                        )}

                        <div className={`max-w-[85%] sm:max-w-[75%] space-y-1 ${isMe ? 'items-end' : 'items-start'}`}>
                          <div
                            className={`p-3 rounded-2xl text-xs leading-relaxed border ${
                              isMe
                                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-slate-950 font-medium border-emerald-400/40 rounded-tr-none shadow-md'
                                : 'bg-slate-900 text-slate-200 border-slate-800 rounded-tl-none shadow-md'
                            }`}
                          >
                            {dm.text}
                          </div>
                          <div className={`text-[10px] text-slate-500 font-mono px-1 ${isMe ? 'text-right' : 'text-left'}`}>
                            {dm.timeString}
                          </div>
                        </div>
                      </div>
                    );
                  })}

                  {/* Typing Indicator */}
                  {isFriendTyping && (
                    <div className="flex items-center gap-2 text-xs text-slate-400 italic py-1">
                      <div className="w-6 h-6 rounded-lg overflow-hidden bg-slate-800 flex items-center justify-center flex-shrink-0">
                        {selectedFriend.photoUrl ? (
                          <img src={selectedFriend.photoUrl} alt={selectedFriend.name} className="w-full h-full object-cover" />
                        ) : (
                          <span className="text-sm">{selectedFriend.avatar}</span>
                        )}
                      </div>
                      <span className="text-emerald-400 font-medium">{selectedFriend.name} წერს...</span>
                      <span className="flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping delay-100" />
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping delay-200" />
                      </span>
                    </div>
                  )}

                  <div ref={dmChatEndRef} />
                </div>

                {/* Direct Message Input Bar */}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSendDirectMessage();
                  }}
                  className="p-3 bg-slate-950/80 border-t border-slate-800 flex items-center gap-2"
                >
                  <input
                    type="text"
                    value={dmInput}
                    onChange={(e) => setDmInput(e.target.value)}
                    placeholder={`მიწერე ${selectedFriend.name}-ს ნებისმიერ თემაზე (ცხოვრება, სიყვარული, ბიზნესი)...`}
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500/60"
                  />
                  <button
                    type="submit"
                    disabled={!dmInput.trim() || isFriendTyping}
                    className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 disabled:bg-slate-800 disabled:text-slate-600 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all active:scale-95 shadow-md"
                  >
                    <span>გაგზავნა</span>
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </form>
              </>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-6 text-slate-400">
                <Users className="w-12 h-12 text-slate-600 mb-2" />
                <h3 className="font-bold text-sm text-slate-200">აირჩიე მეგობარი საუბრის დასაწყებად</h3>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Profile Modal when inspecting any Bot in Global Chat */}
      {inspectedBot && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0f1017] border border-slate-800 w-full max-w-sm rounded-3xl p-5 shadow-2xl relative space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <button
              onClick={() => setInspectedBot(null)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-200 bg-slate-900 rounded-xl"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="text-center space-y-2 pt-2">
              <span className="text-5xl block">{inspectedBot.avatar}</span>
              <h3 className="text-lg font-bold text-slate-100">{inspectedBot.name}</h3>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs font-mono text-amber-400">
                <span>სტატუსი: ლეველი {inspectedBot.level}</span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800/80 text-xs space-y-2 text-slate-300">
              <p className="italic text-slate-400 text-center">"{inspectedBot.bio}"</p>
              {inspectedBot.car && (
                <div className="flex items-center justify-between text-[11px] font-mono pt-1 border-t border-slate-800">
                  <span className="text-slate-500">მანქანა:</span>
                  <span className="text-slate-200 font-semibold">{inspectedBot.car}</span>
                </div>
              )}
              {inspectedBot.job && (
                <div className="flex items-center justify-between text-[11px] font-mono">
                  <span className="text-slate-500">საქმიანობა:</span>
                  <span className="text-emerald-400 font-semibold">{inspectedBot.job}</span>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <button
                onClick={() => handleAddBotToFriends(inspectedBot)}
                className="w-full py-2.5 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2 transition-all active:scale-95"
              >
                <UserPlus className="w-4 h-4" />
                <span>მეგობრებში დამატება & პირადი ჩატი</span>
              </button>
              <button
                onClick={() => setInspectedBot(null)}
                className="w-full py-2 px-4 bg-slate-900 hover:bg-slate-800 text-slate-400 text-xs rounded-xl transition-all"
              >
                დახურვა
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};


