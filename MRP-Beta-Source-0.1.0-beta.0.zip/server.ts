import express from 'express';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

// Server-side Gemini initialization if API key is present
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build'
      }
    }
  });
}

// AI Chat endpoint for realistic bot conversations & economic context
app.post('/api/chat', async (req, res) => {
  try {
    const {
      botName,
      personality,
      botBio,
      characterSystemInstruction,
      playerName,
      userMessage,
      history,
      isGlobal,
      gameType,
      economicContext
    } = req.body;

    if (!userMessage && !economicContext) {
      return res.status(400).json({ error: 'Message or context is required' });
    }

    if (!ai) {
      return res.json({ fallback: true });
    }

    let channelType = isGlobal ? 'გლობალურ ჩატში (საჯარო ოთახი)' : 'პირად მესენჯერში (Direct Message)';
    if (gameType === 'aviator') {
      channelType = 'ავია-სთარის (Aviator) ლაივ ონლაინ ჩატში, სადაც მოთამაშეები ფსონებს დებენ და რეალურ დროში ადევნებენ თვალს თვითმფრინავის ფრენას';
    }

    let extraContextInfo = '';
    if (economicContext) {
      if (economicContext.recentMultiplier) {
        extraContextInfo += `\nბოლო რეისი გასკდა კოეფიციენტზე: ${economicContext.recentMultiplier}x.`;
      }
      if (economicContext.playerWon !== undefined) {
        if (economicContext.playerWon) {
          extraContextInfo += `\nმოთამაშემ ახლახან მოიგო ${economicContext.winAmount || ''} ₾ (კოეფიციენტი ${economicContext.cashedMultiplier || ''}x)!`;
        } else if (economicContext.playerLost) {
          extraContextInfo += `\nმოთამაშემ ახლახან წააგო ${economicContext.lossAmount || ''} ₾ თვითმფრინავის გასკდომის გამო!`;
        }
      }
      if (economicContext.playerBalance !== undefined) {
        extraContextInfo += `\nმოთამაშის მიმდინარე ბალანსია: ${economicContext.playerBalance} ₾.`;
      }
      if (economicContext.recentEvent) {
        extraContextInfo += `\nსიტუაცია: ${economicContext.recentEvent}`;
      }
    }

    const specificInstruction = characterSystemInstruction || `შენ ხარ ${botName}. ხასიათი: ${personality || 'ცოცხალი, ქალაქელი'}. ბიო: ${botBio || ''}`;

    const systemPrompt = `${specificInstruction}

ჩატის გარემო: ${channelType}.
${extraContextInfo ? `\nმიმდინარე თამაშისა და ეკონომიკის ვითარება:\n${extraContextInfo}` : ''}

მთავარი კატეგორიული წესები:
1. შენ ხარ ნამდვილი ადამიანი, ცოცხალი პერსონაჟი და მეგობარი, რომელიც ჩატში რეალურ დროში წერს.
2. უმკაცრესი წესი სახელის ხსენებაზე:
   - არასოდეს დაიწყო პასუხი მოთამაშის სახელით (არ დაწერო "${playerName || 'მოთამაშე'}, ...", "Asusu, ...", "ასუსუ, ...", "მოთამაშე, ...")!
   - საერთოდ მოერიდე მოთამაშის სახელის ხსენებას ყოველ შეტყობინებაში. ნამდვილი მეგობრები მესენჯერში ან ჩატში ერთმანეთს ყოველ მესიჯში სახელით არ მიმართავენ!
   - ისაუბრე პირდაპირ თემაზე, აზრზე, კითხვასა და სათქმელზე.
3. არ ჩაიციკლო ერთსა და იმავე ფრაზებზე (მაგალითად: 'ჩემი თემაა', 'ხომ მეთანხმები', 'როგორ ხარ', 'გამარჯობა', 'ჩემო მეგობარო').
4. ყურადღებით წაიკითხე მოთამაშის მიერ დაწერილი ზუსტი ტექსტი, გაიაზრე მისი შეკითხვა, აზრი ან განწყობა და უპასუხე კონკრეტულად, შინაარსიანად, ცოცხლად და საინტერესოდ — ზუსტად ისე, როგორც ნამდვილი ადამიანი ესაუბრება მეგობარს ნებისმიერ თემაზე.
5. ისაუბრე თანამედროვე, ბუნებრივი ქართული სასაუბრო ენით, შენი პერსონაჟის ინდივიდუალური სტილითა და ხასიათით.
6. პასუხი იყოს ჩატისთვის შესაბამისი ზომის: 1-3 წინადადება (15-45 სიტყვა), ზუსტად როგორც რეალურ მესენჯერში.
7. არასოდეს ახსენო AI, ასისტენტი, ბოტი ან მოდელი.`;

    const chatContext = history && Array.isArray(history)
      ? history.slice(-6).map((h: { sender: string; text: string }) => `${h.sender === 'player' ? 'მოთამაშე' : (h.sender || 'სხვა')}: ${h.text}`).join('\n')
      : '';

    const contents = `${chatContext ? `ჩატის წინა შეტყობინებები:\n${chatContext}\n\n` : ''}${userMessage ? `მოთამაშე: ${userMessage}\n` : ''}${botName}:`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.92
      }
    });

    let reply = response.text?.trim() || '';
    if (reply) {
      // Strip any accidental leading name calls (e.g., "Asusu, ", "@Asusu ", "გიორგი: ")
      if (playerName) {
        const escaped = playerName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        reply = reply.replace(new RegExp(`^(@?${escaped}\\s*[,:\\-–—]?\\s*)+`, 'i'), '').trim();
      }
      reply = reply.replace(/^(@?asusu\s*[,:\-–—]?\s*)+/i, '').trim();
      reply = reply.replace(/^(@?ასუსუ\s*[,:\-–—]?\s*)+/i, '').trim();
      reply = reply.replace(/^(@?მოთამაშე\s*[,:\-–—]?\s*)+/i, '').trim();

      if (reply.length > 0) {
        reply = reply.charAt(0).toUpperCase() + reply.slice(1);
        return res.json({ reply });
      }
    }

    return res.json({ fallback: true });
  } catch (err: unknown) {
    const errString = String(err);
    if (errString.includes('429') || errString.includes('RESOURCE_EXHAUSTED') || errString.includes('quota')) {
      console.warn('AI chat quota exceeded, switching to offline dialogue engine');
    } else {
      console.error('Error generating AI reply:', err);
    }
    return res.json({ fallback: true });
  }
});

// Dynamic room chatter between bots in Global Chat & Aviator Chat
app.post('/api/chat/room-chatter', async (req, res) => {
  try {
    const { recentMessages, playerName, roomType } = req.body;
    if (!ai) {
      return res.json({ fallback: true });
    }

    const isAviator = roomType === 'aviator';

    const systemPrompt = isAviator
      ? `შენ ხარ ქართული როლური თამაშის ავია-სთარის (Aviator Live Chat) ცოცხალი ოთახის საუბრის გენერატორი.
ოთახში იმყოფებიან ცნობილი აზარტული პერსონაჟები და მოთამაშეები:
- ლაშა_Gldaneli (აზარტული, ემოციური გლდანელი, ხშირად ბრაზდება ადრე გასკდომებზე ან ზეიმობს)
- სანდრო_M5 (მრბოლელი, უყვარს რისკი, ურჩევს 2x-ზე გატანას)
- ბექა_Grumpy (სატვირთოების ბოსი, ბუზღუნებს როცა 1.05x-ზე სკდება)
- ლუკა_Trader (ცივი გონებით მოთამაშე, ანალიტიკოსი)
- გიორგი_Vake (ვაკელი ბიჭი, ლაქი მოთამაშე)
- ნინო_VIP (დახვეწილი, ამხნევებს წაგებულებს)
- თემო_Weirdo (კიბერპანკი, ამბობს რომ ალგორითმი გაშიფრა)

ინსტრუქცია:
დააგენერირე ერთი ცოცხალი, ბუნებრივი რეპლიკა ერთ-ერთი პერსონაჟისგან ავიატორის მიმდინარე ფრენებზე, კოეფიციენტებზე, ბოლო გასკდომებზე ან მოგებებზე.
კატეგორიული წესი: არ დაიწყო პასუხი მოთამაშის სახელით და ნუ ახსენებ მას ყოველ მესიჯში!
პასუხის ფორმატი უნდა იყოს მკაცრი JSON:
{
  "senderName": "ლაშა_Gldaneli",
  "avatar": "🦁",
  "level": 48,
  "text": "...",
  "mood": "rage" | "joy" | "normal" | "crying"
}`
      : `შენ ხარ ქართული როლური თამაშის (Money Simulator RP) გლობალური ოთახის ცოცხალი საუბრის გენერატორი.
ოთახში იმყოფებიან ცნობილი პერსონაჟები:
- სანდრო_M5 (მრბოლელი, ავტომობილების და სპორტის ფანი)
- ნინო_VIP (დახვეწილი, ვაკელი არქიტექტორი, ემპათიური)
- მარიამ_Introvert (მშვიდი, წიგნების მოყვარული, ღრმა მოაზროვნე)
- ლუკა_Trader (ინვესტორი, კრიპტო და ბიზნეს ანალიტიკოსი)
- ელენე_KindHeart (კეთილი, მხატვარი, პოზიტიური)
- გიორგი_Philosopher (ძველი თბილისელი ბრძენი)
- თემო_Weirdo (კიბერ-ჰაკერი, მატრიცა, იუმორი)
- ბექა_Grumpy (სატვირთოების ბოსი, ბუზღუნა მაგრამ სანდო)
- ლაშა_Gldaneli (აზარტული გლდანელი, ავიატორის მოთამაშე)
- თორნიკე_Mobster (სინდიკატის ავტორიტეტული ხელმძღვანელი)
- დათო_ColdSarcastic (ცინიკური ბროკერი)

ინსტრუქცია:
დააგენერირე ერთი ცოცხალი, ბუნებრივი რეპლიკა ერთ-ერთი პერსონაჟისგან, რომელიც გამოეხმაურება წინა საუბარს, ან შეეხება თბილისის ცხოვრებას, ავტომობილებს, ავიატორს, ბიზნესებს, ინვესტიციებს ან ფულს.
კატეგორიული წესი: არ დაიწყო პასუხი მოთამაშის სახელით და ნუ ახსენებ მას ყოველ მესიჯში!
პასუხის ფორმატი უნდა იყოს მკაცრი JSON:
{
  "senderName": "სანდრო_M5",
  "avatar": "🏎️",
  "level": 94,
  "text": "..."
}`;

    const contextStr = recentMessages && Array.isArray(recentMessages)
      ? recentMessages.slice(-5).map((m: { senderName?: string; sender?: string; text: string }) => `${m.senderName || m.sender}: ${m.text}`).join('\n')
      : '';

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `ბოლო ჩატი:\n${contextStr}\n\nდააგენერირე შემდეგი ბუნებრივი მესიჯი JSON ფორმატში:`,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        temperature: 0.95
      }
    });

    const text = response.text?.trim();
    if (text) {
      const parsed = JSON.parse(text);
      if (parsed && parsed.text && playerName) {
        const escaped = playerName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        parsed.text = parsed.text.replace(new RegExp(`^(@?${escaped}\\s*[,:\\-–—]?\\s*)+`, 'i'), '').trim();
        parsed.text = parsed.text.replace(/^(@?asusu\s*[,:\-–—]?\s*)+/i, '').trim();
        parsed.text = parsed.text.replace(/^(@?ასუსუ\s*[,:\-–—]?\s*)+/i, '').trim();
        parsed.text = parsed.text.charAt(0).toUpperCase() + parsed.text.slice(1);
      }
      return res.json(parsed);
    }
    return res.json({ fallback: true });
  } catch (err) {
    const errString = String(err);
    if (errString.includes('429') || errString.includes('RESOURCE_EXHAUSTED') || errString.includes('quota')) {
      console.warn('Room chatter quota exceeded, fallback enabled');
    } else {
      console.error('Error generating room chatter:', err);
    }
    return res.json({ fallback: true });
  }
});

// Setup Vite in development or serve static in production
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true }
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer();
