﻿import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Award, Zap, ArrowRight, DollarSign } from 'lucide-react';
import { formatLari } from '../utils/formatters';

interface LevelUpModalProps {
  level: number;
  bonusCash: number;
  onClaim: () => void;
}

export const LevelUpModal: React.FC<LevelUpModalProps> = ({ level, bonusCash, onClaim }) => {
  useEffect(() => {
    // Fire festive fireworks confetti
    const duration = 2.5 * 1000;
    const animationEnd = Date.now() + duration;

    const interval: NodeJS.Timeout = setInterval(function () {
      const timeLeft = animationEnd - Date.now();
      if (timeLeft <= 0) {
        return clearInterval(interval);
      }
      const particleCount = 40 * (timeLeft / duration);
      confetti({
        particleCount,
        spread: 70,
        origin: { y: 0.6 }
      });
    }, 250);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-gradient-to-b from-[#12131c] to-[#0a0a0f] border border-amber-500/40 rounded-2xl p-6 sm:p-8 text-center shadow-[0_0_50px_rgba(245,158,11,0.25)]">
        {/* Glow halo */}
        <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-24 h-24 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center shadow-[0_0_30px_rgba(245,158,11,0.6)]">
          <Award className="w-12 h-12 text-black stroke-[2.5]" />
        </div>

        <div className="mt-8 space-y-4">
          <div className="inline-block px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono text-xs uppercase tracking-wider">
            ახალი ლეველი განბლოკილია!
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-mono tracking-tight">
            დონე <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-yellow-200">{level}</span>
          </h2>

          <p className="text-slate-300 text-sm leading-relaxed">
            გილოცავ! შენი გავლენა და სტატუსი ქალაქში კიდევ უფრო გაიზარდა. ახალი სამუშაოები და შესაძლებლობები ღიაა შენთვის.
          </p>

          <div className="p-4 rounded-xl bg-slate-900/90 border border-emerald-500/30 flex items-center justify-between">
            <div className="flex items-center gap-2 text-left">
              <div className="w-9 h-9 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <DollarSign className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs text-slate-400 block">საბაზისო საჩუქარი</span>
                <span className="text-xs font-semibold text-slate-200">ლეველის ბონუსი</span>
              </div>
            </div>
            <div className="text-xl font-bold font-mono text-emerald-400">
              +{formatLari(bonusCash)}
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={onClaim}
              className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-sm shadow-[0_0_20px_rgba(16,185,129,0.4)] transition-all flex items-center justify-center gap-2"
            >
              <span>საჩუქრის მიღება & გაგრძელება</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};


