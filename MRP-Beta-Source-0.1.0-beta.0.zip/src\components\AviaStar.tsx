﻿import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  Plane,
  Flame,
  CheckCircle2,
  XCircle,
  Clock,
  TrendingUp,
  ShieldCheck,
  AlertOctagon,
  Users,
  Sparkles
} from 'lucide-react';
import { BotChatMessage, AviatorBotBet } from '../types/game';
import { BOT_NAMES } from '../utils/constants';
import { getSmartAviatorBotReaction, getDynamicAviatorChatter } from '../utils/aiChat';
import {
  playCashSound,
  playCrashSound,
  playClickSound,
  playWinSound
} from '../utils/audio';
import { formatLari } from '../utils/formatters';

interface AviaStarProps {
  balance: number;
  playerLevel: number;
  playerName: string;
  playerAvatar: string;
  playerRank?: 'none' | 'red' | 'purple' | 'midnight_purple' | 'devil_red';
  soundEnabled: boolean;
  onWin: (amount: number, multiplier: number, xpReward: number) => void;
  onLoss: (amount: number) => void;
  onBetPlaced: (amount: number) => void;
}

// Preset Georgian chat messages with authentic street/gaming emotions & "GhorShop" troll
const INITIAL_LIVELY_MESSAGES: BotChatMessage[] = [
  {
    id: 'm1',
    sender: 'სანდრო_M5',
    level: 94,
    avatar: '🏎️',
    text: 'წინა რეისზე 14.8x დავქეშე ბიჭებო, დღეს კაი ხოდია!',
    time: '12:01',
    mood: 'joy',
    premiumRank: 'midnight_purple'
  },
  {
    id: 'm2',
    sender: 'ლაშა_Gldaneli',
    level: 18,
    avatar: '🦁',
    text: '1.02-ზე რო გასკდა წეღან ლამის ტელეფონი კედელზე მიმეხეთქა 🤬',
    time: '12:02',
    mood: 'rage',
    premiumRank: 'red'
  },
  {
    id: 'm3',
    sender: 'ზურა_GhorShop',
    level: 5,
    avatar: '🐷',
    text: '🇬🇪 მოდით ყველანი "ღორშოფში" - ყველაზე იაფად ბანკომატის ბარათები, ნაწილები და კოდები!',
    time: '12:02',
    mood: 'normal',
    premiumRank: 'none'
  },
  {
    id: 'm4',
    sender: 'გიორგი_Vake',
    level: 78,
    avatar: '🕶️',
    text: 'ისევ ეს ღორშოფი გამოჩნდა 😂 გააჯვი შენი ღორშოფით აქედან შე თაღლითო!',
    time: '12:03',
    mood: 'joy',
    premiumRank: 'purple'
  },
  {
    id: 'm5',
    sender: 'ირაკლი_Batumi',
    level: 42,
    avatar: '🌊',
    text: 'ბოლო კაპიკები წამივიდა ხალხო 😭😭 სესხი მაქვს ხვალ გადასახდელი...',
    time: '12:03',
    mood: 'crying',
    premiumRank: 'none'
  }
];

export const AviaStar: React.FC<AviaStarProps> = ({
  balance,
  playerLevel,
  playerName,
  playerAvatar,
  playerRank = 'none',
  soundEnabled,
  onWin,
  onLoss,
  onBetPlaced
}) => {
  // Flight state
  const [gameState, setGameState] = useState<'WAITING' | 'FLYING' | 'CRASHED'>('WAITING');
  const [countdown, setCountdown] = useState<number>(4);
  const [multiplier, setMultiplier] = useState<number>(1.0);
  const [crashPoint, setCrashPoint] = useState<number>(2.0);
  const [history, setHistory] = useState<number[]>([1.45, 3.2, 1.12, 14.8, 2.05, 5.12, 1.04, 8.4]);

  // Robust bet state machine: 'NONE' | 'QUEUED' | 'ACTIVE' | 'CASHED'
  // Prevents ANY double-deduction or race condition when clicking during CRASHED or WAITING!
  const [betStatus, setBetStatus] = useState<'NONE' | 'QUEUED' | 'ACTIVE' | 'CASHED'>('NONE');
  const isPlacingBetRef = useRef<boolean>(false);

  const [betAmount, setBetAmount] = useState<number>(20);
  const [betInput, setBetInput] = useState<string>('20');
  const [cashedMultiplier, setCashedMultiplier] = useState<number>(0);
  const [autoCashout, setAutoCashout] = useState<string>('2.00');
  const [autoCashoutEnabled, setAutoCashoutEnabled] = useState<boolean>(false);

  // Dynamic realistic online player count fluctuating between 520 and 3,450+
  const [onlinePlayers, setOnlinePlayers] = useState<number>(1280);

  useEffect(() => {
    const timer = setInterval(() => {
      setOnlinePlayers((prev) => {
        // Random fluctuation with occasional surges
        const delta = Math.floor(Math.random() * 41) - 18;
        let next = prev + delta;
        if (Math.random() < 0.08) {
          next += (Math.random() < 0.5 ? 250 : -200);
        }
        return Math.min(3480, Math.max(520, next));
      });
    }, 3500);
    return () => clearInterval(timer);
  }, []);

  // Live bots
  const [botBets, setBotBets] = useState<AviatorBotBet[]>([]);

  // Chat state
  const [messages, setMessages] = useState<BotChatMessage[]>(INITIAL_LIVELY_MESSAGES);
  const [chatInput, setChatInput] = useState<string>('');
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Canvas ref for flight curve
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number | null>(null);
  const flightStartTimeRef = useRef<number>(0);

  // Auto-scroll chat
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Periodic dynamic chatter with real emotional variety (swearing, crying, joy, missed bet, and GhorShop)
  useEffect(() => {
    const timer = setInterval(async () => {
      if (gameState === 'FLYING' || gameState === 'WAITING') {
        // Occasional GhorShop troll advertisement
        if (Math.random() < 0.08) {
          const ghorShopAds = [
            '🇬🇪 მოდით ყველანი "ღორშოფში" - ყველაზე იაფად ბანკომატის ბარათები, ნაწილები და კოდები!',
            'ღორშოფში 50% ფასდაკლებაა ბიჭებო, ჩაიწერეთ ნომერი: 599-XX-XX-XX!',
            'ღორშოფი - ნომერ პირველი ხარისხი ქალაქში! იჩქარეთ!',
            'ვისაც მოგება გინდათ, ღორშოფის ტალიზმანი შეიძინეთ 15 ლარად!'
          ];
          const ad = ghorShopAds[Math.floor(Math.random() * ghorShopAds.length)];
          addBotMessage('normal', ad, 'ზურა_GhorShop', '🐷', 5, 'none');

          // Roast reply 2 seconds later
          setTimeout(() => {
            const roasts = [
              'ისევ ეს ღორშოფი გამოჩნდა 😂😂😂',
              'გააჯვი შენი ღორშოფით აქედან შე თაღლითო!',
              'ღორშოფში თვითონ ღორები ვაჭრობენ თუ რატო ქვია მასე? 🤣',
              'ადმინ დაუბლოკე ამას ჩათი რა ღორშოფი აუტყდა ყოველ 2 წუთში!',
              'ღორშოფის დირექტორი გამოჩნდა ისევ, წადი იბანავე ტო!'
            ];
            const roast = roasts[Math.floor(Math.random() * roasts.length)];
            const roasters = [
              { name: 'სანდრო_M5', avatar: '🏎️', level: 94, rank: 'midnight_purple' as const },
              { name: 'გიორგი_Vake', avatar: '🕶️', level: 78, rank: 'purple' as const },
              { name: 'ლაშა_Gldaneli', avatar: '🦁', level: 48, rank: 'red' as const }
            ];
            const pick = roasters[Math.floor(Math.random() * roasters.length)];
            addBotMessage('joy', roast, pick.name, pick.avatar, pick.level, pick.rank);
          }, 2400);
          return;
        }

        const chatter = await getDynamicAviatorChatter(
          messages.slice(-5).map((m) => ({ senderName: m.sender, text: m.text })),
          playerName
        );
        if (chatter && chatter.text) {
          const ranks: Array<'none' | 'red' | 'purple' | 'midnight_purple' | 'devil_red'> = ['none', 'none', 'red', 'purple', 'midnight_purple'];
          const randomRank = ranks[Math.floor(Math.random() * ranks.length)];
          addBotMessage(chatter.mood, chatter.text, chatter.senderName, chatter.avatar, chatter.level, randomRank);
        }
      }
    }, 9000);

    return () => clearInterval(timer);
  }, [messages, playerName, gameState]);

  // Push new bot message helper
  const addBotMessage = (
    mood: 'rage' | 'joy' | 'crying' | 'threat' | 'normal',
    textCustom?: string,
    senderCustom?: string,
    avatarCustom?: string,
    levelCustom?: number,
    rankCustom?: 'none' | 'red' | 'purple' | 'midnight_purple' | 'devil_red'
  ) => {
    const randomBot = BOT_NAMES[Math.floor(Math.random() * BOT_NAMES.length)];
    const text = textCustom || `${multiplier > 1.05 ? multiplier.toFixed(2) + 'x' : 'ამ რეისზე'} გასკდა! შემდეგზე ვნახოთ რას იზამს.`;

    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    // Randomized VIP ranks for bots
    const rankRoll = Math.random();
    const randomRank: 'none' | 'red' | 'purple' | 'midnight_purple' | 'devil_red' = rankRoll < 0.01
      ? 'devil_red'
      : rankRoll < 0.04
      ? 'midnight_purple'
      : rankRoll < 0.12
      ? 'purple'
      : rankRoll < 0.32
      ? 'red'
      : 'none';
    const assignedRank = rankCustom !== undefined ? rankCustom : randomRank;

    setMessages((prev) => [
      ...prev.slice(-40),
      {
        id: Math.random().toString(),
        sender: senderCustom || randomBot.name,
        level: levelCustom || randomBot.level,
        avatar: avatarCustom || randomBot.avatar,
        text,
        time: timeStr,
        mood,
        premiumRank: assignedRank
      }
    ]);
  };

  // Generate randomized bot bets for round
  const generateBotBets = () => {
    const shuffled = [...BOT_NAMES].sort(() => 0.5 - Math.random()).slice(0, 7);
    const bets: AviatorBotBet[] = shuffled.map((bot) => {
      const amounts = [10, 25, 50, 100, 250, 500, 1000];
      const botAmount = amounts[Math.floor(Math.random() * amounts.length)];
      const targetMult = parseFloat((1.2 + Math.random() * 4.5).toFixed(2));
      return {
        id: Math.random().toString(),
        name: bot.name,
        avatar: bot.avatar,
        level: bot.level,
        betAmount: botAmount,
        targetMultiplier: targetMult,
        cashedOut: false
      };
    });
    setBotBets(bets);
  };

  // Main flight game loop
  useEffect(() => {
    let timer: NodeJS.Timeout;

    if (gameState === 'WAITING') {
      if (countdown > 0) {
        timer = setTimeout(() => {
          setCountdown((c) => c - 1);
        }, 1000);
      } else {
        // Start Flight!
        // Calculate random crash point with exciting distribution
        const rand = Math.random();
        let target: number;
        if (rand < 0.10) {
          // Instant crash (rare 10%)
          target = 1.01 + Math.random() * 0.18;
        } else if (rand < 0.65) {
          // Low-medium
          target = 1.30 + Math.random() * 1.70;
        } else if (rand < 0.88) {
          // Medium-high
          target = 3.0 + Math.random() * 4.8;
        } else {
          // Rocket moon
          target = 8.0 + Math.random() * 32.0;
        }

        const calculatedCrash = parseFloat(target.toFixed(2));
        setCrashPoint(calculatedCrash);
        setMultiplier(1.0);
        setGameState('FLYING');
        flightStartTimeRef.current = Date.now();
        generateBotBets();

        // If player had queued a bet, it is now ACTIVE in this flight!
        setBetStatus((prev) => (prev === 'QUEUED' ? 'ACTIVE' : prev));
        isPlacingBetRef.current = false;

        // Occasional chatter when someone missed the bet as plane takes off
        if (Math.random() < 0.35) {
          setTimeout(() => {
            const missedPhrases = [
              'აუუუ ვერ მოვასწარი დადება ტოოო! 🤦‍♂️',
              'ბლიად ჩაითვალა რომ დავდე და არ დაიდო?! ვერ მოვასწარი!',
              'ვაიმეე 500 ლარს ვდებდი და აფრინდა ზუსტად!',
              'წამი დამაკლდა რააა!',
              'უყურე ახლა 10x-ზე ავა და მე გარეთ ვარ დარჩენილი 🤦'
            ];
            const p = missedPhrases[Math.floor(Math.random() * missedPhrases.length)];
            const bot = BOT_NAMES[Math.floor(Math.random() * BOT_NAMES.length)];
            addBotMessage('rage', p, bot.name, bot.avatar, bot.level, 'none');
          }, 1200);
        }
      }
    }

    return () => clearTimeout(timer);
  }, [gameState, countdown]);

  // Flying multiplier progression
  useEffect(() => {
    if (gameState !== 'FLYING') return;

    let current = 1.0;
    const startTime = Date.now();

    const updateFlight = () => {
      const elapsed = (Date.now() - startTime) / 1000;
      current = 1.0 + Math.pow(elapsed * 0.85, 1.45);
      const formatted = parseFloat(current.toFixed(2));

      // Check Bot Cashouts
      setBotBets((prev) =>
        prev.map((b) => {
          if (!b.cashedOut && formatted >= b.targetMultiplier && formatted < crashPoint) {
            return {
              ...b,
              cashedOut: true,
              cashedMultiplier: formatted
            };
          }
          return b;
        })
      );

      // Check Auto-Cashout for player
      if (
        betStatus === 'ACTIVE' &&
        autoCashoutEnabled &&
        formatted >= parseFloat(autoCashout)
      ) {
        handleCashOut(formatted);
      }

      if (formatted >= crashPoint) {
        // Plane CRASHED!
        setMultiplier(crashPoint);
        setGameState('CRASHED');
        playCrashSound(soundEnabled);

        // Player loss if active and didn't cash out
        if (betStatus === 'ACTIVE') {
          onLoss(betAmount);
        }

        // Reset bet status to NONE so player can place bet for upcoming flight!
        setBetStatus('NONE');
        setCashedMultiplier(0);
        isPlacingBetRef.current = false;

        // Add to history
        setHistory((prev) => [crashPoint, ...prev.slice(0, 14)]);

        // Bot emotional reactions (Raging, crying, arguing)
        setTimeout(async () => {
          if (crashPoint < 1.15) {
            const rageLines = [
              `შენი დედაც რაა 1.01-ზე გაფრინდა?! თაღლითები ხართ ტო?! 🤬`,
              `ვის ატყუებთ ბიჭო, რა 1.02-ზე კრაში?! ჩემი დედაც მოვ..ან თუ კიდე აქ შემოვიდე!`,
              `ბოლო 100 ლარი წაიღო 1 წამში! რას შვრებით ხალხო?! 😡`,
              `ბიჭო შენ ვის ელაპარაკები საერთოდ, გააჯვი აქედან!`,
              `მოდი პირში მითხარი საბურთალოზე ვარ!`
            ];
            const text = rageLines[Math.floor(Math.random() * rageLines.length)];
            const bot = BOT_NAMES[Math.floor(Math.random() * BOT_NAMES.length)];
            addBotMessage('rage', text, bot.name, bot.avatar, bot.level, 'red');
          } else if (crashPoint > 8.0) {
            const winLines = [
              `უუჰჰჰჰჰჰჰჰ ${crashPoint}x ამოვიღეეეეეეეე 💥💥💥`,
              `საიდან ჩავუხტიიიი 2,400 ლარი დავქეშეეე!`,
              `მადლობა ღმერთს დღეს რესტორანში მივდივარ! 🔥`,
              `ჯიგრებოოო ${crashPoint}x დავიჭირეეეეეეეეეეეეე 🚀💸`
            ];
            const text = winLines[Math.floor(Math.random() * winLines.length)];
            const bot = BOT_NAMES[Math.floor(Math.random() * BOT_NAMES.length)];
            addBotMessage('joy', text, bot.name, bot.avatar, bot.level, 'midnight_purple');
          }
        }, 500);

        // Schedule next round countdown after 3.2 seconds
        setTimeout(() => {
          setGameState('WAITING');
          setCountdown(4);
        }, 3200);

        return;
      }

      setMultiplier(formatted);
      animationFrameRef.current = requestAnimationFrame(updateFlight);
    };

    animationFrameRef.current = requestAnimationFrame(updateFlight);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [gameState, crashPoint, betStatus, autoCashoutEnabled, autoCashout, betAmount, soundEnabled]);

  // Canvas Flight Trajectory Drawing
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      const width = (canvas.width = canvas.parentElement?.clientWidth || 700);
      const height = (canvas.height = 360);

      // Dark atmospheric background
      const bgGrad = ctx.createLinearGradient(0, 0, 0, height);
      bgGrad.addColorStop(0, '#090a10');
      bgGrad.addColorStop(1, '#0e111a');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, width, height);

      // Subtle grid lines
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
      ctx.lineWidth = 1;
      const stepX = width / 6;
      const stepY = height / 5;
      for (let x = 0; x < width; x += stepX) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += stepY) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      if (gameState === 'FLYING' || gameState === 'CRASHED') {
        const normMult = Math.min(25, multiplier);
        const progress = Math.min(1, Math.max(0, (normMult - 1) / 12));

        const startX = 40;
        const startY = height - 40;
        const currentX = startX + progress * (width - 120);
        const currentY = startY - Math.pow(progress, 0.85) * (height - 100);

        // Draw trajectory trail
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.quadraticCurveTo(
          startX + (currentX - startX) * 0.45,
          startY,
          currentX,
          currentY
        );

        ctx.strokeStyle = gameState === 'CRASHED' ? '#ef4444' : '#10b981';
        ctx.lineWidth = 4;
        ctx.stroke();

        // Area under curve glow
        ctx.lineTo(currentX, startY);
        ctx.lineTo(startX, startY);
        const areaGrad = ctx.createLinearGradient(0, currentY, 0, startY);
        if (gameState === 'CRASHED') {
          areaGrad.addColorStop(0, 'rgba(239, 68, 68, 0.25)');
          areaGrad.addColorStop(1, 'rgba(239, 68, 68, 0)');
        } else {
          areaGrad.addColorStop(0, 'rgba(16, 185, 129, 0.25)');
          areaGrad.addColorStop(1, 'rgba(16, 185, 129, 0)');
        }
        ctx.fillStyle = areaGrad;
        ctx.fill();

        // Rocket Icon
        if (gameState === 'CRASHED') {
          ctx.font = '28px sans-serif';
          ctx.fillText('💥', currentX - 14, currentY + 10);
        } else {
          ctx.save();
          ctx.translate(currentX, currentY);
          const angle = -Math.atan2(startY - currentY, currentX - startX) * 0.7;
          ctx.rotate(angle);
          ctx.font = '26px sans-serif';
          ctx.fillText('🚀', 0, 0);
          ctx.restore();
        }
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [gameState, multiplier]);

  // Handle player cash out
  const handleCashOut = (multOverride?: number) => {
    if (gameState !== 'FLYING' || betStatus !== 'ACTIVE') return;

    const cashMult = multOverride || multiplier;
    setBetStatus('CASHED');
    setCashedMultiplier(cashMult);

    const winAmount = Math.floor(betAmount * cashMult);
    const xpBonus = Math.min(60, Math.floor(cashMult * 2.5 + Math.sqrt(betAmount) * 1.5));

    playWinSound(soundEnabled);
    onWin(winAmount, cashMult, xpBonus);

    // Bot reaction on player win
    setTimeout(() => {
      if (cashMult >= 2.0) {
        addBotMessage('joy', `საღოლ! ${cashMult.toFixed(2)}x-ზე გაიტანა +${formatLari(winAmount)}! 🔥`, 'სანდრო_M5', '🏎️', 94, 'midnight_purple');
      }
    }, 450);
  };

  // Place player bet (Bulletproof against double clicks and double deduction)
  const handlePlaceBet = () => {
    if (isPlacingBetRef.current) return;
    if (betStatus === 'QUEUED' || betStatus === 'ACTIVE') return;
    if (gameState === 'FLYING') return;

    const parsed = Number(betInput);
    const finalAmount = isNaN(parsed) || parsed < 5 ? 5 : Math.min(parsed, Math.floor(balance));
    if (balance < finalAmount) return;

    isPlacingBetRef.current = true;
    setBetAmount(finalAmount);
    setBetInput(finalAmount.toString());

    playClickSound(soundEnabled);
    onBetPlaced(finalAmount);
    setBetStatus('QUEUED');
  };

  // Quick Bet Helpers
  const handleQuickBet = (val: number | 'half' | 'double' | 'max') => {
    playClickSound(soundEnabled);
    let nextVal = betAmount;
    if (val === 'half') {
      nextVal = Math.max(5, Math.floor(betAmount / 2));
    } else if (val === 'double') {
      nextVal = Math.min(Math.floor(balance), Math.max(5, betAmount * 2));
    } else if (val === 'max') {
      nextVal = Math.max(5, Math.floor(balance));
    } else {
      nextVal = val;
    }
    setBetAmount(nextVal);
    setBetInput(nextVal.toString());
  };

  // Send user message into chat
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    playClickSound(soundEnabled);
    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    const newMsg: BotChatMessage = {
      id: Math.random().toString(),
      sender: playerName,
      level: playerLevel,
      avatar: playerAvatar,
      text: chatInput.trim(),
      time: timeStr,
      mood: 'normal',
      premiumRank: playerRank
    };

    const textSent = chatInput.trim();
    setMessages((prev) => [...prev.slice(-40), newMsg]);
    setChatInput('');

    // Dynamic response from smart AI bot reading user's exact message and round context
    setTimeout(async () => {
      const reaction = await getSmartAviatorBotReaction({
        event: 'user_chat',
        userMessage: textSent,
        multiplier,
        playerName,
        playerLevel,
        recentMessages: messages.slice(-5).map((m) => ({ sender: m.sender, text: m.text }))
      });

      addBotMessage(reaction.mood, reaction.text, reaction.botName, reaction.avatar, reaction.level);
    }, 900);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 max-w-[1600px] mx-auto px-3 sm:px-4 py-3">
      {/* LEFT COLUMN (4 cols): Real-Time Live Chat with Georgian Bots */}
      <div className="lg:col-span-4 flex flex-col h-[560px] bg-[#0c0d14] border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        {/* Chat Header */}
        <div className="p-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.8)]" />
            <h3 className="font-bold text-xs sm:text-sm text-slate-100 flex items-center gap-1.5">
              <span>AVIATOR LIVE · ჩატი</span>
            </h3>
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-md font-mono font-bold">
            <Users className="w-3 h-3 text-emerald-400" />
            <span>{onlinePlayers.toLocaleString()} ონლაინ</span>
          </div>
        </div>

        {/* Chat Messages Stream */}
        <div className="flex-1 overflow-y-auto p-2.5 space-y-2 text-xs">
          {messages.map((msg) => {
            const isMe = msg.sender === playerName;
            return (
              <div
                key={msg.id}
                className={`p-2 rounded-xl transition-all ${
                  isMe
                    ? 'bg-emerald-500/10 border border-emerald-500/40'
                    : msg.mood === 'rage'
                    ? 'bg-rose-950/25 border border-rose-900/40'
                    : msg.mood === 'joy'
                    ? 'bg-amber-950/25 border border-amber-900/40'
                    : msg.mood === 'crying'
                    ? 'bg-blue-950/25 border border-blue-900/40'
                    : 'bg-slate-900/60 border border-slate-800/60'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="text-sm shrink-0">{msg.avatar}</span>
                    <span className={`font-bold truncate ${isMe ? 'text-emerald-400' : 'text-slate-200'}`}>
                      {msg.sender}
                    </span>

                    {msg.premiumRank === 'devil_red' && (
                      <span className="shrink-0 rounded bg-gradient-to-r from-rose-600 to-fuchsia-600 px-1.5 py-0.5 text-[9px] font-black text-white shadow-[0_0_10px_rgba(244,35,89,.45)]">😈 REDDEVIL</span>
                    )}
                    {/* VIP PREMIUM RANK BADGES IN CHAT */}
                    {msg.premiumRank === 'midnight_purple' && (
                      <span className="px-1.5 py-0.2 rounded bg-purple-900/60 text-fuchsia-300 border border-fuchsia-500/70 text-[9px] font-black font-mono shrink-0 animate-pulse shadow-[0_0_8px_rgba(217,70,239,0.7)]">
                        🌌 MIDNIGHT VIP
                      </span>
                    )}
                    {msg.premiumRank === 'purple' && (
                      <span className="px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-400 border border-purple-500/50 text-[9px] font-black font-mono shrink-0">
                        🟣 PURPLE VIP
                      </span>
                    )}
                    {msg.premiumRank === 'red' && (
                      <span className="px-1.5 py-0.2 rounded bg-red-500/20 text-red-400 border border-red-500/50 text-[9px] font-black font-mono shrink-0">
                        🔴 RED VIP
                      </span>
                    )}

                    <span className="bg-slate-800 text-amber-400 font-mono text-[9px] px-1 py-0.2 rounded border border-slate-700 shrink-0">
                      lvl {msg.level}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono shrink-0 ml-1">{msg.time}</span>
                </div>
                <p className="text-slate-300 leading-relaxed text-[11px] break-words">
                  {msg.text}
                </p>
              </div>
            );
          })}
          <div ref={chatBottomRef} />
        </div>

        {/* Chat Input Bar */}
        <form onSubmit={handleSendMessage} className="p-2 bg-slate-900/90 border-t border-slate-800 flex gap-2">
          <input
            type="text"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            placeholder="დაწერე ჩატში..."
            maxLength={120}
            className="flex-1 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:outline-none text-xs text-slate-100 placeholder-slate-500"
          />
          <button
            type="submit"
            className="px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-colors shrink-0 cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>

      {/* RIGHT COLUMN (8 cols): Flight Viewport & Controls */}
      <div className="lg:col-span-8 space-y-3">
        {/* Multiplier History Pill Strip */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
          <span className="text-[11px] font-bold text-slate-400 shrink-0 uppercase tracking-wider pr-1">
            ისტორია:
          </span>
          {history.map((mult, idx) => {
            const isHigh = mult >= 10.0;
            const isGood = mult >= 2.0;
            const isLow = mult < 1.5;
            return (
              <span
                key={idx}
                className={`px-2 py-0.5 rounded-lg text-xs font-mono font-bold shrink-0 border ${
                  isHigh
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-[0_0_8px_rgba(245,158,11,0.3)]'
                    : isGood
                    ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                    : isLow
                    ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                    : 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30'
                }`}
              >
                {mult.toFixed(2)}x
              </span>
            );
          })}
        </div>

        {/* Flight Viewport Canvas Container */}
        <div className="relative h-[340px] bg-[#090a10] border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex items-center justify-center">
          <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />

          {/* Central Multiplier Indicator */}
          <div className="relative z-20 text-center select-none">
            {gameState === 'WAITING' && (
              <div className="space-y-1.5 animate-fadeIn">
                <div className="text-slate-400 text-xs uppercase font-mono tracking-widest flex items-center justify-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                  <span>შემდეგი რეისი იწყება</span>
                </div>
                <div className="text-4xl sm:text-5xl font-black font-mono text-amber-400 tracking-tight">
                  00:0{countdown}
                </div>
                <div className="w-36 h-1.5 mx-auto bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-amber-400 transition-all duration-1000 ease-linear"
                    style={{ width: `${(countdown / 4) * 100}%` }}
                  />
                </div>
              </div>
            )}

            {gameState === 'FLYING' && (
              <div className="space-y-1 animate-scaleIn">
                <div className="text-5xl sm:text-6xl font-black font-mono tracking-tight text-white drop-shadow-[0_0_35px_rgba(16,185,129,0.6)]">
                  {multiplier.toFixed(2)}x
                </div>
                <div className="text-emerald-400 text-xs font-mono font-bold tracking-wider animate-pulse flex items-center justify-center gap-1">
                  <Flame className="w-3.5 h-3.5" />
                  <span>რეისი მიმდინარეობს</span>
                </div>
              </div>
            )}

            {gameState === 'CRASHED' && (
              <div className="space-y-1 animate-bounce">
                <div className="text-rose-500 text-xs uppercase font-mono tracking-widest font-black flex items-center justify-center gap-1">
                  <AlertOctagon className="w-4 h-4" />
                  <span>გასკდა!</span>
                </div>
                <div className="text-5xl sm:text-6xl font-black font-mono tracking-tight text-rose-500 drop-shadow-[0_0_35px_rgba(244,63,94,0.7)]">
                  {crashPoint.toFixed(2)}x
                </div>
                <div className="text-slate-400 text-[11px] font-mono">
                  მომდევნო რაუნდი მალე დაიწყება...
                </div>
              </div>
            )}
          </div>

          {/* Bot Bets Chips Floating Layer on Right */}
          <div className="absolute top-2 right-2 z-20 hidden sm:flex flex-col gap-1 max-h-[140px] overflow-hidden pointer-events-none opacity-80">
            {botBets.slice(0, 4).map((b) => (
              <div
                key={b.id}
                className={`px-2 py-0.5 rounded-lg text-[10px] font-mono flex items-center gap-1.5 transition-all border ${
                  b.cashedOut
                    ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300'
                    : 'bg-slate-900/80 border-slate-800 text-slate-300'
                }`}
              >
                <span>{b.avatar}</span>
                <span className="truncate max-w-[70px]">{b.name}</span>
                <span className="font-bold">{b.betAmount}₾</span>
                {b.cashedOut && (
                  <span className="text-emerald-400 font-bold ml-1">
                    ✓ {b.cashedMultiplier}x
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* BET CONTROLS PANEL */}
        <div className="p-4 bg-[#0c0d14] border border-slate-800 rounded-2xl space-y-3 shadow-xl">
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
            {/* Bet Input Box (4 cols) */}
            <div className="sm:col-span-4">
              <label className="text-[10px] uppercase font-mono font-bold text-slate-400 block mb-1">
                ფსონის ოდენობა (₾)
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="5"
                  max={Math.floor(balance)}
                  disabled={betStatus === 'ACTIVE' || betStatus === 'QUEUED'}
                  value={betInput}
                  onChange={(e) => {
                    setBetInput(e.target.value);
                    const val = Number(e.target.value);
                    if (!isNaN(val) && val >= 5) setBetAmount(val);
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 font-mono font-black text-sm text-slate-100 focus:outline-none focus:border-emerald-500 disabled:opacity-50"
                />
                <span className="absolute right-3 top-2 font-mono font-bold text-xs text-emerald-400">
                  ₾
                </span>
              </div>
            </div>

            {/* Quick Multiplier Buttons (4 cols) */}
            <div className="sm:col-span-4 flex items-center gap-1.5 flex-wrap">
              {[10, 25, 50, 100].map((val) => (
                <button
                  key={val}
                  type="button"
                  disabled={betStatus === 'ACTIVE' || betStatus === 'QUEUED'}
                  onClick={() => handleQuickBet(val)}
                  className="px-2 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs font-mono text-slate-300 disabled:opacity-40 transition-colors cursor-pointer"
                >
                  +{val}
                </button>
              ))}
              <button
                type="button"
                disabled={betStatus === 'ACTIVE' || betStatus === 'QUEUED'}
                onClick={() => handleQuickBet('half')}
                className="px-2 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs font-mono text-slate-300 disabled:opacity-40 cursor-pointer"
              >
                1/2
              </button>
              <button
                type="button"
                disabled={betStatus === 'ACTIVE' || betStatus === 'QUEUED'}
                onClick={() => handleQuickBet('double')}
                className="px-2 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs font-mono text-slate-300 disabled:opacity-40 cursor-pointer"
              >
                2X
              </button>
              <button
                type="button"
                disabled={betStatus === 'ACTIVE' || betStatus === 'QUEUED'}
                onClick={() => handleQuickBet('max')}
                className="px-2 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs font-mono text-amber-400 font-bold disabled:opacity-40 cursor-pointer"
              >
                MAX
              </button>
            </div>

            {/* Main Action Button: BET or CASH OUT */}
            <div className="sm:col-span-4">
              {gameState === 'FLYING' && betStatus === 'ACTIVE' ? (
                <button
                  type="button"
                  onClick={() => handleCashOut()}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-extrabold text-sm shadow-[0_0_25px_rgba(245,158,11,0.5)] transition-all transform active:scale-95 flex flex-col items-center justify-center leading-tight cursor-pointer"
                >
                  <span className="uppercase tracking-wider">განაღდება</span>
                  <span className="font-mono text-xs font-black">
                    {formatLari(Math.floor(betAmount * multiplier))}
                  </span>
                </button>
              ) : betStatus === 'CASHED' ? (
                <div className="w-full py-3 px-4 rounded-xl bg-emerald-500/20 border border-emerald-500/50 text-emerald-400 font-extrabold text-xs text-center flex flex-col items-center justify-center">
                  <span>✓ განაღდებულია!</span>
                  <span className="font-mono text-[11px]">
                    +{formatLari(Math.floor(betAmount * cashedMultiplier))}
                  </span>
                </div>
              ) : betStatus === 'QUEUED' ? (
                <button
                  type="button"
                  disabled={true}
                  className="w-full py-3 px-4 rounded-xl font-extrabold text-xs sm:text-sm bg-slate-800 text-emerald-400 border border-emerald-500/40 cursor-not-allowed flex flex-col items-center justify-center leading-tight shadow-none"
                >
                  <span className="uppercase tracking-wider">✓ ფსონი მიღებულია</span>
                  <span className="font-mono text-[11px] text-slate-300">
                    {formatLari(betAmount)} • ველით აფრენას
                  </span>
                </button>
              ) : (
                <button
                  type="button"
                  disabled={balance < betAmount || gameState === 'FLYING'}
                  onClick={handlePlaceBet}
                  className="w-full py-3 px-4 rounded-xl font-extrabold text-xs sm:text-sm bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-[0_0_20px_rgba(16,185,129,0.4)] active:scale-95 flex flex-col items-center justify-center leading-tight transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <span className="uppercase tracking-wider">ფსონის დადება</span>
                  <span className="font-mono text-xs">
                    {formatLari(betAmount)}
                  </span>
                </button>
              )}
            </div>
          </div>

          {/* Auto Cashout Row */}
          <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="autoCashoutToggle"
                checked={autoCashoutEnabled}
                onChange={(e) => setAutoCashoutEnabled(e.target.checked)}
                className="w-4 h-4 rounded border-slate-700 text-emerald-500 focus:ring-emerald-500 cursor-pointer"
              />
              <label htmlFor="autoCashoutToggle" className="text-slate-300 font-medium cursor-pointer">
                ავტო-განაღდება:
              </label>
              <input
                type="number"
                step="0.1"
                min="1.1"
                max="100"
                value={autoCashout}
                disabled={!autoCashoutEnabled}
                onChange={(e) => setAutoCashout(e.target.value)}
                className="w-20 px-2 py-0.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono font-bold text-emerald-400 disabled:opacity-40 focus:outline-none focus:border-emerald-500"
              />
              <span className="text-slate-500 font-mono">x</span>
            </div>

            <div className="text-[11px] font-mono text-slate-400">
              ბალანსი: <strong className="text-emerald-400">{formatLari(balance)}</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};


