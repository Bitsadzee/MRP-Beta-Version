﻿export function formatLari(amount: number, forceDecimals: boolean = false): string {
  if (isNaN(amount) || amount === null || amount === undefined) return '0 ₾';
  if (forceDecimals || (amount > 0 && amount < 10 && !Number.isInteger(amount))) {
    return amount.toFixed(2) + ' ₾';
  }
  return Math.floor(amount).toLocaleString('en-US') + ' ₾';
}

export function formatCompact(amount: number): string {
  if (amount >= 1_000_000_000) {
    return (amount / 1_000_000_000).toFixed(1) + 'B ₾';
  }
  if (amount >= 1_000_000) {
    return (amount / 1_000_000).toFixed(1) + 'M ₾';
  }
  if (amount >= 10_000) {
    return (amount / 1_000).toFixed(1) + 'K ₾';
  }
  return formatLari(amount);
}


