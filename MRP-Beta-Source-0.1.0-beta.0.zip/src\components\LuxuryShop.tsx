﻿import React, { useState } from 'react';
import {
  Car as CarIcon,
  Home,
  Building2,
  Warehouse,
  ShieldCheck,
  Check,
  Sparkles,
  Zap,
  Gauge,
  Trophy,
  AlertCircle,
  Wrench
} from 'lucide-react';
import { Car, Garage, Estate, Business, Security, Accessory, TuningPart, CarTuningData } from '../types/game';
import { CarTuningStudio } from './CarTuningStudio';
import { playCashSound, playClickSound } from '../utils/audio';
import { formatLari } from '../utils/formatters';

interface LuxuryShopProps {
  balance: number;
  soundEnabled: boolean;
  garageCapacity: number;
  ownedCars: string[];
  ownedGarages: string[];
  ownedEstates: string[];
  ownedSecurity: string[];
  ownedAccessories?: string[];
  cars: Car[];
  garages: Garage[];
  estates: Estate[];
  securityList: Security[];
  accessories?: Accessory[];
  hasCustomWorkshop?: boolean;
  workshopInventory?: { [partId: string]: number };
  carTunings?: { [carId: string]: CarTuningData };
  onBuyCar: (car: Car) => void;
  onBuyGarage: (garage: Garage) => void;
  onBuyEstate: (estate: Estate) => void;
  onBuySecurity: (security: Security) => void;
  onBuyAccessory?: (accessory: Accessory) => void;
  onTuneCar?: (carId: string, part: TuningPart, isFreeFromWorkshop: boolean) => void;
  onBuyWorkshopPart?: (part: TuningPart) => void;
  onBuyCustomWorkshop?: () => void;
}

export const LuxuryShop: React.FC<LuxuryShopProps> = ({
  balance,
  soundEnabled,
  garageCapacity,
  ownedCars,
  ownedGarages,
  ownedEstates,
  ownedSecurity,
  ownedAccessories = [],
  cars,
  garages,
  estates,
  securityList,
  accessories = [],
  hasCustomWorkshop = false,
  workshopInventory = {},
  carTunings = {},
  onBuyCar,
  onBuyGarage,
  onBuyEstate,
  onBuySecurity,
  onBuyAccessory,
  onTuneCar,
  onBuyWorkshopPart,
  onBuyCustomWorkshop
}) => {
  const [shopCategory, setShopCategory] = useState<'cars' | 'tuning' | 'garages' | 'estates' | 'security' | 'accessories'>('cars');
  const [selectedCarBrand, setSelectedCarBrand] = useState<string>('all');
  const [carSearch, setCarSearch] = useState('');
  const [selectedAccCategory, setSelectedAccCategory] = useState<string>('all');

  const shopTabs = [
    { id: 'cars', label: 'ავტომობილები', icon: <CarIcon className="w-4 h-4" /> },
    { id: 'tuning', label: '🚗 ავტო ტიუნინგი & სახელოსნო', icon: <Wrench className="w-4 h-4" /> },
    { id: 'garages', label: 'გარაჟები (4 ბოქსი)', icon: <Warehouse className="w-4 h-4" /> },
    { id: 'accessories', label: 'აქსესუარები & VIP', icon: <Sparkles className="w-4 h-4" /> },
    { id: 'estates', label: 'აგარაკები & სახლები', icon: <Home className="w-4 h-4" /> },
    { id: 'security', label: 'დაცვა & სტატუსი', icon: <ShieldCheck className="w-4 h-4" /> }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-5 space-y-5">
      {/* Category Tabs */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 bg-[#0c0d14] border border-slate-800 rounded-2xl">
        {shopTabs.map((tab) => {
          const isActive = shopCategory === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                playClickSound(soundEnabled);
                setShopCategory(tab.id as typeof shopCategory);
              }}
              className={`flex-1 min-w-[150px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                isActive
                  ? 'bg-emerald-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. CARS SECTION */}
      {shopCategory === 'cars' && (
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <span>ქალაქის ყველაზე სწრაფი და ელიტური ავტოპარკი</span>
              </h2>
              <span className="text-xs text-slate-400">
                ავტომობილები ზრდიან შენს RP პატივისცემას და შემოსავლის კოეფიციენტს
              </span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono">
              <span className="text-slate-400">გარაჟის ტევადობა:</span>
              <span
                className={`font-bold ${
                  ownedCars.length >= garageCapacity ? 'text-rose-400' : 'text-emerald-400'
                }`}
              >
                {ownedCars.length} / {garageCapacity} ადგილი
              </span>
            </div>
          </div>

          <label className="relative block max-w-xl">
            <span className="sr-only">მანქანის ძებნა</span>
            <input value={carSearch} onChange={(event) => setCarSearch(event.target.value)} placeholder="მოძებნე მარკით ან მოდელით…" className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white outline-none placeholder:text-slate-500 focus:border-emerald-400" />
          </label>

          {/* Brand Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
            {[
              { id: 'all', label: 'ყველა მანქანა' },
              { id: 'bmw', label: 'BMW M-Power' },
              { id: 'mercedes', label: 'Mercedes-Benz & AMG' },
              { id: 'audi', label: 'Audi S/RS Quattro' },
              { id: 'lamborghini', label: 'Lamborghini' },
              { id: 'nissan', label: 'Nissan & GT-R' },
              { id: 'honda', label: 'Honda Type R' },
              { id: 'hyundai', label: 'Hyundai & N-Line' },
              { id: 'pajero', label: 'Pajero 4x4' },
              { id: 'peugeot', label: 'Peugeot Sport' },
              { id: 'ferrari', label: 'Ferrari' },
              { id: 'mustang', label: 'Ford Mustang' },
              { id: 'dodge', label: 'Dodge SRT' },
              { id: 'chevrolet', label: 'Chevrolet' },
              { id: 'toyota', label: 'Toyota' },
              { id: 'supercars', label: 'სუპერქარები' }
            ].map((b) => (
              <button
                key={b.id}
                type="button"
                onClick={() => {
                  playClickSound(soundEnabled);
                  setSelectedCarBrand(b.id);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors border ${
                  selectedCarBrand === b.id
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-sm'
                    : 'bg-slate-900/70 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                {b.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {cars
              .filter((car) => {
                const query = carSearch.trim().toLocaleLowerCase();
                if (query && !`${car.brand} ${car.name}`.toLocaleLowerCase().includes(query)) return false;
                if (selectedCarBrand === 'all') return true;
                const bLower = (car.brand + ' ' + car.name).toLowerCase();
                if (selectedCarBrand === 'bmw') return bLower.includes('bmw');
                if (selectedCarBrand === 'mercedes') return bLower.includes('mercedes');
                if (selectedCarBrand === 'audi') return bLower.includes('audi');
                if (selectedCarBrand === 'lamborghini') return bLower.includes('lamborghini') || bLower.includes('lambo');
                if (selectedCarBrand === 'nissan') return bLower.includes('nissan') || bLower.includes('silvia') || bLower.includes('skyline');
                if (selectedCarBrand === 'honda') return bLower.includes('honda');
                if (selectedCarBrand === 'hyundai') return bLower.includes('hyundai');
                if (selectedCarBrand === 'pajero') return bLower.includes('pajero') || bLower.includes('mitsubishi');
                if (selectedCarBrand === 'peugeot') return bLower.includes('peugeot');
                if (selectedCarBrand === 'chevrolet') return bLower.includes('chevrolet');
                if (selectedCarBrand === 'mustang') return bLower.includes('mustang');
                if (selectedCarBrand === 'dodge') return bLower.includes('dodge');
                if (selectedCarBrand === 'ferrari') return bLower.includes('ferrari');
                if (selectedCarBrand === 'toyota') return bLower.includes('toyota');
                if (selectedCarBrand === 'supercars') {
                  return ['porsche', 'lamborghini', 'bugatti', 'rolls-royce', 'ferrari'].some((s) =>
                    bLower.includes(s)
                  );
                }
                return true;
              })
              .map((car) => {
              const isOwned = ownedCars.includes(car.id);
              const canAfford = balance >= car.price;
              const hasGarageSpace = ownedCars.length < garageCapacity;

              return (
                <div
                  key={car.id}
                  className={`p-4 rounded-2xl border flex flex-col justify-between transition-all ${
                    isOwned
                      ? 'bg-emerald-950/15 border-emerald-500/40 shadow-[0_0_20px_rgba(16,185,129,0.15)]'
                      : 'bg-[#0c0d14] border-slate-800 hover:border-slate-700 shadow-xl'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="w-12 h-12 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-3xl shadow-inner">
                        <span>{car.image}</span>
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        <span className="text-[11px] font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded-md border border-cyan-500/20">
                          {car.brand}
                        </span>
                        <span className="text-[10px] text-amber-400 font-mono flex items-center gap-1">
                          <Trophy className="w-3 h-3" />+{car.respect} RP
                        </span>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-bold text-sm text-slate-100">{car.name}</h3>
                      <div className="flex items-center gap-3 text-xs text-slate-400 mt-2 font-mono">
                        <span className="flex items-center gap-1">
                          <Gauge className="w-3.5 h-3.5 text-blue-400" />
                          {car.speed}
                        </span>
                        <span className="flex items-center gap-1">
                          <Zap className="w-3.5 h-3.5 text-emerald-400" />
                          +{((car.bonusMultiplier - 1) * 100).toFixed(0)}% ბონუსი
                        </span>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                      <span className="text-slate-500">ღირებულება:</span>
                      <span className="font-bold text-slate-100">{formatLari(car.price)}</span>
                    </div>
                  </div>

                  <div className="mt-4 pt-2">
                    {isOwned ? (
                      <div className="w-full py-2.5 px-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center justify-center gap-1.5">
                        <Check className="w-4 h-4 stroke-[3]" />
                        <span>შენს გარაჟშია</span>
                      </div>
                    ) : (
                      <button
                        type="button"
                        disabled={!canAfford || !hasGarageSpace}
                        onClick={() => {
                          playCashSound(soundEnabled);
                          onBuyCar(car);
                        }}
                        className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 ${
                          !hasGarageSpace
                            ? 'bg-slate-900 text-rose-400 border border-rose-500/30 cursor-not-allowed'
                            : canAfford
                            ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md active:scale-95'
                            : 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
                        }`}
                      >
                        {!hasGarageSpace ? (
                          <>
                            <AlertCircle className="w-3.5 h-3.5" />
                            <span>გარაჟი სავსეა! იყიდე ადგილი</span>
                          </>
                        ) : canAfford ? (
                          <>
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>შეძენა ({formatLari(car.price)})</span>
                          </>
                        ) : (
                          <span>არასაკმარისი თანხა</span>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. CAR TUNING STUDIO & WORKSHOP SECTION */}
      {shopCategory === 'tuning' && (
        <CarTuningStudio
          balance={balance}
          soundEnabled={soundEnabled}
          ownedCars={ownedCars}
          cars={cars}
          carTunings={carTunings}
          hasCustomWorkshop={hasCustomWorkshop}
          workshopInventory={workshopInventory}
          onTuneCar={onTuneCar || (() => {})}
          onBuyWorkshopPart={onBuyWorkshopPart || (() => {})}
          onBuyCustomWorkshop={onBuyCustomWorkshop || (() => {})}
        />
      )}

      {/* 3. GARAGES SECTION */}
      {shopCategory === 'garages' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <span>ავტოფარეხები & საპარკინგე კომპლექსები</span>
              </h2>
              <span className="text-xs text-slate-400">
                გაზარდე შენი გარაჟის ტევადობა მეტი სუპერქარის დასაპარკინგებლად
              </span>
            </div>
            <span className="text-xs font-mono text-emerald-400 font-bold">
              მიმდინარე ტევადობა: {garageCapacity} ადგილი
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {garages.map((garage) => {
              const isOwned = ownedGarages.includes(garage.id);
              const canAfford = balance >= garage.price;

              return (
                <div
                  key={garage.id}
                  className={`p-4 rounded-2xl border flex flex-col justify-between ${
                    isOwned
                      ? 'bg-emerald-950/15 border-emerald-500/40'
                      : 'bg-[#0c0d14] border-slate-800 hover:border-slate-700 shadow-xl'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
                        {garage.location}
                      </span>
                      <span className="text-xs font-mono font-bold text-cyan-400">
                        +{garage.capacity} საპარკინგე ადგილი
                      </span>
                    </div>

                    <div>
                      <h3 className="font-bold text-sm text-slate-100">{garage.name}</h3>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        {garage.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                      <span className="text-slate-500">ფასი:</span>
                      <span className="font-bold text-slate-100">{formatLari(garage.price)}</span>
                    </div>
                  </div>

                  <div className="mt-4 pt-2">
                    {isOwned ? (
                      <div className="w-full py-2.5 px-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center justify-center gap-1.5">
                        <Check className="w-4 h-4 stroke-[3]" />
                        <span>შენს მფლობელობაშია</span>
                      </div>
                    ) : (
                      <button
                        type="button"
                        disabled={!canAfford}
                        onClick={() => {
                          playCashSound(soundEnabled);
                          onBuyGarage(garage);
                        }}
                        className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 ${
                          canAfford
                            ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md active:scale-95'
                            : 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
                        }`}
                      >
                        <Warehouse className="w-3.5 h-3.5" />
                        <span>{canAfford ? `შეძენა (${formatLari(garage.price)})` : 'არასაკმარისი თანხა'}</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 3. ESTATES SECTION */}
      {shopCategory === 'estates' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>ლუქს უძრავი ქონება & აგარაკები</span>
            </h2>
            <span className="text-xs text-slate-400">
              აპარტამენტები და რეზიდენციები გენერირებენ პასიურ იჯარას და პრესტიჟს
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {estates.map((est) => {
              const isOwned = ownedEstates.includes(est.id);
              const canAfford = balance >= est.price;

              return (
                <div
                  key={est.id}
                  className={`p-4 rounded-2xl border flex flex-col justify-between ${
                    isOwned
                      ? 'bg-emerald-950/15 border-emerald-500/40'
                      : 'bg-[#0c0d14] border-slate-800 hover:border-slate-700 shadow-xl'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                        {est.location}
                      </span>
                      <span className="text-xs font-mono text-amber-400 flex items-center gap-1">
                        <Trophy className="w-3 h-3" />+{est.respect} RP
                      </span>
                    </div>

                    <div>
                      <h3 className="font-bold text-sm text-slate-100">{est.name}</h3>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        {est.description}
                      </p>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800/80 flex items-center justify-between font-mono text-xs">
                      <div>
                        <span className="text-[10px] text-slate-500 block">პასიური იჯარა</span>
                        <span className="font-bold text-emerald-400">
                          +{formatLari(est.passiveRentPerSec)}/წთ
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-500 block">ფასი</span>
                        <span className="font-bold text-slate-100">{formatLari(est.price)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-2">
                    {isOwned ? (
                      <div className="w-full py-2.5 px-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center justify-center gap-1.5">
                        <Check className="w-4 h-4 stroke-[3]" />
                        <span>შენს საკუთრებაშია</span>
                      </div>
                    ) : (
                      <button
                        type="button"
                        disabled={!canAfford}
                        onClick={() => {
                          playCashSound(soundEnabled);
                          onBuyEstate(est);
                        }}
                        className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 ${
                          canAfford
                            ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md active:scale-95'
                            : 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
                        }`}
                      >
                        <Home className="w-3.5 h-3.5" />
                        <span>{canAfford ? `შეძენა (${formatLari(est.price)})` : 'არასაკმარისი თანხა'}</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. SECURITY SECTION */}
      {shopCategory === 'security' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>პირადი დაცვა, ესკორტი & კიბერ-ფარი</span>
            </h2>
            <span className="text-xs text-slate-400">
              გააძლიერე შენი უსაფრთხოება და მოიპოვე ქუჩის უმაღლესი ავტორიტეტი
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {securityList.map((sec) => {
              const isOwned = ownedSecurity.includes(sec.id);
              const canAfford = balance >= sec.price;

              return (
                <div
                  key={sec.id}
                  className={`p-4 rounded-2xl border flex flex-col justify-between ${
                    isOwned
                      ? 'bg-emerald-950/15 border-emerald-500/40'
                      : 'bg-[#0c0d14] border-slate-800 hover:border-slate-700 shadow-xl'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded-md border border-cyan-500/20">
                        {sec.protectionBonus}
                      </span>
                      <span className="text-xs font-mono text-amber-400 flex items-center gap-1 font-bold">
                        <Trophy className="w-3 h-3" />+{sec.respect} RP
                      </span>
                    </div>

                    <div>
                      <h3 className="font-bold text-sm text-slate-100">{sec.name}</h3>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        {sec.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                      <span className="text-slate-500">კონტრაქტის ფასი:</span>
                      <span className="font-bold text-slate-100">{formatLari(sec.price)}</span>
                    </div>
                  </div>

                  <div className="mt-4 pt-2">
                    {isOwned ? (
                      <div className="w-full py-2.5 px-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center justify-center gap-1.5">
                        <Check className="w-4 h-4 stroke-[3]" />
                        <span>დაცვა აქტიურია</span>
                      </div>
                    ) : (
                      <button
                        type="button"
                        disabled={!canAfford}
                        onClick={() => {
                          playCashSound(soundEnabled);
                          onBuySecurity(sec);
                        }}
                        className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 ${
                          canAfford
                            ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md active:scale-95'
                            : 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
                        }`}
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>{canAfford ? `დაქირავება (${formatLari(sec.price)})` : 'არასაკმარისი თანხა'}</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 6. ACCESSORIES & VIP LUXURY ITEMS SECTION */}
      {shopCategory === 'accessories' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400" />
                <span>ლუქს აქსესუარები, საათები & VIP რეგალია</span>
              </h2>
              <span className="text-xs text-slate-400">
                აქსესუარები მატებენ RP რეპუტაციას და ზრდიან ყველა შემოსავლის კოეფიციენტს
              </span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono">
              <span className="text-slate-400">შეძენილია:</span>
              <span className="font-bold text-emerald-400">
                {ownedAccessories.length} / {accessories.length} ნივთი
              </span>
            </div>
          </div>

          {/* Category Filter Pills for Accessories */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
            {[
              { id: 'all', label: 'ყველა აქსესუარი' },
              { id: 'watch', label: '⌚ საათები (Rolex, Patek, AP)' },
              { id: 'jewelry', label: '💎 სამკაულები & ოქრო' },
              { id: 'clothing', label: '🤵 VIP ტანსაცმელი' },
              { id: 'gadget', label: '📱 გაჯეტები & ბარათები' },
              { id: 'vip', label: '👑 VIP რეგალია' }
            ].map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => {
                  playClickSound(soundEnabled);
                  setSelectedAccCategory(c.id);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors border ${
                  selectedAccCategory === c.id
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm'
                    : 'bg-slate-900/70 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {accessories
              .filter((acc) => {
                if (selectedAccCategory === 'all') return true;
                return acc.category === selectedAccCategory;
              })
              .map((acc) => {
                const isOwned = ownedAccessories.includes(acc.id);
                const canAfford = balance >= acc.price;

                return (
                  <div
                    key={acc.id}
                    className={`p-4 rounded-2xl border transition-all flex flex-col justify-between ${
                      isOwned
                        ? 'bg-amber-950/15 border-amber-500/40 shadow-[0_0_15px_rgba(245,158,11,0.1)]'
                        : 'bg-[#0f1017] border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="w-12 h-12 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-2xl shadow-inner">
                          {acc.image}
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded-md border border-cyan-500/20">
                            +{Math.round((acc.bonusMultiplier - 1) * 100)}% ბონუსი
                          </span>
                          <span className="text-xs font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20 font-bold flex items-center gap-0.5">
                            <Trophy className="w-3 h-3" />+{acc.respect} RP
                          </span>
                        </div>
                      </div>

                      <div>
                        <h3 className="font-bold text-sm text-slate-100">{acc.name}</h3>
                        <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                          {acc.description}
                        </p>
                      </div>

                      <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                        <span className="text-slate-500">ღირებულება:</span>
                        <span className="font-bold text-slate-100">{formatLari(acc.price)}</span>
                      </div>
                    </div>

                    <div className="mt-4 pt-2">
                      {isOwned ? (
                        <div className="w-full py-2.5 px-3 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold text-xs flex items-center justify-center gap-1.5">
                          <Check className="w-4 h-4 stroke-[3]" />
                          <span>მფლობელობაშია</span>
                        </div>
                      ) : (
                        <button
                          type="button"
                          disabled={!canAfford}
                          onClick={() => {
                            if (onBuyAccessory) {
                              playCashSound(soundEnabled);
                              onBuyAccessory(acc);
                            }
                          }}
                          className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 ${
                            canAfford
                              ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md active:scale-95'
                              : 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
                          }`}
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>{canAfford ? `შეძენა (${formatLari(acc.price)})` : 'არასაკმარისი თანხა'}</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}
    </div>
  );
};





