﻿import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Trophy,
  Flame,
  Clock,
  Sparkles,
  TrendingUp,
  CheckCircle2,
  XCircle,
  Play,
  RotateCcw,
  Check,
  AlertCircle,
  Filter,
  Search,
  ArrowUpDown,
  Shuffle
} from 'lucide-react';
import { playCashSound, playWinSound, playClickSound } from '../utils/audio';
import { formatLari } from '../utils/formatters';

export interface Team {
  name: string;
  logo: string;
  strength: number; // 70 to 95
}

export interface Match {
  id: string;
  league: 'laliga' | 'epl' | 'georgia' | 'ucl' | 'national' | 'seriea' | 'bundesliga';
  leagueName: string;
  homeTeam: string;
  homeLogo: string;
  awayTeam: string;
  awayLogo: string;
  homeOdds: number;
  drawOdds: number;
  awayOdds: number;
  maxOdds: number; // For easy sorting by highest odds
  homeGoals: number;
  awayGoals: number;
  minute: number;
  status: 'SCHEDULED' | 'LIVE' | 'FINISHED';
  events: string[];
}

export interface BetSlipItem {
  id: string;
  matchId: string;
  matchTitle: string;
  pick: '1' | 'X' | '2';
  pickLabel: string;
  odds: number;
  betAmount: number;
  potentialWin: number;
  status: 'PENDING' | 'WON' | 'LOST';
  finalScore?: string;
  placedAt: number;
}

interface SportsBettingProps {
  balance: number;
  soundEnabled: boolean;
  onBetPlaced: (amount: number) => void;
  onWin: (amount: number, xpReward: number) => void;
  onLoss: (amount: number) => void;
}

// Extensive Team Pool by League (Vastly expanded for diverse random matchups)
const TEAMS_LALIGA: Team[] = [
  { name: 'Real Madrid', logo: '⚪', strength: 93 },
  { name: 'Barcelona', logo: '🔵🔴', strength: 91 },
  { name: 'Atletico Madrid', logo: '🔴⚪', strength: 87 },
  { name: 'Athletic Bilbao', logo: '🦁', strength: 83 },
  { name: 'Real Sociedad', logo: '🔵⚪', strength: 82 },
  { name: 'Girona', logo: '🔴⚪', strength: 82 },
  { name: 'Villarreal', logo: '🟡', strength: 81 },
  { name: 'Real Betis', logo: '🟢⚪', strength: 80 },
  { name: 'Sevilla', logo: '⚪🔴', strength: 79 },
  { name: 'Valencia', logo: '🦇', strength: 78 },
  { name: 'Celta Vigo', logo: '🩵', strength: 77 },
  { name: 'Mallorca', logo: '🔴', strength: 76 },
  { name: 'Osasuna', logo: '🔴🔵', strength: 76 },
  { name: 'Rayo Vallecano', logo: '⚡', strength: 75 },
  { name: 'Getafe', logo: '🔵', strength: 75 },
  { name: 'Espanyol', logo: '⚪🔵', strength: 74 },
  { name: 'Las Palmas', logo: '🟡🔵', strength: 74 },
  { name: 'Deportivo Alaves', logo: '⚪🔵', strength: 73 }
];

const TEAMS_EPL: Team[] = [
  { name: 'Manchester City', logo: '🩵', strength: 94 },
  { name: 'Arsenal', logo: '🔴⚪', strength: 90 },
  { name: 'Liverpool', logo: '🔴', strength: 91 },
  { name: 'Chelsea', logo: '🔵', strength: 85 },
  { name: 'Aston Villa', logo: '🟣', strength: 84 },
  { name: 'Tottenham', logo: '⚪', strength: 83 },
  { name: 'Manchester United', logo: '🔴👹', strength: 82 },
  { name: 'Newcastle', logo: '⬛⬜', strength: 82 },
  { name: 'Brighton', logo: '🌊', strength: 80 },
  { name: 'West Ham', logo: '⚒️', strength: 79 },
  { name: 'Fulham', logo: '⚪', strength: 78 },
  { name: 'Wolves', logo: '🐺', strength: 77 },
  { name: 'Brentford', logo: '🐝', strength: 77 },
  { name: 'Crystal Palace', logo: '🦅', strength: 76 },
  { name: 'Everton', logo: '🔵', strength: 75 },
  { name: 'Bournemouth', logo: '🍒', strength: 75 }
];

const TEAMS_GEORGIA: Team[] = [
  { name: 'დინამო თბილისი', logo: '🔵', strength: 84 },
  { name: 'ტორპედო ქუთაისი', logo: '🟢', strength: 83 },
  { name: 'დინამო ბათუმი', logo: '🌊', strength: 82 },
  { name: 'დილა გორი', logo: '🔴', strength: 81 },
  { name: 'იბერია 1999 (საბურთალო)', logo: '🦅', strength: 80 },
  { name: 'სამგურალი წყალტუბო', logo: '⚪', strength: 76 },
  { name: 'გაგრა', logo: '🔵', strength: 75 },
  { name: 'კოლხეთი 1913', logo: '🟡', strength: 75 },
  { name: 'თელავი', logo: '🍇', strength: 74 },
  { name: 'სიონი ბოლნისი', logo: '🟡🟢', strength: 73 },
  { name: 'სპაერი', logo: '🛡️', strength: 72 },
  { name: 'გარეჯი საგარეჯო', logo: '⛰️', strength: 71 }
];

const TEAMS_UCL: Team[] = [
  { name: 'Real Madrid', logo: '👑', strength: 94 },
  { name: 'Bayern Munich', logo: '🔴', strength: 92 },
  { name: 'Paris Saint-Germain', logo: '🔵', strength: 91 },
  { name: 'Manchester City', logo: '🩵', strength: 94 },
  { name: 'Inter Milan', logo: '🔵⚫', strength: 89 },
  { name: 'Barcelona', logo: '🔵🔴', strength: 91 },
  { name: 'Arsenal', logo: '🔴⚪', strength: 90 },
  { name: 'Borussia Dortmund', logo: '🟡⚫', strength: 87 },
  { name: 'Juventus', logo: '⚪⚫', strength: 86 },
  { name: 'Bayer Leverkusen', logo: '🔴⚫', strength: 88 },
  { name: 'Atletico Madrid', logo: '🔴⚪', strength: 87 },
  { name: 'AC Milan', logo: '🔴⚫', strength: 85 },
  { name: 'Sporting CP', logo: '🟢⚪', strength: 84 },
  { name: 'Atalanta', logo: '🔵⚫', strength: 84 },
  { name: 'Aston Villa', logo: '🟣', strength: 84 },
  { name: 'Monaco', logo: '🔴⚪', strength: 82 }
];

const TEAMS_NATIONAL: Team[] = [
  { name: 'საქართველო 🇬🇪', logo: '🇬🇪', strength: 84 },
  { name: 'ესპანეთი 🇪🇸', logo: '🇪🇸', strength: 93 },
  { name: 'არგენტინა 🇦🇷', logo: '🇦🇷', strength: 92 },
  { name: 'საფრანგეთი 🇫🇷', logo: '🇫🇷', strength: 92 },
  { name: 'პორტუგალია 🇵🇹', logo: '🇵🇹', strength: 90 },
  { name: 'გერმანია 🇩🇪', logo: '🇩🇪', strength: 89 },
  { name: 'ინგლისი 🏴󠁧󠁢󠁥󠁮󠁧󠁿', logo: '🏴󠁧󠁢󠁥󠁮󠁧󠁿', strength: 91 },
  { name: 'იტალია 🇮🇹', logo: '🇮🇹', strength: 87 },
  { name: 'ბრაზილია 🇧🇷', logo: '🇧🇷', strength: 90 },
  { name: 'ნიდერლანდები 🇳🇱', logo: '🇳🇱', strength: 88 },
  { name: 'ხორვატია 🇭🇷', logo: '🇭🇷', strength: 85 },
  { name: 'ურუგვაი 🇺🇾', logo: '🇺🇾', strength: 86 },
  { name: 'ბელგია 🇧🇪', logo: '🇧🇪', strength: 85 },
  { name: 'შვეიცარია 🇨🇭', logo: '🇨🇭', strength: 83 }
];

const TEAMS_SERIEA: Team[] = [
  { name: 'Inter Milan', logo: '🔵⚫', strength: 90 }, { name: 'AC Milan', logo: '🔴⚫', strength: 88 },
  { name: 'Juventus', logo: '⚪⚫', strength: 88 }, { name: 'Napoli', logo: '🔵', strength: 87 },
  { name: 'Atalanta', logo: '🔵⚫', strength: 86 }, { name: 'Roma', logo: '🟡🔴', strength: 84 },
  { name: 'Lazio', logo: '🩵', strength: 83 }, { name: 'Fiorentina', logo: '🟣', strength: 82 },
  { name: 'Bologna', logo: '🔴🔵', strength: 81 }, { name: 'Torino', logo: '🍷', strength: 78 },
  { name: 'Genoa', logo: '🔴🔵', strength: 76 }, { name: 'Udinese', logo: '⚫⚪', strength: 75 }
];

const TEAMS_BUNDESLIGA: Team[] = [
  { name: 'Bayern Munich', logo: '🔴', strength: 93 }, { name: 'Borussia Dortmund', logo: '🟡⚫', strength: 89 },
  { name: 'Bayer Leverkusen', logo: '🔴⚫', strength: 91 }, { name: 'RB Leipzig', logo: '🔴⚪', strength: 87 },
  { name: 'Eintracht Frankfurt', logo: '🦅', strength: 83 }, { name: 'Stuttgart', logo: '⚪🔴', strength: 84 },
  { name: 'Freiburg', logo: '⚫⚪', strength: 80 }, { name: 'Hoffenheim', logo: '🔵', strength: 78 },
  { name: 'Wolfsburg', logo: '🐺', strength: 78 }, { name: 'Werder Bremen', logo: '🟢⚪', strength: 77 },
  { name: 'Mainz 05', logo: '🔴', strength: 75 }, { name: 'Borussia Mönchengladbach', logo: '🟢⚫', strength: 76 }
];

// Helper to calculate realistic odds from relative team strength + home advantage
function calculateOdds(home: Team, away: Team): { homeOdds: number; drawOdds: number; awayOdds: number; maxOdds: number } {
  const homeAdvantage = 3.5;
  const hPower = home.strength + homeAdvantage;
  const aPower = away.strength;

  const diff = hPower - aPower; // positive if home is favored
  let hOdds = 2.10 - diff * 0.055;
  let aOdds = 2.70 + diff * 0.065;
  let dOdds = 3.30 + Math.abs(diff) * 0.035;

  hOdds = Math.max(1.18, Math.min(12.5, Number(hOdds.toFixed(2))));
  aOdds = Math.max(1.22, Math.min(15.0, Number(aOdds.toFixed(2))));
  dOdds = Math.max(2.85, Math.min(6.5, Number(dOdds.toFixed(2))));

  const maxOdds = Math.max(hOdds, dOdds, aOdds);
  return { homeOdds: hOdds, drawOdds: dOdds, awayOdds: aOdds, maxOdds };
}

// Generate random fresh round of matches across all leagues with full shuffle
function generateFreshRound(): Match[] {
  const roundMatches: Match[] = [];

  const createLeaguePairs = (teams: Team[], league: Match['league'], leagueName: string, count: number) => {
    // True random shuffle so matchups change dynamically every single round
    const shuffled = [...teams].sort(() => Math.random() - 0.5);
    for (let i = 0; i < count * 2 && i + 1 < shuffled.length; i += 2) {
      const home = shuffled[i];
      const away = shuffled[i + 1];
      const { homeOdds, drawOdds, awayOdds, maxOdds } = calculateOdds(home, away);

      roundMatches.push({
        id: `m_${league}_${Date.now()}_${i}_${Math.random().toString(36).substring(2, 6)}`,
        league,
        leagueName,
        homeTeam: home.name,
        homeLogo: home.logo,
        awayTeam: away.name,
        awayLogo: away.logo,
        homeOdds,
        drawOdds,
        awayOdds,
        maxOdds,
        homeGoals: 0,
        awayGoals: 0,
        minute: 0,
        status: 'SCHEDULED',
        events: []
      });
    }
  };

  createLeaguePairs(TEAMS_LALIGA, 'laliga', '🇪🇸 La Liga (ესპანეთი)', 4);
  createLeaguePairs(TEAMS_EPL, 'epl', '🏴󠁧󠁢󠁥󠁮󠁧󠁿 Premier League', 4);
  createLeaguePairs(TEAMS_GEORGIA, 'georgia', '🇬🇪 ეროვნული ლიგა', 3);
  createLeaguePairs(TEAMS_UCL, 'ucl', '🏆 UEFA ჩემპიონთა ლიგა', 4);
  createLeaguePairs(TEAMS_NATIONAL, 'national', '🌍 ეროვნული ნაკრებები', 3);
  createLeaguePairs(TEAMS_SERIEA, 'seriea', '🇮🇹 Serie A', 3);
  createLeaguePairs(TEAMS_BUNDESLIGA, 'bundesliga', '🇩🇪 Bundesliga', 3);

  return roundMatches;
}

export const SportsBetting: React.FC<SportsBettingProps> = ({
  balance,
  soundEnabled,
  onBetPlaced,
  onWin,
  onLoss
}) => {
  const [matches, setMatches] = useState<Match[]>(() => generateFreshRound());
  const [betSlips, setBetSlips] = useState<BetSlipItem[]>([]);
  const [roundRefreshNotice, setRoundRefreshNotice] = useState<string | null>(null);

  // Filtering & Sorting State
  const [activeLeague, setActiveLeague] = useState<'all' | 'laliga' | 'epl' | 'georgia' | 'ucl' | 'national' | 'seriea' | 'bundesliga' | 'live'>('all');
  const [oddsFilter, setOddsFilter] = useState<'all' | 'highest' | 'favorites' | 'underdog' | 'balanced'>('all');
  const [sortBy, setSortBy] = useState<'default' | 'odds_desc' | 'odds_asc'>('default');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Selected match for bet dialog
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);
  const [selectedPick, setSelectedPick] = useState<'1' | 'X' | '2'>('1');
  const [betInput, setBetInput] = useState<string>('50');

  // Currently simulating match
  const [activeSimMatchId, setActiveSimMatchId] = useState<string | null>(null);
  const simIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Clean up timer on unmount
  useEffect(() => {
    return () => {
      if (simIntervalRef.current) clearInterval(simIntervalRef.current);
    };
  }, []);

  // Filtered and Sorted Matches
  const filteredMatches = useMemo(() => {
    let result = [...matches];

    // 1. League Filter
    if (activeLeague === 'live') {
      result = result.filter((m) => m.status === 'LIVE');
    } else if (activeLeague !== 'all') {
      result = result.filter((m) => m.league === activeLeague);
    }

    // 2. Search Query (Team Names)
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        (m) => m.homeTeam.toLowerCase().includes(q) || m.awayTeam.toLowerCase().includes(q)
      );
    }

    // 3. Odds Filter (Includes highest odds filtering)
    if (oddsFilter === 'highest') {
      result = result.filter((m) => m.maxOdds >= 3.20);
    } else if (oddsFilter === 'favorites') {
      result = result.filter((m) => m.homeOdds <= 1.80 || m.awayOdds <= 1.80);
    } else if (oddsFilter === 'underdog') {
      result = result.filter((m) => m.homeOdds >= 4.0 || m.awayOdds >= 4.0);
    } else if (oddsFilter === 'balanced') {
      result = result.filter((m) => Math.abs(m.homeOdds - m.awayOdds) < 1.0);
    }

    // 4. Sorting
    if (sortBy === 'odds_desc') {
      result.sort((a, b) => b.maxOdds - a.maxOdds);
    } else if (sortBy === 'odds_asc') {
      result.sort((a, b) => Math.min(a.homeOdds, a.awayOdds) - Math.min(b.homeOdds, b.awayOdds));
    }

    return result;
  }, [matches, activeLeague, oddsFilter, sortBy, searchQuery]);

  const openBetModal = (match: Match, pick: '1' | 'X' | '2') => {
    playClickSound(soundEnabled);
    setSelectedMatch(match);
    setSelectedPick(pick);
  };

  const handlePlaceBet = () => {
    if (!selectedMatch) return;
    const amount = Number(betInput);
    if (isNaN(amount) || amount < 5 || amount > balance) return;

    playCashSound(soundEnabled);
    onBetPlaced(amount);

    let odds = selectedMatch.homeOdds;
    let pickLabel = `${selectedMatch.homeTeam} მოგება (1)`;
    if (selectedPick === 'X') {
      odds = selectedMatch.drawOdds;
      pickLabel = 'ფრე (X)';
    } else if (selectedPick === '2') {
      odds = selectedMatch.awayOdds;
      pickLabel = `${selectedMatch.awayTeam} მოგება (2)`;
    }

    const newSlip: BetSlipItem = {
      id: `slip_${Date.now()}_${Math.random()}`,
      matchId: selectedMatch.id,
      matchTitle: `${selectedMatch.homeTeam} vs ${selectedMatch.awayTeam}`,
      pick: selectedPick,
      pickLabel,
      odds,
      betAmount: amount,
      potentialWin: Math.floor(amount * odds),
      status: 'PENDING',
      placedAt: Date.now()
    };

    setBetSlips((prev) => [newSlip, ...prev]);
    const targetMatchId = selectedMatch.id;
    setSelectedMatch(null);

    // Auto trigger match simulation
    startMatchSimulation(targetMatchId);
  };

  // Live Match Simulation Engine
  const startMatchSimulation = (matchId: string) => {
    if (activeSimMatchId) return;

    setActiveSimMatchId(matchId);
    setMatches((prev) =>
      prev.map((m) =>
        m.id === matchId
          ? { ...m, status: 'LIVE', minute: 1, homeGoals: 0, awayGoals: 0, events: ['0\' ⚽ მატჩი დაიწყო! მსაჯის სასტვენი.'] }
          : m
      )
    );

    let currentMin = 1;
    let hGoals = 0;
    let aGoals = 0;
    const targetMatch = matches.find((m) => m.id === matchId);
    const events: string[] = ['0\' ⚽ მატჩი დაიწყო! მსაჯის სასტვენი.'];

    simIntervalRef.current = setInterval(() => {
      currentMin += Math.floor(Math.random() * 9) + 7; // jump 7-15 mins

      if (currentMin >= 90) {
        currentMin = 90;
        if (simIntervalRef.current) clearInterval(simIntervalRef.current);
        simIntervalRef.current = null;
        setActiveSimMatchId(null);

        events.unshift(`90' 🏁 მატჩი დასრულდა! საბოლოო ანგარიში: ${hGoals} - ${aGoals}`);

        // Update match to FINISHED
        setMatches((prev) =>
          prev.map((m) =>
            m.id === matchId
              ? { ...m, status: 'FINISHED', minute: 90, homeGoals: hGoals, awayGoals: aGoals, events: [...events] }
              : m
          )
        );

        // Settle all pending slips for this match
        setBetSlips((prevSlips) =>
          prevSlips.map((slip) => {
            if (slip.matchId !== matchId || slip.status !== 'PENDING') return slip;

            let isWin = false;
            if (slip.pick === '1' && hGoals > aGoals) isWin = true;
            if (slip.pick === 'X' && hGoals === aGoals) isWin = true;
            if (slip.pick === '2' && aGoals > hGoals) isWin = true;

            if (isWin) {
              playWinSound(soundEnabled);
              onWin(slip.potentialWin, Math.floor(slip.odds * 40));
              return { ...slip, status: 'WON', finalScore: `${hGoals} - ${aGoals}` };
            } else {
              onLoss(slip.betAmount);
              return { ...slip, status: 'LOST', finalScore: `${hGoals} - ${aGoals}` };
            }
          })
        );

        // Auto-regenerate fresh round of matches across all leagues (La Liga, EPL, Georgia, UCL, Nationals)
        setRoundRefreshNotice('⏳ მატჩი დასრულდა და ფსონი გამოითვალა! 2 წამში დაიწყება ახალი ტური ყველა ლიგაში...');
        setTimeout(() => {
          setMatches(generateFreshRound());
          setRoundRefreshNotice('🔄 ახალი ტური დაიწყო! გუნდები და მატჩები შეიცვალა ყველა ლიგაში (La Liga, EPL, ეროვნული ლიგა და ნაკრებები)!');
          setTimeout(() => setRoundRefreshNotice(null), 4000);
        }, 2600);
      } else {
        // Chance of goal based on odds/ratings
        const rand = Math.random();
        if (rand < 0.28) {
          hGoals += 1;
          playCashSound(soundEnabled);
          events.unshift(`${currentMin}' ⚽ გოოოოლ! ${targetMatch?.homeTeam || 'მასპინძელმა'} გაიტანა! (${hGoals} - ${aGoals})`);
        } else if (rand < 0.52) {
          aGoals += 1;
          playCashSound(soundEnabled);
          events.unshift(`${currentMin}' ⚽ გოოოოლ! ${targetMatch?.awayTeam || 'სტუმარმა'} გაიტანა! (${hGoals} - ${aGoals})`);
        } else if (rand < 0.72) {
          events.unshift(`${currentMin}' 🟨 ყვითელი ბარათი უხეშობისთვის`);
        } else if (rand < 0.88) {
          events.unshift(`${currentMin}' 🧤 მეკარის სახიფათო სეივი! კუთხური.`);
        }

        setMatches((prev) =>
          prev.map((m) =>
            m.id === matchId
              ? { ...m, minute: currentMin, homeGoals: hGoals, awayGoals: aGoals, events: [...events] }
              : m
          )
        );
      }
    }, 1100);
  };

  // Generate completely new round of matches across all leagues
  const handleRegenerateRound = () => {
    playClickSound(soundEnabled);
    if (simIntervalRef.current) {
      clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
      setActiveSimMatchId(null);
    }
    const fresh = generateFreshRound();
    setMatches(fresh);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Sports Arena Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0c121e] via-[#090e18] to-[#07090f] border border-blue-500/30 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/15 border border-blue-500/30 text-blue-400 text-xs font-semibold">
              <Trophy className="w-3.5 h-3.5" />
              <span>ტოტალიზატორი & სპორტული ფსონები</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              საფეხბურთო მატჩები & დინამიური ტურები
            </h1>
            <p className="text-slate-400 text-xs sm:text-sm max-w-xl">
              დადე ფსონი La Liga-ს მრავალფეროვან კლუბებზე, Premier League-ზე, საქართველოს ეროვნულ ლიგასა და ნაკრებებზე. გუნდები და მატჩები რეგულარულად იცვლება!
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-end gap-3 shrink-0">
            <button
              type="button"
              onClick={handleRegenerateRound}
              className="px-4 py-2.5 rounded-xl bg-blue-600/30 hover:bg-blue-600/50 border border-blue-500/50 text-blue-300 font-bold text-xs flex items-center gap-2 transition-all shadow-md active:scale-95"
              title="ახალი მატჩების გენერირება ყველა ლიგაში"
            >
              <Shuffle className="w-4 h-4 text-blue-400" />
              <span>ახალი ტური (მატჩების განახლება)</span>
            </button>

            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl text-right">
              <span className="text-[11px] uppercase tracking-wider text-slate-400 font-bold block mb-1">
                ხელმისაწვდომი ბალანსი
              </span>
              <div className="text-2xl sm:text-3xl font-black font-mono text-emerald-400">
                {formatLari(balance)}
              </div>
            </div>
          </div>
        </div>

        {/* League Selector Tabs */}
        <div className="flex flex-wrap items-center gap-2 mt-6 pt-5 border-t border-slate-800/80">
          {[
            { id: 'all', label: 'ყველა მატჩი' },
            { id: 'laliga', label: '🇪🇸 La Liga' },
            { id: 'epl', label: '🏴󠁧󠁢󠁥󠁮󠁧󠁿 Premier League' },
            { id: 'georgia', label: '🇬🇪 ეროვნული ლიგა' },
            { id: 'ucl', label: '🏆 ჩემპიონთა ლიგა' },
            { id: 'national', label: '🌍 ნაკრებები' },
            { id: 'seriea', label: '🇮🇹 Serie A' },
            { id: 'bundesliga', label: '🇩🇪 Bundesliga' },
            { id: 'live', label: '🔴 LIVE' }
          ].map((lg) => (
            <button
              key={lg.id}
              onClick={() => setActiveLeague(lg.id as any)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                activeLeague === lg.id
                  ? 'bg-blue-500 text-slate-950 shadow-md'
                  : 'bg-slate-900/80 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
              }`}
            >
              {lg.label}
            </button>
          ))}
        </div>
      </div>

      {/* FILTER & SEARCH TOOLBAR (Odds filters, sorting, search) */}
      <div className="p-3 sm:p-4 rounded-2xl bg-[#0c0d14] border border-slate-800 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 text-xs">
        {/* Search by team */}
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="მოძებნე საყვარელი გუნდი (მაგ. Real, Barca, დინამო, საქართველო)..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-blue-500 focus:outline-none text-slate-200 placeholder-slate-500"
          />
        </div>

        {/* Odds Filter Buttons */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-slate-400 font-bold flex items-center gap-1 mr-1">
            <Filter className="w-3.5 h-3.5 text-blue-400" />
            <span>კოეფიციენტი:</span>
          </span>

          <button
            type="button"
            onClick={() => setOddsFilter('all')}
            className={`px-2.5 py-1.5 rounded-lg border font-semibold transition-all ${
              oddsFilter === 'all'
                ? 'bg-blue-500/20 border-blue-500 text-blue-300'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            ყველა
          </button>

          <button
            type="button"
            onClick={() => setOddsFilter('highest')}
            className={`px-2.5 py-1.5 rounded-lg border font-semibold transition-all ${
              oddsFilter === 'highest'
                ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            🔥 მაღალი (&gt; 3.50x)
          </button>

          <button
            type="button"
            onClick={() => setOddsFilter('favorites')}
            className={`px-2.5 py-1.5 rounded-lg border font-semibold transition-all ${
              oddsFilter === 'favorites'
                ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            ⭐ ფავორიტები (&lt; 1.80x)
          </button>

          <button
            type="button"
            onClick={() => setOddsFilter('underdog')}
            className={`px-2.5 py-1.5 rounded-lg border font-semibold transition-all ${
              oddsFilter === 'underdog'
                ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            ⚡ აუტსაიდერები (&gt; 4.00x)
          </button>
        </div>

        {/* Sort Dropdown / Toggle */}
        <div className="flex items-center gap-1.5 shrink-0">
          <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 focus:outline-none focus:border-blue-500"
          >
            <option value="default">სტანდარტული დალაგება</option>
            <option value="odds_desc">უმაღლესი კოეფიციენტით ↓</option>
            <option value="odds_asc">უმცირესი კოეფიციენტით ↑</option>
          </select>
        </div>
      </div>

      {/* Main Grid: Matches (Left 8 cols) & Bet Slip (Right 4 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* MATCHES LIST (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          {/* Round Refresh Notice Banner */}
          {roundRefreshNotice && (
            <div className="p-3.5 rounded-2xl bg-blue-950/90 border border-blue-500 text-blue-200 text-xs font-bold flex items-center justify-between shadow-xl animate-in fade-in">
              <div className="flex items-center gap-2.5">
                <Shuffle className="w-4 h-4 text-blue-400 animate-spin" />
                <span>{roundRefreshNotice}</span>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/40 text-[10px] font-mono font-bold uppercase">
                დინამიური ტური
              </span>
            </div>
          )}

          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Flame className="w-5 h-5 text-amber-400" />
              <span>აქტიური მატჩები ({filteredMatches.length})</span>
            </h2>
            <span className="text-xs text-slate-400 font-mono">
              დააჭირე კოეფიციენტს (1 · X · 2) ფსონის დასადებად
            </span>
          </div>

          {filteredMatches.length === 0 ? (
            <div className="p-8 rounded-2xl bg-[#0c0d14] border border-slate-800 text-center space-y-3">
              <span className="text-4xl block">⚽</span>
              <h3 className="text-base font-bold text-slate-200">მატჩები ვერ მოიძებნა</h3>
              <p className="text-xs text-slate-400">შეცვალე ფილტრი ან დააჭირე "ახალი ტურის გენერირებას"</p>
              <button
                type="button"
                onClick={handleRegenerateRound}
                className="px-4 py-2 rounded-xl bg-blue-500 hover:bg-blue-400 text-slate-950 font-bold text-xs shadow-md"
              >
                მატჩების გენერირება
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredMatches.map((match) => {
                const isSimulating = activeSimMatchId === match.id;
                const highestOutcomeName =
                  match.homeOdds >= match.drawOdds && match.homeOdds >= match.awayOdds
                    ? `${match.homeTeam} (${match.homeOdds.toFixed(2)}x)`
                    : match.awayOdds >= match.drawOdds && match.awayOdds >= match.homeOdds
                    ? `${match.awayTeam} (${match.awayOdds.toFixed(2)}x)`
                    : `ფრე (${match.drawOdds.toFixed(2)}x)`;

                return (
                  <div
                    key={match.id}
                    className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                      match.status === 'LIVE'
                        ? 'bg-[#0f172a]/95 border-blue-500/60 shadow-[0_0_25px_rgba(59,130,246,0.3)]'
                        : match.status === 'FINISHED'
                        ? 'bg-[#0a0b12] border-slate-800/80'
                        : 'bg-[#0c0d14] border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {/* Match Header */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800 text-xs text-slate-400">
                      <span className="font-semibold text-slate-300">{match.leagueName}</span>
                      <div className="flex items-center gap-2 flex-wrap">
                        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/25 text-[11px] font-bold text-amber-300">
                          <Flame className="w-3.5 h-3.5 text-amber-400" />
                          <span>ყველაზე მეტი კოეფიციენტი: <strong className="text-amber-200">{highestOutcomeName}</strong></span>
                        </div>

                        {match.status === 'LIVE' ? (
                          <span className="px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/40 text-[11px] font-bold flex items-center gap-1.5 animate-pulse">
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                            <span>LIVE {match.minute}'</span>
                          </span>
                        ) : match.status === 'FINISHED' ? (
                          <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[11px] font-bold">
                            დასრულდა
                          </span>
                        ) : null}
                      </div>
                    </div>

                    {/* Teams & Score Display */}
                    <div className="py-4 grid grid-cols-7 items-center text-center">
                      {/* Home Team */}
                      <div className="col-span-3 flex flex-col items-center gap-1.5">
                        <span className="text-3xl">{match.homeLogo}</span>
                        <span className="font-extrabold text-sm sm:text-base text-slate-100">
                          {match.homeTeam}
                        </span>
                      </div>

                      {/* Score / VS Center */}
                      <div className="col-span-1 flex flex-col items-center justify-center">
                        {match.status !== 'SCHEDULED' ? (
                          <div className="text-2xl sm:text-3xl font-black font-mono text-white tracking-tight">
                            {match.homeGoals} : {match.awayGoals}
                          </div>
                        ) : (
                          <span className="text-xs font-mono font-bold text-slate-500 bg-slate-900 px-2.5 py-1 rounded-md">
                            VS
                          </span>
                        )}
                      </div>

                      {/* Away Team */}
                      <div className="col-span-3 flex flex-col items-center gap-1.5">
                        <span className="text-3xl">{match.awayLogo}</span>
                        <span className="font-extrabold text-sm sm:text-base text-slate-100">
                          {match.awayTeam}
                        </span>
                      </div>
                    </div>

                    {/* Odds Action Bar (1 · X · 2) */}
                    <div className="grid grid-cols-3 gap-2.5 pt-3 border-t border-slate-800/80">
                      <button
                        type="button"
                        disabled={match.status === 'FINISHED' || isSimulating}
                        onClick={() => openBetModal(match, '1')}
                        className={`p-2.5 rounded-xl border flex flex-col items-center transition-all ${
                          match.homeOdds >= 3.5
                            ? 'bg-amber-950/20 border-amber-500/40 hover:bg-amber-900/30'
                            : 'bg-slate-900/80 border-slate-800 hover:border-blue-500/50 hover:bg-blue-600/20'
                        } disabled:opacity-40`}
                      >
                        <span className="text-[11px] text-slate-400">1 (მასპინძელი)</span>
                        <span className="text-sm font-mono font-black text-emerald-400">
                          {match.homeOdds.toFixed(2)}
                        </span>
                      </button>

                      <button
                        type="button"
                        disabled={match.status === 'FINISHED' || isSimulating}
                        onClick={() => openBetModal(match, 'X')}
                        className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-blue-600/20 border border-slate-800 hover:border-blue-500/50 flex flex-col items-center transition-all disabled:opacity-40"
                      >
                        <span className="text-[11px] text-slate-400">X (ფრე)</span>
                        <span className="text-sm font-mono font-black text-amber-400">
                          {match.drawOdds.toFixed(2)}
                        </span>
                      </button>

                      <button
                        type="button"
                        disabled={match.status === 'FINISHED' || isSimulating}
                        onClick={() => openBetModal(match, '2')}
                        className={`p-2.5 rounded-xl border flex flex-col items-center transition-all ${
                          match.awayOdds >= 3.5
                            ? 'bg-amber-950/20 border-amber-500/40 hover:bg-amber-900/30'
                            : 'bg-slate-900/80 border-slate-800 hover:border-blue-500/50 hover:bg-blue-600/20'
                        } disabled:opacity-40`}
                      >
                        <span className="text-[11px] text-slate-400">2 (სტუმარი)</span>
                        <span className="text-sm font-mono font-black text-cyan-400">
                          {match.awayOdds.toFixed(2)}
                        </span>
                      </button>
                    </div>

                    {/* Live Simulation Events Ticker */}
                    {match.events && match.events.length > 0 && (
                      <div className="mt-3 p-3 rounded-xl bg-slate-950/80 border border-slate-900 text-xs space-y-1 max-h-28 overflow-y-auto">
                        <span className="text-[10px] uppercase font-bold text-slate-500 block">
                          ლაივ კომენტარი & მოვლენები:
                        </span>
                        {match.events.slice(0, 4).map((ev, i) => (
                          <div key={i} className="text-slate-300 font-mono text-[11px] leading-tight">
                            {ev}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Simulation trigger */}
                    {match.status === 'SCHEDULED' && (
                      <div className="pt-2 flex justify-end">
                        <button
                          type="button"
                          onClick={() => startMatchSimulation(match.id)}
                          className="text-[11px] text-slate-400 hover:text-blue-400 flex items-center gap-1 transition-colors"
                        >
                          <Play className="w-3 h-3" />
                          <span>მატჩის სიმულაციის გაშვება (ლაივ ყურება)</span>
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* BET SLIP & BETTING HISTORY (Right 4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="p-4 sm:p-5 rounded-2xl bg-[#0c0d14] border border-slate-800 space-y-4 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <Trophy className="w-4 h-4 text-emerald-400" />
                <span>ჩემი ფსონების ბილეთი ({betSlips.length})</span>
              </h3>
            </div>

            {betSlips.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400 space-y-2">
                <span className="text-3xl block">🎟️</span>
                <p>ბილეთი ცარიელია. აირჩიე ნებისმიერი მატჩი და დადე ფსონი!</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[550px] overflow-y-auto pr-1">
                {betSlips.map((slip) => (
                  <div
                    key={slip.id}
                    className={`p-3.5 rounded-xl border text-xs space-y-2 transition-all ${
                      slip.status === 'WON'
                        ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300'
                        : slip.status === 'LOST'
                        ? 'bg-rose-950/20 border-rose-900/40 text-rose-300'
                        : 'bg-slate-900/80 border-slate-800 text-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between font-bold">
                      <span className="text-slate-100 truncate max-w-[180px]">{slip.matchTitle}</span>
                      {slip.status === 'WON' ? (
                        <span className="px-2 py-0.5 rounded bg-emerald-500 text-slate-950 font-bold text-[10px]">
                          მოგებული! ✅
                        </span>
                      ) : slip.status === 'LOST' ? (
                        <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 border border-rose-500/30 text-[10px]">
                          წაგებული ❌
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30 text-[10px] animate-pulse">
                          ლაივშია... ⏳
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>არჩევანი: <strong className="text-slate-200">{slip.pickLabel}</strong></span>
                      <span className="font-mono font-bold text-amber-400">{slip.odds.toFixed(2)}x</span>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between font-mono">
                      <span className="text-slate-400">ფსონი: {formatLari(slip.betAmount)}</span>
                      <span className={`font-bold ${slip.status === 'WON' ? 'text-emerald-400 text-sm font-black' : 'text-slate-300'}`}>
                        {slip.status === 'WON' ? `+${formatLari(slip.potentialWin)}` : `მოგება: ${formatLari(slip.potentialWin)}`}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* BET PLACEMENT MODAL DIALOG */}
      {selectedMatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-md bg-[#0e1017] border border-blue-500/40 rounded-2xl p-6 shadow-2xl text-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <Trophy className="w-4 h-4 text-blue-400" />
                <span>ფსონის დადასტურება</span>
              </h3>
              <button
                onClick={() => setSelectedMatch(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-center space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-400">{selectedMatch.leagueName}</span>
              <div className="text-base font-extrabold text-white">
                {selectedMatch.homeTeam} vs {selectedMatch.awayTeam}
              </div>
              <div className="inline-block px-3 py-1 rounded-full bg-blue-500/15 border border-blue-500/30 text-blue-300 text-xs font-bold mt-1">
                შენი არჩევანი: {selectedPick === '1' ? `${selectedMatch.homeTeam} (1)` : selectedPick === 'X' ? 'ფრე (X)' : `${selectedMatch.awayTeam} (2)`} · კოეფიციენტი: {selectedPick === '1' ? selectedMatch.homeOdds : selectedPick === 'X' ? selectedMatch.drawOdds : selectedMatch.awayOdds}x
              </div>
            </div>

            {/* Bet Input with clean typing */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>ფსონის ოდენობა</span>
                <span className="text-emerald-400 font-mono">ბალანსი: {formatLari(balance)}</span>
              </div>
              <div className="relative">
                <input
                  type="text"
                  inputMode="numeric"
                  value={betInput}
                  onChange={(e) => {
                    const clean = e.target.value.replace(/[^0-9]/g, '');
                    setBetInput(clean);
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-blue-500 focus:outline-none text-base font-mono font-bold text-slate-100"
                  placeholder="ფსონი (მინ. 5 ₾)"
                />
                <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-sm font-bold text-blue-400">₾</span>
              </div>

              {/* Quick Presets */}
              <div className="flex gap-1.5 pt-1">
                {[10, 20, 50, 100, 500].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setBetInput(amt.toString())}
                    className="flex-1 py-1 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300 hover:border-slate-700"
                  >
                    +{amt}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => setBetInput(Math.floor(balance).toString())}
                  className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono text-amber-400 font-bold"
                >
                  MAX
                </button>
              </div>
            </div>

            {/* Potential Payout */}
            <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30 flex items-center justify-between font-mono text-xs">
              <span className="text-slate-300">შესაძლო მოგება:</span>
              <span className="text-emerald-400 font-black text-sm">
                +{formatLari(Math.floor((Number(betInput) || 0) * (selectedPick === '1' ? selectedMatch.homeOdds : selectedPick === 'X' ? selectedMatch.drawOdds : selectedMatch.awayOdds)))}
              </span>
            </div>

            <button
              type="button"
              disabled={!betInput || Number(betInput) < 5 || Number(betInput) > balance}
              onClick={handlePlaceBet}
              className="w-full py-3 rounded-xl bg-blue-500 hover:bg-blue-400 text-slate-950 font-black text-sm shadow-xl transition-all disabled:opacity-40 cursor-pointer"
            >
              ფსონის დადება & მატჩის გაშვება
            </button>
          </div>
        </div>
      )}
    </div>
  );
};


