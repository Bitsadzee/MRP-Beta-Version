﻿import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  PlayerProfile,
  Job,
  Contract,
  ActiveContract,
  Upgrader,
  Car,
  Garage,
  Estate,
  Business,
  Security,
  Accessory,
  TuningPart,
  CarTuningData
} from './types/game';
import {
  INITIAL_JOBS,
  INITIAL_CONTRACTS,
  INITIAL_UPGRADERS,
  LUXURY_CARS,
  LUXURY_GARAGES,
  LUXURY_ESTATES,
  LUXURY_BUSINESSES,
  LUXURY_SECURITIES,
  LUXURY_ACCESSORIES,
  CRYSTAL_PRICE_GEL,
  getXpRequiredForLevel,
  getLevelUpBonus,
  GAME_MISSIONS,
  TUNING_PARTS,
  ESTATE_RENT_SCALE,
  BUSINESS_INCOME_SCALE,
  UPGRADER_INCOME_SCALE
} from './utils/constants';
import { Header } from './components/Header';
import { AviaStar } from './components/AviaStar';
import { JobsAndContracts } from './components/JobsAndContracts';
import { MiniGames } from './components/MiniGames';
import { LuxuryShop } from './components/LuxuryShop';
import { ProfileModal } from './components/ProfileModal';
import { LevelUpModal } from './components/LevelUpModal';
import { InventoryView } from './components/InventoryView';
import { SportsBetting } from './components/SportsBetting';
import { MissionsView } from './components/MissionsView';
import { RankShopView } from './components/RankShopView';
import { CrystalExchangeModal } from './components/CrystalExchangeModal';
import { RulesModal } from './components/RulesModal';
import { AuthModal, UserAccount } from './components/AuthModal';
import { playLevelUpSound, playCashSound, playClickSound } from './utils/audio';
import { formatLari } from './utils/formatters';
import { Zap } from 'lucide-react';
import { TradingView, TRADING_USD_TO_GEL } from './components/TradingView';

const STORAGE_KEY = 'money_simulator_rp_data_v1';
const ACCOUNTS_KEY = 'money_sim_accounts_v1';
const CURRENT_USER_KEY = 'money_sim_current_user_v1';

const migrateStarterBalance = (saved: Partial<PlayerProfile>): PlayerProfile => {
  const merged = { ...DEFAULT_PLAYER, ...saved };
  const stats = { ...DEFAULT_PLAYER.stats, ...(saved.stats || {}) };
  if (merged.level === 1 && stats.jobsCompleted === 0 && stats.totalEarned === 350 && merged.balance === 350) {
    return { ...merged, balance: 20, stats: { ...stats, totalEarned: 20 } };
  }
  return { ...merged, stats };
};

const DEFAULT_PLAYER: PlayerProfile = {
  name: 'გიორგი_Boss',
  title: 'ქალაქის მმართველი',
  avatar: '🕶️',
  level: 1,
  xp: 0,
  balance: 20, // Starting budget
  crystals: 10,
  premiumRank: 'none',
  completedMissions: [],
  hasCustomTuningWorkshop: false,
  workshopInventory: {},
  carTunings: {},
  reputation: 50,
  soundEnabled: true,
  garageCapacity: 2,
  stats: {
    totalEarned: 20,
    totalLost: 0,
    aviaBets: 0,
    aviaWins: 0,
    biggestMultiplier: 1.0,
    jobsCompleted: 0,
    contractsDone: 0,
    safesCracked: 0,
    wheelSpins: 0,
    levelUpCount: 0
  }
};

export default function App() {
  // Accounts state (Username & Password authentication)
  const [accounts, setAccounts] = useState<{ [username: string]: UserAccount }>(() => {
    try {
      const saved = localStorage.getItem(ACCOUNTS_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return {
      'გიორგი_boss': {
        username: 'გიორგი_Boss',
        passwordHash: '1234',
        createdAt: Date.now(),
        avatar: '🕶️',
        title: 'ქალაქის მმართველი'
      }
    };
  });

  const [currentUser, setCurrentUser] = useState<string | null>(() => {
    try {
      return localStorage.getItem(CURRENT_USER_KEY);
    } catch {
      return null;
    }
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);

  // Load saved player state or default
  const [player, setPlayer] = useState<PlayerProfile>(() => {
    try {
      const activeUser = localStorage.getItem(CURRENT_USER_KEY);
      const userKey = activeUser ? `money_sim_u_${activeUser.toLowerCase()}` : STORAGE_KEY;
      const saved = localStorage.getItem(userKey) || localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return migrateStarterBalance(JSON.parse(saved));
      }
    } catch {
      // ignore
    }
    return DEFAULT_PLAYER;
  });

  // Upgraders state
  const [upgraders, setUpgraders] = useState<Upgrader[]>(() => {
    try {
      const activeUser = localStorage.getItem(CURRENT_USER_KEY);
      const userKey = activeUser ? `money_sim_u_${activeUser.toLowerCase()}` : STORAGE_KEY;
      const saved = localStorage.getItem(`${userKey}_upgraders`) || localStorage.getItem(`${STORAGE_KEY}_upgraders`);
      if (saved) {
        const parsed = JSON.parse(saved) as Upgrader[];
        return INITIAL_UPGRADERS.map((init) => {
          const found = parsed.find((p) => p.id === init.id);
          return found ? { ...init, owned: found.owned ?? 0 } : init;
        });
      }
    } catch {
      // ignore
    }
    return INITIAL_UPGRADERS;
  });

  // Active contracts state
  const [activeContracts, setActiveContracts] = useState<ActiveContract[]>(() => {
    try {
      const activeUser = localStorage.getItem(CURRENT_USER_KEY);
      const userKey = activeUser ? `money_sim_u_${activeUser.toLowerCase()}` : STORAGE_KEY;
      const saved = localStorage.getItem(`${userKey}_contracts`) || localStorage.getItem(`${STORAGE_KEY}_contracts`);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [];
  });

  // Owned luxury items
  const [ownedCars, setOwnedCars] = useState<string[]>(() => {
    try {
      const activeUser = localStorage.getItem(CURRENT_USER_KEY);
      const userKey = activeUser ? `money_sim_u_${activeUser.toLowerCase()}` : STORAGE_KEY;
      const saved = localStorage.getItem(`${userKey}_cars`) || localStorage.getItem(`${STORAGE_KEY}_cars`);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [];
  });

  const [ownedGarages, setOwnedGarages] = useState<string[]>(() => {
    try {
      const activeUser = localStorage.getItem(CURRENT_USER_KEY);
      const userKey = activeUser ? `money_sim_u_${activeUser.toLowerCase()}` : STORAGE_KEY;
      const saved = localStorage.getItem(`${userKey}_garages`) || localStorage.getItem(`${STORAGE_KEY}_garages`);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [];
  });

  const [ownedEstates, setOwnedEstates] = useState<string[]>(() => {
    try {
      const activeUser = localStorage.getItem(CURRENT_USER_KEY);
      const userKey = activeUser ? `money_sim_u_${activeUser.toLowerCase()}` : STORAGE_KEY;
      const saved = localStorage.getItem(`${userKey}_estates`) || localStorage.getItem(`${STORAGE_KEY}_estates`);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [];
  });

  const [ownedBusinesses, setOwnedBusinesses] = useState<{ [id: string]: number }>(() => {
    try {
      const activeUser = localStorage.getItem(CURRENT_USER_KEY);
      const userKey = activeUser ? `money_sim_u_${activeUser.toLowerCase()}` : STORAGE_KEY;
      const saved = localStorage.getItem(`${userKey}_businesses`) || localStorage.getItem(`${STORAGE_KEY}_businesses`);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return {};
  });

  const [ownedSecurity, setOwnedSecurity] = useState<string[]>(() => {
    try {
      const activeUser = localStorage.getItem(CURRENT_USER_KEY);
      const userKey = activeUser ? `money_sim_u_${activeUser.toLowerCase()}` : STORAGE_KEY;
      const saved = localStorage.getItem(`${userKey}_security`) || localStorage.getItem(`${STORAGE_KEY}_security`);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [];
  });

  // Active navigation tab (Default to 'aviator')
  const [activeTab, setActiveTab] = useState<string>('aviator');

  // Modal open states
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
  const [isCrystalExchangeOpen, setIsCrystalExchangeOpen] = useState<boolean>(false);
  const [isRulesOpen, setIsRulesOpen] = useState<boolean>(false);

  // Level Up modal celebration state
  const [levelUpData, setLevelUpData] = useState<{ level: number; bonus: number } | null>(null);

  // Save to localStorage on state changes (User specific)
  useEffect(() => {
    try {
      const activeUser = currentUser || localStorage.getItem(CURRENT_USER_KEY);
      const userKey = activeUser ? `money_sim_u_${activeUser.toLowerCase()}` : STORAGE_KEY;

      localStorage.setItem(userKey, JSON.stringify(player));
      localStorage.setItem(`${userKey}_upgraders`, JSON.stringify(upgraders));
      localStorage.setItem(`${userKey}_contracts`, JSON.stringify(activeContracts));
      localStorage.setItem(`${userKey}_cars`, JSON.stringify(ownedCars));
      localStorage.setItem(`${userKey}_garages`, JSON.stringify(ownedGarages));
      localStorage.setItem(`${userKey}_estates`, JSON.stringify(ownedEstates));
      localStorage.setItem(`${userKey}_businesses`, JSON.stringify(ownedBusinesses));
      localStorage.setItem(`${userKey}_security`, JSON.stringify(ownedSecurity));

      localStorage.setItem(STORAGE_KEY, JSON.stringify(player));
    } catch {
      // ignore storage quota
    }
  }, [currentUser, player, upgraders, activeContracts, ownedCars, ownedGarages, ownedEstates, ownedBusinesses, ownedSecurity]);

  // Auth Handlers
  const handleRegisterSuccess = (username: string, password: string, avatar: string) => {
    const userLower = username.toLowerCase();
    const newAcc: UserAccount = {
      username,
      passwordHash: password,
      createdAt: Date.now(),
      avatar,
      title: 'ახალი RP მოქალაქე'
    };

    const nextAccounts = { ...accounts, [userLower]: newAcc };
    setAccounts(nextAccounts);
    try {
      localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(nextAccounts));
      localStorage.setItem(CURRENT_USER_KEY, username);
    } catch {}

    const freshPlayer: PlayerProfile = {
      ...DEFAULT_PLAYER,
      name: username,
      avatar,
      title: 'ახალი RP მოქალაქე'
    };

    setCurrentUser(username);
    setPlayer(freshPlayer);
    setUpgraders(INITIAL_UPGRADERS);
    setActiveContracts([]);
    setOwnedCars([]);
    setOwnedGarages([]);
    setOwnedEstates([]);
    setOwnedBusinesses({});
    setOwnedSecurity([]);
    setIsAuthModalOpen(false);
  };

  const handleLoginSuccess = (username: string) => {
    const userLower = username.toLowerCase();
    setCurrentUser(username);
    try {
      localStorage.setItem(CURRENT_USER_KEY, username);
      const userKey = `money_sim_u_${userLower}`;
      const savedP = localStorage.getItem(userKey);
      if (savedP) setPlayer(migrateStarterBalance(JSON.parse(savedP)));
      const savedUp = localStorage.getItem(`${userKey}_upgraders`);
      if (savedUp) setUpgraders(JSON.parse(savedUp));
      const savedCon = localStorage.getItem(`${userKey}_contracts`);
      if (savedCon) setActiveContracts(JSON.parse(savedCon));
      const savedC = localStorage.getItem(`${userKey}_cars`);
      if (savedC) setOwnedCars(JSON.parse(savedC));
      const savedG = localStorage.getItem(`${userKey}_garages`);
      if (savedG) setOwnedGarages(JSON.parse(savedG));
      const savedE = localStorage.getItem(`${userKey}_estates`);
      if (savedE) setOwnedEstates(JSON.parse(savedE));
      const savedB = localStorage.getItem(`${userKey}_businesses`);
      if (savedB) setOwnedBusinesses(JSON.parse(savedB));
      const savedS = localStorage.getItem(`${userKey}_security`);
      if (savedS) setOwnedSecurity(JSON.parse(savedS));
    } catch {}
    setIsAuthModalOpen(false);
  };

  const handleLogout = () => {
    playClickSound(player.soundEnabled);
    setCurrentUser(null);
    try {
      localStorage.removeItem(CURRENT_USER_KEY);
    } catch {}
    setIsAuthModalOpen(true);
  };

  // 120-Second Upgrader Cycle Countdown and Payout state
  const [upgraderSecondsLeft, setUpgraderSecondsLeft] = useState<number>(120);
  const [payoutToast, setPayoutToast] = useState<{ message: string; amount: number } | null>(null);
  const secondTickerRef = useRef<number>(0);

  // Auto-dismiss payout toast after 4 seconds
  useEffect(() => {
    if (!payoutToast) return;
    const t = setTimeout(() => setPayoutToast(null), 4000);
    return () => clearTimeout(t);
  }, [payoutToast]);

  // Rank bonuses apply consistently to cash and XP rewards across the game.
  const rankXpMultiplier = useMemo(() => {
    if (player.premiumRank === 'devil_red') return 30.0;
    if (player.premiumRank === 'midnight_purple') return 5.0;
    if (player.premiumRank === 'purple') return 3.0;
    if (player.premiumRank === 'red') return 2.0;
    return 1.0;
  }, [player.premiumRank]);

  const rankMoneyMultiplier = useMemo(() => {
    if (player.premiumRank === 'devil_red') return 25.0;
    if (player.premiumRank === 'midnight_purple') return 2.0;
    if (player.premiumRank === 'purple') return 1.5;
    if (player.premiumRank === 'red') return 1.2;
    return 1.0;
  }, [player.premiumRank]);
  // Compute equivalent passive rate for display in Header
  const passiveIncomeRate = useMemo(() => {
    let rate = 0;
    ownedEstates.forEach((estId) => {
      const estate = LUXURY_ESTATES.find((e) => e.id === estId);
      if (estate) rate += estate.passiveRentPerSec * ESTATE_RENT_SCALE;
    });
    Object.entries(ownedBusinesses).forEach(([bizId, count]) => {
      if (count <= 0) return;
      const biz = LUXURY_BUSINESSES.find((b) => b.id === bizId);
      if (biz && biz.intervalSeconds > 0) {
        rate += (biz.baseIncome * BUSINESS_INCOME_SCALE / biz.intervalSeconds) * count;
      }
    });
    return rate * rankMoneyMultiplier;
  }, [ownedEstates, ownedBusinesses, rankMoneyMultiplier]);

  // Main 1-second game loop
  useEffect(() => {
    const timer = setInterval(() => {
      secondTickerRef.current += 1;
      const currentTick = secondTickerRef.current;

      let earnedThisSecond = 0;

      // 1. Estates rent
      ownedEstates.forEach((estId) => {
        const estate = LUXURY_ESTATES.find((e) => e.id === estId);
        if (estate) earnedThisSecond += estate.passiveRentPerSec * ESTATE_RENT_SCALE;
      });

      // 2. Businesses income
      let businessPayoutThisSecond = 0;
      Object.entries(ownedBusinesses).forEach(([bizId, count]) => {
        if (count <= 0) return;
        const biz = LUXURY_BUSINESSES.find((b) => b.id === bizId);
        if (biz && currentTick % biz.intervalSeconds === 0) {
          businessPayoutThisSecond += biz.baseIncome * BUSINESS_INCOME_SCALE * count;
        }
      });
      earnedThisSecond += businessPayoutThisSecond;

      // 3. Upgraders: exactly 120 seconds cycle
      setUpgraderSecondsLeft((prev) => {
        if (prev <= 1) {
          const upgTotal = upgraders.reduce(
            (sum, u) => sum + (u.passivePerCycle || 0) * UPGRADER_INCOME_SCALE * (u.owned || 0),
            0
          );
          if (upgTotal > 0) {
            setPlayer((p) => ({
              ...p,
              balance: p.balance + Math.floor(upgTotal * rankMoneyMultiplier),
              stats: {
                ...p.stats,
                totalEarned: p.stats.totalEarned + Math.floor(upgTotal * rankMoneyMultiplier)
              }
            }));
            playCashSound(player.soundEnabled);
            setPayoutToast({
              message: '120-წამიანი აფგრეიდების დივიდენდი',
              amount: Math.floor(upgTotal * rankMoneyMultiplier)
            });
          }
          return 120;
        }
        return prev - 1;
      });

      if (earnedThisSecond > 0) {
        setPlayer((prev) => ({
          ...prev,
          balance: prev.balance + earnedThisSecond * rankMoneyMultiplier,
          stats: {
            ...prev.stats,
            totalEarned: prev.stats.totalEarned + earnedThisSecond * rankMoneyMultiplier
          }
        }));
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [upgraders, ownedEstates, ownedBusinesses, player.soundEnabled, rankMoneyMultiplier]);

  // Check and process level progression
  const addXpAndCheckLevel = (addedXp: number) => {
    setPlayer((prev) => {
      let currentLvl = prev.level;
      let currentXp = prev.xp + addedXp;
      let xpNeeded = getXpRequiredForLevel(currentLvl);
      let newLevelReached = false;
      let highestLvl = currentLvl;

      while (currentXp >= xpNeeded && currentLvl < 350) {
        currentXp -= xpNeeded;
        currentLvl++;
        newLevelReached = true;
        highestLvl = currentLvl;
        xpNeeded = getXpRequiredForLevel(currentLvl);
      }

      if (newLevelReached) {
        const bonus = Math.floor(getLevelUpBonus(highestLvl) * rankMoneyMultiplier);
        setLevelUpData({ level: highestLvl, bonus });
        playLevelUpSound(prev.soundEnabled);

        return {
          ...prev,
          level: highestLvl,
          xp: currentXp,
          balance: prev.balance + bonus,
          reputation: prev.reputation + 25,
          stats: {
            ...prev.stats,
            levelUpCount: prev.stats.levelUpCount + 1,
            totalEarned: prev.stats.totalEarned + bonus
          }
        };
      }

      return {
        ...prev,
        xp: currentXp
      };
    });
  };

  // Sound Toggle Handler
  const handleToggleSound = () => {
    setPlayer((prev) => ({
      ...prev,
      soundEnabled: !prev.soundEnabled
    }));
  };

  // Update Profile
  const handleUpdateProfile = (name: string, title: string, avatar: string, customPhoto?: string) => {
    setPlayer((prev) => ({
      ...prev,
      name,
      title,
      avatar,
      customPhoto
    }));
  };

  // Reset Game
  const handleResetGame = () => {
    localStorage.clear();
    setPlayer(DEFAULT_PLAYER);
    setUpgraders(INITIAL_UPGRADERS);
    setActiveContracts([]);
    setOwnedCars([]);
    setOwnedGarages([]);
    setOwnedEstates([]);
    setOwnedBusinesses({});
    setOwnedSecurity([]);
  };

  // Calculate unclaimed completed missions count for red notification dot in Header
  const unclaimedMissionsCount = useMemo(() => {
    return GAME_MISSIONS.filter((m) => {
      const isClaimed = player.completedMissions?.includes(m.id);
      if (isClaimed) return false;
      const progress = m.getProgress(player, ownedCars.length, ownedEstates.length);
      return progress.completed;
    }).length;
  }, [player, ownedCars.length, ownedEstates.length]);


  // Exchange Money for Crystals (1 Crystal = 500 GEL)
  const handleExchangeMoneyForCrystals = (crystalAmount: number) => {
    const costGel = crystalAmount * CRYSTAL_PRICE_GEL;
    if (player.balance < costGel || crystalAmount <= 0) return;

    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance - costGel,
      crystals: (prev.crystals || 0) + crystalAmount,
      reputation: prev.reputation + Math.max(1, Math.floor(crystalAmount / 5))
    }));
  };

  // Ranks can only be upgraded; a lower rank cannot replace the current one.
  const handleBuyRank = (rank: 'red' | 'purple' | 'midnight_purple' | 'devil_red', costCrystals: number) => {
    const priority = { none: 0, red: 1, purple: 2, midnight_purple: 3, devil_red: 4 } as const;
    setPlayer((prev) => {
      const current = prev.premiumRank || 'none';
      if ((prev.crystals || 0) < costCrystals || priority[rank] <= priority[current]) return prev;
      const repGain = rank === 'devil_red' ? 666 : rank === 'midnight_purple' ? 500 : rank === 'purple' ? 100 : 40;
      return { ...prev, crystals: (prev.crystals || 0) - costCrystals, premiumRank: rank, reputation: prev.reputation + repGain };
    });
    playLevelUpSound(player.soundEnabled);
  };

  // Claim Completed Mission
  const handleClaimMission = (missionId: string, cashReward: number, crystalReward: number) => {
    const finalCashReward = Math.floor(cashReward * rankMoneyMultiplier);
    if (player.completedMissions?.includes(missionId)) return;

    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance + finalCashReward,
      crystals: (prev.crystals || 0) + crystalReward,
      completedMissions: [...(prev.completedMissions || []), missionId],
      reputation: prev.reputation + 25,
      stats: {
        ...prev.stats,
        totalEarned: prev.stats.totalEarned + finalCashReward
      }
    }));
    playLevelUpSound(player.soundEnabled);
  };

  // Job Work Handler (multiplied by VIP rank: salary by rankMoneyMultiplier, xp by rankXpMultiplier)
  const handleWorkJob = (job: Job, bonusMultiplier: number = 1.0) => {
    if (bonusMultiplier <= 0) return;

    const finalSalary = Math.floor(job.salary * bonusMultiplier * rankMoneyMultiplier);
    const finalXp = Math.floor(job.xpReward * bonusMultiplier * rankXpMultiplier);

    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance + finalSalary,
      stats: {
        ...prev.stats,
        jobsCompleted: prev.stats.jobsCompleted + 1,
        totalEarned: prev.stats.totalEarned + finalSalary
      }
    }));
    addXpAndCheckLevel(finalXp);
  };

  // Start Contract Handler
  const handleStartContract = (contract: Contract) => {
    if (player.balance < contract.cost) return;

    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance - contract.cost
    }));

    setActiveContracts((prev) => [
      ...prev.filter((c) => c.contractId !== contract.id),
      {
        contractId: contract.id,
        startedAt: Date.now(),
        durationSeconds: contract.durationSeconds,
        completed: false
      }
    ]);
  };

  // Claim Contract Handler (multiplied by VIP rank)
  const handleClaimContract = (contractId: string) => {
    const contract = INITIAL_CONTRACTS.find((c) => c.id === contractId);
    if (!contract) return;

    setActiveContracts((prev) => prev.filter((c) => c.contractId !== contractId));

    const finalPayout = Math.floor(contract.payout * rankMoneyMultiplier);
    const finalXp = Math.floor(contract.xpReward * rankXpMultiplier);

    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance + finalPayout,
      stats: {
        ...prev.stats,
        contractsDone: prev.stats.contractsDone + 1,
        totalEarned: prev.stats.totalEarned + finalPayout
      }
    }));

    addXpAndCheckLevel(finalXp);
  };

  // Buy Upgrader Handler
  const handleBuyUpgrader = (upgraderId: string, cost: number) => {
    if (player.balance < cost) return;

    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance - cost,
      reputation: prev.reputation + 5
    }));

    setUpgraders((prev) =>
      prev.map((u) => (u.id === upgraderId ? { ...u, owned: u.owned + 1 } : u))
    );
  };

  // Avia-Star Handlers
  const handleAviaBetPlaced = (amount: number) => {
    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance - amount,
      stats: {
        ...prev.stats,
        aviaBets: prev.stats.aviaBets + 1
      }
    }));
  };

  const handleAviaWin = (winAmount: number, multiplier: number, xpReward: number) => {
    const finalWin = Math.floor(winAmount * rankMoneyMultiplier);
    const finalXp = Math.floor(xpReward * rankXpMultiplier);

    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance + finalWin,
      stats: {
        ...prev.stats,
        aviaWins: prev.stats.aviaWins + 1,
        totalEarned: prev.stats.totalEarned + finalWin,
        biggestMultiplier: Math.max(prev.stats.biggestMultiplier, multiplier)
      }
    }));
    addXpAndCheckLevel(finalXp);
  };

  const handleAviaLoss = (lostAmount: number) => {
    setPlayer((prev) => ({
      ...prev,
      stats: {
        ...prev.stats,
        totalLost: prev.stats.totalLost + lostAmount
      }
    }));
  };

  // Mini Games Handlers
  const handleMiniGameBet = (amount: number) => {
    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance - amount
    }));
  };

  const handleMiniGameWin = (winAmount: number, xpReward: number) => {
    const finalWin = Math.floor(winAmount * rankMoneyMultiplier);
    const finalXp = Math.floor(xpReward * rankXpMultiplier);

    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance + finalWin,
      stats: {
        ...prev.stats,
        totalEarned: prev.stats.totalEarned + finalWin
      }
    }));
    addXpAndCheckLevel(finalXp);
  };

  const handleMiniGameLoss = (lostAmount: number) => {
    setPlayer((prev) => ({
      ...prev,
      stats: {
        ...prev.stats,
        totalLost: prev.stats.totalLost + lostAmount
      }
    }));
  };

  const handleTrade = (assetId: string, side: 'buy' | 'sell', quantity: number, price: number) => {
    if (!Number.isFinite(quantity) || quantity < 0.000001 || quantity > 1_000_000_000 || !Number.isFinite(price) || price <= 0) return;
    const feeRate = 0.015;
    setPlayer((prev) => {
      const portfolio = { ...(prev.tradingPortfolio || {}) };
      const position = portfolio[assetId] || { quantity: 0, averagePrice: 0 };
      const grossUsd = price * quantity;
      const feeUsd = Math.round(grossUsd * feeRate * 100) / 100;
      if (side === 'buy') {
        const totalCost = (grossUsd + feeUsd) * TRADING_USD_TO_GEL;
        if (prev.balance < totalCost) return prev;
        const nextQuantity = position.quantity + quantity;
        portfolio[assetId] = {
          quantity: nextQuantity,
          averagePrice: (position.averagePrice * position.quantity + grossUsd + feeUsd) / nextQuantity
        };
        return { ...prev, balance: prev.balance - totalCost, tradingPortfolio: portfolio };
      }
      if (position.quantity < quantity) return prev;
      const costBasis = position.averagePrice * quantity;
      const netProceedsUsd = grossUsd - feeUsd;
      const realizedPnLUsd = netProceedsUsd - costBasis;
      const cashSettlement = Math.max(0, costBasis + realizedPnLUsd * rankMoneyMultiplier) * TRADING_USD_TO_GEL;
      portfolio[assetId] = { quantity: position.quantity - quantity, averagePrice: position.averagePrice };
      return {
        ...prev,
        balance: prev.balance + cashSettlement,
        tradingPortfolio: portfolio,
        stats: {
          ...prev.stats,
          totalEarned: prev.stats.totalEarned + Math.max(0, realizedPnLUsd * rankMoneyMultiplier) * TRADING_USD_TO_GEL,
          totalLost: prev.stats.totalLost + Math.max(0, -realizedPnLUsd * rankMoneyMultiplier) * TRADING_USD_TO_GEL
        }
      };
    });
  };
  // Luxury Shop Handlers
  const handleBuyCar = (car: Car) => {
    if (player.balance < car.price || ownedCars.includes(car.id)) return;
    if (ownedCars.length >= player.garageCapacity) return;

    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance - car.price,
      reputation: prev.reputation + car.respect
    }));
    setOwnedCars((prev) => [...prev, car.id]);
    addXpAndCheckLevel(car.respect * 4);
  };

  const handleBuyGarage = (garage: Garage) => {
    if (player.balance < garage.price || ownedGarages.includes(garage.id)) return;

    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance - garage.price,
      garageCapacity: prev.garageCapacity + garage.capacity
    }));
    setOwnedGarages((prev) => [...prev, garage.id]);
    addXpAndCheckLevel(300);
  };

  const handleBuyEstate = (estate: Estate) => {
    if (player.balance < estate.price || ownedEstates.includes(estate.id)) return;

    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance - estate.price,
      reputation: prev.reputation + estate.respect
    }));
    setOwnedEstates((prev) => [...prev, estate.id]);
    addXpAndCheckLevel(estate.respect * 3);
  };

  const handleBuyBusiness = (biz: Business, cost: number) => {
    if (player.balance < cost) return;

    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance - cost,
      reputation: prev.reputation + 40
    }));

    setOwnedBusinesses((prev) => ({
      ...prev,
      [biz.id]: (prev[biz.id] || 0) + 1
    }));
    addXpAndCheckLevel(200);
  };

  const handleBuySecurity = (sec: Security) => {
    if (player.balance < sec.price || ownedSecurity.includes(sec.id)) return;

    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance - sec.price,
      reputation: prev.reputation + sec.respect
    }));
    setOwnedSecurity((prev) => [...prev, sec.id]);
    addXpAndCheckLevel(sec.respect * 2);
  };

  const handleBuyAccessory = (acc: Accessory) => {
    if (player.balance < acc.price || player.equippedAccessories?.includes(acc.id)) return;

    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance - acc.price,
      reputation: prev.reputation + acc.respect,
      equippedAccessories: [...(prev.equippedAccessories || []), acc.id]
    }));
    addXpAndCheckLevel(acc.respect * 3);
  };

  // Car Tuning Handlers
  const handleTuneCar = (carId: string, part: TuningPart, isFreeFromWorkshop: boolean) => {
    // One equipped part per category: upgrades replace the current slot instead of stacking forever.
    setPlayer((prev) => {
      if (!ownedCars.includes(carId)) return prev;
      if (isFreeFromWorkshop && (prev.workshopInventory?.[part.id] || 0) <= 0) return prev;
      if (!isFreeFromWorkshop && prev.balance < part.retailPrice) return prev;

      const current = prev.carTunings?.[carId] || { carId };
      const categories: TuningPart['category'][] = ['color', 'stage', 'turbo', 'intake', 'exhaust', 'suspension'];
      const installedPartIds = { ...(current.installedPartIds || {}) };
      categories.forEach((category) => {
        if (installedPartIds[category]) return;
        const slotName = category === 'color' ? current.colorName
          : category === 'turbo' ? current.turboType
          : category === 'intake' ? current.intakeType
          : category === 'exhaust' ? current.exhaustType
          : category === 'suspension' ? current.suspensionType : undefined;
        const legacyId = category === 'stage' && current.stageLevel
          ? `tune_stage_${current.stageLevel}`
          : TUNING_PARTS.find((candidate) => candidate.category === category && candidate.name === slotName)?.id;
        if (legacyId) installedPartIds[category] = legacyId;
      });
      const previousId = installedPartIds[part.category];
      if (previousId === part.id) return prev;
      const equippedParts = Object.values(installedPartIds)
        .map((id) => TUNING_PARTS.find((candidate) => candidate.id === id))
        .filter((candidate): candidate is TuningPart => Boolean(candidate));
      const previousPart = TUNING_PARTS.find((candidate) => candidate.id === previousId);
      const updated: CarTuningData = {
        ...current,
        extraHp: Math.max(0, equippedParts.reduce((sum, item) => sum + item.hpBonus, 0) - (previousPart?.hpBonus || 0) + part.hpBonus),
        extraSpeedKm: Math.max(0, equippedParts.reduce((sum, item) => sum + item.speedBonusKm, 0) - (previousPart?.speedBonusKm || 0) + part.speedBonusKm),
        extraRespect: Math.max(0, equippedParts.reduce((sum, item) => sum + item.respectBonus, 0) - (previousPart?.respectBonus || 0) + part.respectBonus),
        installedPartIds: { ...installedPartIds, [part.category]: part.id }
      };
      if (part.category === 'color') {
        updated.colorName = part.name;
        updated.colorHex = part.colorHex;
      } else if (part.category === 'stage') {
        updated.stageLevel = Number(part.id.match(/stage_(\d+)/)?.[1] || 0);
      } else if (part.category === 'turbo') updated.turboType = part.name;
      else if (part.category === 'intake') updated.intakeType = part.name;
      else if (part.category === 'exhaust') updated.exhaustType = part.name;
      else if (part.category === 'suspension') updated.suspensionType = part.name;

      return {
        ...prev,
        balance: isFreeFromWorkshop ? prev.balance : prev.balance - part.retailPrice,
        reputation: prev.reputation + part.respectBonus - (previousPart?.respectBonus || 0),
        workshopInventory: isFreeFromWorkshop ? {
          ...(prev.workshopInventory || {}),
          [part.id]: (prev.workshopInventory?.[part.id] || 0) - 1
        } : prev.workshopInventory,
        carTunings: { ...(prev.carTunings || {}), [carId]: updated }
      };
    });
    playLevelUpSound(player.soundEnabled);
  };

  const handleBuyWorkshopPart = (part: TuningPart) => {
    if (!player.hasCustomTuningWorkshop) return;
    if (player.balance < part.wholesalePrice) return;

    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance - part.wholesalePrice,
      workshopInventory: {
        ...(prev.workshopInventory || {}),
        [part.id]: ((prev.workshopInventory || {})[part.id] || 0) + 1
      }
    }));
    playCashSound(player.soundEnabled);
  };

  const handleBuyCustomWorkshop = () => {
    const WORKSHOP_PRICE = 2350500;
    if (player.balance < WORKSHOP_PRICE || player.hasCustomTuningWorkshop) return;

    setPlayer((prev) => ({
      ...prev,
      balance: prev.balance - WORKSHOP_PRICE,
      hasCustomTuningWorkshop: true,
      reputation: prev.reputation + 450
    }));
    playLevelUpSound(player.soundEnabled);
  };

  return (
    <div className="min-h-screen bg-[#08080c] text-slate-100 flex flex-col font-sans selection:bg-emerald-500/20 selection:text-emerald-300">
      {/* Top Header & Progress HUD */}
      <Header
        player={player}
        passiveIncomeRate={passiveIncomeRate}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenProfile={() => setIsProfileOpen(true)}
        onToggleSound={handleToggleSound}
        onLogout={handleLogout}
        onOpenExchangeModal={() => setIsCrystalExchangeOpen(true)}
        unclaimedMissionsCount={unclaimedMissionsCount}
        onOpenRules={() => setIsRulesOpen(true)}
      />

      {/* Main Game Content Area */}
      <main className="flex-1 pb-16">
        {activeTab === 'aviator' && (
          <AviaStar
            balance={player.balance}
            playerLevel={player.level}
            playerName={player.name}
            playerAvatar={player.avatar}
            playerRank={player.premiumRank}
            soundEnabled={player.soundEnabled}
            onBetPlaced={handleAviaBetPlaced}
            onWin={handleAviaWin}
            onLoss={handleAviaLoss}
          />
        )}

        {activeTab === 'missions' && (
          <MissionsView
            player={player}
            ownedCarsCount={ownedCars.length}
            ownedEstatesCount={ownedEstates.length}
            soundEnabled={player.soundEnabled}
            onClaimMission={handleClaimMission}
            onOpenExchangeModal={() => setIsCrystalExchangeOpen(true)}
          />
        )}

        {activeTab === 'rank_shop' && (
          <RankShopView
            player={player}
            soundEnabled={player.soundEnabled}
            onBuyRank={handleBuyRank}
            onExchangeMoneyForCrystals={handleExchangeMoneyForCrystals}
            onOpenExchangeModal={() => setIsCrystalExchangeOpen(true)}
          />
        )}

        {activeTab === 'inventory' && (
          <InventoryView
            player={player}
            ownedCars={ownedCars}
            ownedGarages={ownedGarages}
            ownedEstates={ownedEstates}
            ownedBusinesses={ownedBusinesses}
            ownedSecurity={ownedSecurity}
            ownedAccessories={player.equippedAccessories || []}
            cars={LUXURY_CARS}
            garages={LUXURY_GARAGES}
            estates={LUXURY_ESTATES}
            businesses={LUXURY_BUSINESSES}
            securityList={LUXURY_SECURITIES}
            accessories={LUXURY_ACCESSORIES}
            upgraders={upgraders}
            onNavigateToShop={() => setActiveTab('luxury')}
            onBuyEstate={handleBuyEstate}
          />
        )}

        {activeTab === 'sports' && (
          <SportsBetting
            balance={player.balance}
            soundEnabled={player.soundEnabled}
            onBetPlaced={handleMiniGameBet}
            onWin={handleMiniGameWin}
            onLoss={handleMiniGameLoss}
          />
        )}

        {activeTab === 'jobs' && (
          <JobsAndContracts
            playerLevel={player.level}
            balance={player.balance}
            soundEnabled={player.soundEnabled}
            jobs={INITIAL_JOBS}
            contracts={INITIAL_CONTRACTS}
            upgraders={upgraders}
            activeContracts={activeContracts}
            businesses={LUXURY_BUSINESSES}
            ownedBusinesses={ownedBusinesses}
            upgraderSecondsLeft={upgraderSecondsLeft}
            onWorkJob={handleWorkJob}
            onStartContract={handleStartContract}
            onClaimContract={handleClaimContract}
            onBuyUpgrader={handleBuyUpgrader}
            onBuyBusiness={handleBuyBusiness}
          />
        )}

        {activeTab === 'minigames' && (
          <MiniGames
            balance={player.balance}
            soundEnabled={player.soundEnabled}
            onBetPlaced={handleMiniGameBet}
            onWin={handleMiniGameWin}
            onLoss={handleMiniGameLoss}
          />
        )}

        {activeTab === 'trading' && (
          <TradingView
            balance={player.balance}
            portfolio={player.tradingPortfolio || {}}
            moneyMultiplier={rankMoneyMultiplier}
            onTrade={handleTrade}
          />
        )}

        {activeTab === 'luxury' && (
          <LuxuryShop
            balance={player.balance}
            soundEnabled={player.soundEnabled}
            garageCapacity={player.garageCapacity}
            ownedCars={ownedCars}
            ownedGarages={ownedGarages}
            ownedEstates={ownedEstates}
            ownedSecurity={ownedSecurity}
            ownedAccessories={player.equippedAccessories || []}
            cars={LUXURY_CARS}
            garages={LUXURY_GARAGES}
            estates={LUXURY_ESTATES}
            securityList={LUXURY_SECURITIES}
            accessories={LUXURY_ACCESSORIES}
            hasCustomWorkshop={player.hasCustomTuningWorkshop}
            workshopInventory={player.workshopInventory}
            carTunings={player.carTunings}
            onBuyCar={handleBuyCar}
            onBuyGarage={handleBuyGarage}
            onBuyEstate={handleBuyEstate}
            onBuySecurity={handleBuySecurity}
            onBuyAccessory={handleBuyAccessory}
            onTuneCar={handleTuneCar}
            onBuyWorkshopPart={handleBuyWorkshopPart}
            onBuyCustomWorkshop={handleBuyCustomWorkshop}
          />
        )}
      </main>

      {/* User Login & Registration Modal */}
      <AuthModal
        isOpen={!currentUser || isAuthModalOpen}
        soundEnabled={player.soundEnabled}
        onLoginSuccess={handleLoginSuccess}
        onRegisterSuccess={handleRegisterSuccess}
        accounts={accounts}
      />

      {/* Profile & Stats Modal */}
      {isProfileOpen && (
        <ProfileModal
          player={player}
          ownedCarsCount={ownedCars.length}
          onUpdateProfile={handleUpdateProfile}
          onResetGame={handleResetGame}
          onClose={() => setIsProfileOpen(false)}
        />
      )}

      {/* Level Up Celebration Modal */}
      {levelUpData && (
        <LevelUpModal
          level={levelUpData.level}
          bonusCash={levelUpData.bonus}
          onClaim={() => {
            playCashSound(player.soundEnabled);
            setLevelUpData(null);
          }}
        />
      )}

      {/* Crystal Currency Exchange Modal */}
      <CrystalExchangeModal
        isOpen={isCrystalExchangeOpen}
        onClose={() => setIsCrystalExchangeOpen(false)}
        balance={player.balance}
        crystals={player.crystals || 0}
        soundEnabled={player.soundEnabled}
        onExchange={handleExchangeMoneyForCrystals}
      />

      {/* Rules & RP Guide Modal */}
      <RulesModal
        isOpen={isRulesOpen}
        onClose={() => setIsRulesOpen(false)}
        soundEnabled={player.soundEnabled}
      />

      {/* Floating Dividend Payout Toast */}
      {payoutToast && (
        <div className="fixed bottom-6 right-6 z-50 animate-bounce bg-emerald-950/95 border border-emerald-500/50 text-emerald-300 px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-3 backdrop-blur-md">
          <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
            <Zap className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="text-xs font-semibold text-slate-300">{payoutToast.message}</div>
            <div className="text-sm font-mono font-extrabold text-emerald-400">+{formatLari(payoutToast.amount, true)} ჩაირიცხა!</div>
          </div>
        </div>
      )}
    </div>
  );
}














