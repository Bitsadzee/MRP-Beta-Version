export type MonopolySpaceType = 'go' | 'property' | 'railroad' | 'utility' | 'tax' | 'chance' | 'community' | 'jail' | 'free' | 'goto-jail';
export type MonopolyStatus = 'playing' | 'won' | 'lost';

export interface MonopolySpace {
  id: number;
  name: string;
  type: MonopolySpaceType;
  color?: string;
  price?: number;
  rents?: number[];
  houseCost?: number;
}

export interface MonopolyPlayer {
  id: string;
  name: string;
  token: string;
  isHuman: boolean;
  position: number;
  money: number;
  jailTurns: number;
  jailFreeCards: number;
  bankrupt: boolean;
}

export interface MonopolyDeed {
  ownerId: string | null;
  houses: number;
  mortgaged: boolean;
}

export interface MonopolyTradeOffer {
  fromBotId: string;
  propertyId: number;
  cash: number;
}

export interface MonopolyGameState {
  players: MonopolyPlayer[];
  deeds: Record<number, MonopolyDeed>;
  currentPlayer: number;
  status: MonopolyStatus;
  message: string;
  history: string[];
  lastRoll: [number, number] | null;
  pendingPurchaseId: number | null;
  pendingBotTrade: MonopolyTradeOffer | null;
  consecutiveDoubles: number;
  extraTurnPending: boolean;
  botOfferAttempted: boolean;
  turn: number;
  payoutSettled: boolean;
}

const property = (id: number, name: string, color: string, price: number, rents: number[], houseCost: number): MonopolySpace =>
  ({ id, name, type: 'property', color, price, rents, houseCost });

const special = (id: number, name: string, type: MonopolySpaceType, price?: number): MonopolySpace =>
  ({ id, name, type, price });

export const MONOPOLY_BOARD: MonopolySpace[] = [
  special(0, 'საწყისი — GO', 'go'),
  property(1, 'რუსთაველის გამზირი', 'brown', 60, [2, 10, 30, 90, 160, 250], 50),
  special(2, 'საზოგადოების ფონდი', 'community'),
  property(3, 'აღმაშენებლის გამზირი', 'brown', 60, [4, 20, 60, 180, 320, 450], 50),
  special(4, 'საშემოსავლო გადასახადი', 'tax', 200),
  special(5, 'რკინიგზა — დიდუბე', 'railroad', 200),
  property(6, 'ვაკის პარკი', 'lightblue', 100, [6, 30, 90, 270, 400, 550], 50),
  special(7, 'შანსი', 'chance'),
  property(8, 'საბურთალოს ქუჩა', 'lightblue', 100, [6, 30, 90, 270, 400, 550], 50),
  property(9, 'ჭავჭავაძის გამზირი', 'lightblue', 120, [8, 40, 100, 300, 450, 600], 50),
  special(10, 'ციხე / სტუმრობა', 'jail'),
  property(11, 'თავისუფლების მოედანი', 'pink', 140, [10, 50, 150, 450, 625, 750], 100),
  special(12, 'ელექტროენერგიის კომპანია', 'utility', 150),
  property(13, 'მარჯანიშვილის ქუჩა', 'pink', 140, [10, 50, 150, 450, 625, 750], 100),
  property(14, 'ვერას უბანი', 'pink', 160, [12, 60, 180, 500, 700, 900], 100),
  special(15, 'რკინიგზა — სადგურის მოედანი', 'railroad', 200),
  property(16, 'მთაწმინდის ქუჩა', 'orange', 180, [14, 70, 200, 550, 750, 950], 100),
  special(17, 'საზოგადოების ფონდი', 'community'),
  property(18, 'სოლოლაკის ქუჩა', 'orange', 180, [14, 70, 200, 550, 750, 950], 100),
  property(19, 'ორბელიანის მოედანი', 'orange', 200, [16, 80, 220, 600, 800, 1000], 100),
  special(20, 'უფასო პარკინგი', 'free'),
  property(21, 'გუდიაშვილის მოედანი', 'red', 220, [18, 90, 250, 700, 875, 1050], 150),
  special(22, 'შანსი', 'chance'),
  property(23, 'დადიანის ქუჩა', 'red', 220, [18, 90, 250, 700, 875, 1050], 150),
  property(24, 'პეკინის გამზირი', 'red', 240, [20, 100, 300, 750, 925, 1100], 150),
  special(25, 'რკინიგზა — ნავთლუღი', 'railroad', 200),
  property(26, 'ბათუმის ბულვარი', 'yellow', 260, [22, 110, 330, 800, 975, 1150], 150),
  property(27, 'ევროპის მოედანი', 'yellow', 260, [22, 110, 330, 800, 975, 1150], 150),
  special(28, 'წყლის კომპანია', 'utility', 150),
  property(29, 'გონიოს სანაპირო', 'yellow', 280, [24, 120, 360, 850, 1025, 1200], 150),
  special(30, 'წადი ციხეში', 'goto-jail'),
  property(31, 'ძველი თბილისის კოშკები', 'green', 300, [26, 130, 390, 900, 1100, 1275], 200),
  property(32, 'ყაზბეგის კურორტი', 'green', 300, [26, 130, 390, 900, 1100, 1275], 200),
  special(33, 'საზოგადოების ფონდი', 'community'),
  property(34, 'ბაკურიანის შალე', 'green', 320, [28, 150, 450, 1000, 1200, 1400], 200),
  special(35, 'რკინიგზა — ბათუმი', 'railroad', 200),
  special(36, 'შანსი', 'chance'),
  property(37, 'ბილტმორის სასტუმრო', 'darkblue', 350, [35, 175, 500, 1100, 1300, 1500], 200),
  special(38, 'ფუფუნების გადასახადი', 'tax', 100),
  property(39, 'წყნეთის მამული', 'darkblue', 400, [50, 200, 600, 1400, 1700, 2000], 200)
];

export const MONOPOLY_GROUPS = MONOPOLY_BOARD
  .filter((space) => space.type === 'property')
  .reduce<Record<string, number[]>>((groups, space) => {
    const color = space.color || '';
    groups[color] = [...(groups[color] || []), space.id];
    return groups;
  }, {});

const pushLog = (game: MonopolyGameState, message: string) => {
  game.message = message;
  game.history = [message, ...game.history].slice(0, 12);
};

export const cloneMonopolyGame = (game: MonopolyGameState): MonopolyGameState => ({
  ...game,
  players: game.players.map((player) => ({ ...player })),
  deeds: Object.fromEntries(Object.entries(game.deeds).map(([id, deed]) => [id, { ...deed }])),
  history: [...game.history],
  lastRoll: game.lastRoll ? [...game.lastRoll] as [number, number] : null,
  pendingBotTrade: game.pendingBotTrade ? { ...game.pendingBotTrade } : null
});

export const createMonopolyGame = (playerName: string, startingMoney: number): MonopolyGameState => {
  const players: MonopolyPlayer[] = [
    { id: 'human', name: playerName || 'მოთამაშე', token: '🚗', isHuman: true, position: 0, money: Math.max(0, Math.floor(startingMoney)), jailTurns: 0, jailFreeCards: 0, bankrupt: false },
    { id: 'bot-nino', name: 'ნინო', token: '🐈', isHuman: false, position: 0, money: 1500, jailTurns: 0, jailFreeCards: 0, bankrupt: false },
    { id: 'bot-sandro', name: 'სანდრო', token: '🏎️', isHuman: false, position: 0, money: 1500, jailTurns: 0, jailFreeCards: 0, bankrupt: false },
    { id: 'bot-luka', name: 'ლუკა', token: '🎩', isHuman: false, position: 0, money: 1500, jailTurns: 0, jailFreeCards: 0, bankrupt: false }
  ];
  const deeds = Object.fromEntries(MONOPOLY_BOARD.filter((space) => ['property', 'railroad', 'utility'].includes(space.type)).map((space) => [space.id, { ownerId: null, houses: 0, mortgaged: false }]));
  return {
    players,
    deeds,
    currentPlayer: 0,
    status: 'playing',
    message: 'შენი ჯერია — გააგორე კამათელი.',
    history: ['თამაში დაიწყო. თითოეულ მოთამაშეს აქვს თავისი ფული; GO-ზე გასვლისას მიიღებ ₾200-ს.'],
    lastRoll: null,
    pendingPurchaseId: null,
    pendingBotTrade: null,
    consecutiveDoubles: 0,
    extraTurnPending: false,
    botOfferAttempted: false,
    turn: 1,
    payoutSettled: false
  };
};

export const activePlayers = (game: MonopolyGameState) => game.players.filter((player) => !player.bankrupt);

export const completeSetOwnedBy = (game: MonopolyGameState, space: MonopolySpace, ownerId: string) => {
  if (!space.color) return false;
  const group = MONOPOLY_GROUPS[space.color] || [];
  return group.length > 0 && group.every((id) => game.deeds[id]?.ownerId === ownerId);
};

export const getMonopolyRent = (game: MonopolyGameState, space: MonopolySpace, diceTotal = 0) => {
  const deed = game.deeds[space.id];
  if (!deed || !deed.ownerId || deed.mortgaged) return 0;
  if (space.type === 'property') {
    const rent = space.rents?.[Math.min(deed.houses, 5)] || 0;
    return deed.houses === 0 && completeSetOwnedBy(game, space, deed.ownerId) ? rent * 2 : rent;
  }
  if (space.type === 'railroad') {
    const count = MONOPOLY_BOARD.filter((tile) => tile.type === 'railroad' && game.deeds[tile.id]?.ownerId === deed.ownerId && !game.deeds[tile.id]?.mortgaged).length;
    return [0, 25, 50, 100, 200][count] || 0;
  }
  if (space.type === 'utility') {
    const count = MONOPOLY_BOARD.filter((tile) => tile.type === 'utility' && game.deeds[tile.id]?.ownerId === deed.ownerId && !game.deeds[tile.id]?.mortgaged).length;
    return diceTotal * (count > 1 ? 10 : 4);
  }
  return 0;
};

export const getBuildGroup = (space: MonopolySpace) => space.color ? MONOPOLY_GROUPS[space.color] || [] : [];

export const canBuildMonopolyHouse = (game: MonopolyGameState, spaceId: number, ownerId: string) => {
  const space = MONOPOLY_BOARD[spaceId];
  const deed = game.deeds[spaceId];
  if (!space || space.type !== 'property' || !deed || deed.ownerId !== ownerId || deed.mortgaged || deed.houses >= 5) return false;
  const group = getBuildGroup(space);
  if (!group.length || !group.every((id) => game.deeds[id]?.ownerId === ownerId && !game.deeds[id]?.mortgaged)) return false;
  const minimumHouses = Math.min(...group.map((id) => game.deeds[id]?.houses || 0));
  return deed.houses <= minimumHouses;
};

export const resolveMonopolyPayment = (game: MonopolyGameState, payerIndex: number, amount: number, creditorId: string | null) => {
  const payer = game.players[payerIndex];
  if (!payer || payer.bankrupt) return;
  const payment = Math.max(0, Math.floor(amount));
  const creditor = creditorId ? game.players.find((player) => player.id === creditorId && !player.bankrupt) : undefined;
  if (payer.money >= payment) {
    payer.money -= payment;
    if (creditor) creditor.money += payment;
    return;
  }
  if (creditor) creditor.money += payer.money;
  payer.money = 0;
  payer.bankrupt = true;
  Object.values(game.deeds).forEach((deed) => {
    if (deed.ownerId === payer.id) {
      deed.ownerId = creditor?.id || null;
      deed.houses = 0;
      deed.mortgaged = false;
    }
  });
  pushLog(game, payer.isHuman ? 'გადახდას ვერ გასწვდი — გაკოტრდი.' : payer.name + ' გაკოტრდა; მისი ქონება კრედიტორს გადაეცა.');
  const alive = activePlayers(game);
  if (payer.isHuman) game.status = 'lost';
  else if (alive.length <= 1) game.status = alive[0]?.isHuman ? 'won' : 'lost';
};

type MonopolyCard = { text: string; amount?: number; moveTo?: number; jail?: boolean; fromEach?: number };

const chanceCards: MonopolyCard[] = [
  { text: 'შანსი: მიიღო ₾100 — აქციების გაყიდვა გაგიმართლა.', amount: 100 },
  { text: 'შანსი: გადაიხადე ₾50 — გზის ჯარიმა.', amount: -50 },
  { text: 'შანსი: მიიღო ₾150 — ბანკმა ბონუსი ჩაგირიცხა.', amount: 150 },
  { text: 'შანსი: გადაიხადე ₾75 — სარემონტო ხარჯი.', amount: -75 },
  { text: 'შანსი: გადადი GO-ზე და მიიღე ₾200.', moveTo: 0 },
  { text: 'შანსი: წადი ციხეში — შემდეგ სვლას იქ გაატარებ.', jail: true }
];

const communityCards: MonopolyCard[] = [
  { text: 'ფონდი: მიიღო ₾100 — საზოგადოებამ დაგაჯილდოვა.', amount: 100 },
  { text: 'ფონდი: მიიღო ₾50 — გადასახადი დაგიბრუნდა.', amount: 50 },
  { text: 'ფონდი: გადაიხადე ₾50 — საერთო ხარჯი.', amount: -50 },
  { text: 'ფონდი: მიიღო ₾25 თითოეული მოთამაშისგან.', fromEach: 25 },
  { text: 'ფონდი: გადაიხადე ₾40 — დღესასწაულის ხარჯი.', amount: -40 },
  { text: 'ფონდი: წადი ციხეში — შემდეგ სვლას იქ გაატარებ.', jail: true }
];

const sendToJail = (game: MonopolyGameState, player: MonopolyPlayer, reason: string) => {
  player.position = 10;
  player.jailTurns = 3;
  game.consecutiveDoubles = 0;
  pushLog(game, player.name + ' ციხეშია. ' + reason);
};

export const resolveMonopolyLanding = (game: MonopolyGameState, playerIndex: number, diceTotal: number): number | null => {
  const player = game.players[playerIndex];
  const space = MONOPOLY_BOARD[player.position];
  if (!player || !space) return null;
  if (space.type === 'property' || space.type === 'railroad' || space.type === 'utility') {
    const deed = game.deeds[space.id];
    if (!deed?.ownerId) return space.id;
    if (deed.ownerId !== player.id) {
      const rent = getMonopolyRent(game, space, diceTotal);
      const creditorIndex = game.players.findIndex((owner) => owner.id === deed.ownerId);
      resolveMonopolyPayment(game, playerIndex, rent, creditorIndex >= 0 ? deed.ownerId : null);
      if (rent > 0 && !player.bankrupt) pushLog(game, player.name + ' ₾' + rent + ' ქირა გადაიხადა — ' + space.name + '.');
    } else {
      pushLog(game, player.name + ' საკუთარ ქონებაზე გაჩერდა.');
    }
    return null;
  }
  if (space.type === 'tax') {
    resolveMonopolyPayment(game, playerIndex, space.price || 0, null);
    if (!player.bankrupt) pushLog(game, player.name + ' ₾' + space.price + ' გადასახადი გადაიხადა.');
    return null;
  }
  if (space.type === 'chance' || space.type === 'community') {
    const cards = space.type === 'chance' ? chanceCards : communityCards;
    const card = cards[Math.floor(Math.random() * cards.length)];
    if (card.jail) {
      sendToJail(game, player, card.text);
    } else if (card.moveTo !== undefined) {
      player.position = card.moveTo;
      player.money += 200;
      pushLog(game, card.text);
      resolveMonopolyLanding(game, playerIndex, diceTotal);
    } else if (card.fromEach) {
      game.players.forEach((other, index) => {
        if (index !== playerIndex && !other.bankrupt) resolveMonopolyPayment(game, index, card.fromEach || 0, player.id);
      });
      pushLog(game, card.text);
    } else if ((card.amount || 0) < 0) {
      resolveMonopolyPayment(game, playerIndex, Math.abs(card.amount || 0), null);
      if (!player.bankrupt) pushLog(game, card.text);
    } else {
      player.money += card.amount || 0;
      pushLog(game, card.text);
    }
    return null;
  }
  if (space.type === 'goto-jail') sendToJail(game, player, 'სამი სვლა გამოტოვე ან გადაიხადე ₾50 გასათავისუფლებლად.');
  else if (space.type === 'go') pushLog(game, player.name + ' GO-ზე გაჩერდა.');
  else if (space.type === 'jail') pushLog(game, player.name + ' ციხის სტუმრობის ველზე გაჩერდა.');
  else if (space.type === 'free') pushLog(game, 'უფასო პარკინგი — სვლა უსაფრთხოდ დასრულდა.');
  return null;
};

export const moveMonopolyPlayer = (game: MonopolyGameState, playerIndex: number, distance: number, fromCard = false) => {
  const player = game.players[playerIndex];
  const oldPosition = player.position;
  const nextPosition = (oldPosition + distance) % MONOPOLY_BOARD.length;
  if (!fromCard && oldPosition + distance >= MONOPOLY_BOARD.length) {
    player.money += 200;
    pushLog(game, player.name + ' GO-ს გაიარა და ₾200 მიიღო.');
  }
  player.position = nextPosition;
  return resolveMonopolyLanding(game, playerIndex, game.lastRoll ? game.lastRoll[0] + game.lastRoll[1] : distance);
};

export const advanceMonopolyTurn = (game: MonopolyGameState, extraTurn = false) => {
  game.pendingPurchaseId = null;
  game.pendingBotTrade = null;
  game.botOfferAttempted = false;
  game.extraTurnPending = extraTurn;
  game.consecutiveDoubles = extraTurn ? game.consecutiveDoubles : 0;
  if (!extraTurn) {
    let next = game.currentPlayer;
    for (let tries = 0; tries < game.players.length; tries += 1) {
      next = (next + 1) % game.players.length;
      if (!game.players[next].bankrupt) break;
    }
    game.currentPlayer = next;
    game.turn += 1;
  }
  if (game.players.filter((player) => !player.bankrupt).length <= 1) {
    game.status = game.players[0].bankrupt ? 'lost' : 'won';
  }
};
