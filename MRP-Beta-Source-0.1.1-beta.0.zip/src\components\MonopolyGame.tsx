import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowRightLeft, Banknote, Building2, Check, Clock3, Coins, Dice5, DollarSign,
  Handshake, House, Landmark, RotateCcw, ShieldCheck, Sparkles, Trophy, Users, X
} from 'lucide-react';
import {
  activePlayers, advanceMonopolyTurn, canBuildMonopolyHouse, cloneMonopolyGame,
  completeSetOwnedBy, createMonopolyGame, getBuildGroup, getMonopolyRent,
  MONOPOLY_BOARD, MonopolyGameState, MonopolyPlayer, MonopolySpace,
  moveMonopolyPlayer, resolveMonopolyLanding, resolveMonopolyPayment
} from '../utils/monopoly';

interface MonopolySave {
  bankroll: number;
  game: MonopolyGameState | null;
  lastPayout: number;
}

interface MonopolyGameProps {
  playerName: string;
  saveKey: string;
  mainBalance: number;
  onDeposit: (amount: number) => void;
  onPayout: (amount: number) => void;
}

const INITIAL_MONOPOLY_BANKROLL = 1500;
const SAVE_PREFIX = 'mrp_monopoly_v1_';
const DEFAULT_SAVE: MonopolySave = { bankroll: INITIAL_MONOPOLY_BANKROLL, game: null, lastPayout: 0 };
const GROUP_COLORS: Record<string, string> = {
  brown: '#9b6b43', lightblue: '#77d7e8', pink: '#d879b9', orange: '#f29149',
  red: '#e34b5a', yellow: '#f3ce51', green: '#58b879', darkblue: '#526be0'
};
const formatMoney = (amount: number) => '₾' + Math.max(0, Math.floor(amount)).toLocaleString('ka-GE');

const storageKey = (account: string) => SAVE_PREFIX + encodeURIComponent(account.trim().toLowerCase());

const readSave = (account: string): MonopolySave => {
  try {
    const raw = localStorage.getItem(storageKey(account));
    if (!raw) return { ...DEFAULT_SAVE };
    const saved = JSON.parse(raw) as Partial<MonopolySave>;
    return {
      bankroll: Number.isFinite(saved.bankroll) ? Math.max(0, Number(saved.bankroll)) : INITIAL_MONOPOLY_BANKROLL,
      game: saved.game || null,
      lastPayout: Number.isFinite(saved.lastPayout) ? Math.max(0, Number(saved.lastPayout)) : 0
    };
  } catch {
    return { ...DEFAULT_SAVE };
  }
};

const boardPosition = (id: number): { row: number; column: number } => {
  if (id === 0) return { row: 11, column: 11 };
  if (id < 10) return { row: 11, column: 11 - id };
  if (id === 10) return { row: 11, column: 1 };
  if (id < 20) return { row: 21 - id, column: 1 };
  if (id === 20) return { row: 1, column: 1 };
  if (id < 30) return { row: 1, column: id - 19 };
  if (id === 30) return { row: 1, column: 11 };
  return { row: id - 29, column: 11 };
};

const deedValue = (space: MonopolySpace) => Math.max(20, Math.floor((space.price || 0) * 0.9));

const pushMessage = (game: MonopolyGameState, message: string) => {
  game.message = message;
  game.history = [message, ...game.history].slice(0, 12);
};

const goToJail = (game: MonopolyGameState, player: MonopolyPlayer, message: string) => {
  player.position = 10;
  player.jailTurns = 3;
  game.extraTurnPending = false;
  game.consecutiveDoubles = 0;
  pushMessage(game, player.name + ' ციხეშია. ' + message);
};

const makeBotOffer = (game: MonopolyGameState, bot: MonopolyPlayer) => {
  const human = game.players[0];
  const wants = MONOPOLY_BOARD.filter((space) => {
    const deed = game.deeds[space.id];
    if (!deed || deed.ownerId !== human.id || deed.houses > 0 || deed.mortgaged) return false;
    if (!space.color) return false;
    const group = getBuildGroup(space);
    return group.some((id) => game.deeds[id]?.ownerId === bot.id);
  });
  for (const space of wants) {
    const group = getBuildGroup(space);
    const botGroupPieces = group.filter((id) => game.deeds[id]?.ownerId === bot.id).length;
    const offer = Math.min(Math.floor(bot.money - 180), Math.floor((space.price || 0) * (botGroupPieces === group.length - 1 ? 1.5 : 1.1)));
    if (offer >= Math.floor((space.price || 0) * 0.9)) return { fromBotId: bot.id, propertyId: space.id, cash: offer };
  }
  return null;
};

export const MonopolyGame: React.FC<MonopolyGameProps> = ({ playerName, saveKey, mainBalance, onDeposit, onPayout }) => {
  const [saved, setSaved] = useState<MonopolySave>(() => readSave(saveKey));
  const [loadedFor, setLoadedFor] = useState(saveKey);
  const [depositAmount, setDepositAmount] = useState('500');
  const [selectedSpaceId, setSelectedSpaceId] = useState(0);
  const [tradeTargetId, setTradeTargetId] = useState('');
  const [givePropertyId, setGivePropertyId] = useState('');
  const [wantPropertyId, setWantPropertyId] = useState('');
  const [giveCash, setGiveCash] = useState('0');
  const [wantCash, setWantCash] = useState('0');
  const [tradeFeedback, setTradeFeedback] = useState('');

  useEffect(() => {
    setSaved(readSave(saveKey));
    setLoadedFor(saveKey);
    setTradeFeedback('');
  }, [saveKey]);

  useEffect(() => {
    if (loadedFor !== saveKey) return;
    try {
      localStorage.setItem(storageKey(saveKey), JSON.stringify(saved));
    } catch {
      // Keep the match usable if local storage is unavailable.
    }
  }, [saved, saveKey, loadedFor]);

  const game = saved.game;
  const current = game?.players[game.currentPlayer];
  const human = game?.players[0];
  const isHumanTurn = !!game && game.status === 'playing' && game.currentPlayer === 0 && !game.pendingBotTrade;
  const selectedSpace = MONOPOLY_BOARD[selectedSpaceId] || MONOPOLY_BOARD[0];
  const selectedDeed = game?.deeds[selectedSpace.id];
  const owner = selectedDeed?.ownerId ? game?.players.find((player) => player.id === selectedDeed.ownerId) : undefined;
  const humanProperties = useMemo(() => game ? MONOPOLY_BOARD.filter((space) => game.deeds[space.id]?.ownerId === 'human') : [], [game]);
  const botProperties = useMemo(() => {
    if (!game || !tradeTargetId) return [];
    return MONOPOLY_BOARD.filter((space) => game.deeds[space.id]?.ownerId === tradeTargetId && game.deeds[space.id]?.houses === 0 && !game.deeds[space.id]?.mortgaged);
  }, [game, tradeTargetId]);

  const commitGame = (next: MonopolyGameState) => {
    let nextBankroll = next.players[0]?.money || 0;
    let nextPayout = saved.lastPayout;
    if (next.status === 'won') {
      if (!next.payoutSettled) {
        nextPayout = Math.floor(Math.max(0, next.players[0]?.money || 0) / 2);
        next.payoutSettled = true;
        if (nextPayout > 0) onPayout(nextPayout);
      } else {
        nextPayout = saved.lastPayout;
      }
      nextBankroll = Math.max(0, (next.players[0]?.money || 0) - nextPayout);
    } else if (next.status === 'lost') {
      nextBankroll = 0;
    }
    setSaved((previous) => ({ ...previous, bankroll: nextBankroll, game: next, lastPayout: nextPayout }));
  };

  const depositToBank = () => {
    const amount = Math.floor(Number(depositAmount));
    if (!Number.isFinite(amount) || amount < 50 || amount > mainBalance || game?.status === 'playing') return;
    onDeposit(amount);
    setSaved((previous) => ({ ...previous, bankroll: previous.bankroll + amount }));
  };

  const startNewGame = () => {
    if (saved.bankroll < 300) return;
    setTradeFeedback('');
    setSelectedSpaceId(0);
    setSaved((previous) => ({
      ...previous,
      game: createMonopolyGame(playerName, previous.bankroll),
      lastPayout: 0
    }));
  };

  const finishTurn = (next: MonopolyGameState, extraTurn = false) => {
    advanceMonopolyTurn(next, extraTurn);
    if (next.status === 'playing') {
      const player = next.players[next.currentPlayer];
      pushMessage(next, player.isHuman ? 'შენი ჯერია — გააგორე კამათელი.' : player.name + ' ფიქრობს სვლაზე…');
    }
    commitGame(next);
  };

  const rollForHuman = (payJailFee = false) => {
    if (!game || !isHumanTurn || game.pendingPurchaseId !== null || (game.lastRoll !== null && !game.extraTurnPending)) return;
    const next = cloneMonopolyGame(game);
    const player = next.players[0];
    const die1 = Math.floor(Math.random() * 6) + 1;
    const die2 = Math.floor(Math.random() * 6) + 1;
    const total = die1 + die2;
    const doubles = die1 === die2;
    next.lastRoll = [die1, die2];

    if (player.jailTurns > 0 && payJailFee) {
      if (player.money < 50) return;
      player.money -= 50;
      player.jailTurns = 0;
      next.consecutiveDoubles = 0;
      pushMessage(next, '₾50 გადაიხადე და ციხიდან გამოხვედი.');
      const pending = moveMonopolyPlayer(next, 0, total);
      next.pendingPurchaseId = pending;
      next.extraTurnPending = false;
      commitGame(next);
      return;
    }

    if (player.jailTurns > 0) {
      if (doubles) {
        player.jailTurns = 0;
        next.consecutiveDoubles = 0;
        pushMessage(next, 'ორმაგი გაგორდა — ციხიდან გამოხვედი.');
        next.pendingPurchaseId = moveMonopolyPlayer(next, 0, total);
        next.extraTurnPending = false;
        commitGame(next);
        return;
      }
      player.jailTurns -= 1;
      if (player.jailTurns <= 0) {
        if (player.money >= 50) {
          player.money -= 50;
          player.jailTurns = 0;
          pushMessage(next, 'სამი მცდელობა ამოიწურა — ₾50 გადაიხადე და ციხიდან გამოხვედი. შემდეგ სვლაზე გააგორებ.');
        } else {
          resolveMonopolyPayment(next, 0, 50, null);
        }
      } else {
        pushMessage(next, 'ორმაგი ვერ გაგორდა — ციხეში კიდევ ' + player.jailTurns + ' სვლა რჩები.');
      }
      next.lastRoll = null;
      next.extraTurnPending = false;
      finishTurn(next, false);
      return;
    }

    if (doubles && next.extraTurnPending && next.consecutiveDoubles >= 2) {
      goToJail(next, player, 'ერთ სვლაში ზედიზედ სამი დუბლი გაგორდა.');
      next.lastRoll = [die1, die2];
      next.extraTurnPending = false;
      finishTurn(next, false);
      return;
    }

    next.consecutiveDoubles = doubles ? (next.extraTurnPending ? next.consecutiveDoubles + 1 : 1) : 0;
    next.extraTurnPending = doubles;
    const pending = moveMonopolyPlayer(next, 0, total);
    next.pendingPurchaseId = pending;
    if (next.status === 'playing' && pending === null) {
      pushMessage(next, 'გააგორე ' + die1 + ' + ' + die2 + ' = ' + total + '. აირჩიე ქონება, ივაჭრე ან დაასრულე სვლა.');
    }
    commitGame(next);
  };

  const buyProperty = () => {
    if (!game || !isHumanTurn || game.pendingPurchaseId === null) return;
    const propertyId = game.pendingPurchaseId;
    const next = cloneMonopolyGame(game);
    const space = MONOPOLY_BOARD[propertyId];
    const player = next.players[0];
    const deed = next.deeds[space.id];
    if (!space || !deed || deed.ownerId || player.money < (space.price || 0)) return;
    player.money -= space.price || 0;
    deed.ownerId = player.id;
    next.pendingPurchaseId = null;
    pushMessage(next, space.name + ' იყიდე ₾' + space.price + '-ად.');
    commitGame(next);
  };

  const runAuction = (next: MonopolyGameState, spaceId: number) => {
    const space = MONOPOLY_BOARD[spaceId];
    const price = space.price || 0;
    const candidates = next.players.map((bot, index) => ({ bot, index })).filter(({ bot }) => !bot.isHuman && !bot.bankrupt && bot.money >= price);
    candidates.sort((a, b) => {
      const aCompletes = space.color ? (getBuildGroup(space).filter((id) => next.deeds[id]?.ownerId === a.bot.id).length > 0 ? 1 : 0) : 0;
      const bCompletes = space.color ? (getBuildGroup(space).filter((id) => next.deeds[id]?.ownerId === b.bot.id).length > 0 ? 1 : 0) : 0;
      return bCompletes - aCompletes || b.bot.money - a.bot.money;
    });
    const winner = candidates.find(({ bot }) => bot.money - price >= 120 || price < 120);
    if (!winner) {
      pushMessage(next, 'ქონება აუქციონზე გავიდა, მაგრამ მყიდველი ვერ გამოჩნდა.');
      return;
    }
    winner.bot.money -= price;
    next.deeds[space.id].ownerId = winner.bot.id;
    pushMessage(next, 'აუქციონზე ' + winner.bot.name + '-მა ' + space.name + ' ₾' + price + '-ად შეიძინა.');
  };

  const passProperty = () => {
    if (!game || game.pendingPurchaseId === null || !isHumanTurn) return;
    const propertyId = game.pendingPurchaseId;
    const next = cloneMonopolyGame(game);
    next.pendingPurchaseId = null;
    runAuction(next, propertyId);
    commitGame(next);
  };

  const buildHouse = (spaceId: number) => {
    if (!game || !human || !isHumanTurn || !canBuildMonopolyHouse(game, spaceId, human.id)) return;
    const next = cloneMonopolyGame(game);
    const space = MONOPOLY_BOARD[spaceId];
    const cost = space.houseCost || 0;
    if (next.players[0].money < cost) return;
    next.players[0].money -= cost;
    next.deeds[spaceId].houses += 1;
    pushMessage(next, space.name + ' — ' + (next.deeds[spaceId].houses === 5 ? 'სასტუმრო ააშენე' : 'სახლი ააშენე') + ' ₾' + cost + '-ად.');
    commitGame(next);
  };

  const mortgageProperty = (spaceId: number) => {
    if (!game || !human || !isHumanTurn) return;
    const next = cloneMonopolyGame(game);
    const deed = next.deeds[spaceId];
    const space = MONOPOLY_BOARD[spaceId];
    if (!deed || !space || deed.ownerId !== human.id || deed.houses > 0) return;
    if (deed.mortgaged) {
      const cost = Math.ceil((space.price || 0) * 0.55);
      if (next.players[0].money < cost) return;
      next.players[0].money -= cost;
      deed.mortgaged = false;
      pushMessage(next, space.name + ' გამოისყიდე ₾' + cost + '-ად.');
    } else {
      const value = Math.floor((space.price || 0) / 2);
      next.players[0].money += value;
      deed.mortgaged = true;
      pushMessage(next, space.name + ' დააგირავე და ₾' + value + ' მიიღე.');
    }
    commitGame(next);
  };

  const completeTrade = () => {
    if (!game || !isHumanTurn) return;
    const next = cloneMonopolyGame(game);
    const botIndex = next.players.findIndex((player) => player.id === tradeTargetId && !player.bankrupt);
    const bot = next.players[botIndex];
    const humanPlayer = next.players[0];
    const offeredCash = Math.max(0, Math.floor(Number(giveCash) || 0));
    const requestedCash = Math.max(0, Math.floor(Number(wantCash) || 0));
    const offeredSpace = givePropertyId ? MONOPOLY_BOARD[Number(givePropertyId)] : null;
    const requestedSpace = wantPropertyId ? MONOPOLY_BOARD[Number(wantPropertyId)] : null;
    if (!bot || botIndex < 1 || offeredCash > humanPlayer.money || requestedCash > bot.money) {
      setTradeFeedback('შეთავაზებაში ფული ან მოთამაშე არასწორადაა მითითებული.');
      return;
    }
    if (!offeredSpace && !requestedSpace && offeredCash === 0 && requestedCash === 0) {
      setTradeFeedback('შეთავაზებაში ფული ან ქონება დაამატე.');
      return;
    }
    if (offeredSpace && (next.deeds[offeredSpace.id]?.ownerId !== humanPlayer.id || next.deeds[offeredSpace.id].houses > 0 || next.deeds[offeredSpace.id].mortgaged)) return;
    if (requestedSpace && (next.deeds[requestedSpace.id]?.ownerId !== bot.id || next.deeds[requestedSpace.id].houses > 0 || next.deeds[requestedSpace.id].mortgaged)) return;

    const botReceives = offeredCash + (offeredSpace ? deedValue(offeredSpace) : 0);
    const botPays = requestedCash + (requestedSpace ? deedValue(requestedSpace) : 0);
    const requestCompletesBotSet = requestedSpace?.color
      ? getBuildGroup(requestedSpace).filter((id) => next.deeds[id]?.ownerId === bot.id).length === getBuildGroup(requestedSpace).length - 1
      : false;
    const offerCompletesHumanSet = offeredSpace?.color
      ? getBuildGroup(offeredSpace).filter((id) => next.deeds[id]?.ownerId === humanPlayer.id).length === getBuildGroup(offeredSpace).length - 1
      : false;
    const botValue = botReceives * (requestCompletesBotSet ? 1.5 : 1.1);
    const botCost = botPays * (offerCompletesHumanSet ? 1.55 : 1.05);
    const accepts = bot.money - requestedCash + offeredCash >= 150 && botValue >= botCost * 1.08;

    if (!accepts) {
      setTradeFeedback(bot.name + '-მა შეთავაზება არ მიიღო — მისთვის გაცვლა საკმარისად მომგებიანი არ იყო.');
      return;
    }

    humanPlayer.money = humanPlayer.money - offeredCash + requestedCash;
    bot.money = bot.money + offeredCash - requestedCash;
    if (offeredSpace) next.deeds[offeredSpace.id].ownerId = bot.id;
    if (requestedSpace) next.deeds[requestedSpace.id].ownerId = humanPlayer.id;
    pushMessage(next, 'გარიგება შედგა: ' + bot.name + ' დაეთანხმა შენს შეთავაზებას.');
    setTradeFeedback(bot.name + '-მა შეთავაზება მიიღო. ქონება და თანხა გაცვალეთ.');
    setGiveCash('0');
    setWantCash('0');
    setGivePropertyId('');
    setWantPropertyId('');
    commitGame(next);
  };

  const answerBotTrade = (accept: boolean) => {
    if (!game?.pendingBotTrade) return;
    const next = cloneMonopolyGame(game);
    const offer = next.pendingBotTrade;
    if (!offer) return;
    const bot = next.players.find((player) => player.id === offer?.fromBotId);
    const space = MONOPOLY_BOARD[offer.propertyId];
    if (accept && bot && space && next.deeds[space.id]?.ownerId === 'human' && bot.money >= offer.cash) {
      bot.money -= offer.cash;
      next.players[0].money += offer.cash;
      next.deeds[space.id].ownerId = bot.id;
      pushMessage(next, bot.name + '-ის შეთავაზება მიიღე: ' + space.name + ' ₾' + offer.cash + '-ად გაყიდე.');
    } else {
      pushMessage(next, accept ? 'გარიგება ვეღარ შედგა.' : bot?.name + '-ის შეთავაზება უარყავი.');
    }
    next.pendingBotTrade = null;
    commitGame(next);
  };

  const useJailCard = () => {
    if (!game || !human || !isHumanTurn || human.jailTurns <= 0 || human.jailFreeCards <= 0) return;
    const next = cloneMonopolyGame(game);
    next.players[0].jailFreeCards -= 1;
    next.players[0].jailTurns = 0;
    pushMessage(next, 'თავისუფლების ბარათი გამოიყენე — ციხიდან გამოხვედი. გააგორე კამათელი.');
    next.lastRoll = null;
    commitGame(next);
  };

  const endHumanTurn = () => {
    if (!game || !isHumanTurn || game.pendingPurchaseId !== null || game.pendingBotTrade || !game.lastRoll || game.extraTurnPending) return;
    finishTurn(cloneMonopolyGame(game), false);
  };

  const runBotTurn = (snapshot: MonopolyGameState) => {
    if (snapshot.status !== 'playing') return;
    const next = cloneMonopolyGame(snapshot);
    const playerIndex = next.currentPlayer;
    const bot = next.players[playerIndex];
    if (!bot || bot.isHuman || bot.bankrupt || next.pendingBotTrade) return;

    if (!next.botOfferAttempted) {
      next.botOfferAttempted = true;
      if (Math.random() < 0.34) {
        const offer = makeBotOffer(next, bot);
        if (offer) {
          next.pendingBotTrade = offer;
          const space = MONOPOLY_BOARD[offer.propertyId];
          pushMessage(next, bot.name + ' გთავაზობს ' + space.name + '-ში ₾' + offer.cash + '-ს.');
          commitGame(next);
          return;
        }
      }
    }

    if (bot.jailTurns > 0) {
      if (bot.jailFreeCards > 0) {
        bot.jailFreeCards -= 1;
        bot.jailTurns = 0;
        pushMessage(next, bot.name + ' თავისუფლების ბარათი გამოიყენა.');
      } else {
        const die1 = Math.floor(Math.random() * 6) + 1;
        const die2 = Math.floor(Math.random() * 6) + 1;
        next.lastRoll = [die1, die2];
        if (die1 === die2) {
          bot.jailTurns = 0;
          next.consecutiveDoubles = 0;
          next.pendingPurchaseId = moveMonopolyPlayer(next, playerIndex, die1 + die2);
        } else {
          bot.jailTurns -= 1;
          if (bot.jailTurns <= 0) {
            if (bot.money >= 50) {
              bot.money -= 50;
              bot.jailTurns = 0;
              pushMessage(next, bot.name + ' სამი უშედეგო მცდელობის შემდეგ ₾50 გადაიხადა.');
            } else {
              resolveMonopolyPayment(next, playerIndex, 50, null);
            }
          } else {
            pushMessage(next, bot.name + ' ციხეში დარჩა.');
          }
        }
        next.extraTurnPending = false;
        if (next.status === 'playing' && next.pendingPurchaseId !== null) {
          const space = MONOPOLY_BOARD[next.pendingPurchaseId];
          const deed = next.deeds[space.id];
          if (deed && !deed.ownerId && bot.money >= (space.price || 0) && (bot.money - (space.price || 0) > 150 || (space.price || 0) <= 100)) {
            bot.money -= space.price || 0;
            deed.ownerId = bot.id;
            pushMessage(next, bot.name + ' იყიდა ' + space.name + '.');
          }
          next.pendingPurchaseId = null;
        }
        finishTurn(next, false);
        return;
      }
    }

    const buildable = MONOPOLY_BOARD.filter((space) => canBuildMonopolyHouse(next, space.id, bot.id))
      .sort((a, b) => (b.rents?.[next.deeds[b.id].houses + 1] || 0) - (a.rents?.[next.deeds[a.id].houses + 1] || 0));
    const buildSpace = buildable[0];
    if (buildSpace && bot.money >= (buildSpace.houseCost || 0) * 3) {
      bot.money -= buildSpace.houseCost || 0;
      next.deeds[buildSpace.id].houses += 1;
      pushMessage(next, bot.name + ' სახლს აშენებს ' + buildSpace.name + '-ზე.');
    }

    const die1 = Math.floor(Math.random() * 6) + 1;
    const die2 = Math.floor(Math.random() * 6) + 1;
    const total = die1 + die2;
    const doubles = die1 === die2;
    next.lastRoll = [die1, die2];
    if (doubles && next.extraTurnPending && next.consecutiveDoubles >= 2) {
      goToJail(next, bot, 'ზედიზედ სამი დუბლი გაგორდა.');
      finishTurn(next, false);
      return;
    }
    next.consecutiveDoubles = doubles ? (next.extraTurnPending ? next.consecutiveDoubles + 1 : 1) : 0;
    next.extraTurnPending = doubles;
    const pending = moveMonopolyPlayer(next, playerIndex, total);
    if (pending !== null && next.status === 'playing') {
      const space = MONOPOLY_BOARD[pending];
      const price = space.price || 0;
      const deed = next.deeds[pending];
      const completesSet = !!space.color && getBuildGroup(space).filter((id) => next.deeds[id]?.ownerId === bot.id).length === getBuildGroup(space).length - 1;
      const shouldBuy = bot.money >= price && (bot.money - price >= 150 || completesSet || price <= 100);
      if (shouldBuy && deed && !deed.ownerId) {
        bot.money -= price;
        deed.ownerId = bot.id;
        pushMessage(next, bot.name + ' იყიდა ' + space.name + ' ₾' + price + '-ად.');
      } else {
        pushMessage(next, bot.name + ' ამჯერად ქონება არ იყიდა.');
      }
    }
    next.pendingPurchaseId = null;
    const extraTurn = doubles && bot.jailTurns === 0 && next.status === 'playing';
    finishTurn(next, extraTurn);
  };

  useEffect(() => {
    if (loadedFor !== saveKey || !game || game.status !== 'playing' || game.currentPlayer === 0 || game.pendingBotTrade || game.pendingPurchaseId !== null) return;
    const timer = window.setTimeout(() => runBotTurn(game), 950);
    return () => window.clearTimeout(timer);
  }, [game, loadedFor, saveKey]);

  const tradeEligible = isHumanTurn && !!human && game?.status === 'playing';
  const tradeCashOffer = Math.floor(Number(giveCash) || 0);
  const tradeCashRequest = Math.floor(Number(wantCash) || 0);
  const canOfferTrade = tradeEligible && !!tradeTargetId && (tradeCashOffer > 0 || tradeCashRequest > 0 || !!givePropertyId || !!wantPropertyId)
    && tradeCashOffer <= (human?.money || 0);

  const selectedRent = game ? getMonopolyRent(game, selectedSpace, game.lastRoll ? game.lastRoll[0] + game.lastRoll[1] : 7) : 0;
  const propertyOwned = !!game && !!human && selectedDeed?.ownerId === human.id;
  const tileTextColor = (color?: string) => color === 'yellow' || color === 'lightblue' ? 'text-slate-950' : 'text-white';

  return (
    <div className="mx-auto w-full max-w-[1600px] animate-fadeIn space-y-5 px-3 py-5 sm:px-5 sm:py-7 lg:px-8">
      <section className="relative overflow-hidden rounded-3xl border border-amber-300/20 bg-gradient-to-br from-[#18130d] via-[#111320] to-[#1b1120] p-5 shadow-[0_24px_80px_rgba(0,0,0,.4)] sm:p-7">
        <div className="pointer-events-none absolute -right-10 -top-20 h-64 w-64 rounded-full bg-amber-300/10 blur-3xl" />
        <div className="relative flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
          <div>
            <div className="mb-2 inline-flex items-center gap-2 rounded-full border border-amber-300/20 bg-amber-300/5 px-3 py-1 text-[10px] font-bold uppercase tracking-[.18em] text-amber-200">
              <Landmark className="h-3.5 w-3.5" /> კლასიკური სამაგიდო სტრატეგია
            </div>
            <h1 className="text-3xl font-black tracking-tight text-white sm:text-4xl">MRP <span className="bg-gradient-to-r from-amber-200 via-yellow-300 to-orange-300 bg-clip-text text-transparent">MONOPOLY</span></h1>
            <p className="mt-2 max-w-3xl text-xs leading-relaxed text-slate-400 sm:text-sm">ააშენე უძრავი ქონების იმპერია, შეაგროვე ფერადი ჯგუფები, მოითხოვე ქირა და ივაჭრე სამი სტრატეგიული ბოტის წინააღმდეგ. Monopoly-ის ბანკი ცალკეა; გამარჯვებისას დარჩენილი თანხის ნახევარი MRP-ის ბალანსზე ჩაირიცხება.</p>
          </div>
          <div className="grid grid-cols-2 gap-2 sm:gap-3">
            <div className="min-w-32 rounded-2xl border border-amber-300/15 bg-black/30 p-3 sm:p-4">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Monopoly-ის ბანკი</span>
              <strong className="mt-1 block text-lg font-black text-amber-200 sm:text-xl">{formatMoney(game?.status === 'playing' ? human?.money || 0 : saved.bankroll)}</strong>
            </div>
            <div className="min-w-32 rounded-2xl border border-emerald-300/15 bg-black/30 p-3 sm:p-4">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">MRP ბალანსი</span>
              <strong className="mt-1 block text-lg font-black text-emerald-300 sm:text-xl">{formatMoney(mainBalance)}</strong>
            </div>
          </div>
        </div>
        <div className="relative mt-4 flex flex-wrap gap-x-4 gap-y-1 border-t border-white/5 pt-3 text-[10px] text-slate-500">
          <span>საწყისი Monopoly ბანკი: ₾1,500</span><span>GO-ს გავლისას: +₾200</span><span>გამარჯვებისას: ბანკის დარჩენილი თანხის 50%</span>
        </div>
      </section>

      {!game || game.status !== 'playing' ? (
        <section className="mx-auto grid max-w-5xl gap-4 lg:grid-cols-[1.2fr_.8fr]">
          <div className="rounded-3xl border border-slate-800 bg-[#0d111a] p-5 shadow-xl sm:p-7">
            <div className="flex items-start gap-4">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border border-amber-300/20 bg-amber-300/10 text-3xl">🎲</div>
              <div><h2 className="text-xl font-black text-white">{game?.status === 'won' ? 'შენ გაიმარჯვე!' : game?.status === 'lost' ? 'პარტია დასრულდა' : 'აირჩიე სტრატეგია'}</h2>
                <p className="mt-1 text-sm leading-relaxed text-slate-400">{game?.message || 'ოთხი მოთამაშე, 40 ველი, ყიდვა, ქირა, აუქციონი, სახლები, სასტუმროები, იპოთეკა და გარიგებები.'}</p></div>
            </div>
            {saved.lastPayout > 0 && <div className="mt-5 flex items-center gap-3 rounded-2xl border border-emerald-400/20 bg-emerald-400/5 p-4"><Trophy className="h-5 w-5 text-emerald-300" /><div><div className="text-xs font-bold text-emerald-200">MRP-ზე ჩარიცხული გამარჯვების ჯილდო</div><div className="mt-1 text-xl font-black text-white">+{formatMoney(saved.lastPayout)}</div></div></div>}
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <button onClick={startNewGame} disabled={saved.bankroll < 300} className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-300 to-orange-400 px-5 py-3 text-sm font-black text-slate-950 shadow-lg shadow-amber-500/10 transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40">
                <Dice5 className="h-4 w-4" /> {game ? 'ახალი პარტიის დაწყება' : 'პარტიის დაწყება'}
              </button>
              {saved.bankroll < 300 && <span className="text-xs text-rose-300">ახალი პარტიისთვის Monopoly ბანკში მინიმუმ ₾300 გჭირდება.</span>}
            </div>
          </div>
          <div className="rounded-3xl border border-slate-800 bg-[#0d111a] p-5 shadow-xl sm:p-7">
            <div className="flex items-center gap-2 text-amber-200"><Coins className="h-5 w-5" /><h2 className="font-black text-white">ცალკე Monopoly ბანკი</h2></div>
            <p className="mt-2 text-xs leading-relaxed text-slate-400">ბანკის თანხა შენს MRP ანგარიშს არ ეხება. პარტიებს შორის თანხა ინახება. თუ შემცირდა, შეგიძლია MRP-დან გადაიტანო; გამარჯვებისას დარჩენილი თანხის ნახევარი უკან ჩაგერიცხება.</p>
            <div className="mt-4 rounded-2xl border border-slate-800 bg-slate-950/70 p-4">
              <label className="mb-2 block text-[10px] font-bold uppercase tracking-wider text-slate-500">ბანკში დამატება · MRP-დან Monopoly-ში</label>
              <div className="flex gap-2">
                <input type="number" min={50} max={mainBalance} step={50} value={depositAmount} onChange={(event) => setDepositAmount(event.target.value)} className="min-w-0 flex-1 rounded-xl border border-slate-700 bg-[#090d15] px-3 py-2.5 font-mono text-white outline-none focus:border-amber-300" />
                <button onClick={depositToBank} disabled={!!game && game.status === 'playing'} className="rounded-xl border border-amber-300/25 bg-amber-300/10 px-4 text-xs font-black text-amber-100 transition hover:bg-amber-300/20 disabled:opacity-40">გადატანა</button>
              </div>
              <div className="mt-2 flex justify-between text-[10px] text-slate-500"><span>მინიმუმი: ₾50</span><span>ხელმისაწვდომია: {formatMoney(mainBalance)}</span></div>
            </div>
          </div>
        </section>
      ) : (
        <>
          <section className="grid gap-4 xl:grid-cols-[minmax(0,1.55fr)_minmax(300px,.75fr)]">
            <div className="overflow-x-auto rounded-3xl border border-slate-800 bg-[#0b1018] p-2 shadow-2xl sm:p-4">
              <div className="relative mx-auto grid aspect-square min-w-[700px] max-w-[900px] grid-cols-11 grid-rows-11 gap-[3px] rounded-2xl border border-amber-200/15 bg-[#16150f] p-1.5 sm:gap-1.5 sm:p-2">
                {MONOPOLY_BOARD.map((space) => {
                  const point = boardPosition(space.id);
                  const deed = game.deeds[space.id];
                  const spaceOwner = deed?.ownerId ? game.players.find((player) => player.id === deed.ownerId) : undefined;
                  const tokens = game.players.filter((player) => !player.bankrupt && player.position === space.id);
                  const isSpecial = space.type !== 'property' && space.type !== 'railroad' && space.type !== 'utility';
                  const corner = [0, 10, 20, 30].includes(space.id);
                  const backColor = space.color ? GROUP_COLORS[space.color] : undefined;
                  return (
                    <button key={space.id} onClick={() => setSelectedSpaceId(space.id)} style={{ gridRow: point.row, gridColumn: point.column }}
                      className={'relative flex min-h-0 min-w-0 flex-col justify-between overflow-hidden rounded-md border p-1 text-left transition hover:z-10 hover:border-amber-200 ' + (selectedSpaceId === space.id ? 'border-amber-200 ring-1 ring-amber-200/70' : 'border-white/10') + (corner ? ' p-1.5 sm:p-2' : '') + (isSpecial ? ' bg-[#1d202a]' : ' bg-[#f0e5c1]')}>
                      {backColor && <div style={{ backgroundColor: backColor }} className="absolute inset-x-0 top-0 h-2 sm:h-3" />}
                      {spaceOwner && <div style={{ backgroundColor: backColor || '#e2e8f0' }} className="absolute inset-x-0 top-2 h-1 sm:top-3" />}
                      <span className={'mt-2 line-clamp-2 w-full text-center text-[7px] font-black leading-tight sm:mt-3 sm:text-[9px] ' + (isSpecial ? 'text-slate-200' : 'text-slate-900')}>{space.name}</span>
                      {!isSpecial && <span className="w-full text-center text-[7px] font-bold text-slate-800 sm:text-[8px]">{formatMoney(space.price || 0)}</span>}
                      {deed?.houses ? <span className="w-full text-center text-[8px] text-emerald-300">{deed.houses === 5 ? '🏨' : '🏠'.repeat(deed.houses)}</span> : null}
                      {tokens.length > 0 && <span className="flex w-full flex-wrap justify-center gap-0.5 text-[10px] sm:text-xs">{tokens.map((player) => <span key={player.id} title={player.name}>{player.token}</span>)}</span>}
                    </button>
                  );
                })}
                <div className="col-start-2 col-end-11 row-start-2 row-end-11 flex flex-col items-center justify-center overflow-hidden rounded-xl border border-amber-200/10 bg-[radial-gradient(ellipse_at_center,rgba(174,130,48,.16),rgba(12,15,22,.98)_68%)] p-5 text-center">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-amber-200/20 bg-amber-200/10 text-3xl">🎲</div>
                  <div className="mt-3 text-[10px] font-black uppercase tracking-[.24em] text-amber-200/75">MONOPOLY · თბილისი</div>
                  <h2 className="mt-2 max-w-md text-2xl font-black text-white">{current?.isHuman ? 'შენი სვლაა' : current?.name + ' ფიქრობს…'}</h2>
                  <p className="mt-2 max-w-lg text-xs leading-relaxed text-slate-300">{game.message}</p>
                  {game.lastRoll && <div className="mt-4 flex items-center gap-2"><span className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-lg font-black text-white">{game.lastRoll[0]}</span><span className="text-slate-500">+</span><span className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-lg font-black text-white">{game.lastRoll[1]}</span></div>}
                  <div className="mt-4 flex flex-wrap justify-center gap-2">
                    <button onClick={() => rollForHuman()} disabled={!isHumanTurn || game.pendingPurchaseId !== null || (!!game.lastRoll && !game.extraTurnPending)} className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-300 to-orange-400 px-4 py-2.5 text-xs font-black text-slate-950 transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-35"><Dice5 className="h-4 w-4" /> კამათლის გაგორება</button>
                    <button onClick={endHumanTurn} disabled={!isHumanTurn || game.pendingPurchaseId !== null || !game.lastRoll || game.extraTurnPending} className="rounded-xl border border-slate-600 bg-slate-900/80 px-4 py-2.5 text-xs font-bold text-slate-200 transition hover:border-amber-200/50 disabled:cursor-not-allowed disabled:opacity-35">სვლის დასრულება</button>
                  </div>
                  {game.pendingPurchaseId !== null && isHumanTurn && <div className="mt-4 flex flex-wrap justify-center gap-2 rounded-2xl border border-amber-200/20 bg-amber-200/5 p-3"><span className="w-full text-xs font-bold text-amber-100">{MONOPOLY_BOARD[game.pendingPurchaseId].name} — {formatMoney(MONOPOLY_BOARD[game.pendingPurchaseId].price || 0)}</span><button onClick={buyProperty} className="inline-flex items-center gap-1 rounded-lg bg-emerald-400 px-3 py-2 text-[10px] font-black text-slate-950"><Check className="h-3.5 w-3.5" /> ყიდვა</button><button onClick={passProperty} className="rounded-lg border border-slate-600 px-3 py-2 text-[10px] font-bold text-slate-200">აუქციონზე გაშვება</button></div>}
                  {human?.jailTurns ? <div className="mt-3 flex flex-wrap justify-center gap-2"><button onClick={() => rollForHuman()} disabled={!isHumanTurn} className="rounded-lg border border-amber-200/30 bg-amber-200/10 px-3 py-2 text-[10px] font-bold text-amber-100 disabled:opacity-40">ორმაგის ცდა · დარჩა {human.jailTurns}</button><button onClick={() => rollForHuman(true)} disabled={!isHumanTurn || human.money < 50} className="rounded-lg border border-rose-300/25 bg-rose-300/10 px-3 py-2 text-[10px] font-bold text-rose-100 disabled:opacity-40">₾50-ად გამოსვლა და სვლის გაგრძელება</button>{human.jailFreeCards > 0 && <button onClick={useJailCard} className="rounded-lg border border-emerald-300/25 bg-emerald-300/10 px-3 py-2 text-[10px] font-bold text-emerald-100">თავისუფლების ბარათი</button>}</div> : null}
                  {game.pendingBotTrade && <div className="mt-4 flex max-w-md flex-wrap justify-center gap-2 rounded-2xl border border-cyan-300/20 bg-cyan-300/5 p-3"><span className="w-full text-xs font-bold text-cyan-100">{game.players.find((player) => player.id === game.pendingBotTrade?.fromBotId)?.name} გთავაზობს {MONOPOLY_BOARD[game.pendingBotTrade.propertyId].name}-ში {formatMoney(game.pendingBotTrade.cash)}-ს.</span><button onClick={() => answerBotTrade(true)} className="rounded-lg bg-emerald-400 px-3 py-2 text-[10px] font-black text-slate-950">შეთავაზების მიღება</button><button onClick={() => answerBotTrade(false)} className="rounded-lg border border-slate-600 px-3 py-2 text-[10px] font-bold text-slate-200">უარყოფა</button></div>}
                </div>
              </div>
              <div className="mx-auto mt-3 flex max-w-[900px] flex-wrap gap-2 px-1 text-[10px] text-slate-500"><span>🎲 კამათელი</span><span>🏠 სახლი</span><span>🏨 სასტუმრო</span><span>🚗 შენი ფიგურა</span><span>● ქონების მფლობელი</span><span>სახლები თანაბრად შენდება</span></div>
            </div>

            <aside className="space-y-4">
              <section className="rounded-3xl border border-slate-800 bg-[#0d111a] p-4 shadow-xl sm:p-5">
                <div className="mb-3 flex items-center justify-between"><h2 className="flex items-center gap-2 text-sm font-black text-white"><Users className="h-4 w-4 text-amber-200" /> მოთამაშეები</h2><span className="text-[10px] text-slate-500">სვლა {game.turn}</span></div>
                <div className="space-y-2">
                  {game.players.map((player, index) => (
                    <div key={player.id} className={'flex items-center justify-between rounded-xl border px-3 py-2 ' + (player.bankrupt ? 'border-slate-800 bg-slate-950/30 opacity-40' : game.currentPlayer === index ? 'border-amber-200/30 bg-amber-200/5' : 'border-slate-800 bg-slate-950/60')}>
                      <div className="flex min-w-0 items-center gap-2"><span className="text-lg">{player.token}</span><div className="min-w-0"><div className="truncate text-xs font-bold text-white">{player.name}{player.isHuman ? ' · შენ' : ''}</div><div className="text-[9px] text-slate-500">{player.bankrupt ? 'გაკოტრდა' : player.jailTurns > 0 ? 'ციხეში · ' + player.jailTurns + ' სვლა' : MONOPOLY_BOARD[player.position].name}</div></div></div>
                      <div className="shrink-0 text-right"><div className="text-xs font-black text-amber-100">{formatMoney(player.money)}</div><div className="text-[9px] text-slate-500">{Object.values(game.deeds).filter((deed) => deed.ownerId === player.id).length} ქონება</div></div>
                    </div>
                  ))}
                </div>
                <div className="mt-3 rounded-xl border border-slate-800 bg-slate-950/60 p-3"><div className="mb-2 flex items-center gap-2 text-[10px] font-bold uppercase tracking-wider text-slate-500"><Clock3 className="h-3.5 w-3.5" /> ბოლო მოვლენები</div><div className="space-y-1.5">{game.history.slice(0, 4).map((entry, index) => <p key={index} className="text-[10px] leading-relaxed text-slate-400">{entry}</p>)}</div></div>
              </section>

              <section className="rounded-3xl border border-amber-200/15 bg-gradient-to-br from-[#15140f] to-[#10131b] p-4 shadow-xl sm:p-5">
                <div className="flex items-center justify-between gap-3"><div className="flex items-center gap-2 text-amber-100"><LandPlotIcon /><h2 className="text-sm font-black text-white">ქონების ბარათი</h2></div><span className="rounded-md border border-slate-700 px-2 py-0.5 text-[9px] font-bold text-slate-400">#{selectedSpace.id}</span></div>
                {selectedSpace.color && <div style={{ backgroundColor: GROUP_COLORS[selectedSpace.color] }} className="mt-3 h-2 rounded-full" />}
                <div className="mt-3 text-base font-black text-white">{selectedSpace.name}</div>
                {(selectedSpace.type === 'property' || selectedSpace.type === 'railroad' || selectedSpace.type === 'utility') ? (
                  <div className="mt-3 space-y-2 text-[11px]">
                    <div className="flex justify-between text-slate-400"><span>შესყიდვის ფასი</span><b className="text-white">{formatMoney(selectedSpace.price || 0)}</b></div>
                    <div className="flex justify-between text-slate-400"><span>მფლობელი</span><b className="text-white">{owner?.name || 'თავისუფალია'}</b></div>
                    {selectedSpace.type === 'property' && <div className="space-y-1 rounded-xl border border-slate-800 bg-slate-950/60 p-2.5">{(selectedSpace.rents || []).map((rent, index) => <div key={index} className="flex justify-between text-slate-400"><span>{index === 0 ? 'საბაზისო ქირა' : index === 5 ? 'სასტუმრო' : index + ' სახლი'}</span><span className="font-mono text-slate-200">{formatMoney(index === 0 && game && selectedDeed?.ownerId ? getMonopolyRent(game, selectedSpace) : rent)}</span></div>)}</div>}
                    {selectedSpace.type !== 'property' && <div className="flex justify-between text-slate-400"><span>მიმდინარე ქირა</span><b className="text-white">{formatMoney(selectedRent)}</b></div>}
                    {selectedDeed?.mortgaged && <div className="rounded-lg bg-rose-400/10 px-2 py-1 text-[10px] font-bold text-rose-200">Իპოთეკაშია · ქირა არ ირიცხება</div>}
                  </div>
                ) : <p className="mt-2 text-xs leading-relaxed text-slate-400">სპეციალური ველი — დააჭირე კამათლის ღილაკს, რომ მისი შედეგი გაიგო.</p>}
                {propertyOwned && selectedSpace.type === 'property' && selectedDeed && (
                  <div className="mt-3 grid grid-cols-2 gap-2">
                    <button onClick={() => buildHouse(selectedSpace.id)} disabled={!isHumanTurn || !canBuildMonopolyHouse(game, selectedSpace.id, human?.id || '') || (selectedSpace.houseCost || 0) > (human?.money || 0)} className="inline-flex items-center justify-center gap-1 rounded-xl border border-emerald-300/20 bg-emerald-300/10 px-2 py-2 text-[10px] font-bold text-emerald-100 disabled:opacity-35"><House className="h-3.5 w-3.5" /> {selectedDeed.houses === 4 ? 'სასტუმროს აგება' : 'სახლის აგება'} · {formatMoney(selectedSpace.houseCost || 0)}</button>
                    <button onClick={() => mortgageProperty(selectedSpace.id)} disabled={!isHumanTurn || selectedDeed.houses > 0 || (selectedDeed.mortgaged && (human?.money || 0) < Math.ceil((selectedSpace.price || 0) * 0.55))} className="rounded-xl border border-slate-600 bg-slate-900 px-2 py-2 text-[10px] font-bold text-slate-200 disabled:opacity-35">{selectedDeed.mortgaged ? 'იპოთეკის გამოსყიდვა' : 'იპოთეკაში ჩადება'}</button>
                  </div>
                )}
              </section>

              <section className="rounded-3xl border border-cyan-300/15 bg-[#0d111a] p-4 shadow-xl sm:p-5">
                <div className="flex items-center gap-2 text-cyan-200"><Handshake className="h-4 w-4" /><h2 className="text-sm font-black text-white">ქონებით ვაჭრობა</h2></div>
                <p className="mt-1 text-[10px] leading-relaxed text-slate-500">შესთავაზე ბოტს ფული ან ქონება. ბოტი შეაფასებს გარიგების სარგებელს და სრული ფერის ჯგუფის ღირებულებას.</p>
                <div className="mt-3 space-y-2">
                  <select value={tradeTargetId} onChange={(event) => { setTradeTargetId(event.target.value); setWantPropertyId(''); }} disabled={!tradeEligible} className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white outline-none disabled:opacity-40">
                    <option value="">აირჩიე ბოტი</option>{game.players.filter((player) => !player.isHuman && !player.bankrupt).map((player) => <option key={player.id} value={player.id}>{player.name}</option>)}
                  </select>
                  <select value={givePropertyId} onChange={(event) => setGivePropertyId(event.target.value)} disabled={!tradeEligible} className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white outline-none disabled:opacity-40"><option value="">რას აძლევ? — ქონება</option>{humanProperties.filter((space) => game.deeds[space.id]?.houses === 0 && !game.deeds[space.id]?.mortgaged).map((space) => <option key={space.id} value={space.id}>{space.name} · {formatMoney(space.price || 0)}</option>)}</select>
                  <input type="number" min={0} max={human?.money || 0} step={25} value={giveCash} onChange={(event) => setGiveCash(event.target.value)} disabled={!tradeEligible} placeholder="თანხა, რომელსაც აძლევ" className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white outline-none focus:border-cyan-300 disabled:opacity-40" />
                  <select value={wantPropertyId} onChange={(event) => setWantPropertyId(event.target.value)} disabled={!tradeEligible || !tradeTargetId} className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white outline-none disabled:opacity-40"><option value="">რას ითხოვ? — ქონება</option>{botProperties.map((space) => <option key={space.id} value={space.id}>{space.name} · {formatMoney(space.price || 0)}</option>)}</select>
                  <input type="number" min={0} step={25} value={wantCash} onChange={(event) => setWantCash(event.target.value)} disabled={!tradeEligible} placeholder="თანხა, რომელსაც ითხოვ" className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white outline-none focus:border-cyan-300 disabled:opacity-40" />
                  <button onClick={completeTrade} disabled={!canOfferTrade} className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-cyan-300/25 bg-cyan-300/10 py-2.5 text-xs font-black text-cyan-100 transition hover:bg-cyan-300/15 disabled:cursor-not-allowed disabled:opacity-35"><ArrowRightLeft className="h-4 w-4" /> შეთავაზების გაგზავნა</button>
                  {tradeFeedback && <p className="rounded-lg bg-slate-950/70 p-2 text-[10px] leading-relaxed text-cyan-100">{tradeFeedback}</p>}
                </div>
              </section>
            </aside>
          </section>
        </>
      )}

      <section className="grid gap-3 md:grid-cols-3">
        <RuleCard icon={<Banknote className="h-4 w-4" />} title="კლასიკური ეკონომიკა" text="იყიდე ველები, გადაიხადე ქირა, ააშენე სახლები თანაბრად და შემდეგ — სასტუმრო. სრულ ფერის ჯგუფზე საბაზისო ქირა ორმაგდება." />
        <RuleCard icon={<ArrowRightLeft className="h-4 w-4" />} title="გარიგებები და იპოთეკა" text="ბოტებს გაუგზავნე ფულისა და ქონების შეთავაზებები; მათი გადაწყვეტილება ჯგუფის სტრატეგიას ითვალისწინებს. უქირაოდ დარჩენილი ქონება აუქციონზე გადის." />
        <RuleCard icon={<ShieldCheck className="h-4 w-4" />} title="დაცული ანგარიშები" text="Monopoly-ის ბანკი ცალკე ინახება თითო ანგარიშზე. MRP-ის ანგარიში და ძველი პროგრესი განახლებისას არ იშლება." />
      </section>
    </div>
  );
};

const LandPlotIcon = () => <Building2 className="h-4 w-4" />;

const RuleCard: React.FC<{ icon: React.ReactNode; title: string; text: string }> = ({ icon, title, text }) => (
  <div className="flex gap-3 rounded-2xl border border-slate-800 bg-[#0d111a] p-4">
    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-amber-300/15 bg-amber-300/5 text-amber-200">{icon}</span>
    <div><h3 className="text-xs font-black text-white">{title}</h3><p className="mt-1 text-[10px] leading-relaxed text-slate-500">{text}</p></div>
  </div>
);
