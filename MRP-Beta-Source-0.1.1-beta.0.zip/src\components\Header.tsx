﻿import React from 'react';
import { Volume2, VolumeX, User, Sparkles, TrendingUp, Shield, LogOut, Briefcase, Zap, BookOpen } from 'lucide-react';
import { PlayerProfile } from '../types/game';
import { getXpRequiredForLevel } from '../utils/constants';
import { formatLari } from '../utils/formatters';

interface HeaderProps {
  player: PlayerProfile;
  passiveIncomeRate: number;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenProfile: () => void;
  onToggleSound: () => void;
  onLogout?: () => void;
  onOpenExchangeModal: () => void;
  unclaimedMissionsCount?: number;
  onOpenRules: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  player,
  passiveIncomeRate,
  activeTab,
  setActiveTab,
  onOpenProfile,
  onToggleSound,
  onLogout,
  onOpenExchangeModal,
  unclaimedMissionsCount = 0,
  onOpenRules
}) => {
  const xpNeeded = getXpRequiredForLevel(player.level);
  const xpProgressPercent = Math.min(100, Math.max(0, (player.xp / xpNeeded) * 100));

  // Removed 'chat' tab as requested! Only keep chat inside AviaStar!
  const navTabs = [
    { id: 'aviator', label: 'ავიატორი', icon: '✈️' },
    { id: 'inventory', label: 'ინვენტარი', icon: '📦' },
    { id: 'sports', label: 'სპორტი', icon: '⚽' },
    { id: 'jobs', label: 'სამუშაო & ბიზნესი', icon: '💼' },
    { id: 'trading', label: 'Trading', icon: '📈' },
    { id: 'monopoly', label: 'Monopoly', icon: '🎲' },
    { id: 'minigames', label: 'კაზინო', icon: '🎰' },
    { id: 'luxury', label: 'ლუქს მაღაზია', icon: '💎' },
    { id: 'profile', label: 'სტატისტიკა', icon: '📊' }
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-cyan-300/15 bg-[#070914]/90 shadow-[0_16px_50px_rgba(0,0,0,.45)] backdrop-blur-2xl">
      {/* Top Main Navigation Bar */}
      <div className="max-w-[1720px] mx-auto px-3 sm:px-4 py-1.5 sm:py-2 flex flex-col 2xl:flex-row items-center justify-between gap-2.5">
        
        {/* ========================================================
            LEFT CORNER: BRAND (MRP), RP BADGE, MISSIONS (WITH RED DOT),
            RANK SHOP, STAR PASS, STAR MISSIONS, RULES BUTTON
        ======================================================== */}
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 w-full 2xl:w-auto justify-between 2xl:justify-start">
          {/* Brand Logo & MRP Tag */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="flex items-center gap-2 rounded-2xl border border-cyan-300/25 bg-gradient-to-br from-cyan-400/10 via-indigo-500/10 to-violet-500/10 px-3 py-2 shadow-[0_0_28px_rgba(34,211,238,.09)]">
              <img src={`${import.meta.env.BASE_URL}mrp-coin.svg`} alt="MRP coin" className="h-8 w-8 rounded-full shadow-[0_0_16px_rgba(250,204,21,.35)]" />
              <div className="leading-tight">
                <span className="font-black text-sm sm:text-base tracking-wider bg-gradient-to-r from-cyan-200 via-sky-300 to-violet-300 bg-clip-text text-transparent">
                  MRP
                </span>
                <span className="text-[9px] text-amber-400 font-mono font-bold block tracking-wider">
                  MONEY ROLEPLAY
                </span>
                <span className="text-[8px] font-extrabold tracking-[.16em] text-cyan-200/80 block">BETA VERSION</span>
              </div>
            </div>

            {/* RP Reputation Badge */}
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900/90 border border-slate-800 text-xs font-mono text-amber-400" title="მოთამაშის RP რეპუტაცია">
              <Shield className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-bold">{player.reputation} RP</span>
            </div>

            {/* 🎯 MISSIONS BUTTON WITH PULSATING RED DOT */}
            <button
              onClick={() => setActiveTab('missions')}
              className={`relative flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'missions'
                  ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.6)] font-black'
                  : 'bg-slate-900/90 border-amber-500/40 text-amber-300 hover:border-amber-400 hover:bg-amber-500/10'
              }`}
              title="სპეციალური მისიები და კრისტალები"
            >
              <span className="text-sm">🎯</span>
              <span className="font-mono">მისიები</span>
              {/* Red notification dot if player completed any mission ready to claim */}
              {unclaimedMissionsCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500 border border-slate-950 shadow-[0_0_10px_rgba(244,63,94,1)]" />
                </span>
              )}
            </button>

            {/* 👑 RANK SHOP BUTTON NEXT TO MISSIONS */}
            <button
              onClick={() => setActiveTab('rank_shop')}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'rank_shop'
                  ? 'bg-gradient-to-r from-cyan-400 via-sky-400 to-violet-500 text-slate-950 border-cyan-200 shadow-[0_0_20px_rgba(56,189,248,0.4)] font-black'
                  : 'bg-slate-900/90 border-violet-400/25 text-violet-200 hover:border-violet-300/60 hover:bg-violet-400/10'
              }`}
              title="Rank Shop — შეიძინე და განავითარე VIP რანკი"
            >
              <span className="text-sm">👑</span>
              <span className="font-mono">Rank Shop</span>
            </button>

            {/* 📜 RULES MODAL BUTTON */}
            <button
              onClick={onOpenRules}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-emerald-500/40 bg-slate-900/90 hover:bg-emerald-500/10 text-emerald-300 hover:border-emerald-400 text-xs font-bold transition-all cursor-pointer font-mono"
              title="MRP წესები & გზამკვლევი"
            >
              <BookOpen className="w-3.5 h-3.5 text-emerald-400" />
              <span>წესები</span>
            </button>

            {/* Sound Toggle */}
            <button
              onClick={onToggleSound}
              className={`p-2 rounded-xl border transition-all cursor-pointer ${
                player.soundEnabled
                  ? 'bg-slate-900 border-slate-700 text-emerald-400 hover:border-emerald-500/60 shadow-sm'
                  : 'bg-slate-900 border-slate-800 text-slate-500 hover:text-slate-300'
              }`}
              title={player.soundEnabled ? 'ხმის გამორთვა' : 'ხმის ჩართვა'}
            >
              {player.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
          </div>

          {/* Desktop Nav Tabs on Left */}
          <nav className="hidden lg:flex items-center gap-1 rounded-2xl border border-white/10 bg-gradient-to-r from-slate-950/95 via-[#101626]/95 to-slate-950/95 p-1.5 shadow-inner shadow-black/50 overflow-x-auto max-w-full">
            {navTabs.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    if (tab.id === 'profile') {
                      onOpenProfile();
                    } else {
                      setActiveTab(tab.id);
                    }
                  }}
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                    isActive
                      ? 'bg-gradient-to-r from-cyan-300 to-sky-400 text-slate-950 shadow-[0_0_16px_rgba(34,211,238,.24)] font-black'
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <span className="text-sm">{tab.icon}</span>
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* ========================================================
            RIGHT: PROFILE + XP + [MONEY + CRYSTALS + STARS BALANCES]
        ======================================================== */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-2.5 shrink-0 w-full 2xl:w-auto">
          {/* 1. Profile & XP Box */}
          <div
            onClick={onOpenProfile}
            className="group cursor-pointer flex items-center gap-2.5 px-3 py-1.5 rounded-2xl bg-gradient-to-r from-slate-900/90 via-[#10121c] to-slate-900/90 border border-slate-800 hover:border-emerald-500/50 transition-all shadow-lg min-w-[200px] sm:min-w-[220px]"
            title="დააწკაპუნეთ პროფილის სანახავად"
          >
            {/* Avatar & Level Tag */}
            <div className="relative w-9 h-9 rounded-xl overflow-hidden bg-slate-800 border-2 border-emerald-500/40 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-md">
              {player.customPhoto ? (
                <img src={player.customPhoto} alt={player.name} className="w-full h-full object-cover" />
              ) : (
                <span className="text-lg">{player.avatar}</span>
              )}
              <span className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-950 font-black text-[9px] px-1 py-0.2 rounded-full border border-black font-mono shadow-sm">
                L{player.level}
              </span>
            </div>

            {/* Profile Info & XP */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1">
                <div className="flex items-center gap-1.5 truncate">
                  <span className="font-extrabold text-xs sm:text-sm text-slate-100 group-hover:text-emerald-300 transition-colors truncate">
                    {player.name}
                  </span>
                  {/* VIP PREMIUM BADGE NEXT TO NAME */}
                  {player.premiumRank === 'devil_red' && (
                    <span className="shrink-0 rounded-md border border-rose-300/70 bg-gradient-to-r from-rose-700/80 via-red-600/70 to-fuchsia-700/70 px-1.5 py-0.5 text-[9px] font-black tracking-wider text-white shadow-[0_0_14px_rgba(244,35,89,.65)] animate-pulse">
                      😈 REDDEVIL
                    </span>
                  )}                  {player.premiumRank === 'midnight_purple' && (
                    <span className="px-1.5 py-0.2 rounded-md bg-purple-900/60 text-fuchsia-300 border border-fuchsia-500/70 text-[9px] font-black font-mono tracking-wider shrink-0 animate-pulse shadow-[0_0_12px_rgba(217,70,239,0.7)]">
                      🌌 MIDNIGHT
                    </span>
                  )}
                  {player.premiumRank === 'purple' && (
                    <span className="px-1.5 py-0.2 rounded-md bg-purple-500/20 text-purple-400 border border-purple-500/50 text-[9px] font-black font-mono tracking-wider shrink-0 animate-pulse shadow-[0_0_10px_rgba(168,85,247,0.6)]">
                      🟣 PURPLE VIP
                    </span>
                  )}
                  {player.premiumRank === 'red' && (
                    <span className="px-1.5 py-0.2 rounded-md bg-red-500/20 text-red-400 border border-red-500/50 text-[9px] font-black font-mono tracking-wider shrink-0 animate-pulse shadow-[0_0_8px_rgba(239,68,68,0.5)]">
                      🔴 RED VIP
                    </span>
                  )}
                </div>
                <span className="text-[10px] text-amber-400 font-mono font-bold bg-amber-500/10 px-1 py-0.2 rounded border border-amber-500/20 shrink-0">
                  L{player.level}
                </span>
              </div>

              {/* XP Linear Progress Bar */}
              <div className="mt-1 space-y-0.5">
                <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                  <span className="truncate text-slate-500">{player.title}</span>
                  <span className="text-emerald-400 font-semibold">{xpProgressPercent.toFixed(0)}% XP</span>
                </div>
                <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 transition-all duration-300"
                    style={{ width: `${xpProgressPercent}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* 2. Glowing Money Balance */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-gradient-to-br from-emerald-950/40 via-slate-900 to-slate-950 border-2 border-emerald-500/40 shadow-[0_0_15px_rgba(16,185,129,0.2)] shrink-0">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-bold text-base shadow-inner">
              ₾
            </div>
            <div className="flex flex-col">
              <span className="text-[9px] uppercase font-mono font-bold text-slate-400 tracking-wider">
                ბალანსი
              </span>
              <div className="font-mono font-black text-xs sm:text-sm text-emerald-400 tracking-tight leading-tight">
                {formatLari(player.balance)}
              </div>
              {passiveIncomeRate > 0 && (
                <div className="flex items-center gap-1 text-[9px] font-mono text-emerald-300/90 font-bold">
                  <TrendingUp className="w-2.5 h-2.5 text-emerald-400" />
                  <span>+{formatLari(passiveIncomeRate * 60)}/წთ</span>
                </div>
              )}
            </div>
          </div>

          {/* 3. Glowing Crystals Balance Capsule */}
          <div
            onClick={onOpenExchangeModal}
            className="cursor-pointer group flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-gradient-to-br from-cyan-950/40 via-slate-900 to-slate-950 border-2 border-cyan-500/40 hover:border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.2)] shrink-0 transition-all"
            title="კრისტალების ბალანსი - დააწკაპუნეთ გადასაცვლელად"
          >
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 flex items-center justify-center font-bold text-base shadow-inner group-hover:scale-105 transition-transform">
              💎
            </div>
            <div className="flex flex-col">
              <div className="flex items-center justify-between gap-1">
                <span className="text-[9px] uppercase font-mono font-bold text-slate-400 tracking-wider">
                  კრისტალები
                </span>
                <span className="text-[8px] text-cyan-400 font-mono font-bold bg-cyan-500/10 px-1 rounded border border-cyan-500/20">
                  +გადაცვლა
                </span>
              </div>
              <div className="font-mono font-black text-xs sm:text-sm text-cyan-300 tracking-tight leading-tight">
                {(player.crystals || 0).toLocaleString()} 💎
              </div>
            </div>
          </div>

          {/* Logout / Switch User Button on Right */}
          {onLogout && (
            <button
              onClick={onLogout}
              className="p-2 sm:px-2.5 sm:py-2 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-rose-500/50 text-slate-400 hover:text-rose-400 transition-all text-xs font-bold flex items-center gap-1.5 shrink-0 cursor-pointer"
              title="ექაუნთიდან გამოსვლა / შეცვლა"
            >
              <LogOut className="w-4 h-4 text-rose-400" />
            </button>
          )}
        </div>
      </div>

      {/* Mobile Navigation Strip */}
      <div className="lg:hidden flex items-center justify-start gap-2 border-t border-white/5 bg-gradient-to-r from-slate-950 via-[#0e1320] to-slate-950 px-2 py-2 overflow-x-auto scrollbar-none">
        {navTabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                if (tab.id === 'profile') {
                  onOpenProfile();
                } else {
                  setActiveTab(tab.id);
                }
              }}
              className={`flex flex-col items-center py-1 px-2.5 rounded-lg text-[10px] font-medium whitespace-nowrap transition-colors cursor-pointer shrink-0 min-w-[64px] ${
                isActive ? 'text-cyan-200 bg-cyan-300/10 ring-1 ring-cyan-300/20 font-black' : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              <span className="text-base">{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};






