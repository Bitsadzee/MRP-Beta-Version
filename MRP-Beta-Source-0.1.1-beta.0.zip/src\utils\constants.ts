﻿export const ESTATE_RENT_SCALE = 1 / 60;
export const BUSINESS_INCOME_SCALE = 1 / 30;
export const UPGRADER_INCOME_SCALE = 1 / 5;

export const INITIAL_JOBS: Job[] = [
  {
    id: 'courier',
    name: 'Wolt/Glovo კურიერი',
    iconName: 'Bike',
    category: 'სტარტერი',
    requiredLevel: 1,
    salary: 35,
    xpReward: 12,
    cooldownSeconds: 18,
    description: 'მიიტანე შეკვეთები ვაკე-საბურთალოს ქუჩებში. სწრაფი და მარტივი ნაღდი ფული.',
    tasks: [
      {
        id: 't_courier_1',
        name: 'მისამართის შერჩევა',
        type: 'quiz',
        prompt: 'მომხმარებელი ელოდება შეკვეთას ჭავჭავაძეზე. რომელია უმოკლესი მარშრუტი?',
        options: ['ჭავჭავაძის გამზირით პირდაპირ', 'ვაკის პარკის გავლით', 'მელიქიშვილიდან შემოვლით'],
        correctOption: 0
      },
      {
        id: 't_courier_2',
        name: 'სწრაფი პედლები',
        type: 'quick_tap',
        prompt: 'დააჭირე სწრაფად 5-ჯერ, რომ შეკვეთა ცხელი მიიტანო!',
        targetCount: 5
      },
      {
        id: 't_courier_3',
        name: 'თერმო-ჩანთის ტემპერატურა',
        type: 'slider',
        prompt: 'დააყენე თერმო-ჩანთის იდეალური ტემპერატურა: 65°C',
        sliderTarget: 65
      },
      {
        id: 't_courier_4',
        name: 'საცობში მანევრირება',
        type: 'quick_tap',
        prompt: 'დააჭირე 7-ჯერ, რომ პიკის საათში მანქანებს შორის გაძვრე!',
        targetCount: 7
      },
      {
        id: 't_courier_5',
        name: 'სადარბაზოს დომოფონი',
        type: 'code',
        prompt: 'კლიენტის მიერ მოწოდებული დომოფონის კოდი: 2480',
        options: ['2480']
      },
      {
        id: 't_courier_6',
        name: 'ცხელი პიცის ბალანსი',
        type: 'slider',
        prompt: 'დააბალანსე ჩანთა მოსახვევში: სლაიდერი 50%-ზე (50)',
        sliderTarget: 50
      },
      {
        id: 't_courier_7',
        name: 'წვიმაში სპრინტი',
        type: 'quick_tap',
        prompt: 'დააჭირე 8-ჯერ, რომ კოკისპირულ წვიმაში მშრალად მიირბინო!',
        targetCount: 8
      },
      {
        id: 't_courier_8',
        name: 'კლიენტის ჩაი (Tip)',
        type: 'quiz',
        prompt: 'კლიენტმა 20 ლარიანი ჩაი დაგიტოვა. როგორია კურიერის პროფესიონალური პასუხი?',
        options: ['დიდი მადლობა, გემრიელად მიირთვით და კარგ დღეს გისურვებთ!', 'რატომ მხოლოდ 20 ლარი?', 'ჩუმად წასვლა'],
        correctOption: 0
      }
    ]
  },
  {
    id: 'barber',
    name: 'ელიტური ბარბერი',
    iconName: 'Scissors',
    category: 'სერვისი',
    requiredLevel: 4,
    salary: 75,
    xpReward: 30,
    cooldownSeconds: 22,
    description: 'მოდური ვარცხნილობები და წვერის გასწორება ქალაქის ბიზნესმენებისთვის.',
    tasks: [
      {
        id: 't_barber_1',
        name: 'ფეიდის ხაზის გასწორება',
        type: 'slider',
        prompt: 'გაასწორე ტრიმერის სიზუსტის სლაიდერი 80%-ზე',
        sliderTarget: 80
      },
      {
        id: 't_barber_2',
        name: 'სტილის შერჩევა',
        type: 'quiz',
        prompt: 'ბიზნესმენს სურს კლასიკური და ელეგანტური იმიჯი. რას ურჩევ?',
        options: ['Classic Side-Part Fade', 'მოჰავკი და მწვანე საღებავი', 'ნულზე გადაპარსვა'],
        correctOption: 0
      },
      {
        id: 't_barber_3',
        name: 'წვერის ზეთის დატანა',
        type: 'quick_tap',
        prompt: 'დააჭირე 6-ჯერ წვერის იდეალური ბზინვარებისთვის!',
        targetCount: 6
      },
      {
        id: 't_barber_4',
        name: 'მაკრატლის კუთხის დაკალიბრება',
        type: 'slider',
        prompt: 'დააყენე დანის პირის დახრა 45 გრადუსზე',
        sliderTarget: 45
      },
      {
        id: 't_barber_5',
        name: 'ცხელი პირსახოცი',
        type: 'quick_tap',
        prompt: 'დააჭირე 8-ჯერ, რომ კლიენტმა მაქსიმალური რელაქსი იგრძნოს!',
        targetCount: 8
      },
      {
        id: 't_barber_6',
        name: 'VIP ოდეკოლონის შერჩევა',
        type: 'quiz',
        prompt: 'საღამოს შეხვედრისთვის რომელი სურნელია იდეალური?',
        options: ['თამბაქოსა და ვანილის კეთილშობილი ნოტები', 'იაფფასიანი სპირტი', 'სარეცხი ფხვნილის სუნი'],
        correctOption: 0
      },
      {
        id: 't_barber_7',
        name: 'ტრიმერის სიჩქარე',
        type: 'slider',
        prompt: 'დააყენე ტრიმერის ბრუნი 7000 RPM-ზე (70-ზე)',
        sliderTarget: 70
      }
    ]
  },
  {
    id: 'mechanic',
    name: 'M-Power & Quattro ავტომექანიკოსი',
    iconName: 'Wrench',
    category: 'ავტო-ინდუსტრია',
    requiredLevel: 9,
    salary: 150,
    xpReward: 70,
    cooldownSeconds: 28,
    description: 'ძრავების ფორსირება, ტურბოების დაყენება და დრიფტ-ბოლდების მომზადება.',
    tasks: [
      {
        id: 't_mech_1',
        name: 'ტურბოს წნევის დაკალიბრება',
        type: 'slider',
        prompt: 'დააყენე ტურბო-ბუსტი ზუსტად 1.8 ბარზე (18-ზე)',
        sliderTarget: 18
      },
      {
        id: 't_mech_2',
        name: 'ძრავის დიაგნოსტიკა',
        type: 'quiz',
        prompt: 'Audi 3.2 FSI Quattro-ს ცილინდრში ნაპერწკალი აკლია. რა არის შესაცვლელი?',
        options: ['სანთლები (Babina/Spark Plugs)', 'უკანა ბამპერი', 'საქარე მინა'],
        correctOption: 0
      },
      {
        id: 't_mech_3',
        name: 'ბოლტების გადაჭერა დინამომეტრით',
        type: 'quick_tap',
        prompt: 'დააჭირე 8-ჯერ დისკების მჭიდროდ დასამაგრებლად!',
        targetCount: 8
      },
      {
        id: 't_mech_4',
        name: 'ზეთის სამუშაო წნევა',
        type: 'slider',
        prompt: 'დააყენე ძრავის ზეთის წნევა 4.2 ბარზე (42-ზე)',
        sliderTarget: 42
      },
      {
        id: 't_mech_5',
        name: 'ECU ჩიპის პროგრამირება',
        type: 'code',
        prompt: 'შეიყვანე სარბოლო ჩიპის კოდი: 9110',
        options: ['9110']
      },
      {
        id: 't_mech_6',
        name: 'სამუხრუჭე ხუნდების შეცვლა',
        type: 'quick_tap',
        prompt: 'დააჭირე 9-ჯერ კერამიკული ხუნდების დასაყენებლად!',
        targetCount: 9
      },
      {
        id: 't_mech_7',
        name: 'სავალი ნაწილის კუთხე (Camber)',
        type: 'slider',
        prompt: 'დააყენე სპორტული დახრის კუთხე -2.5 გრადუსზე (25)',
        sliderTarget: 25
      }
    ]
  },
  {
    id: 'dj',
    name: 'VIP კლუბის რეზიდენტი DJ',
    iconName: 'Music',
    category: 'ღამის ცხოვრება',
    requiredLevel: 18,
    salary: 320,
    xpReward: 150,
    cooldownSeconds: 35,
    description: 'ანთებ ყველაზე პოპულარულ ღამის კლუბებს. სოლიდური ჰონორარი და ქალაქის პატივისცემა.',
    tasks: [
      {
        id: 't_dj_1',
        name: 'BPM სინქრონიზაცია',
        type: 'slider',
        prompt: 'დააყენე ტრეკის ტემპი 80 BPM-ზე',
        sliderTarget: 80
      },
      {
        id: 't_dj_2',
        name: 'დროპის გაშვება',
        type: 'quick_tap',
        prompt: 'დააჭირე 7-ჯერ, რომ კლუბის დარბაზი ააფეთქო ბასით!',
        targetCount: 7
      },
      {
        id: 't_dj_3',
        name: 'მუსიკალური გემოვნება',
        type: 'quiz',
        prompt: 'პიკის საათში დარბაზს სჭირდება ენერგია. რომელ ჟანრს აირჩევ?',
        options: ['Melodic Techno & Peak Time Bass', 'ნელი სევდიანი ბალადა', 'რადიო რეკლამები'],
        correctOption: 0
      },
      {
        id: 't_dj_4',
        name: 'Low-Pass Filter ფილტრი',
        type: 'slider',
        prompt: 'დაწიე ბასის ფილტრი 35%-ზე დროპის წინ',
        sliderTarget: 35
      },
      {
        id: 't_dj_5',
        name: 'ლაზერული შოუს კოდი',
        type: 'code',
        prompt: 'შეიყვანე სცენის განათების კოდი: 4433',
        options: ['4433']
      },
      {
        id: 't_dj_6',
        name: 'საკვამლე აპარატის გაშვება',
        type: 'quick_tap',
        prompt: 'დააჭირე 6-ჯერ სცენაზე სქელი ნისლის გასაშვებად!',
        targetCount: 6
      },
      {
        id: 't_dj_7',
        name: 'მიკროფონის ჰაიპი',
        type: 'quiz',
        prompt: 'როგორ აიყოლიებ 2,000 კაციან დარბაზს?',
        options: ['ხელები მაღლა, თბილისო, ეს თქვენი ღამეა!', 'ყველანი სახლში წადით', 'სიჩუმე შევინარჩუნოთ'],
        correctOption: 0
      }
    ]
  },
  {
    id: 'crypto_trader',
    name: 'კრიპტო Scalper',
    iconName: 'TrendingUp',
    category: 'ფინანსები',
    requiredLevel: 32,
    salary: 750,
    xpReward: 620,
    cooldownSeconds: 45,
    description: 'სწრაფი ოპერაციები ბერკეტით. მაღალი რისკი, უზარმაზარი მოგება.',
    tasks: [
      {
        id: 't_trade_1',
        name: 'Stop-Loss დაყენება',
        type: 'slider',
        prompt: 'დააყენე რისკის ზღვარი 5%-ზე კაპიტალის დასაცავად',
        sliderTarget: 5
      },
      {
        id: 't_trade_2',
        name: 'ბაზრის ანალიზი',
        type: 'quiz',
        prompt: 'გრაფიკზე გამოჩნდა "Bullish Divergence" და მოცულობის ზრდა. რა პოზიცია გავხსნათ?',
        options: ['Long (ყიდვა)', 'Short (გაყიდვა)', 'დეპოზიტის გამოტანა'],
        correctOption: 0
      },
      {
        id: 't_trade_3',
        name: 'სწრაფი ორდერის დადება',
        type: 'quick_tap',
        prompt: 'დააჭირე 8-ჯერ წამიერი მოგების დასაფიქსირებლად!',
        targetCount: 8
      },
      {
        id: 't_trade_4',
        name: 'Leverage ბერკეტი',
        type: 'slider',
        prompt: 'დააყენე ოპტიმალური ბერკეტი 15x-ზე',
        sliderTarget: 15
      },
      {
        id: 't_trade_5',
        name: '2FA უსაფრთხოების კოდი',
        type: 'code',
        prompt: 'შეიყვანე კრიპტო-საფულის 2FA გასაღები: 8851',
        options: ['8851']
      },
      {
        id: 't_trade_6',
        name: 'Order Book-ის Spread',
        type: 'slider',
        prompt: 'დააყენე ყიდვა-გაყიდვის სპრედი 0.2%-ზე (2)',
        sliderTarget: 2
      },
      {
        id: 't_trade_7',
        name: 'გაზის (Gas Fee) გათვლა',
        type: 'quiz',
        prompt: 'რომელ ქსელშია ყველაზე დაბალი ტრანზაქციის საკომისიო სწრაფი გადარიცხვისთვის?',
        options: ['Solana / Layer 2', 'ძველი გადატვირთული ქსელი', 'საბანკო გადარიცხვა 3 დღეში'],
        correctOption: 0
      }
    ]
  },
  {
    id: 'broker',
    name: 'ლუქს უძრავი ქონების ბროკერი',
    iconName: 'Building',
    category: 'უძრავი ქონება',
    requiredLevel: 55,
    salary: 1800,
    xpReward: 1600,
    cooldownSeconds: 55,
    description: 'პენტჰაუსებისა და ვილების გაყიდვა წყნეთსა და კოჯორში. სქელი საკომისიოები.',
    tasks: [
      {
        id: 't_broker_1',
        name: 'მოლაპარაკება ფასდაკლებაზე',
        type: 'slider',
        prompt: 'შეათანხმე საკომისიო ზუსტად 3%-ზე',
        sliderTarget: 3
      },
      {
        id: 't_broker_2',
        name: 'კლიენტის პრეზენტაცია',
        type: 'quiz',
        prompt: 'უცხოელი ინვესტორი ეძებს პანორამულ ვილას აუზით. სად შესთავაზებ?',
        options: ['წყნეთის ფიჭვნარში მინის რეზიდენციას', 'ქალაქგარეთ მიტოვებულ საწყობს', 'სარდაფს მეტროსთან'],
        correctOption: 0
      },
      {
        id: 't_broker_3',
        name: 'ხელშეკრულების გაფორმება',
        type: 'quick_tap',
        prompt: 'დააჭირე 9-ჯერ ნოტარიული ბეჭდების დასასმელად!',
        targetCount: 9
      },
      {
        id: 't_broker_4',
        name: 'კვადრატულის ფასი',
        type: 'slider',
        prompt: 'დააყენე კვადრატულის საორიენტაციო ფასი 35-ზე (3,500$)',
        sliderTarget: 35
      },
      {
        id: 't_broker_5',
        name: 'საჯარო რეესტრის კოდი',
        type: 'code',
        prompt: 'შეიყვანე საკადასტრო კოდის ამონაწერი: 6620',
        options: ['6620']
      },
      {
        id: 't_broker_6',
        name: 'ესქროუ (Escrow) ანგარიშის გახსნა',
        type: 'code',
        prompt: 'დაადასტურე დეპოზიტის ტრანშის კოდი: 1199',
        options: ['1199']
      },
      {
        id: 't_broker_7',
        name: 'პენტჰაუსის ხედის შეფასება',
        type: 'slider',
        prompt: 'დააყენე პანორამული ტერასის ფართობი 80 კვ.მ-ზე (80)',
        sliderTarget: 80
      }
    ]
  },
  {
    id: 'syndicate_boss',
    name: 'მიწისქვეშა სინდიკატის ხელმძღვანელი',
    iconName: 'ShieldAlert',
    category: 'შავი ბაზარი',
    requiredLevel: 95,
    salary: 5000,
    xpReward: 4200,
    cooldownSeconds: 70,
    description: 'აკონტროლებ ქალაქის ჩრდილოვან ეკონომიკას. არავინ ბედავს შენთან დაპირისპირებას.',
    tasks: [
      {
        id: 't_boss_1',
        name: 'კონფიდენციალური დაშიფვრა',
        type: 'code',
        prompt: 'შეიყვანე სინდიკატის უსაფრთხო კოდი ტრანზაქციის გასატარებლად: 7709',
        options: ['7709']
      },
      {
        id: 't_boss_2',
        name: 'კორუფციული შეთანხმება',
        type: 'quiz',
        prompt: 'რა არის მთავარი წესი სინდიკატის წარმატებისთვის?',
        options: ['ერთგულება, დისციპლინა და ჩუმი ოპერაციები', 'ყველაფრის სოც-ქსელში ატვირთვა', 'პანიკა პირველივე პრობლემაზე'],
        correctOption: 0
      },
      {
        id: 't_boss_3',
        name: 'სამფლობელოს განმტკიცება',
        type: 'quick_tap',
        prompt: 'დააჭირე 10-ჯერ ქალაქის ყველა უბანზე კონტროლისთვის!',
        targetCount: 10
      },
      {
        id: 't_boss_4',
        name: 'შვეიცარიული ოფშორი',
        type: 'slider',
        prompt: 'გადაანაწილე ჩრდილოვანი შემოსავლის 40% საიდუმლო ფონდში',
        sliderTarget: 40
      },
      {
        id: 't_boss_5',
        name: 'საიდუმლო ბუნკერის კოდი',
        type: 'code',
        prompt: 'დაადასტურე საიდუმლო სეიფის კომბინაცია: 9944',
        options: ['9944']
      },
      {
        id: 't_boss_6',
        name: 'კავშირის გაშიფვრა',
        type: 'slider',
        prompt: 'გაასწორე სატელიტური სიხშირე 88.0 GHz-ზე (88)',
        sliderTarget: 88
      }
    ]
  },
  {
    id: 'tech_mogul',
    name: 'გლობალური ტექ-მაგნატი',
    iconName: 'Cpu',
    category: 'მაღალი ტექნოლოგიები',
    requiredLevel: 160,
    salary: 15000,
    xpReward: 14000,
    cooldownSeconds: 90,
    description: 'ფლობ მონაცემთა ცენტრებს და სატელიტურ ქსელებს. მსოფლიოს ბედი შენს ხელთაა.',
    tasks: [
      {
        id: 't_tech_1',
        name: 'კვანტური სერვერის გადატვირთვა',
        type: 'slider',
        prompt: 'დაარეგულირე კვანტური გაგრილება 50 ნიშნულზე',
        sliderTarget: 50
      },
      {
        id: 't_tech_2',
        name: 'AI ალგორითმის არქიტექტურა',
        type: 'quiz',
        prompt: 'რომელი ნეიროქსელი უზრუნველყოფს რეალურ დროში მაქსიმალურ სიზუსტეს?',
        options: ['Multimodal Transformer with Real-Time Attention', 'უბრალო Excel ცხრილი', 'Random Generator'],
        correctOption: 0
      },
      {
        id: 't_tech_3',
        name: 'სატელიტური თანავარსკვლავედის გაშვება',
        type: 'quick_tap',
        prompt: 'დააჭირე 12-ჯერ ორბიტალური სისტემების გასააქტიურებლად!',
        targetCount: 12
      },
      {
        id: 't_tech_4',
        name: 'კიბერ-ფარის ავტორიზაცია',
        type: 'code',
        prompt: 'შეიყვანე სუპერკომპიუტერის root გასაღები: 2048',
        options: ['2048']
      },
      {
        id: 't_tech_5',
        name: 'სერვერების ენერგომომარაგება',
        type: 'slider',
        prompt: 'დააყენე ბირთვული გენერატორის სიმძლავრე 98%-ზე',
        sliderTarget: 98
      },
      {
        id: 't_tech_6',
        name: 'კვანტური კრიპტოგრაფია',
        type: 'code',
        prompt: 'შეიყვანე კვანტური შიფრატორის გასაღები: 4096',
        options: ['4096']
      }
    ]
  },
  {
    id: 'croupier',
    name: 'VIP კაზინოს კრუპიე & დილერი',
    iconName: 'Dices',
    category: 'აზარტული თამაშები',
    requiredLevel: 14,
    salary: 220,
    xpReward: 210,
    cooldownSeconds: 28,
    description: 'აკონტროლებ მაგიდას BlackJack-სა და რულეტკაზე. თვალის ერთი შევლებით იცი მოთამაშის ფსიქოლოგია.',
    tasks: [
      {
        id: 't_croup_1',
        name: 'კარტის დარიგება BlackJack-ზე',
        type: 'quiz',
        prompt: 'მოთამაშეს ყავს 16, დილერის ღია კარტია 6. რა მოქმედებას ელით მოთამაშისგან?',
        options: ['Stand (გაჩერება)', 'Hit (კიდევ ერთი კარტის აღება)', 'ფსონის გაოთხმაგება'],
        correctOption: 0
      },
      {
        id: 't_croup_2',
        name: 'ჩიპების სწრაფი გადათვლა',
        type: 'quick_tap',
        prompt: 'დააჭირე 7-ჯერ მოგებული ჩიპების მომენტალური გასაცემად!',
        targetCount: 7
      },
      {
        id: 't_croup_3',
        name: 'რულეტკის ბორბლის ბრუნი',
        type: 'slider',
        prompt: 'დააყენე ბურთულის სასროლი სიჩქარე 45 RPM-ზე',
        sliderTarget: 45
      },
      {
        id: 't_croup_4',
        name: 'კარტის დასტის გაჭრა (Cut)',
        type: 'slider',
        prompt: 'გაჭერი 52-კარტიანი დასტა შუაზე: ზუსტად 26-ზე',
        sliderTarget: 26
      },
      {
        id: 't_croup_5',
        name: 'VIP მაგიდის უსაფრთხოების კოდი',
        type: 'code',
        prompt: 'შეიყვანე კრუპიეს პერსონალური გასაღები: 7721',
        options: ['7721']
      },
      {
        id: 't_croup_6',
        name: 'მოთამაშის ფსიქოლოგია',
        type: 'quiz',
        prompt: 'აზარტში შესული ოლიგარქი ზედიზედ აგებს და ნერვიულობს. რა არის კრუპიეს ეტიკეტი?',
        options: ['შეინარჩუნე უნაკლო თავაზიანობა და პროფესიონალიზმი', 'დაუწყე დაცინვა', 'დატოვე მაგიდა'],
        correctOption: 0
      },
      {
        id: 't_croup_7',
        name: 'ჩიპების პირამიდის აგება',
        type: 'quick_tap',
        prompt: 'დააჭირე 8-ჯერ ჩიპების დასალაგებლად მაგიდაზე!',
        targetCount: 8
      }
    ]
  },
  {
    id: 'vip_driver',
    name: 'ოლიგარქის პირადი VIP მძღოლი',
    iconName: 'Car',
    category: 'ლუქს სერვისი',
    requiredLevel: 24,
    salary: 500,
    xpReward: 460,
    cooldownSeconds: 35,
    description: 'მართავ Maybach-სა და Rolls-Royce-ს. აცილებ ქალაქის ელიტას უსაფრთხოდ და უმაღლესი კომფორტით.',
    tasks: [
      {
        id: 't_drv_1',
        name: 'საცობის ექსპრეს შემოვლა',
        type: 'quiz',
        prompt: 'აეროპორტის ტრასაზე შეფერხებაა. რომელი მარშრუტით მიიყვან ბოსს დროულად?',
        options: ['ორთაჭალის შემოვლითი გზატკეცილით', 'მთავარ საცობში დგომით', 'ფეხით სიარულით'],
        correctOption: 0
      },
      {
        id: 't_drv_2',
        name: 'Maybach-ის სავალი ნაწილის სინაზე',
        type: 'slider',
        prompt: 'დააყენე პნევმო-დაკიდების სირბილე 90%-ზე',
        sliderTarget: 90
      },
      {
        id: 't_drv_3',
        name: 'კარის გაღება და ბარგის დაბინავება',
        type: 'quick_tap',
        prompt: 'დააჭირე 6-ჯერ უმაღლესი ეტიკეტის დასაცავად!',
        targetCount: 6
      },
      {
        id: 't_drv_4',
        name: 'საბურავების სამუშაო წნევა',
        type: 'slider',
        prompt: 'დაარეგულირე წნევა 2.4 ბარზე (24-ზე) მაქსიმალური კომფორტისთვის',
        sliderTarget: 24
      },
      {
        id: 't_drv_5',
        name: 'კერძო ტერმინალის საშვი',
        type: 'code',
        prompt: 'შეიყვანე აეროპორტის VIP ტერმინალის საშვის კოდი: 5510',
        options: ['5510']
      },
      {
        id: 't_drv_6',
        name: 'ესკორტის კოლონა',
        type: 'quick_tap',
        prompt: 'დააჭირე 8-ჯერ დაცვის ესკორტის სინქრონული მოძრაობისთვის!',
        targetCount: 8
      },
      {
        id: 't_drv_7',
        name: 'კლიმატ-კონტროლის დაკალიბრება',
        type: 'slider',
        prompt: 'დააყენე სალონის იდეალური ტემპერატურა 21°C-ზე (21)',
        sliderTarget: 21
      }
    ]
  },
  {
    id: 'detective',
    name: 'კერძო გამომძიებელი & დეტექტივი',
    iconName: 'Search',
    category: 'გამოძიება',
    requiredLevel: 42,
    salary: 1400,
    xpReward: 1150,
    cooldownSeconds: 45,
    description: 'ხსნი ჩახლართულ საქმეებს, აგროვებ კომპრომატებს და ეძებ სიმართლეს ქალაქის ჩრდილში.',
    tasks: [
      {
        id: 't_det_1',
        name: 'მიყურადების სიხშირის დაჭერა',
        type: 'slider',
        prompt: 'დაასინქრონე რადიო-მიმღები 75 MHz-ზე (75-ზე)',
        sliderTarget: 75
      },
      {
        id: 't_det_2',
        name: 'კვალის ანალიზი',
        type: 'quiz',
        prompt: 'ადგილზე დარჩენილია მაღალი კლასის სუნამოს სურნელი და შავი ხელთათმანი. ვინ არის ეჭვმიტანილი?',
        options: ['ელიტური სინდიკატის კონტრაქტორი', 'შემთხვევითი გამვლელი', 'ქუჩის მტრედი'],
        correctOption: 0
      },
      {
        id: 't_det_3',
        name: 'სამხილების გადაღება ტელე-ობიექტივით',
        type: 'quick_tap',
        prompt: 'დააჭირე 8-ჯერ მკაფიო კადრების დასაფიქსირებლად!',
        targetCount: 8
      },
      {
        id: 't_det_4',
        name: 'საიდუმლო არქივის შიფრი',
        type: 'code',
        prompt: 'შეიყვანე დახურული საქმის შიფრი: 3099',
        options: ['3099']
      },
      {
        id: 't_det_5',
        name: 'მიკროფონის მგრძნობელობა',
        type: 'slider',
        prompt: 'დააყენე მიკროფონის მგრძნობელობა 75 dB-ზე',
        sliderTarget: 75
      },
      {
        id: 't_det_6',
        name: 'სეიფის საკეტის გაშიფვრა',
        type: 'quick_tap',
        prompt: 'დააჭირე 9-ჯერ ელექტრონული საკეტის გასატეხად!',
        targetCount: 9
      }
    ]
  },
  {
    id: 'holding_president',
    name: 'საერთაშორისო ჰოლდინგის პრეზიდენტი',
    iconName: 'Crown',
    category: 'უმაღლესი მმართველობა',
    requiredLevel: 210,
    salary: 40000,
    xpReward: 39000,
    cooldownSeconds: 120,
    description: 'მართავ კონტინენტურ აქტივებს, ბანკებსა და საინვესტიციო იმპერიას. შენი ხელმოწერა მილიარდებს წყვეტს.',
    tasks: [
      {
        id: 't_pres_1',
        name: 'მეგა-შერწყმის დამტკიცება',
        type: 'quiz',
        prompt: 'რომელი სტრატეგიული გადაწყვეტილება გააორმაგებს ჰოლდინგის კაპიტალიზაციას?',
        options: ['ტექნოლოგიური და ლოჯისტიკური აქტივების ინტეგრაცია', 'ყველა აქციის გაყიდვა', 'ოფისის დაკეტვა'],
        correctOption: 0
      },
      {
        id: 't_pres_2',
        name: 'პრეზიდენტის სეიფის კოდი',
        type: 'code',
        prompt: 'შეიყვანე პრეზიდენტის კოდი აქტივების ტრანშისთვის: 9901',
        options: ['9901']
      },
      {
        id: 't_pres_3',
        name: 'დირექტორთა საბჭოს ხმის მიცემა',
        type: 'quick_tap',
        prompt: 'დააჭირე 14-ჯერ ისტორიული რეზოლუციის მისაღებად!',
        targetCount: 14
      },
      {
        id: 't_pres_4',
        name: 'გლობალური დივიდენდის პროცენტი',
        type: 'slider',
        prompt: 'დააყენე კვარტალური დივიდენდი 18%-ზე (18)',
        sliderTarget: 18
      },
      {
        id: 't_pres_5',
        name: 'აქციების Buyback ოპერაცია',
        type: 'quick_tap',
        prompt: 'დააჭირე 10-ჯერ ბაზრიდან აქციების გამოსასყიდად!',
        targetCount: 10
      },
      {
        id: 't_pres_6',
        name: 'კრიპტო-რეზერვის ავტორიზაცია',
        type: 'code',
        prompt: 'შეიყვანე ციფრული რეზერვის სამაგისტრო გასაღები: 8800',
        options: ['8800']
      }
    ]
  },
  {
    id: 'taxi_driver', name: 'თბილისის ტაქსის მძღოლი', iconName: 'Car', category: 'ტრანსპორტი', requiredLevel: 2,
    salary: 45, xpReward: 16, cooldownSeconds: 18,
    description: 'გადაიყვანე მგზავრები ქალაქში უსაფრთხოდ და დროულად.',
    tasks: [
      { id: 't_taxi_1', name: 'მარშრუტის დაგეგმვა', type: 'quiz', prompt: 'მგზავრს ვაკიდან თავისუფლების მოედანზე უნდა მისვლა. რომელ მარშრუტს ირჩევ?', options: ['საცობის შემოვლით გზას', 'ყველაზე გრძელ გზას', 'შემთხვევით ქუჩას'], correctOption: 0 },
      { id: 't_taxi_2', name: 'ტარიფის გამოთვლა', type: 'slider', prompt: 'მგზავრობის საფასური დააყენე 18 ლარზე.', sliderTarget: 18 },
      { id: 't_taxi_3', name: 'სწრაფი გაჩერება', type: 'quick_tap', prompt: 'დააჭირე 5-ჯერ, რომ უსაფრთხოდ აიყვანო მგზავრი!', targetCount: 5 },
      { id: 't_taxi_4', name: 'მგზავრის კოდი', type: 'code', prompt: 'შეიყვანე მგზავრის შეკვეთის კოდი: 2416', options: ['2416'] }
    ]
  },
  {
    id: 'barista', name: 'ბარისტა ძველ თბილისში', iconName: 'Coffee', category: 'სერვისი', requiredLevel: 3,
    salary: 60, xpReward: 22, cooldownSeconds: 22,
    description: 'მოამზადე შეკვეთები და მოემსახურე კაფის სტუმრებს.',
    tasks: [
      { id: 't_barista_1', name: 'ყავის რეცეპტი', type: 'quiz', prompt: 'კაპუჩინოს მოსამზადებლად რა გჭირდება?', options: ['ესპრესო და აქაფებული რძე', 'მხოლოდ ჩაი', 'ლიმონი და წყალი'], correctOption: 0 },
      { id: 't_barista_2', name: 'რძის ტემპერატურა', type: 'slider', prompt: 'რძის ტემპერატურა დააყენე 62 გრადუსზე.', sliderTarget: 62 },
      { id: 't_barista_3', name: 'შეკვეთების მიღება', type: 'quick_tap', prompt: 'დააჭირე 6-ჯერ, რომ რიგის შეკვეთები მიიღო!', targetCount: 6 },
      { id: 't_barista_4', name: 'მაგიდის ნომერი', type: 'code', prompt: 'შეიყვანე შეკვეთის მაგიდის ნომერი: 1204', options: ['1204'] }
    ]
  },
  {
    id: 'paramedic', name: 'სასწრაფო დახმარების პარამედიკოსი', iconName: 'HeartPulse', category: 'მედიცინა', requiredLevel: 7,
    salary: 95, xpReward: 35, cooldownSeconds: 28,
    description: 'შეაფასე გამოძახება და დაეხმარე პაციენტს კლინიკამდე.',
    tasks: [
      { id: 't_para_1', name: 'პირველადი დახმარება', type: 'quiz', prompt: 'პაციენტი გონზეა და ხელი აქვს გაჭრილი. რა არის პირველი ნაბიჯი?', options: ['ჭრილობის დაფარვა და სისხლდენის შეჩერება', 'პაციენტის მარტო დატოვება', 'წყლის დასხმა'], correctOption: 0 },
      { id: 't_para_2', name: 'პულსის შემოწმება', type: 'slider', prompt: 'პულსი დააფიქსირე 76 დარტყმაზე წუთში.', sliderTarget: 76 },
      { id: 't_para_3', name: 'სამედიცინო ჩანთა', type: 'quick_tap', prompt: 'დააჭირე 7-ჯერ და მოამზადე პირველადი დახმარების ჩანთა!', targetCount: 7 },
      { id: 't_para_4', name: 'გამოძახების კოდი', type: 'code', prompt: 'შეიყვანე სასწრაფოს დავალების კოდი: 1127', options: ['1127'] }
    ]
  },
  {
    id: 'chef', name: 'რესტორნის მზარეული', iconName: 'ChefHat', category: 'კვება', requiredLevel: 11,
    salary: 140, xpReward: 48, cooldownSeconds: 35,
    description: 'მოამზადე კერძები და შეინარჩუნე სამზარეულოს ტემპი.',
    tasks: [
      { id: 't_chef_1', name: 'შეკვეთის შერჩევა', type: 'quiz', prompt: 'ხაჭაპურის მთავარი ინგრედიენტი რომელია?', options: ['ყველი', 'კაკაო', 'ბრინჯი'], correctOption: 0 },
      { id: 't_chef_2', name: 'ღუმელის დაყენება', type: 'slider', prompt: 'ღუმელის ტემპერატურა დააყენე 85 გრადუსზე.', sliderTarget: 85 },
      { id: 't_chef_3', name: 'სერვირების ტემპი', type: 'quick_tap', prompt: 'დააჭირე 8-ჯერ და გაატანე შეკვეთები!', targetCount: 8 },
      { id: 't_chef_4', name: 'სამზარეულოს შეკვეთა', type: 'code', prompt: 'შეიყვანე შეკვეთის ნომერი: 3075', options: ['3075'] }
    ]
  },
  {
    id: 'construction', name: 'სამშენებლო ბრიგადის ოსტატი', iconName: 'HardHat', category: 'მშენებლობა', requiredLevel: 16,
    salary: 220, xpReward: 70, cooldownSeconds: 45,
    description: 'შეამოწმე მასალები და უხელმძღვანელე ბრიგადის ცვლას.',
    tasks: [
      { id: 't_build_1', name: 'უსაფრთხოების შემოწმება', type: 'quiz', prompt: 'სამშენებლო მოედანზე მუშაობამდე რა უნდა ჩაიცვა?', options: ['ჩაფხუტი და დამცავი ფეხსაცმელი', 'სანდლები', 'არაფერი'], correctOption: 0 },
      { id: 't_build_2', name: 'მასალის გაზომვა', type: 'slider', prompt: 'ფიცრის სიგრძე 40 სმ ნიშნულზე დააყენე.', sliderTarget: 40 },
      { id: 't_build_3', name: 'ინვენტარის დათვლა', type: 'quick_tap', prompt: 'დააჭირე 9-ჯერ და დათვალე ხელსაწყოები!', targetCount: 9 },
      { id: 't_build_4', name: 'ობიექტის კოდი', type: 'code', prompt: 'შეიყვანე სამშენებლო ობიექტის კოდი: 4382', options: ['4382'] }
    ]
  },
  {
    id: 'it_support', name: 'კომპიუტერული ტექნიკის სპეციალისტი', iconName: 'Laptop', category: 'ტექნოლოგია', requiredLevel: 23,
    salary: 350, xpReward: 95, cooldownSeconds: 55,
    description: 'მოაგვარე საოფისე ქსელისა და კომპიუტერების პრობლემები.',
    tasks: [
      { id: 't_it_1', name: 'ქსელის დიაგნოსტიკა', type: 'quiz', prompt: 'ინტერნეტი ერთ კომპიუტერზე არ მუშაობს. რა შეამოწმებ ჯერ?', options: ['ქსელურ კავშირს', 'კომპიუტერის ფერს', 'დინამიკს'], correctOption: 0 },
      { id: 't_it_2', name: 'სერვერის დატვირთვა', type: 'slider', prompt: 'სერვერის დატვირთვა დააყენე 42%-ზე.', sliderTarget: 42 },
      { id: 't_it_3', name: 'კომპონენტების მონტაჟი', type: 'quick_tap', prompt: 'დააჭირე 8-ჯერ და მოამზადე კომპიუტერი!', targetCount: 8 },
      { id: 't_it_4', name: 'სერვისის კოდი', type: 'code', prompt: 'შეიყვანე ტექნიკური მხარდაჭერის კოდი: 6130', options: ['6130'] }
    ]
  },
  {
    id: 'teacher', name: 'კერძო სკოლის მასწავლებელი', iconName: 'BookOpen', category: 'განათლება', requiredLevel: 30,
    salary: 550, xpReward: 140, cooldownSeconds: 70,
    description: 'ჩაატარე გაკვეთილი და შეამოწმე მოსწავლეების პროგრესი.',
    tasks: [
      { id: 't_teacher_1', name: 'გაკვეთილის გეგმა', type: 'quiz', prompt: 'რომელი არჩევანი ეხმარება მოსწავლეს ახალი თემის გაგებაში?', options: ['მაგალითი და ახსნა', 'მხოლოდ რთული ტესტი', 'თემის გამოტოვება'], correctOption: 0 },
      { id: 't_teacher_2', name: 'გაკვეთილის დრო', type: 'slider', prompt: 'გაკვეთილის ხანგრძლივობა დააყენე 45 წუთზე.', sliderTarget: 45 },
      { id: 't_teacher_3', name: 'ნაშრომების შემოწმება', type: 'quick_tap', prompt: 'დააჭირე 10-ჯერ და შეამოწმე დავალებები!', targetCount: 10 },
      { id: 't_teacher_4', name: 'კლასის ჟურნალი', type: 'code', prompt: 'შეიყვანე კლასის ჟურნალის კოდი: 7521', options: ['7521'] }
    ]
  },
  {
    id: 'pilot', name: 'რეგიონული ავიახაზების პილოტი', iconName: 'Plane', category: 'ავიაცია', requiredLevel: 40,
    salary: 900, xpReward: 220, cooldownSeconds: 90,
    description: 'მოამზადე რეისი და უსაფრთხოდ გადაიყვანე მგზავრები.',
    tasks: [
      { id: 't_pilot_1', name: 'წინასაფრენი შემოწმება', type: 'quiz', prompt: 'აფრენამდე რა მოწმდება პირველ რიგში?', options: ['თვითმფრინავის სისტემები', 'მგზავრების მუსიკა', 'სავარძლების ფერი'], correctOption: 0 },
      { id: 't_pilot_2', name: 'სიმაღლის დაყენება', type: 'slider', prompt: 'სიმაღლის მაჩვენებელი დააყენე 90 ნიშნულზე.', sliderTarget: 90 },
      { id: 't_pilot_3', name: 'საკონტროლო პანელი', type: 'quick_tap', prompt: 'დააჭირე 10-ჯერ და შეამოწმე სისტემები!', targetCount: 10 },
      { id: 't_pilot_4', name: 'რეისის ნომერი', type: 'code', prompt: 'შეიყვანე რეისის ნომერი: 8406', options: ['8406'] }
    ]
  },
  {
    id: 'farmer', name: 'კახეთის მევენახე', iconName: 'Sprout', category: 'სოფლის მეურნეობა', requiredLevel: 50,
    salary: 1400, xpReward: 310, cooldownSeconds: 120,
    description: 'მოუარე ვენახს და მოამზადე მოსავალი გასაყიდად.',
    tasks: [
      { id: 't_farm_1', name: 'მოსავლის მოვლა', type: 'quiz', prompt: 'რა ეხმარება ვაზს ჯანმრთელი მოსავლის მოცემაში?', options: ['მორწყვა და მოვლა', 'მოსავლის დატოვება უყურადღებოდ', 'ფესვების მოჭრა'], correctOption: 0 },
      { id: 't_farm_2', name: 'მოსავლის წონა', type: 'slider', prompt: 'მოსავლის ყუთის წონა დააყენე 24 კგ-ზე.', sliderTarget: 24 },
      { id: 't_farm_3', name: 'ყურძნის დახარისხება', type: 'quick_tap', prompt: 'დააჭირე 12-ჯერ და დაახარისხე მოსავალი!', targetCount: 12 },
      { id: 't_farm_4', name: 'მინდვრის კოდი', type: 'code', prompt: 'შეიყვანე ვენახის ნაკვეთის კოდი: 5062', options: ['5062'] }
    ]
  },
  {
    id: 'event_planner', name: 'თბილისის ღონისძიებების კოორდინატორი', iconName: 'CalendarDays', category: 'ღონისძიებები', requiredLevel: 65,
    salary: 2500, xpReward: 500, cooldownSeconds: 150,
    description: 'დაგეგმე ღონისძიება, შეათანხმე მომწოდებლები და გაუძეხი სტუმრებს.',
    tasks: [
      { id: 't_event_1', name: 'ღონისძიების გეგმა', type: 'quiz', prompt: 'რა არის ღონისძიების დაგეგმვის პირველი ნაბიჯი?', options: ['ბიუჯეტისა და საჭიროებების განსაზღვრა', 'ყველა დეკორის ყიდვა', 'სტუმრების იგნორირება'], correctOption: 0 },
      { id: 't_event_2', name: 'ბიუჯეტის კონტროლი', type: 'slider', prompt: 'დეკორაციის ბიუჯეტის მაჩვენებელი დააყენე 32 ნიშნულზე.', sliderTarget: 32 },
      { id: 't_event_3', name: 'სტუმრების მიღება', type: 'quick_tap', prompt: 'დააჭირე 12-ჯერ და მიიღე სტუმრები!', targetCount: 12 },
      { id: 't_event_4', name: 'დარბაზის კოდი', type: 'code', prompt: 'შეიყვანე ღონისძიების დარბაზის კოდი: 9145', options: ['9145'] }
    ]
  }
];

export const INITIAL_CONTRACTS: Contract[] = [
  {
    id: 'cntr_1',
    title: 'კონტეინერის ექსპედირება ფოთის პორტიდან',
    client: 'შავი ზღვის ლოჯისტიკა',
    cost: 500,
    payout: 650,
    xpReward: 260,
    durationSeconds: 15,
    requiredLevel: 2,
    description: 'სწრაფი ტვირთი გერმანიიდან. საჭიროებს საწყის დეპოზიტს და გარანტირებულ მიწოდებას.'
  },
  {
    id: 'cntr_2',
    title: 'ელიტური წვეულების ორგანიზება შატოზე',
    client: 'VIP კლუბის წევრები',
    cost: 3500,
    payout: 4700,
    xpReward: 850,
    durationSeconds: 30,
    requiredLevel: 12,
    description: 'შამპანური, ცოცხალი მუსიკა და უმაღლესი დონის დაცვა ქალაქის ელიტისთვის.'
  },
  {
    id: 'cntr_3',
    title: 'კაზინოს სერვერების კიბერ-დაცვის აუდიტი',
    client: 'ონლაინ გემბლინგ ჰოლდინგი',
    cost: 18000,
    payout: 23400,
    xpReward: 2600,
    durationSeconds: 60,
    requiredLevel: 30,
    description: 'DDoS შეტევების მოგერიება და შიდა ტრანზაქციების დაშიფვრა.'
  },
  {
    id: 'cntr_4',
    title: 'კერძო საინვესტიციო ფონდის რესტრუქტურიზაცია',
    client: 'შვეიცარიული ჰოლდინგი',
    cost: 75000,
    payout: 97500,
    xpReward: 7800,
    durationSeconds: 120,
    requiredLevel: 65,
    description: 'ოფშორული ანგარიშების ოპტიმიზაცია და აქტივების გადაბარება.'
  },
  {
    id: 'cntr_5',
    title: 'ქალაქის ინფრასტრუქტურის მონოპოლიზაცია',
    client: 'კონსორციუმი "მეგაპოლისი"',
    cost: 350000,
    payout: 455000,
    xpReward: 25000,
    durationSeconds: 240,
    requiredLevel: 120,
    description: 'უპრეცედენტო მასშტაბის მეგა-პროექტი. უზრუნველყოფს უმაღლეს ძალაუფლებას.'
  },
  {
    id: 'cntr_gold',
    title: 'ოქროს ზოდების შეიარაღებული ტრანსპორტირება',
    client: 'შვეიცარიული ოქროს საცავი',
    cost: 8500,
    payout: 11000,
    xpReward: 1650,
    durationSeconds: 45,
    requiredLevel: 20,
    description: 'ჯავშნიანი კოლონით 100 კგ ოქროს უსაფრთხო გადატანა აეროპორტის ტერმინალამდე.'
  },
  {
    id: 'cntr_yacht',
    title: 'ბათუმის VIP იახტ-კლუბის გახსნის საზეიმო ხელშეკრულება',
    client: 'შავი ზღვის ელიტარული ასოციაცია',
    cost: 45000,
    payout: 58000,
    xpReward: 4800,
    durationSeconds: 90,
    requiredLevel: 48,
    description: 'ლუქს იახტების პრეზენტაცია, საერთაშორისო სტუმრების მიღება და ექსკლუზიური უფლებები.'
  },
  {
    id: 'cntr_crypto_fund',
    title: 'კრიპტო ჰეჯ-ფონდის ლიკვიდურობის უზრუნველყოფა',
    client: 'Global DeFi Consortium',
    cost: 160000,
    payout: 210000,
    xpReward: 11000,
    durationSeconds: 150,
    requiredLevel: 85,
    description: 'მილიონობით დოლარის კრიპტოაქტივების სტაბილიზაცია და სვოპ ოპერაციები.'
  },
  {
    id: 'cntr_quantum',
    title: 'კვანტური სატელიტის გაშვება ორბიტაზე',
    client: 'კოსმოსური სააგენტო "GeoSpace"',
    cost: 750000,
    payout: 1050000,
    xpReward: 42000,
    durationSeconds: 300,
    requiredLevel: 145,
    description: 'მაღალტექნოლოგიური თანამგზავრის გაშვება გლობალური ფინანსური ქსელების დასაკავშირებლად.'
  },
  {
    id: 'cntr_oil',
    title: 'ტრანს-კავკასიური ენერგომაგისტრალის კონსორციუმი',
    client: 'საერთაშორისო ენერგო ჰოლდინგი',
    cost: 2400000,
    payout: 3360000,
    xpReward: 120000,
    durationSeconds: 450,
    requiredLevel: 220,
    description: 'გლობალური მასშტაბის მეგა-კონტრაქტი. სახელმწიფო დონის შემოსავლები და გავლენა.'
  }
];

export const INITIAL_UPGRADERS: Upgrader[] = [
  {
    id: 'upg_coffee',
    name: 'ორმაგი ესპრესო და ენერგეტიკი',
    description: 'მატებს ენერგიას და ავტომატურ ფულად ბონუსს 120 წამში ერთხელ.',
    iconName: 'Coffee',
    baseCost: 150,
    passivePerCycle: 240, // 240 Lari every 120s
    cycleSeconds: 120,
    owned: 0
  },
  {
    id: 'upg_bot',
    name: 'AI სავაჭრო ალგორითმი',
    description: 'ავტომატური ბოტი, რომელიც გენერირებს კაპიტალს 120 წამში ერთხელ.',
    iconName: 'Bot',
    baseCost: 1200,
    passivePerCycle: 2160, // 2,160 Lari every 120s
    cycleSeconds: 120,
    owned: 0
  },
  {
    id: 'upg_manager',
    name: 'პერსონალური ფინანსური მენეჯერი',
    description: 'პროფესიონალი, რომელიც 120 წამში ერთხელ რიცხავს სოლიდურ დივიდენდს.',
    iconName: 'Briefcase',
    baseCost: 6500,
    passivePerCycle: 11400, // 11,400 Lari every 120s
    cycleSeconds: 120,
    owned: 0
  },
  {
    id: 'upg_offshore',
    name: 'ოფშორული საბანკო არხები',
    description: 'გადასახადებისგან თავისუფალი მსხვილი ტრანში 120 წამში ერთხელ.',
    iconName: 'Globe',
    baseCost: 35000,
    passivePerCycle: 57600, // 57,600 Lari every 120s
    cycleSeconds: 120,
    owned: 0
  },
  {
    id: 'upg_political',
    name: 'გავლენიანი პოლიტიკური კავშირები',
    description: 'მწვანე შუქი და გიგანტური შემოდინება 120 წამში ერთხელ.',
    iconName: 'Crown',
    baseCost: 180000,
    passivePerCycle: 288000, // 288,000 Lari every 120s
    cycleSeconds: 120,
    owned: 0
  },
  {
    id: 'upg_quantum',
    name: 'კვანტური სუპერკომპიუტერი',
    description: 'კოლოსალური გამოთვლითი სიმძლავრე და მეგა-მოგება 120 წამში ერთხელ.',
    iconName: 'Zap',
    baseCost: 950000,
    passivePerCycle: 1740000, // 1.74M Lari every 120s
    cycleSeconds: 120,
    owned: 0
  },
  {
    id: 'upg_airbnb_sololaki',
    name: 'სოლოლაკის Airbnb მენეჯმენტი',
    description: 'ტურისტების მუდმივი ნაკადი და სტაბილური დივიდენდი 120 წამში ერთხელ.',
    iconName: 'Home',
    baseCost: 8500,
    passivePerCycle: 14200,
    cycleSeconds: 120,
    owned: 0
  },
  {
    id: 'upg_carwash_chain',
    name: 'ავტო-სამრეცხაოების 24/7 ქსელი',
    description: 'თვითმომსახურების ბოქსები საბურთალო-დიდუბეში. ფული მოედინება 120 წამში ერთხელ.',
    iconName: 'Droplets',
    baseCost: 24000,
    passivePerCycle: 42000,
    cycleSeconds: 120,
    owned: 0
  },
  {
    id: 'upg_asic_hangar',
    name: 'ASIC სამაინინგო ანგარი გლდანში',
    description: 'სამრეწველო სიმძლავრის კრიპტო მაინერები. 120 წამში ერთხელ სქელი ბიტკოინ მოგება.',
    iconName: 'Cpu',
    baseCost: 95000,
    passivePerCycle: 165000,
    cycleSeconds: 120,
    owned: 0
  },
  {
    id: 'upg_dubai_fund',
    name: 'დუბაის უძრავი ქონების ფონდი',
    description: 'საინვესტიციო წილი Downtown Dubai-ს ცათამბჯენებში 120 წამში ერთხელ.',
    iconName: 'Building2',
    baseCost: 450000,
    passivePerCycle: 760000,
    cycleSeconds: 120,
    owned: 0
  },
  {
    id: 'upg_satellite_network',
    name: 'კოსმოსური სატელიტური ინტერნეტი',
    description: 'გლობალური თანამგზავრული ქსელი. უზარმაზარი კოსმოსური დივიდენდი 120 წამში ერთხელ.',
    iconName: 'Radio',
    baseCost: 3500000,
    passivePerCycle: 6200000,
    cycleSeconds: 120,
    owned: 0
  }
];

export const LUXURY_CARS: Car[] = [
  {
    id: 'car_lada',
    name: 'VAZ 2107 "შავ ტონირებაში"',
    brand: 'Lada',
    price: 900,
    respect: 10,
    bonusMultiplier: 1.01,
    speed: '145 კმ/სთ',
    color: '#1a1a1a',
    image: '🏎️'
  },
  // --- ძველი მერსედესები (Old Mercedes Classics) ---
  {
    id: 'car_w124',
    name: 'Mercedes-Benz W124 E500 "ვოლჩოკი"',
    brand: 'Mercedes-Benz Classic',
    price: 18500,
    respect: 75,
    bonusMultiplier: 1.04,
    speed: '250 კმ/სთ',
    color: '#0f172a',
    image: '🚘'
  },
  {
    id: 'car_w140',
    name: 'Mercedes-Benz W140 S600 V12 "კაბანი"',
    brand: 'Mercedes-Benz Classic',
    price: 32000,
    respect: 120,
    bonusMultiplier: 1.07,
    speed: '250 კმ/სთ',
    color: '#050505',
    image: '🚘'
  },
  {
    id: 'car_w211_e55',
    name: 'Mercedes-Benz E55 AMG W211 Kompressor V8',
    brand: 'Mercedes-AMG',
    price: 38000,
    respect: 150,
    bonusMultiplier: 1.09,
    speed: '280 კმ/სთ',
    color: '#334155',
    image: '🏎️'
  },
  // --- ტოიოტები (Toyotas) ---
  {
    id: 'car_prius',
    name: 'Toyota Prius 20 Hybrid "ქალაქის ეკონომია"',
    brand: 'Toyota',
    price: 8500,
    respect: 30,
    bonusMultiplier: 1.02,
    speed: '170 კმ/სთ',
    color: '#e2e8f0',
    image: '🚗'
  },
  {
    id: 'car_camry',
    name: 'Toyota Camry 3.5 V6 "შავი პრესტიჟი"',
    brand: 'Toyota',
    price: 28000,
    respect: 90,
    bonusMultiplier: 1.06,
    speed: '235 კმ/სთ',
    color: '#111827',
    image: '🚙'
  },
  {
    id: 'car_prado',
    name: 'Toyota Land Cruiser Prado 150 4.0 V6',
    brand: 'Toyota',
    price: 65000,
    respect: 210,
    bonusMultiplier: 1.10,
    speed: '200 კმ/სთ',
    color: '#ffffff',
    image: '🚙'
  },
  {
    id: 'car_lc300',
    name: 'Toyota Land Cruiser 300 GR Sport Twin-Turbo',
    brand: 'Toyota',
    price: 145000,
    respect: 390,
    bonusMultiplier: 1.14,
    speed: '220 კმ/სთ',
    color: '#1e293b',
    image: '🚙'
  },
  {
    id: 'car_supra',
    name: 'Toyota GR Supra 3.0 Turbo Manual Edition',
    brand: 'Toyota GR',
    price: 89000,
    respect: 280,
    bonusMultiplier: 1.12,
    speed: '275 კმ/სთ',
    color: '#ef4444',
    image: '🏎️'
  },
  // --- 4 ტიპის AUDI QUATTRO ---
  {
    id: 'car_audi_a6_c6',
    name: 'Audi A6 C6 3.2 FSI V6 Quattro',
    brand: 'Audi Quattro',
    price: 19500,
    respect: 70,
    bonusMultiplier: 1.05,
    speed: '250 კმ/სთ',
    color: '#334155',
    image: '🚘'
  },
  {
    id: 'car_audi_s6_c7',
    name: 'Audi S6 C7 4.0 TFSI V8 BiTurbo Quattro',
    brand: 'Audi Quattro',
    price: 49000,
    respect: 180,
    bonusMultiplier: 1.11,
    speed: '280 კმ/სთ',
    color: '#090a0f',
    image: '🏎️'
  },
  {
    id: 'car_audi_rs6_c8',
    name: 'Audi RS6 Avant C8 Quattro 600HP',
    brand: 'Audi Sport Quattro',
    price: 198000,
    respect: 520,
    bonusMultiplier: 1.18,
    speed: '305 კმ/სთ',
    color: '#475569',
    image: '🚀'
  },
  {
    id: 'car_audi_r8',
    name: 'Audi R8 V10 Performance Quattro',
    brand: 'Audi Sport Quattro',
    price: 340000,
    respect: 850,
    bonusMultiplier: 1.25,
    speed: '331 კმ/სთ',
    color: '#f59e0b',
    image: '⚡'
  },
  // --- BMW & Mercedes-Benz & Supercars ---
  {
    id: 'car_e39',
    name: 'BMW M5 E39 V8 5.0',
    brand: 'BMW M-Power',
    price: 24000,
    respect: 85,
    bonusMultiplier: 1.05,
    speed: '280 კმ/სთ',
    color: '#0d2040',
    image: '🚘'
  },
  {
    id: 'car_gwagon',
    name: 'Mercedes-Benz G63 AMG "Geländewagen"',
    brand: 'Mercedes-AMG',
    price: 185000,
    respect: 450,
    bonusMultiplier: 1.12,
    speed: '250 კმ/სთ',
    color: '#111827',
    image: '🚙'
  },
  // --- ახალი მერსედესები (New Mercedes Modern Generation) ---
  {
    id: 'car_merc_gt63s',
    name: 'Mercedes-AMG GT 63 S E-Performance 4-Door 843HP',
    brand: 'Mercedes-AMG',
    price: 260000,
    respect: 650,
    bonusMultiplier: 1.22,
    speed: '316 კმ/სთ',
    color: '#1e1b4b',
    image: '⚡'
  },
  {
    id: 'car_merc_s680_maybach',
    name: 'Mercedes-Maybach S 680 V12 4MATIC Biturbo',
    brand: 'Mercedes-Maybach',
    price: 420000,
    respect: 980,
    bonusMultiplier: 1.30,
    speed: '260 კმ/სთ',
    color: '#18181b',
    image: '👑'
  },
  {
    id: 'car_gt3rs',
    name: 'Porsche 911 GT3 RS Weissach',
    brand: 'Porsche',
    price: 680000,
    respect: 1200,
    bonusMultiplier: 1.35,
    speed: '320 კმ/სთ',
    color: '#047857',
    image: '🏎️'
  },
  {
    id: 'car_lambo',
    name: 'Lamborghini Revuelto V12 Hybrid',
    brand: 'Lamborghini',
    price: 1950000,
    respect: 3500,
    bonusMultiplier: 1.45,
    speed: '355 კმ/სთ',
    color: '#f59e0b',
    image: '⚡'
  },
  {
    id: 'car_chiron',
    name: 'Bugatti Chiron Pur Sport Quad-Turbo',
    brand: 'Bugatti',
    price: 6500000,
    respect: 12000,
    bonusMultiplier: 1.80,
    speed: '440 კმ/სთ',
    color: '#2563eb',
    image: '🚀'
  },
  // --- CHEVROLET ---
  {
    id: 'car_camaro_ss',
    name: 'Chevrolet Camaro SS 6.2 V8 Muscle',
    brand: 'Chevrolet',
    price: 48000,
    respect: 180,
    bonusMultiplier: 1.07,
    speed: '290 კმ/სთ',
    color: '#eab308',
    image: '🏎️'
  },
  {
    id: 'car_camaro_zl1',
    name: 'Chevrolet Camaro ZL1 650HP Supercharged',
    brand: 'Chevrolet',
    price: 78000,
    respect: 240,
    bonusMultiplier: 1.10,
    speed: '318 კმ/სთ',
    color: '#facc15',
    image: '🏎️'
  },
  {
    id: 'car_corvette_c8',
    name: 'Chevrolet Corvette C8 Stingray V8',
    brand: 'Chevrolet',
    price: 165000,
    respect: 480,
    bonusMultiplier: 1.15,
    speed: '312 კმ/სთ',
    color: '#ef4444',
    image: '🚀'
  },
  {
    id: 'car_corvette_z06',
    name: 'Chevrolet Corvette Z06 5.5 Flat-Plane V8 670HP',
    brand: 'Chevrolet',
    price: 290000,
    respect: 720,
    bonusMultiplier: 1.25,
    speed: '330 კმ/სთ',
    color: '#ea580c',
    image: '🚀'
  },
  {
    id: 'car_tahoe',
    name: 'Chevrolet Tahoe High Country 6.2 V8 "შავი გიგანტი"',
    brand: 'Chevrolet',
    price: 115000,
    respect: 340,
    bonusMultiplier: 1.12,
    speed: '230 კმ/სთ',
    color: '#09090b',
    image: '🚙'
  },
  // --- MUSTANGS ---
  {
    id: 'car_mustang_gt',
    name: 'Ford Mustang GT 5.0 V8 Coyote',
    brand: 'Mustang',
    price: 52000,
    respect: 190,
    bonusMultiplier: 1.08,
    speed: '260 კმ/სთ',
    color: '#3b82f6',
    image: '🐎'
  },
  {
    id: 'car_mustang_darkhorse',
    name: 'Ford Mustang Dark Horse 500HP 5.0 V8',
    brand: 'Mustang',
    price: 88000,
    respect: 290,
    bonusMultiplier: 1.11,
    speed: '280 კმ/სთ',
    color: '#1e3a8a',
    image: '🐎'
  },
  {
    id: 'car_mustang_gt350r',
    name: 'Ford Mustang Shelby GT350R Voodoo V8 Track Edition',
    brand: 'Mustang',
    price: 115000,
    respect: 360,
    bonusMultiplier: 1.13,
    speed: '285 კმ/სთ',
    color: '#ffffff',
    image: '⚡'
  },
  {
    id: 'car_mustang_shelby',
    name: 'Ford Mustang Shelby GT500 760HP "Predator"',
    brand: 'Mustang',
    price: 145000,
    respect: 440,
    bonusMultiplier: 1.14,
    speed: '290 კმ/სთ',
    color: '#1e1b4b',
    image: '⚡'
  },
  {
    id: 'car_mustang_rtr',
    name: 'Ford Mustang RTR Spec 5 Drift Edition 750HP',
    brand: 'Mustang',
    price: 175000,
    respect: 520,
    bonusMultiplier: 1.16,
    speed: '305 კმ/სთ',
    color: '#16a34a',
    image: '🔥'
  },
  // --- DODGE ---
  {
    id: 'car_dodge_scatpack',
    name: 'Dodge Challenger R/T Scat Pack 392 HEMI 485HP',
    brand: 'Dodge SRT',
    price: 68000,
    respect: 220,
    bonusMultiplier: 1.09,
    speed: '292 კმ/სთ',
    color: '#7c2d12',
    image: '🏎️'
  },
  {
    id: 'car_dodge_hellcat',
    name: 'Dodge Challenger SRT Hellcat Redeye 797HP',
    brand: 'Dodge SRT',
    price: 125000,
    respect: 390,
    bonusMultiplier: 1.13,
    speed: '327 კმ/სთ',
    color: '#7f1d1d',
    image: '🔥'
  },
  {
    id: 'car_dodge_ram_trx',
    name: 'Dodge RAM 1500 TRX 6.2 Supercharged 702HP',
    brand: 'Dodge SRT',
    price: 140000,
    respect: 420,
    bonusMultiplier: 1.14,
    speed: '190 კმ/სთ',
    color: '#27272a',
    image: '🛻'
  },
  {
    id: 'car_dodge_demon',
    name: 'Dodge Charger SRT Demon 840HP "Drag King"',
    brand: 'Dodge SRT',
    price: 195000,
    respect: 560,
    bonusMultiplier: 1.18,
    speed: '335 კმ/სთ',
    color: '#18181b',
    image: '😈'
  },
  {
    id: 'car_dodge_viper',
    name: 'Dodge Viper ACR 8.4 V10 645HP "Track Monster"',
    brand: 'Dodge SRT',
    price: 340000,
    respect: 850,
    bonusMultiplier: 1.25,
    speed: '332 კმ/სთ',
    color: '#991b1b',
    image: '🐍'
  },
  // --- FERRARI ---
  {
    id: 'car_ferrari_458',
    name: 'Ferrari 458 Italia 4.5 V8 Atmos Sound',
    brand: 'Ferrari',
    price: 420000,
    respect: 950,
    bonusMultiplier: 1.28,
    speed: '325 კმ/სთ',
    color: '#b91c1c',
    image: '🏎️'
  },
  {
    id: 'car_ferrari_488_pista',
    name: 'Ferrari 488 Pista Twin-Turbo V8 710HP',
    brand: 'Ferrari',
    price: 590000,
    respect: 1250,
    bonusMultiplier: 1.34,
    speed: '340 კმ/სთ',
    color: '#ef4444',
    image: '🚀'
  },
  {
    id: 'car_ferrari_f8',
    name: 'Ferrari F8 Tributo 3.9 V8 BiTurbo 720HP',
    brand: 'Ferrari',
    price: 720000,
    respect: 1400,
    bonusMultiplier: 1.38,
    speed: '340 კმ/სთ',
    color: '#dc2626',
    image: '🏎️'
  },
  {
    id: 'car_ferrari_812',
    name: 'Ferrari 812 Superfast 6.5 V12 800HP',
    brand: 'Ferrari',
    price: 980000,
    respect: 1950,
    bonusMultiplier: 1.42,
    speed: '340 კმ/სთ',
    color: '#991b1b',
    image: '⚡'
  },
  {
    id: 'car_ferrari_sf90',
    name: 'Ferrari SF90 Stradale Hybrid 1000HP',
    brand: 'Ferrari',
    price: 1850000,
    respect: 3400,
    bonusMultiplier: 1.55,
    speed: '340 კმ/სთ',
    color: '#991b1b',
    image: '⚡'
  },
  {
    id: 'car_ferrari_laferrari',
    name: 'Ferrari LaFerrari V12 HY-KERS 963HP Hypercar',
    brand: 'Ferrari',
    price: 5400000,
    respect: 9800,
    bonusMultiplier: 1.85,
    speed: '352 კმ/სთ',
    color: '#b91c1c',
    image: '👑'
  },
  {
    id: 'car_rolls',
    name: 'Rolls-Royce Phantom VIII Diamond Edition',
    brand: 'Rolls-Royce',
    price: 11000000,
    respect: 25000,
    bonusMultiplier: 2.20,
    speed: '250 კმ/სთ',
    color: '#312e81',
    image: '👑'
  },
  // --- BMW MODELS ---
  {
    id: 'car_bmw_e34_540i',
    name: 'BMW E34 540i V8 Manual "ლეგენდა"',
    brand: 'BMW Classic',
    price: 22000,
    respect: 95,
    bonusMultiplier: 1.05,
    speed: '250 კმ/სთ',
    color: '#0f172a',
    image: '🚘'
  },
  {
    id: 'car_bmw_e30_m3',
    name: 'BMW E30 M3 Sport Evolution',
    brand: 'BMW M-Power',
    price: 75000,
    respect: 260,
    bonusMultiplier: 1.11,
    speed: '248 კმ/სთ',
    color: '#b91c1c',
    image: '🏎️'
  },
  {
    id: 'car_bmw_m4_g82',
    name: 'BMW M4 Competition G82 510HP',
    brand: 'BMW M-Power',
    price: 185000,
    respect: 420,
    bonusMultiplier: 1.15,
    speed: '290 კმ/სთ',
    color: '#eab308',
    image: '🏎️'
  },
  {
    id: 'car_bmw_x5m_f95',
    name: 'BMW X5 M Competition F95 625HP',
    brand: 'BMW M-Power',
    price: 240000,
    respect: 580,
    bonusMultiplier: 1.20,
    speed: '290 კმ/სთ',
    color: '#1e293b',
    image: '🚙'
  },
  {
    id: 'car_bmw_m8_gc',
    name: 'BMW M8 Gran Coupe Competition 625HP',
    brand: 'BMW M-Power',
    price: 295000,
    respect: 680,
    bonusMultiplier: 1.24,
    speed: '305 კმ/სთ',
    color: '#0284c7',
    image: '⚡'
  },
  {
    id: 'car_bmw_m5_cs',
    name: 'BMW M5 CS V8 BiTurbo 635HP Gold Bronze',
    brand: 'BMW M-Power',
    price: 310000,
    respect: 720,
    bonusMultiplier: 1.25,
    speed: '305 კმ/სთ',
    color: '#14532d',
    image: '🏎️'
  },
  // --- NISSAN MODELS ---
  {
    id: 'car_nissan_370z',
    name: 'Nissan 370Z Nismo V6 350HP',
    brand: 'Nissan',
    price: 36000,
    respect: 130,
    bonusMultiplier: 1.07,
    speed: '260 კმ/სთ',
    color: '#ffffff',
    image: '🏎️'
  },
  {
    id: 'car_nissan_silvia_s15',
    name: 'Nissan Silvia S15 Spec-R Turbo "Drift King"',
    brand: 'Nissan',
    price: 42000,
    respect: 160,
    bonusMultiplier: 1.08,
    speed: '250 კმ/სთ',
    color: '#06b6d4',
    image: '💨'
  },
  {
    id: 'car_nissan_gtr_nismo',
    name: 'Nissan GT-R R35 Nismo 600HP "Godzilla"',
    brand: 'Nissan Nismo',
    price: 320000,
    respect: 750,
    bonusMultiplier: 1.26,
    speed: '315 კმ/სთ',
    color: '#f8fafc',
    image: '🚀'
  },
  // --- HONDA MODELS ---
  {
    id: 'car_honda_s2000',
    name: 'Honda S2000 AP2 9000 RPM VTEC Roadster',
    brand: 'Honda',
    price: 38000,
    respect: 150,
    bonusMultiplier: 1.08,
    speed: '245 კმ/სთ',
    color: '#eab308',
    image: '🏎️'
  },
  {
    id: 'car_honda_civic_fl5',
    name: 'Honda Civic Type R FL5 2.0 Turbo 330HP',
    brand: 'Honda Type R',
    price: 58000,
    respect: 210,
    bonusMultiplier: 1.10,
    speed: '275 კმ/სთ',
    color: '#ef4444',
    image: '🏎️'
  },
  {
    id: 'car_honda_nsx',
    name: 'Honda NSX Type S Twin-Turbo Hybrid 600HP',
    brand: 'Honda Sport',
    price: 390000,
    respect: 880,
    bonusMultiplier: 1.28,
    speed: '308 კმ/სთ',
    color: '#3b82f6',
    image: '⚡'
  },
  // --- MITSUBISHI PAJERO ---
  {
    id: 'car_pajero_4',
    name: 'Mitsubishi Pajero 4 3.8 V6 Ultimate 4x4',
    brand: 'Mitsubishi',
    price: 45000,
    respect: 160,
    bonusMultiplier: 1.08,
    speed: '200 კმ/სთ',
    color: '#334155',
    image: '🚙'
  },
  {
    id: 'car_pajero_evo',
    name: 'Mitsubishi Pajero Evolution 3.5 V6 MIVEC (Dakar Legend)',
    brand: 'Mitsubishi Ralliart',
    price: 68000,
    respect: 230,
    bonusMultiplier: 1.11,
    speed: '210 კმ/სთ',
    color: '#f1f5f9',
    image: '🚙'
  },
  // --- PEUGEOT MODELS ---
  {
    id: 'car_peugeot_206_rc',
    name: 'Peugeot 206 RC 2.0 16V "Pocket Rocket"',
    brand: 'Peugeot Sport',
    price: 14000,
    respect: 55,
    bonusMultiplier: 1.04,
    speed: '220 კმ/სთ',
    color: '#2563eb',
    image: '🚗'
  },
  {
    id: 'car_peugeot_508_pse',
    name: 'Peugeot 508 PSE Sport Engineered AWD Hybrid 360HP',
    brand: 'Peugeot Sport',
    price: 72000,
    respect: 250,
    bonusMultiplier: 1.11,
    speed: '250 კმ/სთ',
    color: '#475569',
    image: '🏎️'
  },
  // --- LAMBORGHINI MODELS ---
  {
    id: 'car_lambo_murcielago',
    name: 'Lamborghini Murcielago LP670-4 SuperVeloce V12',
    brand: 'Lamborghini',
    price: 750000,
    respect: 1500,
    bonusMultiplier: 1.38,
    speed: '342 კმ/სთ',
    color: '#eab308',
    image: '🐂'
  },
  {
    id: 'car_lambo_urus',
    name: 'Lamborghini Urus Performante Twin-Turbo 666HP',
    brand: 'Lamborghini',
    price: 820000,
    respect: 1700,
    bonusMultiplier: 1.40,
    speed: '306 კმ/სთ',
    color: '#16a34a',
    image: '🚙'
  },
  {
    id: 'car_lambo_huracan_sto',
    name: 'Lamborghini Huracan STO V10 640HP Track Weapon',
    brand: 'Lamborghini',
    price: 980000,
    respect: 1900,
    bonusMultiplier: 1.43,
    speed: '325 კმ/სთ',
    color: '#06b6d4',
    image: '⚡'
  },
  {
    id: 'car_lambo_aventador_svj',
    name: 'Lamborghini Aventador SVJ V12 770HP King',
    brand: 'Lamborghini',
    price: 1450000,
    respect: 2800,
    bonusMultiplier: 1.50,
    speed: '352 კმ/სთ',
    color: '#84cc16',
    image: '👑'
  },
  // --- AUDI S8 D3 & A8 D3 & RS7 ---
  {
    id: 'car_audi_a8_d3',
    name: 'Audi A8 D3 4.2 V8 Quattro "პრეზიდენტის ლიმუზინი"',
    brand: 'Audi Quattro',
    price: 26000,
    respect: 110,
    bonusMultiplier: 1.06,
    speed: '250 კმ/სთ',
    color: '#0f172a',
    image: '🚘'
  },
  {
    id: 'car_audi_s8_d3',
    name: 'Audi S8 D3 5.2 V10 Quattro (Lamborghini Engine 450HP)',
    brand: 'Audi Quattro',
    price: 46000,
    respect: 195,
    bonusMultiplier: 1.10,
    speed: '280 კმ/სთ',
    color: '#18181b',
    image: '🏎️'
  },
  {
    id: 'car_audi_rs7',
    name: 'Audi RS7 Sportback Performance 630HP Quattro',
    brand: 'Audi Sport Quattro',
    price: 280000,
    respect: 640,
    bonusMultiplier: 1.22,
    speed: '305 კმ/სთ',
    color: '#09090b',
    image: '🚀'
  },
  // --- HYUNDAI MODELS ---
  {
    id: 'car_hyundai_coupe_tiburon',
    name: 'Hyundai Coupe (Tiburon) 2.7 V6 FX Sport',
    brand: 'Hyundai',
    price: 15500,
    respect: 60,
    bonusMultiplier: 1.04,
    speed: '220 კმ/სთ',
    color: '#e11d48',
    image: '🏎️'
  },
  {
    id: 'car_hyundai_genesis_coupe',
    name: 'Hyundai Genesis Coupe 3.8 V6 Track RWD 350HP',
    brand: 'Hyundai',
    price: 34000,
    respect: 135,
    bonusMultiplier: 1.07,
    speed: '260 კმ/სთ',
    color: '#2563eb',
    image: '🏎️'
  },
  {
    id: 'car_hyundai_elantra_n',
    name: 'Hyundai Elantra N 2.0 Turbo 280HP "Corner Rascal"',
    brand: 'Hyundai N',
    price: 48000,
    respect: 170,
    bonusMultiplier: 1.09,
    speed: '250 კმ/სთ',
    color: '#38bdf8',
    image: '🏎️'
  },
  {
    id: 'car_hyundai_ioniq_5n',
    name: 'Hyundai Ioniq 5 N Drift Special AWD 650HP',
    brand: 'Hyundai N',
    price: 115000,
    respect: 340,
    bonusMultiplier: 1.13,
    speed: '260 კმ/სთ',
    color: '#0284c7',
    image: '⚡'
  },
  {
    id: 'car_hyundai_elantra_gt',
    name: 'Hyundai Elantra GT Sport 1.6 Turbo 201HP',
    brand: 'Hyundai',
    price: 24000,
    respect: 85,
    bonusMultiplier: 1.05,
    speed: '225 კმ/სთ',
    color: '#dc2626',
    image: '🚗'
  },
  {
    id: 'car_hyundai_i30n',
    name: 'Hyundai i30 N Performance Pack 280HP Hatchback',
    brand: 'Hyundai N',
    price: 39000,
    respect: 145,
    bonusMultiplier: 1.08,
    speed: '250 კმ/სთ',
    color: '#0ea5e9',
    image: '🏎️'
  },
  {
    id: 'car_hyundai_tucson_nline',
    name: 'Hyundai Tucson N-Line 2.5 Turbo AWD',
    brand: 'Hyundai',
    price: 43000,
    respect: 155,
    bonusMultiplier: 1.08,
    speed: '220 კმ/სთ',
    color: '#334155',
    image: '🚙'
  },
  // --- ADDITIONAL REQUESTED BMW MODELS ---
  {
    id: 'car_bmw_e36_m3',
    name: 'BMW E36 M3 3.2 Coupe 321HP Manual',
    brand: 'BMW Classic',
    price: 32000,
    respect: 120,
    bonusMultiplier: 1.06,
    speed: '250 კმ/სთ',
    color: '#1e3a8a',
    image: '🚘'
  },
  {
    id: 'car_bmw_e46_csl',
    name: 'BMW E46 M3 CSL Carbon Lightweight 360HP',
    brand: 'BMW M-Power',
    price: 95000,
    respect: 320,
    bonusMultiplier: 1.12,
    speed: '280 კმ/სთ',
    color: '#64748b',
    image: '🏎️'
  },
  {
    id: 'car_bmw_e60_m5',
    name: 'BMW E60 M5 5.0 V10 507HP F1 Sound',
    brand: 'BMW M-Power',
    price: 42000,
    respect: 165,
    bonusMultiplier: 1.08,
    speed: '305 კმ/სთ',
    color: '#09090b',
    image: '🚀'
  },
  {
    id: 'car_bmw_f90_m5',
    name: 'BMW M5 F90 Competition xDrive 625HP',
    brand: 'BMW M-Power',
    price: 175000,
    respect: 480,
    bonusMultiplier: 1.16,
    speed: '305 კმ/სთ',
    color: '#1e1b4b',
    image: '⚡'
  },
  {
    id: 'car_bmw_xm_red',
    name: 'BMW XM Label Red V8 Hybrid 748HP Super-SUV',
    brand: 'BMW M-Power',
    price: 360000,
    respect: 850,
    bonusMultiplier: 1.27,
    speed: '290 კმ/სთ',
    color: '#991b1b',
    image: '👑'
  },
  // --- ADDITIONAL REQUESTED NISSAN MODELS ---
  {
    id: 'car_nissan_r34_gtr',
    name: 'Nissan Skyline GT-R R34 V-Spec II Nür "Godzilla"',
    brand: 'Nissan',
    price: 195000,
    respect: 520,
    bonusMultiplier: 1.18,
    speed: '300 კმ/სთ',
    color: '#0284c7',
    image: '🐉'
  },
  {
    id: 'car_nissan_patrol_nismo',
    name: 'Nissan Patrol Nismo 5.6 V8 428HP VVIP SUV',
    brand: 'Nissan Nismo',
    price: 110000,
    respect: 330,
    bonusMultiplier: 1.13,
    speed: '250 კმ/სთ',
    color: '#f8fafc',
    image: '🚙'
  },
  {
    id: 'car_nissan_350z',
    name: 'Nissan 350Z Fairlady Z 3.5 V6 Manual Drift Spec',
    brand: 'Nissan',
    price: 21000,
    respect: 80,
    bonusMultiplier: 1.05,
    speed: '250 კმ/სთ',
    color: '#f97316',
    image: '🏎️'
  },
  // --- ADDITIONAL REQUESTED HONDA MODELS ---
  {
    id: 'car_honda_ek9',
    name: 'Honda Civic Type R EK9 Championship White 185HP',
    brand: 'Honda Type R',
    price: 28000,
    respect: 105,
    bonusMultiplier: 1.06,
    speed: '235 კმ/სთ',
    color: '#ffffff',
    image: '🏎️'
  },
  {
    id: 'car_honda_integra_dc2',
    name: 'Honda Integra Type R DC2 B18C VTEC',
    brand: 'Honda Type R',
    price: 33000,
    respect: 125,
    bonusMultiplier: 1.07,
    speed: '240 კმ/სთ',
    color: '#ffffff',
    image: '🏎️'
  },
  {
    id: 'car_honda_accord_euror',
    name: 'Honda Accord Euro R CL7 2.0 K20A Red Top',
    brand: 'Honda Sport',
    price: 19000,
    respect: 75,
    bonusMultiplier: 1.05,
    speed: '230 კმ/სთ',
    color: '#3b82f6',
    image: '🚗'
  },
  // --- ADDITIONAL REQUESTED PAJERO MODELS ---
  {
    id: 'car_pajero_sport',
    name: 'Mitsubishi Pajero Sport 3.0 V6 Super Select 4WD',
    brand: 'Mitsubishi',
    price: 38000,
    respect: 140,
    bonusMultiplier: 1.07,
    speed: '195 კმ/სთ',
    color: '#475569',
    image: '🚙'
  },
  {
    id: 'car_pajero_2_swb',
    name: 'Mitsubishi Pajero 2 Short Wheelbase 3.5 V6 Classic',
    brand: 'Mitsubishi',
    price: 16000,
    respect: 65,
    bonusMultiplier: 1.04,
    speed: '185 კმ/სთ',
    color: '#15803d',
    image: '🚙'
  },
  // --- ADDITIONAL REQUESTED PEUGEOT MODELS ---
  {
    id: 'car_peugeot_rcz_r',
    name: 'Peugeot RCZ R 1.6 THP 270HP Turbo Coupe',
    brand: 'Peugeot Sport',
    price: 29000,
    respect: 110,
    bonusMultiplier: 1.06,
    speed: '250 კმ/სთ',
    color: '#b91c1c',
    image: '🏎️'
  },
  {
    id: 'car_peugeot_208_gti',
    name: 'Peugeot 208 GTi by Peugeot Sport Torsen LSD',
    brand: 'Peugeot Sport',
    price: 22000,
    respect: 85,
    bonusMultiplier: 1.05,
    speed: '230 კმ/სთ',
    color: '#1e293b',
    image: '🚗'
  },
  {
    id: 'car_peugeot_406_coupe',
    name: 'Peugeot 406 Coupe 3.0 V6 Pininfarina Design',
    brand: 'Peugeot',
    price: 13500,
    respect: 55,
    bonusMultiplier: 1.04,
    speed: '240 კმ/სთ',
    color: '#3b82f6',
    image: '🚘'
  },
  // --- ADDITIONAL REQUESTED LAMBORGHINI MODELS ---
  {
    id: 'car_lambo_gallardo_superleggera',
    name: 'Lamborghini Gallardo LP570-4 Superleggera V10',
    brand: 'Lamborghini',
    price: 420000,
    respect: 960,
    bonusMultiplier: 1.30,
    speed: '325 კმ/სთ',
    color: '#eab308',
    image: '🐂'
  },
  {
    id: 'car_lambo_diablo_vt',
    name: 'Lamborghini Diablo VT 6.0 SE V12 Icon',
    brand: 'Lamborghini Classic',
    price: 640000,
    respect: 1350,
    bonusMultiplier: 1.36,
    speed: '335 კმ/სთ',
    color: '#7c3aed',
    image: '🐂'
  },
  {
    id: 'car_lambo_revuelto',
    name: 'Lamborghini Revuelto V12 HPEV Hybrid 1015HP',
    brand: 'Lamborghini',
    price: 1650000,
    respect: 3200,
    bonusMultiplier: 1.55,
    speed: '355 კმ/სთ',
    color: '#f97316',
    image: '👑'
  },
  // --- ADDITIONAL REQUESTED AUDI MODELS ---
  {
    id: 'car_audi_rs6_c8_performance',
    name: 'Audi RS6 Avant C8 Performance 630HP Quattro',
    brand: 'Audi Sport Quattro',
    price: 260000,
    respect: 620,
    bonusMultiplier: 1.21,
    speed: '305 კმ/სთ',
    color: '#334155',
    image: '🚀'
  },
  {
    id: 'car_audi_ttrs',
    name: 'Audi TT RS 2.5 TFSI 5-Cylinder Quattro 400HP',
    brand: 'Audi Sport Quattro',
    price: 68000,
    respect: 240,
    bonusMultiplier: 1.11,
    speed: '280 კმ/სთ',
    color: '#06b6d4',
    image: '🏎️'
  },
  {
    id: 'car_audi_rs4_b7',
    name: 'Audi RS4 Avant B7 4.2 V8 8250 RPM Manual Quattro',
    brand: 'Audi Sport Quattro',
    price: 34000,
    respect: 130,
    bonusMultiplier: 1.07,
    speed: '260 კმ/სთ',
    color: '#1e3a8a',
    image: '🏎️'
  },
  {
    id: 'car_m4_csl_pass',
    name: 'BMW M4 CSL (Star Pass Edition)',
    brand: 'bmw',
    price: 480000,
    respect: 650,
    bonusMultiplier: 1.45,
    speed: '325 კმ/სთ (550 ცხ.ძ)',
    color: '#334155',
    image: '🏎️'
  },
  {
    id: 'car_gt3rs_pass',
    name: 'Porsche 911 GT3 RS Clubsport (Star Pass Edition)',
    brand: 'supercars',
    price: 950000,
    respect: 1250,
    bonusMultiplier: 1.85,
    speed: '345 კმ/სთ (525 ცხ.ძ)',
    color: '#84cc16',
    image: '🚀'
  }
];

export const LUXURY_GARAGES: Garage[] = [
  {
    id: 'gar_basic',
    name: 'საბურთალოს პრივატული ავტო-ბოქსი',
    capacity: 2,
    price: 12000,
    location: 'საბურთალო, პოლიტკოვსკაია',
    description: 'კეთილმოწყობილი ავტოფარეხი ვიდეოკამერებით, ელექტრო ჟალუზით და 2 ავტომობილის ადგილით.'
  },
  {
    id: 'gar_vake',
    name: 'ვაკის ორდონიანი მიწისქვეშა გარაჟი',
    capacity: 5,
    price: 45000,
    location: 'ვაკე, ჭავჭავაძის გამზირი',
    description: 'კლიმატკონტროლი, დითეილინგ ზონა, 24/7 ცოცხალი დაცვა და 5 ავტომობილის ადგილი.'
  },
  {
    id: 'gar_ortachala',
    name: 'ორთაჭალის VIP სპორტკარის გარაჟი სახელოსნოთი',
    capacity: 9,
    price: 120000,
    location: 'ორთაჭალა, სანაპირო',
    description: 'ორდონიანი სივრცე შეჯავშნული ჭიშკრით, პირადი მექანიკოსის პუნქტით და 9 ავტომობილის ადგილით.'
  },
  {
    id: 'gar_penthouse',
    name: 'მთაწმინდის პანორამული ელიტარული მეგა-გარაჟი',
    capacity: 18,
    price: 350000,
    location: 'მთაწმინდის პანორამა',
    description: 'ავტოლიფტი, შუშის საგამოფენო დარბაზი, კერძო დაცვის პუნქტი და 18 სუპერქარის ადგილი.'
  },
  {
    id: 'gar_batumi_port',
    name: 'ბათუმის პორტის სუპერქარების მეგა-ტერმინალი',
    capacity: 40,
    price: 2400000,
    location: 'ბათუმის ახალი იახტკლუბი',
    description: 'პირადი ელიტური საზღვაო ტერმინალი მთელი ავტოპარკისა და იახტის ეკიპირებისთვის (40 ადგილი).'
  },
  {
    id: 'gar_rustavi', name: 'რუსთავის სარბოლო ავტოფარეხი', capacity: 3, price: 28000,
    location: 'რუსთავი, ავტოდრომის უბანი', description: 'სარბოლო ავტოდრომთან ახლოს მდებარე 3 ავტომობილის დაცული გარაჟი.'
  },
  {
    id: 'gar_kutaisi', name: 'ქუთაისის კლასიკური მანქანების ჰანგარი', capacity: 6, price: 78000,
    location: 'ქუთაისი, აეროპორტის გზა', description: 'კლასიკური და საკოლექციო მანქანებისთვის მოწყობილი 6 ადგილიანი ჰანგარი.'
  },
  {
    id: 'gar_batumi', name: 'ბათუმის ზღვისპირა ავტო-ლოფტი', capacity: 8, price: 165000,
    location: 'ბათუმი, ახალი ბულვარი', description: 'ზღვის ხედით, დითეილინგ სივრცით და 8 მანქანის ადგილით.'
  },
  {
    id: 'gar_telavi', name: 'თელავის ვენახის მამულის ავტოფარეხი', capacity: 12, price: 420000,
    location: 'თელავი, წინანდლის გზა', description: 'კერძო მამულის დაცული ავტოფარეხი 12 ავტომობილისთვის.'
  },
  {
    id: 'gar_airport', name: 'თბილისის აეროპორტის კოლექციონერის ჰანგარი', capacity: 24, price: 980000,
    location: 'თბილისის საერთაშორისო აეროპორტი', description: 'კლიმატკონტროლით აღჭურვილი 24 ადგილიანი პრემიუმ ჰანგარი.'
  },
  {
    id: 'gar_mestia', name: 'მესტიის ალპური ავტო-სარდაფი', capacity: 15, price: 720000,
    location: 'მესტია, ცენტრი', description: 'მთის პირობებისთვის დაცული სივრცე 15 ყველგანმავალი და სპორტული მანქანისთვის.'
  }
];

export const LUXURY_ESTATES: Estate[] = [
  {
    id: 'est_sololaki',
    name: 'სოლოლაკის "იტალიური ეზოს" ნახევრად დანგრეული ბინა',
    location: 'თბილისი, სოლოლაკი, ასათიანის ქუჩა',
    price: 8500,
    respect: 20,
    passiveRentPerSec: 2,
    description: 'ხის აივანი ჩამოწოლილია, მეზობელი მზესუმზირას გაყრის თავზე, კედლები 1902 წლის ისტორიას ინახავს, სამაგიეროდ ტურისტებზე შეიძლება შეტენვა Airbnb-ზე!'
  },
  {
    id: 'est_saburtalo',
    name: 'მოდერნული აპარტამენტი საბურთალოზე',
    location: 'თბილისი, პოლიტკოვსკაია',
    price: 95000,
    respect: 120,
    passiveRentPerSec: 15,
    description: '3-ოთახიანი დიზაინერული რემონტით და ქალაქის ხედით.'
  },
  {
    id: 'est_vake',
    name: 'ორდონიანი პენტჰაუსი ჭავჭავაძეზე',
    location: 'ვაკე, ჭავჭავაძე',
    price: 520000,
    respect: 680,
    passiveRentPerSec: 90,
    description: '350 კვ.მ, პირადი ვერანდა ჯაკუზით და ექსკლუზიური ინტერიერი.'
  },
  {
    id: 'est_tskhneti',
    name: 'ვილა წყნეთის ფიჭვნარში',
    location: 'წყნეთი',
    price: 2400000,
    respect: 2800,
    passiveRentPerSec: 420,
    description: 'გარე გათბობადი აუზი, ვერტმფრენის დასაჯდომი და 4-მეტრიანი გალავანი.'
  },
  {
    id: 'est_kojori',
    name: 'სამეფო რეზიდენცია კოჯორში',
    location: 'კოჯორი',
    price: 7800000,
    respect: 9500,
    passiveRentPerSec: 1650,
    description: 'ისტორიული სასახლე, უმაღლესი დონის უსაფრთხოების სისტემა.'
  },
  {
    id: 'est_island',
    name: 'პირადი კუნძული შავ ზღვაზე',
    location: 'შავი ზღვის აკვატორია',
    price: 28000000,
    respect: 40000,
    passiveRentPerSec: 6800,
    description: 'ავტონომიური სამოთხე: პირადი პორტი, ასაფრენი ზოლი და სრული სუვერენიტეტი.'
  },
  {
    id: 'est_custom_tuning_workshop',
    name: 'შენი საკუთარი ტიუნინგი',
    location: 'თბილისის აეროპორტის გზატკეცილი',
    price: 2350500,
    respect: 2400,
    passiveRentPerSec: 350,
    description: 'შენი საკუთარი პრესტიჟული ავტო-ტიუნინგ სახელოსნო & საწყობი! გახსნისას გაძლევს წვდომას საბითუმო ნაწილებზე, რომლებსაც შენს მანქანებზე დააყენებ სრულიად უფასოდ (0 ₾ მონტაჟი)!'
  },
  {
    id: 'est_lagodekhi_reserve',
    name: 'სახლი ლაგოდეხის ნაკრძალში',
    location: 'ლაგოდეხის დაცული ტერიტორია',
    price: 1850000,
    respect: 1600,
    passiveRentPerSec: 280,
    description: 'ელიტური ეკო-რეზიდენცია მთის ძირას და პირად ნაკრძალში. Star Pass Tier 25-ის უნიკალური პრიზი.'
  },
  {
    id: 'est_kutaisi_palace',
    name: 'სახლი ქუთაისში',
    location: 'ქუთაისი, სამეფო რეზიდენცია',
    price: 4800000,
    respect: 4500,
    passiveRentPerSec: 850,
    description: 'სამეფო სასახლე პანორამული ხედით, მარმარილოს აუზით და პირადი პარკით. Star Pass Tier 50-ის უმაღლესი პრიზი.'
  }
];

export const LUXURY_BUSINESSES: Business[] = [
  {
    id: 'biz_hazelnut',
    name: 'თხილის სარჩევი ავტომატური აპარატები',
    type: 'აგრო-ინდუსტრია & გადამუშავება',
    basePrice: 35000,
    baseIncome: 4.5, // რეალური დარიცხვა: 0.15 ₾ ყოველ 30 წამში
    intervalSeconds: 30,
    ownedCount: 0,
    description: 'თხილის თანამედროვე ავტომატიზირებული სარჩევი და დამხარისხებელი ხაზი. ყოველ 30 წამში გამოიმუშავებს 0.15 ₾-ს.'
  },
  {
    id: 'biz_shawarma',
    name: 'შაურმის პრემიუმ ქსელი "King Shawarma"',
    type: 'სწრაფი კვება',
    basePrice: 48000,
    baseIncome: 45, // 45 ლარი ყოველ 10 წამში
    intervalSeconds: 10,
    ownedCount: 0,
    description: 'მუდმივი რიგები და ცხელი ნაღდი ფული: +1.50 ₾ ყოველ 10 წამში.'
  },
  {
    id: 'biz_wash',
    name: 'VIP დითეილინგ ცენტრი & სამრეცხაო',
    type: 'ავტო სერვისი',
    basePrice: 190000,
    baseIncome: 180, // 180 ლარი ყოველ 10 წამში
    intervalSeconds: 10,
    ownedCount: 0,
    description: 'ქალაქის ყველაზე ძვირადღირებული მანქანების მომსახურება: +6 ₾ ყოველ 10 წამში.'
  },
  {
    id: 'biz_club',
    name: 'ღამის კლუბი "Neon District"',
    type: 'გართობა & VIP',
    basePrice: 850000,
    baseIncome: 950, // 950 ლარი ყოველ 10 წამში
    intervalSeconds: 10,
    ownedCount: 0,
    description: 'ქალაქის ყველაზე ელიტარული წვეულებები: +31.67 ₾ ყოველ 10 წამში.'
  },
  {
    id: 'biz_winery',
    name: 'ღვინის მარანი და შატო "კახური ოქრო"',
    type: 'მეღვინეობა & ტურიზმი',
    basePrice: 1650000,
    baseIncome: 2200, // 2,200 ლარი ყოველ 10 წამში
    intervalSeconds: 10,
    ownedCount: 0,
    description: 'ქვევრის ექსპორტი და პრემიუმ დეგუსტაციები: +73.33 ₾ ყოველ 10 წამში.'
  },
  {
    id: 'biz_crypto',
    name: 'კრიპტო მაინინგ ფერმა & ბირჟა',
    type: 'ტექნოლოგია',
    basePrice: 4200000,
    baseIncome: 6500, // 6,500 ლარი ყოველ 10 წამში
    intervalSeconds: 10,
    ownedCount: 0,
    description: 'ათასობით ASIC მაინერი ჰიდრო-გაგრილებით: +216.67 ₾ ყოველ 10 წამში.'
  },
  {
    id: 'biz_mall',
    name: 'სავაჭრო ცენტრი "City Mall Plaza"',
    type: 'კომერციული მოლი',
    basePrice: 9500000,
    baseIncome: 18500, // 18,500 ლარი ყოველ 10 წამში
    intervalSeconds: 10,
    ownedCount: 0,
    description: 'ასობით ბრენდული მაღაზიის იჯარა: +616.67 ₾ ყოველ 10 წამში.'
  },
  {
    id: 'biz_bank',
    name: 'კერძო საინვესტიციო ბანკი "Tbilisi Capital"',
    type: 'საფინანსო ინსტიტუტი',
    basePrice: 22000000,
    baseIncome: 50000, // 50,000 ლარი ყოველ 10 წამში
    intervalSeconds: 10,
    ownedCount: 0,
    description: 'მილიონობით დეპოზიტის მართვა: +1,666.67 ₾ ყოველ 10 წამში.'
  }
];

export const LUXURY_SECURITIES: Security[] = [
  {
    id: 'sec_bodyguard',
    name: 'პირადი მცველი (სპეცრაზმის ვეტერანი)',
    price: 25000,
    respect: 150,
    protectionBonus: '+15% რეპუტაციის დაცვა',
    description: 'გამოცდილი პროფესიონალი, რომელიც მუდამ შენს უკან დგას.'
  },
  {
    id: 'sec_escort',
    name: 'ჯავშნიანი კორტეჟი შავი SUV-ებით',
    price: 180000,
    respect: 850,
    protectionBonus: '+40% ქუჩის გავლენა',
    description: 'ქალაქში გადაადგილება ციმციმებით და შეიარაღებული დაცვით.'
  },
  {
    id: 'sec_cyber',
    name: 'ელიტური კიბერ-უსაფრთხოების ბიურო',
    price: 950000,
    respect: 3200,
    protectionBonus: 'სრული იმუნიტეტი ანგარიშებზე',
    description: 'ჰაკერების შეტევების და ფინანსური თვალთვალის სრული ბლოკირება.'
  },
  {
    id: 'sec_army',
    name: 'კერძო სამხედრო კონტრაქტორების რაზმი (PMC)',
    price: 4500000,
    respect: 15000,
    protectionBonus: 'აბსოლუტური იმპერიის სტატუსი',
    description: 'სრული სამხედრო ეკიპირება, დრონები და დაუმარცხებელი ძალა.'
  }
];

// Profile Avatar Presets
export const AVATAR_PRESETS = [
  { id: 'av_boss', name: 'სინდიკატის ბოსი', emoji: '🕶️', gradient: 'from-amber-500 to-red-600' },
  { id: 'av_tycoon', name: 'ოლიგარქი', emoji: '💼', gradient: 'from-emerald-500 to-teal-700' },
  { id: 'av_racer', name: 'ქუჩის მრბოლელი', emoji: '🏎️', gradient: 'from-blue-600 to-indigo-800' },
  { id: 'av_hacker', name: 'კიბერ-გენიოსი', emoji: '💻', gradient: 'from-cyan-400 to-blue-600' },
  { id: 'av_crypto', name: 'Crypto King', emoji: '💎', gradient: 'from-purple-500 to-pink-600' },
  { id: 'av_gentleman', name: 'არისტოკრატი', emoji: '🎩', gradient: 'from-slate-700 to-slate-900' },
  { id: 'av_monarch', name: 'იმპერატორი', emoji: '👑', gradient: 'from-yellow-400 to-amber-600' },
  { id: 'av_lion', name: 'ქალაქის ლომი', emoji: '🦁', gradient: 'from-orange-500 to-red-700' },
  { id: 'av_ninja', name: 'ჩრდილოვანი აგენტი', emoji: '🥷', gradient: 'from-zinc-700 to-zinc-950' },
  { id: 'av_lady', name: 'ელიტური ლედი', emoji: '👸', gradient: 'from-rose-500 to-purple-700' },
  { id: 'av_pilot', name: 'ავია-კაპიტანი', emoji: '✈️', gradient: 'from-sky-500 to-blue-700' },
  { id: 'av_vip', name: 'VIP მილიარდერი', emoji: '✨', gradient: 'from-emerald-400 to-amber-500' }
];

// Chat bots templates with realistic Georgian casino/RP banter & random VIP ranks
export const BOT_NAMES: Array<{ name: string; level: number; avatar: string; premiumRank?: 'none' | 'red' | 'purple' }> = [
  { name: 'გიორგი_Vake', level: 42, avatar: '🕶️', premiumRank: 'red' },
  { name: 'ლაშა_Gldaneli', level: 18, avatar: '🦁', premiumRank: 'red' },
  { name: 'სანდრო_M5', level: 94, avatar: '🏎️', premiumRank: 'red' },
  { name: 'დათო_777', level: 11, avatar: '💼', premiumRank: 'none' },
  { name: 'ლუკა_Trader', level: 165, avatar: '💎', premiumRank: 'purple' },
  { name: 'ბექა_Bimmer', level: 78, avatar: '🎩', premiumRank: 'red' },
  { name: 'ნიკუშ_Rustavi', level: 6, avatar: '🥷', premiumRank: 'none' },
  { name: 'ზურა_GigaChad', level: 230, avatar: '👑', premiumRank: 'purple' },
  { name: 'ირაკლი_Saburtalo', level: 35, avatar: '✨', premiumRank: 'none' },
  { name: 'ვაკო_Drifter', level: 52, avatar: '🏎️', premiumRank: 'red' },
  { name: 'შოთა_Crypto', level: 118, avatar: '💻', premiumRank: 'purple' },
  { name: 'თემო_Sniper', level: 89, avatar: '🥷', premiumRank: 'none' },
  { name: 'თორნიკე_VIP', level: 140, avatar: '💼', premiumRank: 'purple' },
  { name: 'კოკა_Batumi', level: 63, avatar: '🕶️', premiumRank: 'red' }
];

export const RAGE_MESSAGES = [
  'აუუუუ 1.03-ზე გასკდა ჩემი 500 ლარიიიი 🤬🤬',
  'დედას ვფიცავარ გატეხილია ეს თამაშიიი!',
  'ადმინ შენ მოგიტყ... ჩემი ბოლო ფული იყო დედას გეფიცები 🤬',
  'წავაგეეეეე ბიჭოოო ბინის ქირის ფული ჩავდეეე 💀',
  'რატო არ გამოვიტანე 2x-ზეეეე, რატო ვხარბობდიიი!',
  'რა უნდოდა 1.15-ზე რო გასკდააა, მეღადავებით?! 😤',
  'სისტემა პირდაპირ ჩემს წაგებაზეა მომართული 🤦‍♂️',
  'ყველაფერი წამგლიჯა ამ თვითმფრინავმაააა'
];

export const JOY_MESSAGES = [
  'ეეეეე 18.5x დავსვიიი! 3,700₾ ჩაირიცხააა 🔥🔥🔥',
  'მამა აქ არის, 42x-ზე გავიტანე და გავედი! 🤑🤑',
  'გაასწორააა, ახალი M5-ის საწყისი ფული ამოვიღე!',
  'ვახ რა მომენტი იყოოო, გული გამიჩერდა და მაინც მოვიგე! 🚀',
  'ავტო-ქეშაუთმა მიშველა 3.5x-ზე, 1,400₾ ჯიბეშიააა 🎉',
  'დღეს ჩემი იღბლიანი დღეა, მესამე მოგება ზედიზედ! 🥂',
  'ეს არის ნამდვილი ადრენალინი! 💸💸'
];

export const CRYING_MESSAGES = [
  'ვეღარ ვსუნთქავ ტირილი მინდა... 😭',
  'ბოლო 20 ლარი იყო ძმაო, ხვალ რითი ვიარო...',
  'დღეს შიმშილი მელის ნაღდად 💔',
  'ვინმემ 10 ლარი გადმომირიცხეთ რა, ხვალ დაგიბრუნებთ ორმაგად 😭',
  'ისევ 0 ₾ მაქვს ბალანსზე, რატომ არ გავჩერდი...'
];

export const THREAT_MESSAGES = [
  'გავაჩერებ ამ სერვერს დოსით გეფიცებით თუ არ დააბრუნებთ!',
  'სად არის ამ საიტის ოფისი, ხვალ მივდივარ პირადად სალაპარაკოდ! 😡',
  'ადმინ ფული დამიბრუნე თორე ჩემს ბიჭებს ამოვიყვან!',
  'პოლიციაში ვრეკავ ახლავე, ეს რა თაღლითობაა 🚨',
  'ქალაქში ვინც ხართ ამ თამაშის უკან, გაგარკვევთ ვინ ხართ!'
];

export const NORMAL_MESSAGES = [
  'ავტო-ქეშაუთი 2.0x დააყენეთ ხალხო, ნუ ხართ გაუმაძღრები 😉',
  'ვინმემ Bugatti იყიდა უკვე ლუქს შოპში?',
  'კონტრაქტებიც გააკეთეთ, კარგი ფული მოდის სამსახურიდან 👍',
  'შემდეგ რეისზე 100₾-ს ვდებ, ვინ შემოდის ჩემთან ერთად?',
  'ნელ-ნელა უნდა აგროვო, კაზინო ყოველთვის არ იძლევა',
  'ბიზნესები იყიდეთ, პასიურად მოაქვს წამში ₾₾₾'
];

export const LUXURY_ACCESSORIES: Accessory[] = [
  // --- WATCHES ---
  {
    id: 'acc_rolex_sub',
    name: 'Rolex Submariner Date 18K Yellow Gold',
    category: 'watch',
    price: 18000,
    respect: 90,
    bonusMultiplier: 1.03,
    image: '⌚',
    description: 'შვეიცარიული ლეგენდა: მყარი ოქრო, კერამიკული ბეზელი და უმაღლესი სტატუსი.'
  },
  {
    id: 'acc_rolex_daytona',
    name: 'Rolex Daytona Platinum Ice Blue Dial',
    category: 'watch',
    price: 65000,
    respect: 280,
    bonusMultiplier: 1.06,
    image: '⌚',
    description: 'პლატინის კორპუსი და ყინულისფერი ციფერბლატი — მრბოლელთა უმაღლესი ეტალონი.'
  },
  {
    id: 'acc_ap_royal',
    name: 'Audemars Piguet Royal Oak Offshore Chrono',
    category: 'watch',
    price: 95000,
    respect: 390,
    bonusMultiplier: 1.07,
    image: '⌚',
    description: 'ტიტანისა და კერამიკის ექსტრემალური ქრონოგრაფი ქალაქის ელიტისთვის.'
  },
  {
    id: 'acc_patek_naut',
    name: 'Patek Philippe Nautilus 5711/1R Rose Gold',
    category: 'watch',
    price: 145000,
    respect: 480,
    bonusMultiplier: 1.08,
    image: '⌚',
    description: 'ოლიგარქების საათი: იშვიათი ვარდისფერი ოქრო და გლობალური პრესტიჟი.'
  },
  {
    id: 'acc_richard_mille',
    name: 'Richard Mille RM 11-03 Carbon Red TPT',
    category: 'watch',
    price: 380000,
    respect: 1200,
    bonusMultiplier: 1.15,
    image: '⌚',
    description: 'ულტრა-მსუბუქი კარბონის ჰიპერ-საათი ფორმულა 1-ის ტექნოლოგიით.'
  },
  // --- JEWELRY ---
  {
    id: 'acc_gold_chain',
    name: '24K მასიური ოქროს ძეწკვი "BOSS"',
    category: 'jewelry',
    price: 28000,
    respect: 140,
    bonusMultiplier: 1.04,
    image: '📿',
    description: 'ნახევარი კილოგრამი სუფთა ქართული ოქრო — ქუჩაში ყველა გიცნობს.'
  },
  {
    id: 'acc_cuban_diamond',
    name: 'Miami Cuban Link 40ct VVS ბრილიანტის ჯაჭვი',
    category: 'jewelry',
    price: 88000,
    respect: 350,
    bonusMultiplier: 1.07,
    image: '💎',
    description: 'ყინულივით მბზინავი VVS ბრილიანტები, რომლებიც ბნელშიც ანათებენ.'
  },
  {
    id: 'acc_cartier_ring',
    name: 'Cartier Panthère ბრილიანტის ბეჭედი',
    category: 'jewelry',
    price: 45000,
    respect: 230,
    bonusMultiplier: 1.05,
    image: '💍',
    description: 'ზურმუხტის თვალები და უმაღლესი სისუფთავის ბრილიანტები.'
  },
  {
    id: 'acc_sapphire_signet',
    name: 'სამეფო საფირონის ბეჭედი "Crown Crest"',
    category: 'jewelry',
    price: 72000,
    respect: 310,
    bonusMultiplier: 1.06,
    image: '💍',
    description: 'ბირმული სამეფო ლურჯი საფირონი და პლატინის გრავირება.'
  },
  // --- CLOTHING ---
  {
    id: 'acc_gucci_suit',
    name: 'Gucci & Louis Vuitton VIP ტყავის გარდერობი',
    category: 'clothing',
    price: 14000,
    respect: 80,
    bonusMultiplier: 1.02,
    image: '👔',
    description: 'იტალიური ხელით შეკერილი კოსტიუმი და პრემიუმ ტყავის ქურთუკი.'
  },
  {
    id: 'acc_brioni_tuxedo',
    name: 'Brioni Bespoke Silk Tuxedo "Black Tie"',
    category: 'clothing',
    price: 36000,
    respect: 190,
    bonusMultiplier: 1.05,
    image: '🤵',
    description: 'აბრეშუმის ლაცკანები და რომის ოსტატების ექსკლუზიური თარგი.'
  },
  {
    id: 'acc_hermes_jacket',
    name: 'Hermès ნიანგის ტყავის ქურთუკი',
    category: 'clothing',
    price: 110000,
    respect: 420,
    bonusMultiplier: 1.09,
    image: '🧥',
    description: 'მსოფლიოში მხოლოდ 10 ეგზემპლარი. აბსოლუტური ფუფუნების მწვერვალი.'
  },
  // --- GADGETS ---
  {
    id: 'acc_cyber_glasses',
    name: 'Cyberpunk ნეონის სათვალე HUD Display',
    category: 'gadget',
    price: 8500,
    respect: 60,
    bonusMultiplier: 1.02,
    image: '🕶️',
    description: 'ფინანსური კურსებისა და მოწინააღმდეგის რეპუტაციის პირდაპირი ჩვენება ლინზაზე.'
  },
  {
    id: 'acc_vertu_phone',
    name: 'Vertu Signature Diamond 4G კრიპტო-ტელეფონი',
    category: 'gadget',
    price: 55000,
    respect: 240,
    bonusMultiplier: 1.05,
    image: '📱',
    description: 'საფირონის ეკრანი, ლალის ღილაკები და სამხედრო დონის დაშიფვრა.'
  },
  {
    id: 'acc_amex_black',
    name: 'American Express Centurion "Black Card"',
    category: 'gadget',
    price: 120000,
    respect: 490,
    bonusMultiplier: 1.08,
    image: '💳',
    description: 'ტიტანის ულიმიტო ბარათი და პერსონალური გლობალური კონსიერჟი 24/7.'
  },
  // --- VIP REGALIA ---
  {
    id: 'acc_golden_deagle',
    name: '24K მოოქროვილი Desert Eagle Trophy Stand',
    category: 'vip',
    price: 75000,
    respect: 320,
    bonusMultiplier: 1.06,
    image: '🔫',
    description: 'კოლექციური შედევრი კაბინეტის მაგიდისთვის. ძალაუფლების სიმბოლო.'
  },
  {
    id: 'acc_diamond_cane',
    name: 'ბრილიანტებით მოოჭვილი კვერთხი "Tbilisi Lord"',
    category: 'vip',
    price: 220000,
    respect: 750,
    bonusMultiplier: 1.12,
    image: '🪄',
    description: 'სინდიკატის უმაღლესი მბრძანებლის რეგალია. აბსოლუტური პატივისცემა.'
  },
  {
    id: 'acc_helicopter',
    name: 'Eurocopter EC130 VIP კერძო ვერტმფრენი',
    category: 'vip',
    price: 3800000,
    respect: 9200,
    bonusMultiplier: 1.35,
    image: '🚁',
    description: 'ქალაქის საცობების თავზე გადაფრენა საკუთარი პენტჰაუსის სახურავიდან.'
  }
];

export interface RankTitle {
  minLevel: number;
  title: string;
  badge: string;
  description: string;
  perk: string;
}

export const RANK_TITLES: RankTitle[] = [
  { minLevel: 1, title: 'ქუჩის დამწყები', badge: '🥉', description: 'ახალი ჩამოსული ქალაქში, ეძებს პირველ შესაძლებლობას.', perk: 'საბაზისო სტატუსი' },
  { minLevel: 5, title: 'Wolt-ის ტოპ კურიერი', badge: '🚲', description: 'იცის ქალაქის ყველა ჩიხი და ქუჩა.', perk: '+5% შემოსავალი სამუშაოებიდან' },
  { minLevel: 10, title: 'ავტო-დითეილერი & მექანიკოსი', badge: '🔧', description: 'იცის ძრავებისა და ტურბინების საიდუმლოებები.', perk: '+7% ხელფასი ავტო-სფეროში' },
  { minLevel: 15, title: 'ქალაქის მრბოლელი', badge: '🏎️', description: 'ღამის თბილისის გზების ოსტატი.', perk: '+8% ბონუსი ავია-სთარზე' },
  { minLevel: 22, title: 'VIP კლუბის რეზიდენტი', badge: '🎧', description: 'ღამის ცხოვრებისა და წვეულებების ცენტრი.', perk: '+10% რეპუტაციის ბონუსი' },
  { minLevel: 30, title: 'ჩრდილოვანი დილერი', badge: '🕶️', description: 'კონტრაქტებისა და სწრაფი ფულის ექსპერტი.', perk: '+12% კონტრაქტის მოგება' },
  { minLevel: 42, title: 'კრიპტო Scalper & ბროკერი', badge: '📈', description: 'წამებში ატარებს მილიონიან ტრანზაქციებს.', perk: '+14% სავაჭრო შემოსავალი' },
  { minLevel: 55, title: 'კომერციული ბიზნესმენი', badge: '💼', description: 'ფლობს შაურმებს და დითეილინგ ცენტრებს.', perk: '+15% პასიური ბიზნეს შემოსავალი' },
  { minLevel: 70, title: 'თხილის იმპერიის მმართველი', badge: '🌰', description: 'ავტომატიზირებული აგრო-ინდუსტრიის მაგნატი.', perk: '+18% აგრო-დივიდენდი' },
  { minLevel: 85, title: 'სინდიკატის კაპიტანი', badge: '🛡️', description: 'ქალაქის უბნებს აკონტროლებს.', perk: '+20% რეპუტაციის დაცვა' },
  { minLevel: 100, title: 'თბილისის მილიონერი', badge: '💎', description: 'ლუქს ვილები და სუპერქარების კოლექცია.', perk: '+22% ფასდაკლება გარაჟებზე' },
  { minLevel: 120, title: 'ღვინის მარნებისა და შატოს მფლობელი', badge: '🍷', description: 'საუკუნოვანი ტრადიციები და პრემიუმ ექსპორტი.', perk: '+25% პასიური რენტა' },
  { minLevel: 140, title: 'ოლიგარქი & მაგნატი', badge: '👑', description: 'მთელი უბნების ინფრასტრუქტურის მმართველი.', perk: '+28% აფგრეიდების დივიდენდი' },
  { minLevel: 165, title: 'კვანტური ტექ-მაგნატი', badge: '💻', description: 'სუპერკომპიუტერებისა და სატელიტების ქსელი.', perk: '+30% მაღალტექნოლოგიური მოგება' },
  { minLevel: 190, title: 'კრიპტო იმპერატორი', badge: '⚡', description: 'გლობალური ბირჟებისა და მაინერების მფლობელი.', perk: '+32% ყველა მოგებაზე' },
  { minLevel: 220, title: 'ქუჩის ლეგენდა (Street Legend)', badge: '🔥', description: 'მისი სახელი ყველას შიშსა და მოწიწებას ჰგვრის.', perk: '+35% პატივისცემის აურა' },
  { minLevel: 250, title: 'ქალაქის მაფიის ბოსი', badge: '🦁', description: 'არავინ ბედავს მისთვის გზის გადაჭრას.', perk: '+40% ქუჩის გავლენა' },
  { minLevel: 280, title: 'იმპერიის მბრძანებელი', badge: '🏛️', description: 'ფლობს ბანკებს, პორტებსა და მეგაპოლისს.', perk: '+45% სრული ეკონომიკური მონოპოლია' },
  { minLevel: 315, title: 'ჩრდილოვანი მმართველი (Illuminati)', badge: '👁️', description: 'კულისებიდან მართავს მთელ ქვეყანას.', perk: '+50% მაქსიმალური ძალაუფლება' },
  { minLevel: 350, title: 'ქალაქის ღმერთი (Master of RP)', badge: '✨', description: 'მიაღწია აბსოლუტურ მწვერვალს. ლეგენდა!', perk: 'ლეგენდარული უკვდავება' }
];

// Rich stylized photo avatar gallery for player customization
export const PHOTO_AVATAR_PRESETS = [
  {
    id: 'ph_boss_male',
    name: 'სინდიკატის ბოსი',
    category: 'მაფია & ძალაუფლება',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80'
  },
  {
    id: 'ph_lady_boss',
    name: 'VIP ელიტური ლედი',
    category: 'ფუფუნება',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'
  },
  {
    id: 'ph_racer',
    name: 'ქუჩის მრბოლელი',
    category: 'ავტოსპორტი',
    url: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80'
  },
  {
    id: 'ph_crypto_trader',
    name: 'კრიპტო მილიარდერი',
    category: 'ბიზნესი',
    url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80'
  },
  {
    id: 'ph_architect',
    name: 'დიზაინერი & არქიტექტორი',
    category: 'არტი',
    url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80'
  },
  {
    id: 'ph_hacker',
    name: 'კიბერ-ანალიტიკოსი',
    category: 'ტექნოლოგია',
    url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=300&q=80'
  },
  {
    id: 'ph_gentleman',
    name: 'არისტოკრატი ბანკირი',
    category: 'ფინანსები',
    url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=300&q=80'
  },
  {
    id: 'ph_model',
    name: 'Glamour & Showbiz',
    category: 'ფუფუნება',
    url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80'
  },
  {
    id: 'ph_pilot',
    name: 'პირადი ავიაკაპიტანი',
    category: 'ავიაცია',
    url: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80'
  },
  {
    id: 'ph_creative',
    name: 'ინტელექტუალი & პოეტი',
    category: 'სიმშვიდე',
    url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80'
  },
  {
    id: 'ph_stealth',
    name: 'ჩრდილოვანი აგენტი',
    category: 'შავი ბაზარი',
    url: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=300&q=80'
  },
  {
    id: 'ph_sheikh',
    name: 'ოქროს მაგნატი',
    category: 'უმაღლესი VIP',
    url: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80'
  }
];

export function getRankForLevel(level: number): RankTitle {
  for (let i = RANK_TITLES.length - 1; i >= 0; i--) {
    if (level >= RANK_TITLES[i].minLevel) {
      return RANK_TITLES[i];
    }
  }
  return RANK_TITLES[0];
}

// Calculate XP required for a level (1 to 350)
// Significantly more challenging and rewarding so players cannot boost easily
export function getXpRequiredForLevel(level: number): number {
  if (level <= 1) return 300;
  // Steep exponential growth curve
  return Math.floor(300 * Math.pow(level, 1.85));
}

// Calculate bonus money given upon reaching a level
export function getLevelUpBonus(level: number): number {
  return Math.floor(75 + level * 45 + Math.pow(level, 1.25) * 9);
}

// ==========================================
// RANK SHOP & CRYSTALS (PREMIUM RANKS)
// ==========================================
export interface PremiumRankInfo {
  id: 'red' | 'purple' | 'midnight_purple' | 'devil_red';
  name: string;
  nameGe: string;
  badge: string;
  color: string;
  textColor: string;
  bgGradient: string;
  borderColor: string;
  glowColor: string;
  priceCrystals: number;
  xpMultiplier: number;
  moneyMultiplier: number;
  description: string;
  perks: string[];
}

export const RANK_SHOP_ITEMS: PremiumRankInfo[] = [
  {
    id: 'red', name: 'Red Premium', nameGe: 'წითელი პრემიუმი', badge: '🔴 RED VIP',
    color: '#ef4444', textColor: 'text-red-400', bgGradient: 'from-red-950/80 via-red-900/40 to-slate-950',
    borderColor: 'border-red-500/60', glowColor: 'shadow-[0_0_25px_rgba(239,68,68,0.45)]',
    priceCrystals: 50, xpMultiplier: 2.0, moneyMultiplier: 1.2,
    description: 'წითელი სტატუსი: x2 XP და x1.2 ფულადი ჯილდო თამაშის შემოსავლებზე.',
    perks: ['⚡ x2 XP ყველა მოქმედებაზე', '💰 x1.2 ფულადი ჯილდო თამაშის შემოსავლებზე', '🔴 წითელი VIP ნიშანი პროფილსა და ჩატში', '👑 RP ქალაქის რეიტინგის სტატუსი']
  },
  {
    id: 'purple', name: 'Purple Premium', nameGe: 'იასამნისფერი პრემიუმი', badge: '🟣 PURPLE VIP',
    color: '#a855f7', textColor: 'text-purple-400', bgGradient: 'from-purple-950/80 via-purple-900/40 to-slate-950',
    borderColor: 'border-purple-500/60', glowColor: 'shadow-[0_0_30px_rgba(168,85,247,0.5)]',
    priceCrystals: 150, xpMultiplier: 3.0, moneyMultiplier: 1.5,
    description: 'იასამნისფერი სტატუსი: x3 XP და x1.5 ფულადი ჯილდო თამაშის შემოსავლებზე.',
    perks: ['⚡ x3 XP ყველა მოქმედებაზე', '💰 x1.5 ფულადი ჯილდო თამაშის შემოსავლებზე', '🟣 იასამნისფერი VIP ნიშანი პროფილსა და ჩატში', '💎 მაღალი სტატუსი Rank Shop-ში']
  },
  {
    id: 'midnight_purple', name: 'Midnight Purple', nameGe: 'Midnight Purple ელიტა', badge: '🌌 MIDNIGHT PURPLE',
    color: '#9333ea', textColor: 'text-fuchsia-400', bgGradient: 'from-[#1c0836] via-[#100424] to-[#04020a]',
    borderColor: 'border-fuchsia-500/80', glowColor: 'shadow-[0_0_40px_rgba(217,70,239,0.7)]',
    priceCrystals: 60000, xpMultiplier: 5.0, moneyMultiplier: 2.0,
    description: 'Midnight Purple: x5 XP და x2 ფულადი ჯილდო თამაშის შემოსავლებზე.',
    perks: ['⚡ x5 XP თამაშის შემოსავლებზე', '💰 x2 ფულადი ჯილდო თამაშის შემოსავლებზე', '🌌 Midnight Purple ანიმირებული ნიშანი', '✨ გამორჩეული პროფილის სტატუსი']
  },
  {
    id: 'devil_red', name: 'RedDevil', nameGe: 'RedDevil', badge: '😈 REDDEVIL',
    color: '#fb174f', textColor: 'text-rose-300', bgGradient: 'from-[#390612] via-[#190817] to-[#050b16]',
    borderColor: 'border-rose-400/80', glowColor: 'shadow-[0_0_48px_rgba(244,35,89,0.55)]',
    priceCrystals: 666666, xpMultiplier: 30.0, moneyMultiplier: 25.0,
    description: 'უმაღლესი RedDevil რანკი: x30 XP და x25 ფულადი ჯილდო თამაშის შემოსავლებზე.',
    perks: ['⚡ x30 XP თამაშის შემოსავლებზე', '💰 x25 ფულადი ჯილდო თამაშის შემოსავლებზე', '😈 RedDevil ანიმირებული ნიშანი პროფილსა და ჩატში', '📈 ვაჭრობის მოგებაც და ზარალიც x25-ზე ითვლება']
  }
];
// Crystal exchange rate: 10 Crystals = 5,000 GEL (500 GEL per crystal)
export const CRYSTAL_PRICE_GEL = 500;

// ==========================================
// MISSIONS SYSTEM (CHALLENGING CRYSTAL & CASH REWARDS)
// ==========================================
export interface MissionDef {
  id: string;
  title: string;
  description: string;
  icon: string;
  targetCount: number;
  rewardCash: number;
  rewardCrystals: number;
  unit: string;
  getProgress: (player: PlayerProfile, ownedCarsCount: number, ownedEstatesCount: number) => { current: number; completed: boolean };
}

export const GAME_MISSIONS: MissionDef[] = [
  {
    id: 'm_earn_50k',
    title: 'დამწყები მილიონერი',
    description: 'გამოიმუშავე ჯამურად მინიმუმ 50,000 ₾ ქალაქში',
    icon: '💰',
    targetCount: 50000,
    rewardCash: 1200,
    rewardCrystals: 5,
    unit: '₾',
    getProgress: (player) => ({
      current: Math.min(50000, player.stats.totalEarned),
      completed: player.stats.totalEarned >= 50000
    })
  },
  {
    id: 'm_avia_wins',
    title: 'ავიატორის ოსტატი',
    description: 'მოიგე მინიმუმ 15 რეისი ავიატორში',
    icon: '🚀',
    targetCount: 15,
    rewardCash: 1800,
    rewardCrystals: 8,
    unit: 'მოგება',
    getProgress: (player) => ({
      current: Math.min(15, player.stats.aviaWins),
      completed: player.stats.aviaWins >= 15
    })
  },
  {
    id: 'm_car_collector',
    title: 'ავტო-კოლექციონერი',
    description: 'შეიძინე მინიმუმ 3 ლუქს ავტომობილი გარაჟში',
    icon: '🏎️',
    targetCount: 3,
    rewardCash: 2500,
    rewardCrystals: 10,
    unit: 'მანქანა',
    getProgress: (_player, ownedCarsCount) => ({
      current: Math.min(3, ownedCarsCount),
      completed: ownedCarsCount >= 3
    })
  },
  {
    id: 'm_jobs_done',
    title: 'შრომისმოყვარე მოქალაქე',
    description: 'წარმატებით დაასრულე 25 სამუშაო დავალება',
    icon: '💼',
    targetCount: 25,
    rewardCash: 2200,
    rewardCrystals: 6,
    unit: 'დავალება',
    getProgress: (player) => ({
      current: Math.min(25, player.stats.jobsCompleted),
      completed: player.stats.jobsCompleted >= 25
    })
  },
  {
    id: 'm_estates_owned',
    title: 'უძრავი ქონების მაგნატი',
    description: 'შეიძინე მინიმუმ 2 პრესტიჟული უძრავი ქონება',
    icon: '🏰',
    targetCount: 2,
    rewardCash: 8000,
    rewardCrystals: 20,
    unit: 'ქონება',
    getProgress: (_player, _cars, ownedEstatesCount) => ({
      current: Math.min(2, ownedEstatesCount),
      completed: ownedEstatesCount >= 2
    })
  },
  {
    id: 'm_avia_high_mult',
    title: 'სტრატოსფეროს მმართველი',
    description: 'დაიჭირე მინიმუმ 10.0x კოეფიციენტი ავიატორში',
    icon: '⚡',
    targetCount: 10,
    rewardCash: 3000,
    rewardCrystals: 18,
    unit: 'x',
    getProgress: (player) => ({
      current: Math.min(10, Number(player.stats.biggestMultiplier.toFixed(1))),
      completed: player.stats.biggestMultiplier >= 10.0
    })
  },
  {
    id: 'm_reach_level_25',
    title: 'ქალაქის ავტორიტეტი',
    description: 'მიაღწიე 25-ე დონეს (Level 25) RP სამყაროში',
    icon: '🎖️',
    targetCount: 25,
    rewardCash: 10000,
    rewardCrystals: 25,
    unit: 'დონე',
    getProgress: (player) => ({
      current: Math.min(25, player.level),
      completed: player.level >= 25
    })
  },
  {
    id: 'm_earn_million',
    title: 'მილიარდერთა კლუბი',
    description: 'გამოიმუშავე ჯამურად 1,000,000 ₾ კაპიტალი',
    icon: '👑',
    targetCount: 1000000,
    rewardCash: 15000,
    rewardCrystals: 50,
    unit: '₾',
    getProgress: (player) => ({
      current: Math.min(1000000, player.stats.totalEarned),
      completed: player.stats.totalEarned >= 1000000
    })
  },
  {
    id: 'm_jobs_60', title: 'ცვლის უფროსი', description: 'დაასრულე 60 სამუშაო დავალება', icon: '🧰',
    targetCount: 60, rewardCash: 7000, rewardCrystals: 12, unit: 'დავალება',
    getProgress: (player) => ({ current: Math.min(60, player.stats.jobsCompleted), completed: player.stats.jobsCompleted >= 60 })
  },
  {
    id: 'm_earn_250k', title: 'სანდო პროფესიონალი', description: 'გამოიმუშავე ჯამურად 250,000 ₾', icon: '📈',
    targetCount: 250000, rewardCash: 5000, rewardCrystals: 10, unit: '₾',
    getProgress: (player) => ({ current: Math.min(250000, player.stats.totalEarned), completed: player.stats.totalEarned >= 250000 })
  },
  {
    id: 'm_car_collector_6', title: 'ავტოპარკის მფლობელი', description: 'შეაგროვე 6 ავტომობილი', icon: '🚘',
    targetCount: 6, rewardCash: 9000, rewardCrystals: 15, unit: 'მანქანა',
    getProgress: (_player, ownedCarsCount) => ({ current: Math.min(6, ownedCarsCount), completed: ownedCarsCount >= 6 })
  },
  {
    id: 'm_level_10', title: 'ქალაქის ნაცნობი სახე', description: 'მიაღწიე მე-10 დონეს', icon: '🏅',
    targetCount: 10, rewardCash: 3500, rewardCrystals: 8, unit: 'დონე',
    getProgress: (player) => ({ current: Math.min(10, player.level), completed: player.level >= 10 })
  },
  {
    id: 'm_avia_50', title: 'ავიატორის პილოტი', description: 'მოიგე 50 რეისი ავიატორში', icon: '🛩️',
    targetCount: 50, rewardCash: 5000, rewardCrystals: 10, unit: 'მოგება',
    getProgress: (player) => ({ current: Math.min(50, player.stats.aviaWins), completed: player.stats.aviaWins >= 50 })
  }
];

// ==========================================
// CAR TUNING & CUSTOM WORKSHOP PARTS CATALOG
// ==========================================

export const TUNING_PARTS: TuningPart[] = [
  // Colors
  { id: 'tune_color_midnight', name: 'Midnight Purple Metallic', category: 'color', retailPrice: 25000, wholesalePrice: 12000, hpBonus: 0, speedBonusKm: 0, respectBonus: 35, description: 'ღრმა იასამნისფერი ქამელეონი ნანო-ლაქით.', colorHex: '#4c1d95' },
  { id: 'tune_color_nardo', name: 'Frozen Nardo Grey', category: 'color', retailPrice: 18000, wholesalePrice: 8500, hpBonus: 0, speedBonusKm: 0, respectBonus: 25, description: 'მქრქალი გერმანული სპორტული ნაცრისფერი.', colorHex: '#64748b' },
  { id: 'tune_color_black', name: 'Ultra Deep Obsidian Black', category: 'color', retailPrice: 20000, wholesalePrice: 9500, hpBonus: 0, speedBonusKm: 0, respectBonus: 30, description: 'შთანმთქმელი ღრმა შავი იმიჯი.', colorHex: '#0a0a0c' },
  { id: 'tune_color_acid', name: 'Acid Neon Lime Green', category: 'color', retailPrice: 22000, wholesalePrice: 10500, hpBonus: 0, speedBonusKm: 0, respectBonus: 30, description: 'აგრესიული ტრეკის საღებავი.', colorHex: '#84cc16' },
  { id: 'tune_color_rosso', name: 'Rosso Corsa Racing Red', category: 'color', retailPrice: 24000, wholesalePrice: 11500, hpBonus: 0, speedBonusKm: 0, respectBonus: 32, description: 'იტალიური ლეგენდარული წითელი ფერი.', colorHex: '#dc2626' },

  // Stages
  { id: 'tune_stage_1', name: 'Stage 1 ECU Dynamic Remap', category: 'stage', retailPrice: 45000, wholesalePrice: 22000, hpBonus: 45, speedBonusKm: 15, respectBonus: 50, description: 'პროგრამული დაჩიპვა: +45 ცხ.ძ, +15 კმ/სთ.' },
  { id: 'tune_stage_2', name: 'Stage 2 Aggressive Race Map', category: 'stage', retailPrice: 95000, wholesalePrice: 48000, hpBonus: 95, speedBonusKm: 30, respectBonus: 110, description: 'ინტერქულერი და აგრესიული ბარები: +95 ცხ.ძ, +30 კმ/სთ.' },
  { id: 'tune_stage_3', name: 'Stage 3 Competition Pop & Bang Tune', category: 'stage', retailPrice: 195000, wholesalePrice: 98000, hpBonus: 180, speedBonusKm: 55, respectBonus: 240, description: 'უმაღლესი სარბოლო ჩიპი: +180 ცხ.ძ, +55 კმ/სთ.' },

  // Turbos
  { id: 'tune_turbo_twin', name: 'Twin-Scroll High Performance Turbo', category: 'turbo', retailPrice: 65000, wholesalePrice: 32000, hpBonus: 75, speedBonusKm: 22, respectBonus: 70, description: 'ორმაგი ბუსტი მყისიერი აჩქარებისთვის: +75 ცხ.ძ.' },
  { id: 'tune_turbo_garrett', name: 'Garrett GT45 Hybrid Big Turbo', category: 'turbo', retailPrice: 135000, wholesalePrice: 68000, hpBonus: 140, speedBonusKm: 42, respectBonus: 160, description: 'გიგანტური ჰიბრიდული ტურბინა: +140 ცხ.ძ.' },
  { id: 'tune_turbo_whipple', name: 'Whipple Twin-Screw Supercharger', category: 'turbo', retailPrice: 260000, wholesalePrice: 130000, hpBonus: 220, speedBonusKm: 65, respectBonus: 320, description: 'მექანიკური დამბერი მძლავრი ძრავისთვის: +220 ცხ.ძ!' },

  // Intakes
  { id: 'tune_intake_kn', name: 'K&N High-Flow Carbon Air Intake', category: 'intake', retailPrice: 15000, wholesalePrice: 7000, hpBonus: 20, speedBonusKm: 6, respectBonus: 20, description: 'ნახშირბადის სპორტული ფილტრი: +20 ცხ.ძ.' },
  { id: 'tune_intake_eventuri', name: 'Eventuri Dual Carbon Cone Air System', category: 'intake', retailPrice: 35000, wholesalePrice: 17000, hpBonus: 45, speedBonusKm: 14, respectBonus: 45, description: 'აეროდინამიკური ჰაერის შემწოვი: +45 ცხ.ძ.' },

  // Exhausts
  { id: 'tune_exhaust_straight', name: 'Catless Straight Pipe Downpipe', category: 'exhaust', retailPrice: 42000, wholesalePrice: 20000, hpBonus: 40, speedBonusKm: 12, respectBonus: 45, description: 'ცეცხლის მსროლელი პირდაპირი მაყუჩი: +40 ცხ.ძ.' },
  { id: 'tune_exhaust_akrapovic', name: 'Akrapovič Evolution Titanium Full Exhaust', category: 'exhaust', retailPrice: 90000, wholesalePrice: 45000, hpBonus: 70, speedBonusKm: 24, respectBonus: 95, description: 'ტიტანის ეგზოტიკური ხმა და წონის შემცირება: +70 ცხ.ძ.' },

  // Suspension & Brakes
  { id: 'tune_susp_kw', name: 'KW V3 Coilover Track Suspension', category: 'suspension', retailPrice: 48000, wholesalePrice: 24000, hpBonus: 25, speedBonusKm: 10, respectBonus: 50, description: 'დადაბლებული კლირენსი და უნაკლო მოჭიდება მოსახვევებში.' },
  { id: 'tune_brakes_brembo', name: 'Brembo Carbon-Ceramic 6-Piston Kit', category: 'suspension', retailPrice: 110000, wholesalePrice: 55000, hpBonus: 35, speedBonusKm: 15, respectBonus: 120, description: 'კარბონ-კერამიკული მუხრუჭები ექსტრემალური შეჩერებისთვის.' }
];

// Helper to determine stars granted per mission claimed
export const getStarsForPlayer = (premiumRank?: 'none' | 'red' | 'purple' | 'midnight_purple' | 'devil_red'): number => {
  if (premiumRank === 'purple' || premiumRank === 'midnight_purple') {
    return Math.random() < 0.5 ? 6 : 7;
  }
  if (premiumRank === 'red') {
    return Math.random() < 0.5 ? 3 : 4;
  }
  return Math.random() < 0.5 ? 1 : 2;
};

// ==========================================
// STAR MISSIONS (DEDICATED TO EARNING STARS)
// ==========================================
export interface StarMissionDef {
  id: string;
  title: string;
  description: string;
  icon: string;
  targetCount: number;
  rewardCash: number;
  unit: string;
  getProgress: (player: PlayerProfile, ownedCarsCount: number, ownedEstatesCount: number) => { current: number; completed: boolean };
}

export const STAR_MISSIONS: StarMissionDef[] = [
  {
    id: 'sm_1_jobs',
    title: 'ქალაქის მუშა ხელი',
    description: 'შეასრულე 10 სამუშაო ცვლა',
    icon: '💼',
    targetCount: 10,
    rewardCash: 15000,
    unit: 'ცვლა',
    getProgress: (p) => ({ current: Math.min(10, p.stats.jobsCompleted), completed: p.stats.jobsCompleted >= 10 })
  },
  {
    id: 'sm_2_avia',
    title: 'სწრაფი აფრენა',
    description: 'მოიგე 5 რეისი ავია-სთარში',
    icon: '🚀',
    targetCount: 5,
    rewardCash: 20000,
    unit: 'მოგება',
    getProgress: (p) => ({ current: Math.min(5, p.stats.aviaWins), completed: p.stats.aviaWins >= 5 })
  },
  {
    id: 'sm_3_contracts',
    title: 'ბიზნეს პარტნიორი',
    description: 'დახურე 3 ბიზნეს კონტრაქტი',
    icon: '📜',
    targetCount: 3,
    rewardCash: 35000,
    unit: 'კონტრაქტი',
    getProgress: (p) => ({ current: Math.min(3, p.stats.contractsDone), completed: p.stats.contractsDone >= 3 })
  },
  {
    id: 'sm_4_earn_cash',
    title: 'ფულის ნაკადი',
    description: 'გამოიმუშავე ჯამურად 150,000 ₾',
    icon: '💵',
    targetCount: 150000,
    rewardCash: 50000,
    unit: '₾',
    getProgress: (p) => ({ current: Math.min(150000, p.stats.totalEarned), completed: p.stats.totalEarned >= 150000 })
  },
  {
    id: 'sm_5_safes',
    title: 'სეიფების ჩუმი ოსტატი',
    description: 'გატეხე 3 სეიფი კაზინოში',
    icon: '🔓',
    targetCount: 3,
    rewardCash: 30000,
    unit: 'სეიფი',
    getProgress: (p) => ({ current: Math.min(3, p.stats.safesCracked), completed: p.stats.safesCracked >= 3 })
  },
  {
    id: 'sm_6_level_10',
    title: '10-ე დონის აღნიშვნა',
    description: 'მიაღწიე მინიმუმ მე-10 დონეს',
    icon: '⭐',
    targetCount: 10,
    rewardCash: 40000,
    unit: 'დონე',
    getProgress: (p) => ({ current: Math.min(10, p.level), completed: p.level >= 10 })
  },
  {
    id: 'sm_7_car_owner',
    title: 'ავტომფლობელი',
    description: 'ფლობდე მინიმუმ 2 ავტომობილს გარაჟში',
    icon: '🏎️',
    targetCount: 2,
    rewardCash: 45000,
    unit: 'მანქანა',
    getProgress: (_p, cars) => ({ current: Math.min(2, cars), completed: cars >= 2 })
  },
  {
    id: 'sm_8_avia_mult',
    title: 'მაღალი სიჩქარე',
    description: 'დააფიქსირე მინიმუმ 5.0x კოეფიციენტი',
    icon: '⚡',
    targetCount: 5,
    rewardCash: 35000,
    unit: 'x',
    getProgress: (p) => ({ current: Math.min(5, Math.floor(p.stats.biggestMultiplier)), completed: p.stats.biggestMultiplier >= 5.0 })
  },
  {
    id: 'sm_9_wheel',
    title: 'იღბლიანი დატრიალება',
    description: 'დაატრიალე იღბლის ბორბალი 10-ჯერ',
    icon: '🎡',
    targetCount: 10,
    rewardCash: 25000,
    unit: 'სპინი',
    getProgress: (p) => ({ current: Math.min(10, p.stats.wheelSpins), completed: p.stats.wheelSpins >= 10 })
  },
  {
    id: 'sm_10_estates',
    title: 'სახლის მფლობელი',
    description: 'შეიძინე მინიმუმ 1 უძრავი ქონება',
    icon: '🏡',
    targetCount: 1,
    rewardCash: 60000,
    unit: 'ქონება',
    getProgress: (_p, _c, estates) => ({ current: Math.min(1, estates), completed: estates >= 1 })
  },
  {
    id: 'sm_11_tuning_owner',
    title: 'ტუნინგის ექსპერტი',
    description: 'შეიძინე "შენი საკუთარი ტიუნინგი" ან გააუმჯობესე მანქანა',
    icon: '🔧',
    targetCount: 1,
    rewardCash: 100000,
    unit: 'ტიუნინგი',
    getProgress: (p) => ({ current: p.hasCustomTuningWorkshop ? 1 : 0, completed: !!p.hasCustomTuningWorkshop })
  },
  {
    id: 'sm_12_reputation',
    title: 'ქალაქის გავლენა',
    description: 'დააგროვე 200 RP რეპუტაცია',
    icon: '👑',
    targetCount: 200,
    rewardCash: 80000,
    unit: 'RP',
    getProgress: (p) => ({ current: Math.min(200, p.reputation), completed: p.reputation >= 200 })
  }
];

// ==========================================
// 50 TIERS STAR PASS (500 STARS TOTAL TO COMPLETE)
// ==========================================
// T1: 10, T2: 30, T3: 55, T4: 70 ... T50: 500
export const STAR_PASS_TIERS: StarPassTier[] = [
  { tier: 1, requiredStars: 10, freeReward: { type: 'cash', amount: 15000, title: '15,000 ₾ სტარტერ ბონუსი', icon: '💵' }, plusReward: { type: 'cash', amount: 80000, title: '80,000 ₾ VIP ქეში', description: 'VIP საწყისი კაპიტალი', icon: '💰' } },
  { tier: 2, requiredStars: 30, freeReward: { type: 'reputation', amount: 20, title: '+20 RP რეპუტაცია', icon: '🛡️' }, plusReward: { type: 'crystals', amount: 25, title: '25 💎 კრისტალები', description: 'პრემიუმ კრისტალების პაკეტი', icon: '💎' } },
  { tier: 3, requiredStars: 55, freeReward: { type: 'cash', amount: 25000, title: '25,000 ₾ ნაღდი ფული', icon: '💵' }, plusReward: { type: 'cash', amount: 120000, title: '120,000 ₾ VIP ქეში', description: 'სოლიდური შემოსავალი', icon: '💰' } },
  { tier: 4, requiredStars: 70, freeReward: { type: 'crystals', amount: 5, title: '5 💎 კრისტალები', icon: '💎' }, plusReward: { type: 'tuning_kit', amount: 1, title: 'Stage 1 ECU ჩიპ-პაკეტი', description: 'უფასო Stage 1 ნაწილი საწყობში', icon: '⚡' } },
  { tier: 5, requiredStars: 85, freeReward: { type: 'xp', amount: 250, title: '+250 XP გამოცდილება', icon: '⭐' }, plusReward: { type: 'cash', amount: 160000, title: '160,000 ₾ VIP ქეში', description: 'ფინანსური ბუსტი', icon: '💰' } },
  { tier: 6, requiredStars: 100, freeReward: { type: 'cash', amount: 35000, title: '35,000 ₾ ნაღდი ფული', icon: '💵' }, plusReward: { type: 'crystals', amount: 40, title: '40 💎 კრისტალები', description: 'კრისტალების მარაგი', icon: '💎' } },
  { tier: 7, requiredStars: 115, freeReward: { type: 'reputation', amount: 35, title: '+35 RP რეპუტაცია', icon: '🛡️' }, plusReward: { type: 'tuning_kit', amount: 1, title: 'Twin-Scroll Turbo ნაწილი', description: 'უფასო ტურბო შენს გარაჟში', icon: '🌀' } },
  { tier: 8, requiredStars: 130, freeReward: { type: 'cash', amount: 45000, title: '45,000 ₾ ნაღდი ფული', icon: '💵' }, plusReward: { type: 'cash', amount: 220000, title: '220,000 ₾ VIP ქეში', description: 'მსხვილი ინვესტიცია', icon: '💰' } },
  { tier: 9, requiredStars: 145, freeReward: { type: 'crystals', amount: 8, title: '8 💎 კრისტალები', icon: '💎' }, plusReward: { type: 'crystals', amount: 60, title: '60 💎 კრისტალები', description: 'VIP კრისტალების წვიმა', icon: '💎' } },
  {
    tier: 10,
    requiredStars: 160,
    freeReward: { type: 'cash', amount: 60000, title: '60,000 ₾ ნაღდი ფული', icon: '💵' },
    plusReward: {
      type: 'car',
      item: { id: 'car_m4_csl_pass', name: 'BMW M4 CSL (Star Pass Edition)', brand: 'bmw', price: 480000, respect: 650, bonusMultiplier: 1.45, speed: '325 კმ/სთ (550 ცხ.ძ)', color: '#334155', image: '🏎️' },
      title: 'BMW M4 CSL (Star Pass Edition)',
      description: 'ექსკლუზიური 550 ცხ.ძ-იანი ლეგენდა Star Pass-ის 10-ე Tier-ზე!',
      icon: '🏎️'
    }
  },
  { tier: 11, requiredStars: 175, freeReward: { type: 'xp', amount: 400, title: '+400 XP გამოცდილება', icon: '⭐' }, plusReward: { type: 'cash', amount: 260000, title: '260,000 ₾ VIP ქეში', description: 'მაღალი დონის შემოსავალი', icon: '💰' } },
  { tier: 12, requiredStars: 190, freeReward: { type: 'cash', amount: 70000, title: '70,000 ₾ ნაღდი ფული', icon: '💵' }, plusReward: { type: 'tuning_kit', amount: 1, title: 'Akrapovič Titanium გამოსაბოლქვი', description: 'ტიტანის მაყუჩის ნაწილი', icon: '🔥' } },
  { tier: 13, requiredStars: 205, freeReward: { type: 'crystals', amount: 10, title: '10 💎 კრისტალები', icon: '💎' }, plusReward: { type: 'cash', amount: 300000, title: '300,000 ₾ VIP ქეში', description: 'სინდიკატის ჰონორარი', icon: '💰' } },
  { tier: 14, requiredStars: 220, freeReward: { type: 'reputation', amount: 50, title: '+50 RP რეპუტაცია', icon: '🛡️' }, plusReward: { type: 'crystals', amount: 75, title: '75 💎 კრისტალები', description: 'პრემიუმ ძვირფასეულობა', icon: '💎' } },
  { tier: 15, requiredStars: 235, freeReward: { type: 'cash', amount: 85000, title: '85,000 ₾ ნაღდი ფული', icon: '💵' }, plusReward: { type: 'cash', amount: 350000, title: '350,000 ₾ VIP ქეში', description: 'კაპიტალის ზრდა', icon: '💰' } },
  { tier: 16, requiredStars: 250, freeReward: { type: 'xp', amount: 600, title: '+600 XP გამოცდილება', icon: '⭐' }, plusReward: { type: 'tuning_kit', amount: 1, title: 'Stage 2 ECU Pro Map', description: 'უფასო Stage 2 ნაწილი', icon: '⚡' } },
  { tier: 17, requiredStars: 265, freeReward: { type: 'crystals', amount: 12, title: '12 💎 კრისტალები', icon: '💎' }, plusReward: { type: 'cash', amount: 400000, title: '400,000 ₾ VIP ქეში', description: 'ელიტური მოგება', icon: '💰' } },
  { tier: 18, requiredStars: 275, freeReward: { type: 'cash', amount: 95000, title: '95,000 ₾ ნაღდი ფული', icon: '💵' }, plusReward: { type: 'crystals', amount: 90, title: '90 💎 კრისტალები', description: 'კრისტალების საგანძური', icon: '💎' } },
  { tier: 19, requiredStars: 285, freeReward: { type: 'reputation', amount: 60, title: '+60 RP რეპუტაცია', icon: '🛡️' }, plusReward: { type: 'tuning_kit', amount: 1, title: 'Brembo Carbon-Ceramic Kit', description: 'სარბოლო სამუხრუჭე სისტემა', icon: '🛑' } },
  { tier: 20, requiredStars: 295, freeReward: { type: 'cash', amount: 110000, title: '110,000 ₾ ნაღდი ფული', icon: '💵' }, plusReward: { type: 'cash', amount: 500000, title: '500,000 ₾ ნახევარი მილიონი', description: 'კოლოსალური ფულადი ჯილდო', icon: '💰' } },
  { tier: 21, requiredStars: 305, freeReward: { type: 'crystals', amount: 15, title: '15 💎 კრისტალები', icon: '💎' }, plusReward: { type: 'crystals', amount: 100, title: '100 💎 კრისტალები', description: '100 ძვირფასი ქვა', icon: '💎' } },
  { tier: 22, requiredStars: 315, freeReward: { type: 'xp', amount: 800, title: '+800 XP გამოცდილება', icon: '⭐' }, plusReward: { type: 'cash', amount: 550000, title: '550,000 ₾ VIP ქეში', description: 'ბიზნეს დივიდენდი', icon: '💰' } },
  { tier: 23, requiredStars: 325, freeReward: { type: 'cash', amount: 125000, title: '125,000 ₾ ნაღდი ფული', icon: '💵' }, plusReward: { type: 'tuning_kit', amount: 1, title: 'Garrett GT45 Big Turbo', description: 'ჰიბრიდული გიგანტური ტურბო', icon: '🌀' } },
  { tier: 24, requiredStars: 335, freeReward: { type: 'reputation', amount: 75, title: '+75 RP რეპუტაცია', icon: '🛡️' }, plusReward: { type: 'cash', amount: 650000, title: '650,000 ₾ VIP ქეში', description: 'ოლიგარქიული ბონუსი', icon: '💰' } },
  {
    tier: 25,
    requiredStars: 350,
    freeReward: { type: 'cash', amount: 150000, title: '150,000 ₾ ნაღდი ფული', icon: '💵' },
    plusReward: {
      type: 'estate',
      item: { id: 'est_lagodekhi_reserve', name: 'სახლი ლაგოდეხის ნაკრძალში', location: 'ლაგოდეხის დაცული ტერიტორია', price: 1850000, respect: 1600, passiveRentPerSec: 280, description: 'ელიტური ეკო-რეზიდენცია მთის ძირას და პირად ნაკრძალში. Star Pass Tier 25-ის უნიკალური პრიზი.' },
      title: '🏡 სახლი ლაგოდეხის ნაკრძალში',
      description: 'უნიკალური ელიტური რეზიდენცია ალპურ ნაკრძალში, +280 ₾/წმ პასიური შემოსავლით!',
      icon: '🏡'
    }
  },
  { tier: 26, requiredStars: 360, freeReward: { type: 'crystals', amount: 18, title: '18 💎 კრისტალები', icon: '💎' }, plusReward: { type: 'cash', amount: 700000, title: '700,000 ₾ VIP ქეში', description: 'ფინანსური მაგნატი', icon: '💰' } },
  { tier: 27, requiredStars: 370, freeReward: { type: 'xp', amount: 1000, title: '+1000 XP გამოცდილება', icon: '⭐' }, plusReward: { type: 'crystals', amount: 120, title: '120 💎 კრისტალები', description: 'კრისტალების მთები', icon: '💎' } },
  { tier: 28, requiredStars: 380, freeReward: { type: 'cash', amount: 175000, title: '175,000 ₾ ნაღდი ფული', icon: '💵' }, plusReward: { type: 'tuning_kit', amount: 1, title: 'KW V3 Track Coilovers', description: 'სპორტული დაკიდების სისტემა', icon: '🔩' } },
  { tier: 29, requiredStars: 390, freeReward: { type: 'reputation', amount: 90, title: '+90 RP რეპუტაცია', icon: '🛡️' }, plusReward: { type: 'cash', amount: 800000, title: '800,000 ₾ VIP ქეში', description: 'ქალაქის მმართველი', icon: '💰' } },
  { tier: 30, requiredStars: 400, freeReward: { type: 'cash', amount: 200000, title: '200,000 ₾ ნაღდი ფული', icon: '💵' }, plusReward: { type: 'crystals', amount: 150, title: '150 💎 კრისტალები', description: 'VIP სუპერ-პაკეტი', icon: '💎' } },
  { tier: 31, requiredStars: 410, freeReward: { type: 'crystals', amount: 20, title: '20 💎 კრისტალები', icon: '💎' }, plusReward: { type: 'cash', amount: 900000, title: '900,000 ₾ VIP ქეში', description: 'თითქმის მილიონი', icon: '💰' } },
  { tier: 32, requiredStars: 418, freeReward: { type: 'xp', amount: 1200, title: '+1200 XP გამოცდილება', icon: '⭐' }, plusReward: { type: 'tuning_kit', amount: 1, title: 'Stage 3 Competition Tune', description: 'უმაღლესი სთეიჯის ჩიპი', icon: '⚡' } },
  { tier: 33, requiredStars: 426, freeReward: { type: 'cash', amount: 220000, title: '220,000 ₾ ნაღდი ფული', icon: '💵' }, plusReward: { type: 'cash', amount: 1000000, title: '1,000,000 ₾ მთელი მილიონი', description: '1 მილიონი ლარი ბალანსზე!', icon: '💰' } },
  { tier: 34, requiredStars: 434, freeReward: { type: 'reputation', amount: 110, title: '+110 RP რეპუტაცია', icon: '🛡️' }, plusReward: { type: 'crystals', amount: 180, title: '180 💎 კრისტალები', description: 'ძვირფასი კაპიტალი', icon: '💎' } },
  {
    tier: 35,
    requiredStars: 442,
    freeReward: { type: 'cash', amount: 250000, title: '250,000 ₾ ნაღდი ფული', icon: '💵' },
    plusReward: {
      type: 'car',
      item: { id: 'car_gt3rs_pass', name: 'Porsche 911 GT3 RS Clubsport (Star Pass Edition)', brand: 'supercars', price: 950000, respect: 1250, bonusMultiplier: 1.85, speed: '345 კმ/სთ (525 ცხ.ძ)', color: '#84cc16', image: '🚀' },
      title: 'Porsche 911 GT3 RS Clubsport',
      description: 'ლეგენდარული სუპერქარი 345 კმ/სთ სიჩქარით და აერო-პაკეტით!',
      icon: '🚀'
    }
  },
  { tier: 36, requiredStars: 450, freeReward: { type: 'crystals', amount: 25, title: '25 💎 კრისტალები', icon: '💎' }, plusReward: { type: 'cash', amount: 1150000, title: '1,150,000 ₾ VIP ქეში', description: 'სუპერ მოგება', icon: '💰' } },
  { tier: 37, requiredStars: 456, freeReward: { type: 'xp', amount: 1500, title: '+1500 XP გამოცდილება', icon: '⭐' }, plusReward: { type: 'tuning_kit', amount: 1, title: 'Whipple Twin-Screw Supercharger', description: 'მძლავრი სუპერჩარჯერი', icon: '🌪️' } },
  { tier: 38, requiredStars: 462, freeReward: { type: 'cash', amount: 280000, title: '280,000 ₾ ნაღდი ფული', icon: '💵' }, plusReward: { type: 'crystals', amount: 200, title: '200 💎 კრისტალები', description: 'სამეფო კრისტალები', icon: '💎' } },
  { tier: 39, requiredStars: 468, freeReward: { type: 'reputation', amount: 130, title: '+130 RP რეპუტაცია', icon: '🛡️' }, plusReward: { type: 'cash', amount: 1300000, title: '1,300,000 ₾ VIP ქეში', description: 'დიდოსტატის ბონუსი', icon: '💰' } },
  { tier: 40, requiredStars: 474, freeReward: { type: 'cash', amount: 300000, title: '300,000 ₾ ნაღდი ფული', icon: '💵' }, plusReward: { type: 'crystals', amount: 220, title: '220 💎 კრისტალები', description: 'კრისტალების ზღვა', icon: '💎' } },
  { tier: 41, requiredStars: 480, freeReward: { type: 'crystals', amount: 30, title: '30 💎 კრისტალები', icon: '💎' }, plusReward: { type: 'cash', amount: 1500000, title: '1,500,000 ₾ VIP ქეში', description: '1.5 მილიონი ლარი', icon: '💰' } },
  { tier: 42, requiredStars: 484, freeReward: { type: 'xp', amount: 2000, title: '+2000 XP გამოცდილება', icon: '⭐' }, plusReward: { type: 'tuning_kit', amount: 1, title: 'Eventuri Dual Carbon Intake', description: 'კარბონის საუკეთესო სისტემა', icon: '💨' } },
  { tier: 43, requiredStars: 488, freeReward: { type: 'cash', amount: 350000, title: '350,000 ₾ ნაღდი ფული', icon: '💵' }, plusReward: { type: 'crystals', amount: 250, title: '250 💎 კრისტალები', description: 'ელიტური კრისტალები', icon: '💎' } },
  { tier: 44, requiredStars: 492, freeReward: { type: 'reputation', amount: 160, title: '+160 RP რეპუტაცია', icon: '🛡️' }, plusReward: { type: 'cash', amount: 1750000, title: '1,750,000 ₾ VIP ქეში', description: 'მსხვილი კაპიტალი', icon: '💰' } },
  { tier: 45, requiredStars: 495, freeReward: { type: 'crystals', amount: 35, title: '35 💎 კრისტალები', icon: '💎' }, plusReward: { type: 'crystals', amount: 300, title: '300 💎 კრისტალები', description: 'სუპერ კრისტალები', icon: '💎' } },
  { tier: 46, requiredStars: 496, freeReward: { type: 'xp', amount: 2500, title: '+2500 XP გამოცდილება', icon: '⭐' }, plusReward: { type: 'cash', amount: 2000000, title: '2,000,000 ₾ 2 მილიონი!', description: '2 მილიონი ნაღდი ფული!', icon: '💰' } },
  { tier: 47, requiredStars: 497, freeReward: { type: 'reputation', amount: 200, title: '+200 RP რეპუტაცია', icon: '🛡️' }, plusReward: { type: 'crystals', amount: 350, title: '350 💎 კრისტალები', description: 'უმაღლესი კრისტალები', icon: '💎' } },
  { tier: 48, requiredStars: 498, freeReward: { type: 'cash', amount: 400000, title: '400,000 ₾ ნაღდი ფული', icon: '💵' }, plusReward: { type: 'cash', amount: 2500000, title: '2,500,000 ₾ VIP ქეში', description: 'ფინანსური იმპერია', icon: '💰' } },
  { tier: 49, requiredStars: 499, freeReward: { type: 'crystals', amount: 50, title: '50 💎 კრისტალები', icon: '💎' }, plusReward: { type: 'crystals', amount: 500, title: '500 💎 კრისტალები', description: 'მეგა კრისტალების ყუთი', icon: '💎' } },
  {
    tier: 50,
    requiredStars: 500,
    freeReward: { type: 'cash', amount: 600000, title: '600,000 ₾ საზეიმო ფინალი', icon: '👑' },
    plusReward: {
      type: 'estate',
      item: { id: 'est_kutaisi_palace', name: 'სახლი ქუთაისში', location: 'ქუთაისი, სამეფო რეზიდენცია', price: 4800000, respect: 4500, passiveRentPerSec: 850, description: 'სამეფო სასახლე პანორამული ხედით, მარმარილოს აუზით და პირადი პარკით. Star Pass Tier 50-ის უმაღლესი პრიზი.' },
      title: '🏰 სახლი ქუთაისში (სამეფო სასახლე)',
      description: 'Star Pass-ის უმაღლესი ფინალური ჯილდო: 4.8M ₾-იანი სასახლე ქუთაისში, +850 ₾/წმ პასიური შემოსავლით!',
      icon: '🏰'
    }
  }
];











import type { Accessory, Business, Car, Contract, Estate, Garage, Job, PlayerProfile, Security, StarPassTier, TuningPart, Upgrader } from '../types/game';

